! function() {
    "use strict";
    let s = null;
    const c = ["debug", "info", "warn", "error"];
    let l = c.reduce((e, a, d) => (e[a] = function() {
        var e = "debug" === a ? "log" : a;
        if (s && console && "function" == typeof console[e]) {
            var t = c.indexOf(s.toString().toLocaleLowerCase());
            if (!0 === s || -1 < t && t <= d) {
                for (var n = arguments.length, i = new Array(n), o = 0; o < n; o++) i[o] = arguments[o];
                const [d, ...r] = [...i];
                console[e](a.toUpperCase() + " - (TTD) " + d, ...r)
            }
        }
    }, e), {});

    function e(e) {
        s = e
    }
    let u = null,
        o = {},
        p = {},
        f = {},
        v = {};

    function t(e) {
        var t = e[0],
            e = e[1];
        if ("setIdentifier" !== t) throw "method not implemented";
        i(e)
    }

    function r(e, t) {
        n(t),
            function t(e, i) {
                let o = b(e, i, u.triggerElements);
                let n = b(e, i, u.cssSelectors);
                p[i] = p[i] || [];
                f[i] = f[i] || [];
                v[i] = v[i] || [];
                for (var r of n) r && r.tagName && "INPUT" === r.tagName && f[i].push(r);
                l.debug(`triggers ["${i}"] `, o);
                l.debug(`validInputs ["${i}"] `, n);
                o.forEach(e => {
                    p[i].push(e)
                });
                for (let n = 0; n < o.length; n++) {
                    var a = function() {
                        try {
                            l.debug("Detect event: ", u.detectionEventType, "on element, ", o[n]);
                            let e = Object.entries(f).map(e => e[1]).flatMap(e => e);
                            for (var t of e) {
                                let e = t.value.trim();
                                if (y(e)) {
                                    l.debug("We detected: ", e), m();
                                    break
                                }
                            }
                        } catch (e) {}
                    };
                    v[i].push(a), o[n].addEventListener(u.detectionEventType, a, {
                        once: !0,
                        capture: !0
                    })
                }
                let d = w(e);
                for (let e = 0; e < d.length; e++) {
                    const s = d[e],
                        c = i + "/shadow_root_" + e;
                    t(s, c), h(s, c)
                }
            }(e, t)
    }

    function m() {
        if (l.debug("Detection stopped."), u.detectDynamicNodes) {
            l.debug("Checking for dynamically added elements is turned off.");
            for (var [e, t] of Object.entries(o)) t && t.disconnect(), o = {}
        }
        n("all")
    }

    function n(e) {
        if (l.debug(`clearing detection hooks (${e})`), "all" === e) {
            for (var [t, n] of Object.entries(p))
                if (n)
                    for (let e = 0; e < n.length; e++) n[e].removeEventListener(u.detectionEventType, v[t][e], {
                        capture: !0
                    });
            p = {}, v = []
        } else {
            var i, o, r = [];
            for ([i, o] of Object.entries(p))
                if (i.startsWith(e)) {
                    if (o)
                        for (let e = 0; e < o.length; e++) o[e].removeEventListener(u.detectionEventType, v[i][e], {
                            capture: !0
                        });
                    r.push(i)
                }
            for (let e = 0; e < r.length; e++) {
                var a = r[e];
                p[a] = [], v[a] = []
            }
        }
    }

    function y(e) {
        return function(e) {
            var t = /((([^<>()\[\].,;:\s@"]+(\.[^<>()\[\].,;:\s@"]+)*)|(".+"))@(([^<>()[\].,;:\s@"]+\.)+[^<>()[\].,;:\s@"]{2,}))/i;
            if (u.detectionSubject.includes("email") && t.test(e)) return e = e.match(t)[0].toLowerCase().trim(), l.debug("We detected email: " + e), a(e, "email"), !0;
            return !1
        }(e) || !1
    }

    function h(n, i) {
        u.detectDynamicNodes && (o[i] = new d(function(e, t) {
            l.debug("Detected dynamically added nodes."), r(n, i)
        }, 500), o[i].observe(n, {
            childList: !0,
            subtree: !0,
            attributes: !0
        }))
    }

    function i(e) {
        e && e.type && e.identifier ? "email" !== e.type ? l.error("Identifier type is not supported, ", e.type) : (a(e.identifier, e.type), m()) : l.error("wrong identifier format")
    }

    function a(e, t) {
        var n;
        e && t && (n = new CustomEvent("detected-identifier", {
            detail: {
                identifier: e,
                type: t
            }
        }), l.info("Dispatched event with identifier: ", e, " and type: ", t), window.dispatchEvent(n))
    }

    function g(e) {
        if (e && e.__upixel_detection) try {
            r(e.__upixel_detection.root, e.__upixel_detection.scopeName)
        } catch (e) {}
    }

    function b(t, n, i) {
        l.debug(`collectElements("${n}", ${i})`);
        let o = [];
        for (var e of i) 0 < e.length && (e = t.querySelectorAll(e)) && e.forEach(e => {
            o.includes(e) || o.push(e)
        });
        var r = window.location.hostname,
            a = document.getElementsByTagName("iframe");
        for (let e = 0; e < a.length; e++) {
            var d = a[e];
            if (function(e, t) {
                    if (t.src) try {
                        var n = e === new URL(t.src).hostname;
                        return n && l.debug("Iframe " + t.src + " can be accessed"), n
                    } catch (e) {
                        l.debug("error: ", e)
                    }
                }(r, d) && (d.__upixel_detection = {
                    root: t,
                    scopeName: n + "/iframe"
                }, d.removeEventListener("load", g), d.addEventListener("load", g), d.contentDocument))
                for (var s of i) 0 < s.length && d.contentDocument.querySelectorAll(s).forEach(e => {
                    o.includes(e) || o.push(e)
                })
        }
        return o
    }

    function w(e) {
        return [...e.querySelectorAll("*")].filter(e => !!e.shadowRoot).map(e => e.shadowRoot)
    }

    function d(e, t) {
        this.callback = e, this.minDelayMs = t, this.lastInvocationTime = 0, this.args = null, this.nextTimeoutHandle = null, this.mutationObserver = new MutationObserver(this.throttledCallback.bind(this))
    }
    d.prototype.observe = function(e, t) {
        this.mutationObserver.observe(e, t)
    }, d.prototype.disconnect = function() {
        null != this.nextTimeoutHandle && clearTimeout(this.nextTimeoutHandle), this.mutationObserver.disconnect()
    }, d.prototype.takeRecords = function() {
        return this.mutationObserver.takeRecords()
    }, d.prototype.throttledCallback = function(e, t) {
        var n = Date.now();
        null != this.args ? this.args = arguments : this.lastInvocationTime + this.minDelayMs < n ? (this.lastInvocationTime = n, this.callback(e, t)) : (this.args = arguments, this.nextTimeoutHandle = setTimeout(function() {
            this.lastInvocationTime = Date.now(), this.nextTimeoutHandle = null, this.callback.apply(null, this.args), this.args = null
        }.bind(this), this.minDelayMs))
    }, window.ttdPixel = window.ttdPixel || {}, window.ttdPixel.startDetection = function(e) {
        u = e, l.info("Detection started! Library is configured to detect: ", u.detectionSubject), l.info("Detection event type is ", u.detectionEventType), l.debug("Full config: ", u), "onclick" === u.detectionEventType && (u.detectionEventType = "click"), "onsubmit" === u.detectionEventType || "click" === u.detectionEventType ? (e = document.querySelector("body")) && (r(e, "document"), u.detectDynamicNodes) && h(e, "document") : l.debug("Detection type not supported! We will not start auto detection."), window.ttdPixelEventsLayer = window.ttdPixelEventsLayer || [], window.ttdPixelEventsLayer.forEach(t), window.ttdPixelEventsLayer.push = function(e) {
            return Array.prototype.push.call(window.ttdPixelEventsLayer, e), t(e), this.length
        }
    }, window.ttdPixel.setIdentifier = i, window.ttdPixel.enableDebug = () => e("debug"), window.ttdPixel.disableLog = () => e(null)
}();
var ttd_dom_ready = function() {
    var t, n, i = {
            "[object Boolean]": "boolean",
            "[object Number]": "number",
            "[object String]": "string",
            "[object Function]": "function",
            "[object Array]": "array",
            "[object Date]": "date",
            "[object RegExp]": "regexp",
            "[object Object]": "object"
        },
        l = {
            isReady: !1,
            readyWait: 1,
            holdReady: function(e) {
                e ? l.readyWait++ : l.ready(!0)
            },
            ready: function(e) {
                if (!0 === e && !--l.readyWait || !0 !== e && !l.isReady) {
                    if (!document.body) return setTimeout(l.ready, 1);
                    (l.isReady = !0) !== e && 0 < --l.readyWait || t.resolveWith(document, [l])
                }
            },
            bindReady: function() {
                if (!t) {
                    if (t = l._Deferred(), "complete" === document.readyState) return setTimeout(l.ready, 1);
                    if (document.addEventListener) document.addEventListener("DOMContentLoaded", n, !1), window.addEventListener("load", l.ready, !1);
                    else if (document.attachEvent) {
                        document.attachEvent("onreadystatechange", n), window.attachEvent("onload", l.ready);
                        var e = !1;
                        try {
                            e = null == window.frameElement
                        } catch (e) {}
                        document.documentElement.doScroll && e && o()
                    }
                }
            },
            _Deferred: function() {
                var a, n, d, s = [],
                    c = {
                        done: function() {
                            if (!d) {
                                var e, t, n, i, o, r = arguments;
                                for (a && (o = a, a = 0), e = 0, t = r.length; e < t; e++) "array" === (i = l.type(n = r[e])) ? c.done.apply(c, n) : "function" === i && s.push(n);
                                o && c.resolveWith(o[0], o[1])
                            }
                            return this
                        },
                        resolveWith: function(e, t) {
                            if (!d && !a && !n) {
                                t = t || [], n = 1;
                                try {
                                    for (; s[0];) s.shift().apply(e, t)
                                } finally {
                                    a = [e, t], n = 0
                                }
                            }
                            return this
                        },
                        resolve: function() {
                            return c.resolveWith(this, arguments), this
                        },
                        isResolved: function() {
                            return !(!n && !a)
                        },
                        cancel: function() {
                            return d = 1, s = [], this
                        }
                    };
                return c
            },
            type: function(e) {
                return null == e ? String(e) : i[Object.prototype.toString.call(e)] || "object"
            }
        };

    function o() {
        if (!l.isReady) {
            try {
                document.documentElement.doScroll("left")
            } catch (e) {
                return void setTimeout(o, 1)
            }
            l.ready()
        }
    }
    return document.addEventListener ? n = function() {
            document.removeEventListener("DOMContentLoaded", n, !1), l.ready()
        } : document.attachEvent && (n = function() {
            "complete" === document.readyState && (document.detachEvent("onreadystatechange", n), l.ready())
        }),
        function(e) {
            l.bindReady(), l.type(e), t.done(e)
        }
}();

function TTDUniversalPixelApi(e) {
    return new _TTDUniversalPixelApi(e)
}

function _TTDUniversalPixelApi(G) {
    var J = "1.1.0";
    const s = ["ru6qq3d", "ufqc9us", "ugj89je", "foh1kju", "1znfrjo", "xjagv7s", "0g3yesi", "6kn3s7q", "d5bjpnk", "k8v60jg", "t6jmgnz", "e2zo2dn", "Yb4bc7v", "80qouob", "fndgd00", "7b1me90", "rz1ru9d", "d8dz0ay", "7jqld3p", "7ypx83u", "l9q6q4w", "m3nv74a", "5c01m9d"];

    function X(e) {
        return new URL(e).hostname
    }

    function Y(e) {
        return e.type && "EUID" === e.type || !(!e.serverPublicKey || !e.serverPublicKey.includes("EUID"))
    }

    function Q(e) {
        return e.type && "UID2" === e.type || !(!e.serverPublicKey || !e.serverPublicKey.includes("UID2"))
    }
    async function c(r, d, s, e, c, l) {
        this._uidSdkListenerLock = {};
        let u = {};
        this.setUidVariables = function(e) {
            Q(e) ? (u.uidSdkUrl = "https://js.adsrvr.org/uid2-sdk-3.10.0.js", u.uidBaseUrl = "https://global.prod.uidapi.com", u.rtUidTokenName = "uid2_token") : Y(e) && (u.uidSdkUrl = "https://js.adsrvr.org/euid-sdk-3.10.0.js", u.uidBaseUrl = "https://prod.euid.eu", u.rtUidTokenName = "euid_token")
        }, this.setupUidSdk = function(e, t, i, o) {
            void 0 === this._uidSdkListenerLock[e] && (this._uidSdkListenerLock[e] = 1, this.setUidVariables(t), void 0 === u.sdkObj && void 0 === window.ttdPixel.uidSdkLoaderPromise ? window.ttdPixel.uidSdkLoaderPromise = new Promise((e, t) => {
                var n = document.createElement("script");
                n.setAttribute("defer", !0), n.setAttribute("src", u.uidSdkUrl), n.addEventListener("load", () => {
                    e(), i()
                }), n.addEventListener("error", e => {
                    t(e), o(e)
                }), document.body.appendChild(n)
            }) : (async () => {
                try {
                    await window.ttdPixel.uidSdkLoaderPromise, i()
                } catch (e) {
                    console.warn("Failed to load uid sdk: ", e)
                }
            })())
        };
        var p = document.getElementsByTagName("body")[0];
        if (p) {
            var f = "",
                v = {},
                t = {
                    MonetaryValue: "v",
                    MonetaryValueFormat: "vf"
                },
                m = [];
            if ("undefined" != typeof _pixelParams)
                for (var y in _pixelParams) {
                    var h = _pixelParams[y],
                        y = t[y];
                    y && h && !/%%.*%%/i.test(h) && (h = encodeURIComponent(h), m.push(y + "=" + h), v[y] = h)
                }
            var g = "adv=" + r,
                W = "upid=" + d.join(","),
                b = (v.adv = r, G || function() {
                    var e = window,
                        t = "",
                        n = !1;
                    try {
                        top.location.href && (t = top.location.href)
                    } catch (e) {
                        n = !0
                    }
                    if (n)
                        for (;;) try {
                            if (t = e.document.referrer, window.parent == e) break;
                            e = window.parent
                        } catch (e) {
                            break
                        } - 1 < t.indexOf("cloudfront.net") && (t = function(e, t) {
                            t = t.replace(/[\[]/, "\\[").replace(/[\]]/, "\\]");
                            t = new RegExp("[\\?&]" + t + "=([^&#]*)").exec(e);
                            return null === t ? "" : decodeURIComponent(t[1].replace(/\+/g, " "))
                        }(t, "url") || t);
                    return t
                }()),
                F = encodeURIComponent(b),
                b = (v.ref = b, J);
            if (v.upv = b, f = s + "?" + g + "&ref=" + F + "&" + W + "&upv=" + b, e)
                for (var w in e) {
                    var _ = e[w];
                    void 0 !== _ && (f = f + "&" + w + "=" + _, v[w] = "" + _)
                }
            0 < m.length && (f = f + "&" + m.join("&")), navigator.joinAdInterestGroup && (f += "&paapi=1", v.paapi = "1"), (localStorage.getItem("UID2-sdk-identity") || localStorage.getItem("EUID-sdk-identity")) && (f += "&uidcs=1", v.uidcs = "1");
            let n;
            const H = new Promise((e, t) => {
                n = e
            });
            var k = null,
                E = !1,
                D = null;
            "function" == typeof __tcfapi ? (L = setTimeout(z, 1e3), __tcfapi("addEventListener", 2, V)) : "function" == typeof __cmp ? (k = setTimeout($, 1e3), __cmp("ping", null, I)) : "function" == typeof __gpp ? void 0 !== (g = P()).gppString ? N(g.gppString, g.gppSid) : (T = setTimeout(K, 1e3), __gpp("addEventListener", B)) : O();
            let i = !1,
                o = (void 0 !== c && (i = !0), r + ":" + d.join(",")),
                a = !1;
            i ? (a = !0, this.setupUidSdk(o, c, () => U(c), e => {
                console.warn("UID enabled but failed to register hooks: ", e)
            })) : window.addEventListener("message", e => {
                try {
                    if (null !== e.origin && "null" !== e.origin) {
                        var t = new URL(e.origin);
                        if (t.hostname.endsWith(".adsrvr.org") && !i && "string" == typeof e.data) {
                            const n = JSON.parse(e.data);
                            !n.type || "string" != typeof n.type || "UID2" !== n.type && "EUID" !== n.type || n.advertiserId && "string" == typeof n.advertiserId && n.advertiserId == r && (a = !0, this.setupUidSdk(o, c, () => U(n), e => {
                                console.warn("UID enabled but failed to register hooks: ", e)
                            }))
                        }
                    }
                } catch (e) {}
            });
            var T = null,
                S = !1,
                L = null,
                x = !1;
            async function j() {
                "hidden" === document.visibilityState && (l && await q(v), document.removeEventListener("visibilitychange", j))
            }
            async function M(e, n) {
                try {
                    var t, i, o = e();
                    !o && function(e) {
                        if ("string" == typeof e.subscriptionId && "string" == typeof e.serverPublicKey) return 1;
                        console.error("subscription id and serverPublicKey must both be provided and both be strings to run cstg")
                    }(n) && (void 0 !== n.email ? u.sdkObj.setIdentityFromEmail(n.email, n) : void 0 !== n.emailHash ? u.sdkObj.setIdentityFromEmailHash(n.emailHash, n) : void 0 !== n.phone ? u.sdkObj.setIdentityFromPhone(n.phone, n) : void 0 !== n.phoneHash && u.sdkObj.setIdentityFromPhoneHash(n.phoneHash, n)), o ? (l ? await q(v, o.advertising_token) : await A(o.advertising_token), document.removeEventListener("visibilitychange", j)) : window.ttdPixel.activeDetection || (t = new Promise(t => {
                        window.addEventListener("detected-identifier", function(e) {
                            t(e.detail.identifier), window.ttdPixel.activeDetection = null
                        }), window.ttdPixel.startDetection(n)
                    }), i = await (window.ttdPixel.activeDetection = t), await u.sdkObj.setIdentityFromEmail(i, n))
                } catch (e) {
                    console.warn("error setting up fireOrDetact: ", e)
                }
            }

            function U(n) {
                Q(n) ? u.sdkObj = __uid2 : Y(n) && (u.sdkObj = __euid);
                try {
                    u.sdkObj.callbacks.push(async (e, t) => {
                        switch (e) {
                            case "SdkLoaded":
                                try {
                                    window.__ttd_m_invoke_once = window.__ttd_m_invoke_once || {}, window.__ttd_m_invoke_once._uid_init || (window.__ttd_m_invoke_once._uid_init = 1, n.baseUrl || (n.baseUrl = u.uidBaseUrl), u.sdkObj.init({
                                        baseUrl: n.baseUrl
                                    }))
                                } catch (e) {
                                    console.info("Non-TTD actor initialized UID SDK, mind the consistency of UID baseUrl.")
                                }
                                break;
                            case "InitCompleted":
                                await M(() => t.identity, n);
                                break;
                            case "IdentityUpdated":
                                l ? await q(v, t.identity.advertising_token) : await A(t.identity.advertising_token), document.removeEventListener("visibilitychange", j)
                        }
                    })
                } catch (e) {
                    console.warn("Did not setup uid hooks: ", e)
                }
            }

            function P() {
                var e, t = __gpp("getGPPData"),
                    t = {
                        gppString: t ? .gppString,
                        gppSid: t ? .applicableSections ? .join(",")
                    };
                return void 0 === t.gppString && (e = __gpp("ping"), t.gppString = e ? .gppString, t.gppSid = e ? .applicableSections ? .join(",")), t
            }

            function B(e, t) {
                var n;
                S ? __gpp("removeEventListener", function() {}, e.listenerId) : "signalStatus" === e.eventName && "ready" === e.data && (n = P(), clearTimeout(T), D = new Date, N(n.gppString, n.gppSid), __gpp("removeEventListener", function() {}, e.listenerId))
            }

            function K() {
                S = !0, O()
            }

            function $() {
                E = !0, O()
            }

            function I(e) {
                E || (e.cmpLoaded || e.gdprAppliesGlobally ? (clearTimeout(k), D = new Date, __cmp("getConsentData", null, O)) : setTimeout(function() {
                    __cmp("ping", null, I)
                }, 200))
            }

            function O(e) {
                var t;
                null != D && (t = new Date - D, f = f + "&ret=" + t, v.ret = t), E && (f += "&pto=1", v.pto = "1"), null != e && (t = e.gdprApplies ? "1" : "0", f = f + "&gdpr=" + t + "&gdpr_consent=" + e.consentData, v.gdpr = t, v.gdpr_consent = e.consentData), R()
            }
            async function R() {
                var e = "universal_pixel_" + d.join("_");
                n(f), await C(f, e, "TTD Universal Pixel"), document.addEventListener("visibilitychange", j)
            }
            async function A(e, t) {
                await C(await H + "&uiddt=" + e + "&uidcs=" + t, "universal_pixel_" + d.join("_") + "_uid", "TTD Universal Pixel with UID")
            }
            async function C(e, t, n) {
                let i = document.getElementById(t);
                for (; i && i.parentElement.removeChild(i), i = document.getElementById(t););
                let o = document.createElement("iframe");

                function r() {
                    p.appendChild(o), setTimeout(async () => {
                        l && !a && (await q(v), document.removeEventListener("visibilitychange", j))
                    }, 1e3)
                }
                o.setAttribute("id", t), o.setAttribute("height", 0), o.setAttribute("width", 0), o.setAttribute("style", "display:none;"), o.setAttribute("src", e), o.setAttribute("title", n), e.includes("/track/rt") && n.includes("Realtime Fallback") ? (p.appendChild(o), document.removeEventListener("visibilitychange", j)) : "complete" === document.readyState ? setTimeout(r, 0) : window.addEventListener ? window.addEventListener("load", r) : window.attachEvent ? window.attachEvent("onload", r) : r()
            }

            function z() {
                x = !0, O()
            }

            function V(e, t) {
                var n;
                x ? __tcfapi("removeEventListener", 2, function(e) {}, e.listenerId) : t && (clearTimeout(L), t = e, null != D && (n = new Date - D, f = f + "&ret=" + n, v.ret = n), x && (f += "&pto=1", v.pto = "1"), null != t && (n = function(e) {
                    return e ? "1" : "0"
                }(t.gdprApplies), f = f + "&gdpr=" + n + "&gdpr_consent=" + t.tcString, v.gdpr = n, v.gdpr_consent = t.tcString), R(), D = new Date, __tcfapi("removeEventListener", 2, function(e) {}, e.listenerId))
            }

            function N(e, t) {
                var n;
                null != D && (n = new Date - D, f = f + "&ret=" + n, v.ret = n), null != e && (f = f + "&gpp_consent=" + e, v.gpp_consent = e), null != t && (f = f + "&gpp_sid=" + t, v.gpp_sid = t), R()
            }
            async function q(e, t) {
                e.pixel_ids = d, t && (e[u.rtUidTokenName] = t);
                const i = function(e) {
                        var t = {};
                        for (const n in e) void 0 !== e[n] && (t[n] = e[n]);
                        return t
                    }(e),
                    o = {
                        data: [{ ...i
                        }]
                    },
                    r = `https://${X(s)}/track/realtimeconversion`;
                return new Promise((e, t) => {
                    const n = new XMLHttpRequest;
                    n.withCredentials = !0, n.open("POST", r), n.setRequestHeader("Content-type", "application/json"), n.setRequestHeader("eventDataSource", "UpSdk"), n.setRequestHeader("eventDataSourceVersion", J), n.onload = () => {
                        (200 <= n.status && n.status < 300 ? e : t)(n.response)
                    }, n.onerror = async () => {
                        t(n.statusText), async function(e) {
                            var t = "universal_pixel_realtime_fallback_" + d.join("_");
                            e.eds = "UpSdkGet", e.edsv = J, e.upid = d.join(",");
                            const {
                                pixel_ids: n,
                                ...i
                            } = e;
                            e = new URLSearchParams(i), await C(`https://${X(s)}/track/rt` + "?" + e.toString(), t, "TTD Universal Pixel Realtime Fallback")
                        }(i)
                    }, n.send(JSON.stringify(o))
                }).catch(e => {})
            }
        }
    }
    this.init = async function(t, n, i, o, r, a) {
        if (("string" == typeof arguments[3] || !arguments[3] && 7 <= arguments.length) && (arguments[3] = null, 4 < arguments.length)) {
            for (var e = 4; e < arguments.length; e++) arguments[e - 1] = arguments[e];
            delete arguments[arguments.length - 1]
        }
        if (t && "" != t && n && !(n.length <= 0)) {
            let e = i;
            var d;
            (a = s.includes(t) ? !0 : a) && (d = X(i), e = `https://${d}/track/cei`), await c(t, n, e, o, r, a)
        }
    }
}
"undefined" != typeof process && void 0 !== process ? .env ? .JEST_WORKER_ID && (module.exports = {
    TTDUniversalPixelApi: TTDUniversalPixelApi
});
//# sourceMappingURL=up_loader.1.1.0.js.map