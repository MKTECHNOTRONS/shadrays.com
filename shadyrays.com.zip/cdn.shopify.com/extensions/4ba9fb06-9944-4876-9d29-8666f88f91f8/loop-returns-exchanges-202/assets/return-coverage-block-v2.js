var tC = Object.defineProperty;
var nC = (It, ft, en) => ft in It ? tC(It, ft, {
    enumerable: !0,
    configurable: !0,
    writable: !0,
    value: en
}) : It[ft] = en;
var Re = (It, ft, en) => nC(It, typeof ft != "symbol" ? ft + "" : ft, en);
(function() {
    "use strict";
    var av;
    var It = document.createElement("style");
    It.textContent = `.loop-return-coverage{border-top:1px solid var(--border-primaryDefault, #D8DBDF);border-bottom:1px solid var(--border-primaryDefault, #D8DBDF);background:var(--border-primaryDefault);padding:21px 4px}.loop-return-coverage .loop-return-coverage__title{font-weight:600;font-size:14px}.loop-return-coverage .loop-return-coverage__caption{font-weight:400;font-size:12px}.loop-return-coverage .loop-return-coverage__link{text-decoration:underline;cursor:pointer}.loop-return-coverage .loop-return-coverage__product{align-items:start;column-gap:10px;display:flex;font-size:14px}.loop-return-coverage .loop-return-coverage__product .loop-return-coverage__checkbox{margin-top:3px;width:18px;height:18px}.loop-return-coverage .loop-return-coverage__product p{margin:0;text-align:left;line-height:21px}.loop-return-coverage__hidden{display:none}dialog[data-offset-dialog=true]::backdrop{background:#000000b3}dialog[data-offset-dialog=true]{border:0}dialog[data-offset-dialog=true] .container{position:fixed;left:50%;top:50%;transform:translate(-50%,-50%);background:#fff;border-radius:var(--Radius-banner, 12px);box-sizing:border-box;display:flex;flex-direction:column;height:auto;justify-content:center;padding:24px 32px;width:593px;max-width:calc(100vw - 3rem);letter-spacing:.06rem;line-height:calc(1 + .8 / var(--font-body-scale));font-family:var(--font-body-family);font-style:var(--font-body-style);font-weight:var(--font-body-weight)}dialog[data-offset-dialog=true] .container .close-container{position:absolute;top:14px;right:21px;cursor:pointer}dialog[data-offset-dialog=true] .container .modal-media{display:flex;width:100%;padding:14px}dialog[data-offset-dialog=true] .container .modal-media-image{padding:3px 0 0}dialog[data-offset-dialog=true] .container .modal-media-content{padding:0 17px}dialog[data-offset-dialog=true] .container p.modal-terms{font-style:italic;font-size:12px;color:#707070;line-height:18px}dialog[data-offset-dialog=true] .container a{color:#707070;text-decoration:underline}dialog[data-offset-dialog=true] .container span.logo{position:relative;width:100%}dialog[data-offset-dialog=true] .container hr{margin:10px auto;width:100%}dialog[data-offset-dialog=true] .container h1{font-size:32px;margin:10px auto;text-align:left;width:100%}dialog[data-offset-dialog=true] .container h5{font-size:20px;font-weight:600;text-align:left;line-height:1.2;margin:0 0 21px}dialog[data-offset-dialog=true] .container p{font-size:15px;margin:0;line-height:1.5}dialog[data-offset-dialog=true] .container .modal-icon{stroke-width:initial;width:100%;max-width:100%;max-height:100%;fill:none;display:block}dialog[data-offset-dialog=true] .container .modal-icon-wrapper{stroke:currentColor;color:#707070;max-width:100%;max-height:100%;display:block}dialog[data-offset-dialog=true] .container-shipping-protection{width:596px;padding:14px 21px}dialog[data-offset-dialog=true] .loop-return-coverage__logo img{width:auto}.loop-return-coverage-ace{background:var(--border-primaryDefault)}.loop-return-coverage-ace .loop-return-coverage__title{font-weight:600;font-size:16px;display:inline-block}.loop-return-coverage-ace .loop-return-coverage__caption{font-weight:400;font-size:12px}.loop-return-coverage-ace .loop-return-coverage__link{text-decoration:underline;cursor:pointer}.loop-return-coverage-ace .loop-return-coverage__info{padding-left:5px;cursor:pointer;height:20px;position:relative;top:4px}.loop-return-coverage-ace .loop-return-coverage__button{padding:16px 0 0}.loop-return-coverage-ace .loop-return-coverage__cta__plus{display:flex;width:100%;height:50px;min-width:93.6px;padding:12.6px 16px;justify-content:center;align-items:center;gap:4px;flex-shrink:0;background-color:rgb(var(--color-button, 0,0,0));color:rgb(var(--color-button-text, 255,255,255));font-weight:600;border-radius:var(--buttons-radius-outset);font-size:16px;cursor:pointer}.loop-return-coverage-ace .loop-return-coverage__cta__standard{display:flex;width:100%;height:50px;min-width:93.6px;padding:12.6px 16px;justify-content:center;align-items:center;gap:4px;flex-shrink:0;color:rgb(var(--color-secondary-button-text, 0,0,0));background-color:rgb(var(--color-secondary-button, 255,255,255));font-weight:500;border-radius:var(--buttons-radius-outset);border-color:rgb(var(--color-secondary-button-text, 0,0,0));font-size:13px;cursor:pointer}.loop-return-coverage-ace .loop-return-coverage__product{gap:16px;display:flex;padding:8px 0;border-top:1px solid var(--border-primaryDefault, #B6BAC3);border-bottom:1px solid var(--border-primaryDefault, #B6BAC3);align-items:stretch}.loop-return-coverage-ace .loop-return-coverage__product :first-child{flex:1}.loop-return-coverage-ace .loop-return-coverage__product p{margin:0;text-align:left;line-height:21px}.loop-hidden{display:none!important}
/*$vite$:1*/`, document.head.appendChild(It);

    function ft(e) {
        return e && e.__esModule && Object.prototype.hasOwnProperty.call(e, "default") ? e.default : e
    }
    var en = {
            exports: {}
        },
        xo = {},
        du = {
            exports: {}
        },
        T = {};
    /**
     * @license React
     * react.production.min.js
     *
     * Copyright (c) Facebook, Inc. and its affiliates.
     *
     * This source code is licensed under the MIT license found in the
     * LICENSE file in the root directory of this source tree.
     */
    var wr = Symbol.for("react.element"),
        sv = Symbol.for("react.portal"),
        uv = Symbol.for("react.fragment"),
        cv = Symbol.for("react.strict_mode"),
        fv = Symbol.for("react.profiler"),
        dv = Symbol.for("react.provider"),
        pv = Symbol.for("react.context"),
        vv = Symbol.for("react.forward_ref"),
        gv = Symbol.for("react.suspense"),
        hv = Symbol.for("react.memo"),
        mv = Symbol.for("react.lazy"),
        pu = Symbol.iterator;

    function yv(e) {
        return e === null || typeof e != "object" ? null : (e = pu && e[pu] || e["@@iterator"], typeof e == "function" ? e : null)
    }
    var vu = {
            isMounted: function() {
                return !1
            },
            enqueueForceUpdate: function() {},
            enqueueReplaceState: function() {},
            enqueueSetState: function() {}
        },
        gu = Object.assign,
        hu = {};

    function _n(e, t, n) {
        this.props = e, this.context = t, this.refs = hu, this.updater = n || vu
    }
    _n.prototype.isReactComponent = {}, _n.prototype.setState = function(e, t) {
        if (typeof e != "object" && typeof e != "function" && e != null) throw Error("setState(...): takes an object of state variables to update or a function which returns an object of state variables.");
        this.updater.enqueueSetState(this, e, t, "setState")
    }, _n.prototype.forceUpdate = function(e) {
        this.updater.enqueueForceUpdate(this, e, "forceUpdate")
    };

    function mu() {}
    mu.prototype = _n.prototype;

    function pa(e, t, n) {
        this.props = e, this.context = t, this.refs = hu, this.updater = n || vu
    }
    var va = pa.prototype = new mu;
    va.constructor = pa, gu(va, _n.prototype), va.isPureReactComponent = !0;
    var yu = Array.isArray,
        wu = Object.prototype.hasOwnProperty,
        ga = {
            current: null
        },
        Cu = {
            key: !0,
            ref: !0,
            __self: !0,
            __source: !0
        };

    function Su(e, t, n) {
        var r, o = {},
            i = null,
            a = null;
        if (t != null)
            for (r in t.ref !== void 0 && (a = t.ref), t.key !== void 0 && (i = "" + t.key), t) wu.call(t, r) && !Cu.hasOwnProperty(r) && (o[r] = t[r]);
        var l = arguments.length - 2;
        if (l === 1) o.children = n;
        else if (1 < l) {
            for (var s = Array(l), u = 0; u < l; u++) s[u] = arguments[u + 2];
            o.children = s
        }
        if (e && e.defaultProps)
            for (r in l = e.defaultProps, l) o[r] === void 0 && (o[r] = l[r]);
        return {
            $$typeof: wr,
            type: e,
            key: i,
            ref: a,
            props: o,
            _owner: ga.current
        }
    }

    function wv(e, t) {
        return {
            $$typeof: wr,
            type: e.type,
            key: t,
            ref: e.ref,
            props: e.props,
            _owner: e._owner
        }
    }

    function ha(e) {
        return typeof e == "object" && e !== null && e.$$typeof === wr
    }

    function Cv(e) {
        var t = {
            "=": "=0",
            ":": "=2"
        };
        return "$" + e.replace(/[=:]/g, function(n) {
            return t[n]
        })
    }
    var xu = /\/+/g;

    function ma(e, t) {
        return typeof e == "object" && e !== null && e.key != null ? Cv("" + e.key) : t.toString(36)
    }

    function Eo(e, t, n, r, o) {
        var i = typeof e;
        (i === "undefined" || i === "boolean") && (e = null);
        var a = !1;
        if (e === null) a = !0;
        else switch (i) {
            case "string":
            case "number":
                a = !0;
                break;
            case "object":
                switch (e.$$typeof) {
                    case wr:
                    case sv:
                        a = !0
                }
        }
        if (a) return a = e, o = o(a), e = r === "" ? "." + ma(a, 0) : r, yu(o) ? (n = "", e != null && (n = e.replace(xu, "$&/") + "/"), Eo(o, t, n, "", function(u) {
            return u
        })) : o != null && (ha(o) && (o = wv(o, n + (!o.key || a && a.key === o.key ? "" : ("" + o.key).replace(xu, "$&/") + "/") + e)), t.push(o)), 1;
        if (a = 0, r = r === "" ? "." : r + ":", yu(e))
            for (var l = 0; l < e.length; l++) {
                i = e[l];
                var s = r + ma(i, l);
                a += Eo(i, t, n, s, o)
            } else if (s = yv(e), typeof s == "function")
                for (e = s.call(e), l = 0; !(i = e.next()).done;) i = i.value, s = r + ma(i, l++), a += Eo(i, t, n, s, o);
            else if (i === "object") throw t = String(e), Error("Objects are not valid as a React child (found: " + (t === "[object Object]" ? "object with keys {" + Object.keys(e).join(", ") + "}" : t) + "). If you meant to render a collection of children, use an array instead.");
        return a
    }

    function ko(e, t, n) {
        if (e == null) return e;
        var r = [],
            o = 0;
        return Eo(e, r, "", "", function(i) {
            return t.call(n, i, o++)
        }), r
    }

    function Sv(e) {
        if (e._status === -1) {
            var t = e._result;
            t = t(), t.then(function(n) {
                (e._status === 0 || e._status === -1) && (e._status = 1, e._result = n)
            }, function(n) {
                (e._status === 0 || e._status === -1) && (e._status = 2, e._result = n)
            }), e._status === -1 && (e._status = 0, e._result = t)
        }
        if (e._status === 1) return e._result.default;
        throw e._result
    }
    var Se = {
            current: null
        },
        Oo = {
            transition: null
        },
        xv = {
            ReactCurrentDispatcher: Se,
            ReactCurrentBatchConfig: Oo,
            ReactCurrentOwner: ga
        };

    function Eu() {
        throw Error("act(...) is not supported in production builds of React.")
    }
    T.Children = {
        map: ko,
        forEach: function(e, t, n) {
            ko(e, function() {
                t.apply(this, arguments)
            }, n)
        },
        count: function(e) {
            var t = 0;
            return ko(e, function() {
                t++
            }), t
        },
        toArray: function(e) {
            return ko(e, function(t) {
                return t
            }) || []
        },
        only: function(e) {
            if (!ha(e)) throw Error("React.Children.only expected to receive a single React element child.");
            return e
        }
    }, T.Component = _n, T.Fragment = uv, T.Profiler = fv, T.PureComponent = pa, T.StrictMode = cv, T.Suspense = gv, T.__SECRET_INTERNALS_DO_NOT_USE_OR_YOU_WILL_BE_FIRED = xv, T.act = Eu, T.cloneElement = function(e, t, n) {
        if (e == null) throw Error("React.cloneElement(...): The argument must be a React element, but you passed " + e + ".");
        var r = gu({}, e.props),
            o = e.key,
            i = e.ref,
            a = e._owner;
        if (t != null) {
            if (t.ref !== void 0 && (i = t.ref, a = ga.current), t.key !== void 0 && (o = "" + t.key), e.type && e.type.defaultProps) var l = e.type.defaultProps;
            for (s in t) wu.call(t, s) && !Cu.hasOwnProperty(s) && (r[s] = t[s] === void 0 && l !== void 0 ? l[s] : t[s])
        }
        var s = arguments.length - 2;
        if (s === 1) r.children = n;
        else if (1 < s) {
            l = Array(s);
            for (var u = 0; u < s; u++) l[u] = arguments[u + 2];
            r.children = l
        }
        return {
            $$typeof: wr,
            type: e.type,
            key: o,
            ref: i,
            props: r,
            _owner: a
        }
    }, T.createContext = function(e) {
        return e = {
            $$typeof: pv,
            _currentValue: e,
            _currentValue2: e,
            _threadCount: 0,
            Provider: null,
            Consumer: null,
            _defaultValue: null,
            _globalName: null
        }, e.Provider = {
            $$typeof: dv,
            _context: e
        }, e.Consumer = e
    }, T.createElement = Su, T.createFactory = function(e) {
        var t = Su.bind(null, e);
        return t.type = e, t
    }, T.createRef = function() {
        return {
            current: null
        }
    }, T.forwardRef = function(e) {
        return {
            $$typeof: vv,
            render: e
        }
    }, T.isValidElement = ha, T.lazy = function(e) {
        return {
            $$typeof: mv,
            _payload: {
                _status: -1,
                _result: e
            },
            _init: Sv
        }
    }, T.memo = function(e, t) {
        return {
            $$typeof: hv,
            type: e,
            compare: t === void 0 ? null : t
        }
    }, T.startTransition = function(e) {
        var t = Oo.transition;
        Oo.transition = {};
        try {
            e()
        } finally {
            Oo.transition = t
        }
    }, T.unstable_act = Eu, T.useCallback = function(e, t) {
        return Se.current.useCallback(e, t)
    }, T.useContext = function(e) {
        return Se.current.useContext(e)
    }, T.useDebugValue = function() {}, T.useDeferredValue = function(e) {
        return Se.current.useDeferredValue(e)
    }, T.useEffect = function(e, t) {
        return Se.current.useEffect(e, t)
    }, T.useId = function() {
        return Se.current.useId()
    }, T.useImperativeHandle = function(e, t, n) {
        return Se.current.useImperativeHandle(e, t, n)
    }, T.useInsertionEffect = function(e, t) {
        return Se.current.useInsertionEffect(e, t)
    }, T.useLayoutEffect = function(e, t) {
        return Se.current.useLayoutEffect(e, t)
    }, T.useMemo = function(e, t) {
        return Se.current.useMemo(e, t)
    }, T.useReducer = function(e, t, n) {
        return Se.current.useReducer(e, t, n)
    }, T.useRef = function(e) {
        return Se.current.useRef(e)
    }, T.useState = function(e) {
        return Se.current.useState(e)
    }, T.useSyncExternalStore = function(e, t, n) {
        return Se.current.useSyncExternalStore(e, t, n)
    }, T.useTransition = function() {
        return Se.current.useTransition()
    }, T.version = "18.3.1", du.exports = T;
    var k = du.exports;
    const Lo = ft(k);
    /**
     * @license React
     * react-jsx-runtime.production.min.js
     *
     * Copyright (c) Facebook, Inc. and its affiliates.
     *
     * This source code is licensed under the MIT license found in the
     * LICENSE file in the root directory of this source tree.
     */
    var Ev = k,
        kv = Symbol.for("react.element"),
        Ov = Symbol.for("react.fragment"),
        Lv = Object.prototype.hasOwnProperty,
        Pv = Ev.__SECRET_INTERNALS_DO_NOT_USE_OR_YOU_WILL_BE_FIRED.ReactCurrentOwner,
        Iv = {
            key: !0,
            ref: !0,
            __self: !0,
            __source: !0
        };

    function ku(e, t, n) {
        var r, o = {},
            i = null,
            a = null;
        n !== void 0 && (i = "" + n), t.key !== void 0 && (i = "" + t.key), t.ref !== void 0 && (a = t.ref);
        for (r in t) Lv.call(t, r) && !Iv.hasOwnProperty(r) && (o[r] = t[r]);
        if (e && e.defaultProps)
            for (r in t = e.defaultProps, t) o[r] === void 0 && (o[r] = t[r]);
        return {
            $$typeof: kv,
            type: e,
            key: i,
            ref: a,
            props: o,
            _owner: Pv.current
        }
    }
    xo.Fragment = Ov, xo.jsx = ku, xo.jsxs = ku, en.exports = xo;
    var w = en.exports,
        ya = {},
        Ou = {
            exports: {}
        },
        Me = {},
        Lu = {
            exports: {}
        },
        Pu = {};
    /**
     * @license React
     * scheduler.production.min.js
     *
     * Copyright (c) Facebook, Inc. and its affiliates.
     *
     * This source code is licensed under the MIT license found in the
     * LICENSE file in the root directory of this source tree.
     */
    (function(e) {
        function t(P, M) {
            var j = P.length;
            P.push(M);
            e: for (; 0 < j;) {
                var W = j - 1 >>> 1,
                    ne = P[W];
                if (0 < o(ne, M)) P[W] = M, P[j] = ne, j = W;
                else break e
            }
        }

        function n(P) {
            return P.length === 0 ? null : P[0]
        }

        function r(P) {
            if (P.length === 0) return null;
            var M = P[0],
                j = P.pop();
            if (j !== M) {
                P[0] = j;
                e: for (var W = 0, ne = P.length, mr = ne >>> 1; W < mr;) {
                    var ut = 2 * (W + 1) - 1,
                        yr = P[ut],
                        ct = ut + 1,
                        Nn = P[ct];
                    if (0 > o(yr, j)) ct < ne && 0 > o(Nn, yr) ? (P[W] = Nn, P[ct] = j, W = ct) : (P[W] = yr, P[ut] = j, W = ut);
                    else if (ct < ne && 0 > o(Nn, j)) P[W] = Nn, P[ct] = j, W = ct;
                    else break e
                }
            }
            return M
        }

        function o(P, M) {
            var j = P.sortIndex - M.sortIndex;
            return j !== 0 ? j : P.id - M.id
        }
        if (typeof performance == "object" && typeof performance.now == "function") {
            var i = performance;
            e.unstable_now = function() {
                return i.now()
            }
        } else {
            var a = Date,
                l = a.now();
            e.unstable_now = function() {
                return a.now() - l
            }
        }
        var s = [],
            u = [],
            c = 1,
            f = null,
            d = 3,
            h = !1,
            y = !1,
            m = !1,
            E = typeof setTimeout == "function" ? setTimeout : null,
            v = typeof clearTimeout == "function" ? clearTimeout : null,
            p = typeof setImmediate < "u" ? setImmediate : null;
        typeof navigator < "u" && navigator.scheduling !== void 0 && navigator.scheduling.isInputPending !== void 0 && navigator.scheduling.isInputPending.bind(navigator.scheduling);

        function g(P) {
            for (var M = n(u); M !== null;) {
                if (M.callback === null) r(u);
                else if (M.startTime <= P) r(u), M.sortIndex = M.expirationTime, t(s, M);
                else break;
                M = n(u)
            }
        }

        function C(P) {
            if (m = !1, g(P), !y)
                if (n(s) !== null) y = !0, hr(O);
                else {
                    var M = n(u);
                    M !== null && So(C, M.startTime - P)
                }
        }

        function O(P, M) {
            y = !1, m && (m = !1, v(I), I = -1), h = !0;
            var j = d;
            try {
                for (g(M), f = n(s); f !== null && (!(f.expirationTime > M) || P && !Oe());) {
                    var W = f.callback;
                    if (typeof W == "function") {
                        f.callback = null, d = f.priorityLevel;
                        var ne = W(f.expirationTime <= M);
                        M = e.unstable_now(), typeof ne == "function" ? f.callback = ne : f === n(s) && r(s), g(M)
                    } else r(s);
                    f = n(s)
                }
                if (f !== null) var mr = !0;
                else {
                    var ut = n(u);
                    ut !== null && So(C, ut.startTime - M), mr = !1
                }
                return mr
            } finally {
                f = null, d = j, h = !1
            }
        }
        var N = !1,
            S = null,
            I = -1,
            $ = 5,
            z = -1;

        function Oe() {
            return !(e.unstable_now() - z < $)
        }

        function nt() {
            if (S !== null) {
                var P = e.unstable_now();
                z = P;
                var M = !0;
                try {
                    M = S(!0, P)
                } finally {
                    M ? Pt() : (N = !1, S = null)
                }
            } else N = !1
        }
        var Pt;
        if (typeof p == "function") Pt = function() {
            p(nt)
        };
        else if (typeof MessageChannel < "u") {
            var fa = new MessageChannel,
                fu = fa.port2;
            fa.port1.onmessage = nt, Pt = function() {
                fu.postMessage(null)
            }
        } else Pt = function() {
            E(nt, 0)
        };

        function hr(P) {
            S = P, N || (N = !0, Pt())
        }

        function So(P, M) {
            I = E(function() {
                P(e.unstable_now())
            }, M)
        }
        e.unstable_IdlePriority = 5, e.unstable_ImmediatePriority = 1, e.unstable_LowPriority = 4, e.unstable_NormalPriority = 3, e.unstable_Profiling = null, e.unstable_UserBlockingPriority = 2, e.unstable_cancelCallback = function(P) {
            P.callback = null
        }, e.unstable_continueExecution = function() {
            y || h || (y = !0, hr(O))
        }, e.unstable_forceFrameRate = function(P) {
            0 > P || 125 < P ? console.error("forceFrameRate takes a positive int between 0 and 125, forcing frame rates higher than 125 fps is not supported") : $ = 0 < P ? Math.floor(1e3 / P) : 5
        }, e.unstable_getCurrentPriorityLevel = function() {
            return d
        }, e.unstable_getFirstCallbackNode = function() {
            return n(s)
        }, e.unstable_next = function(P) {
            switch (d) {
                case 1:
                case 2:
                case 3:
                    var M = 3;
                    break;
                default:
                    M = d
            }
            var j = d;
            d = M;
            try {
                return P()
            } finally {
                d = j
            }
        }, e.unstable_pauseExecution = function() {}, e.unstable_requestPaint = function() {}, e.unstable_runWithPriority = function(P, M) {
            switch (P) {
                case 1:
                case 2:
                case 3:
                case 4:
                case 5:
                    break;
                default:
                    P = 3
            }
            var j = d;
            d = P;
            try {
                return M()
            } finally {
                d = j
            }
        }, e.unstable_scheduleCallback = function(P, M, j) {
            var W = e.unstable_now();
            switch (typeof j == "object" && j !== null ? (j = j.delay, j = typeof j == "number" && 0 < j ? W + j : W) : j = W, P) {
                case 1:
                    var ne = -1;
                    break;
                case 2:
                    ne = 250;
                    break;
                case 5:
                    ne = 1073741823;
                    break;
                case 4:
                    ne = 1e4;
                    break;
                default:
                    ne = 5e3
            }
            return ne = j + ne, P = {
                id: c++,
                callback: M,
                priorityLevel: P,
                startTime: j,
                expirationTime: ne,
                sortIndex: -1
            }, j > W ? (P.sortIndex = j, t(u, P), n(s) === null && P === n(u) && (m ? (v(I), I = -1) : m = !0, So(C, j - W))) : (P.sortIndex = ne, t(s, P), y || h || (y = !0, hr(O))), P
        }, e.unstable_shouldYield = Oe, e.unstable_wrapCallback = function(P) {
            var M = d;
            return function() {
                var j = d;
                d = M;
                try {
                    return P.apply(this, arguments)
                } finally {
                    d = j
                }
            }
        }
    })(Pu), Lu.exports = Pu;
    var Nv = Lu.exports;
    /**
     * @license React
     * react-dom.production.min.js
     *
     * Copyright (c) Facebook, Inc. and its affiliates.
     *
     * This source code is licensed under the MIT license found in the
     * LICENSE file in the root directory of this source tree.
     */
    var _v = k,
        De = Nv;

    function x(e) {
        for (var t = "https://reactjs.org/docs/error-decoder.html?invariant=" + e, n = 1; n < arguments.length; n++) t += "&args[]=" + encodeURIComponent(arguments[n]);
        return "Minified React error #" + e + "; visit " + t + " for the full message or use the non-minified dev environment for full errors and additional helpful warnings."
    }
    var Iu = new Set,
        Cr = {};

    function tn(e, t) {
        Rn(e, t), Rn(e + "Capture", t)
    }

    function Rn(e, t) {
        for (Cr[e] = t, e = 0; e < t.length; e++) Iu.add(t[e])
    }
    var dt = !(typeof window > "u" || typeof window.document > "u" || typeof window.document.createElement > "u"),
        wa = Object.prototype.hasOwnProperty,
        Rv = /^[:A-Z_a-z\u00C0-\u00D6\u00D8-\u00F6\u00F8-\u02FF\u0370-\u037D\u037F-\u1FFF\u200C-\u200D\u2070-\u218F\u2C00-\u2FEF\u3001-\uD7FF\uF900-\uFDCF\uFDF0-\uFFFD][:A-Z_a-z\u00C0-\u00D6\u00D8-\u00F6\u00F8-\u02FF\u0370-\u037D\u037F-\u1FFF\u200C-\u200D\u2070-\u218F\u2C00-\u2FEF\u3001-\uD7FF\uF900-\uFDCF\uFDF0-\uFFFD\-.0-9\u00B7\u0300-\u036F\u203F-\u2040]*$/,
        Nu = {},
        _u = {};

    function Mv(e) {
        return wa.call(_u, e) ? !0 : wa.call(Nu, e) ? !1 : Rv.test(e) ? _u[e] = !0 : (Nu[e] = !0, !1)
    }

    function Dv(e, t, n, r) {
        if (n !== null && n.type === 0) return !1;
        switch (typeof t) {
            case "function":
            case "symbol":
                return !0;
            case "boolean":
                return r ? !1 : n !== null ? !n.acceptsBooleans : (e = e.toLowerCase().slice(0, 5), e !== "data-" && e !== "aria-");
            default:
                return !1
        }
    }

    function jv(e, t, n, r) {
        if (t === null || typeof t > "u" || Dv(e, t, n, r)) return !0;
        if (r) return !1;
        if (n !== null) switch (n.type) {
            case 3:
                return !t;
            case 4:
                return t === !1;
            case 5:
                return isNaN(t);
            case 6:
                return isNaN(t) || 1 > t
        }
        return !1
    }

    function xe(e, t, n, r, o, i, a) {
        this.acceptsBooleans = t === 2 || t === 3 || t === 4, this.attributeName = r, this.attributeNamespace = o, this.mustUseProperty = n, this.propertyName = e, this.type = t, this.sanitizeURL = i, this.removeEmptyString = a
    }
    var pe = {};
    "children dangerouslySetInnerHTML defaultValue defaultChecked innerHTML suppressContentEditableWarning suppressHydrationWarning style".split(" ").forEach(function(e) {
        pe[e] = new xe(e, 0, !1, e, null, !1, !1)
    }), [
        ["acceptCharset", "accept-charset"],
        ["className", "class"],
        ["htmlFor", "for"],
        ["httpEquiv", "http-equiv"]
    ].forEach(function(e) {
        var t = e[0];
        pe[t] = new xe(t, 1, !1, e[1], null, !1, !1)
    }), ["contentEditable", "draggable", "spellCheck", "value"].forEach(function(e) {
        pe[e] = new xe(e, 2, !1, e.toLowerCase(), null, !1, !1)
    }), ["autoReverse", "externalResourcesRequired", "focusable", "preserveAlpha"].forEach(function(e) {
        pe[e] = new xe(e, 2, !1, e, null, !1, !1)
    }), "allowFullScreen async autoFocus autoPlay controls default defer disabled disablePictureInPicture disableRemotePlayback formNoValidate hidden loop noModule noValidate open playsInline readOnly required reversed scoped seamless itemScope".split(" ").forEach(function(e) {
        pe[e] = new xe(e, 3, !1, e.toLowerCase(), null, !1, !1)
    }), ["checked", "multiple", "muted", "selected"].forEach(function(e) {
        pe[e] = new xe(e, 3, !0, e, null, !1, !1)
    }), ["capture", "download"].forEach(function(e) {
        pe[e] = new xe(e, 4, !1, e, null, !1, !1)
    }), ["cols", "rows", "size", "span"].forEach(function(e) {
        pe[e] = new xe(e, 6, !1, e, null, !1, !1)
    }), ["rowSpan", "start"].forEach(function(e) {
        pe[e] = new xe(e, 5, !1, e.toLowerCase(), null, !1, !1)
    });
    var Ca = /[\-:]([a-z])/g;

    function Sa(e) {
        return e[1].toUpperCase()
    }
    "accent-height alignment-baseline arabic-form baseline-shift cap-height clip-path clip-rule color-interpolation color-interpolation-filters color-profile color-rendering dominant-baseline enable-background fill-opacity fill-rule flood-color flood-opacity font-family font-size font-size-adjust font-stretch font-style font-variant font-weight glyph-name glyph-orientation-horizontal glyph-orientation-vertical horiz-adv-x horiz-origin-x image-rendering letter-spacing lighting-color marker-end marker-mid marker-start overline-position overline-thickness paint-order panose-1 pointer-events rendering-intent shape-rendering stop-color stop-opacity strikethrough-position strikethrough-thickness stroke-dasharray stroke-dashoffset stroke-linecap stroke-linejoin stroke-miterlimit stroke-opacity stroke-width text-anchor text-decoration text-rendering underline-position underline-thickness unicode-bidi unicode-range units-per-em v-alphabetic v-hanging v-ideographic v-mathematical vector-effect vert-adv-y vert-origin-x vert-origin-y word-spacing writing-mode xmlns:xlink x-height".split(" ").forEach(function(e) {
        var t = e.replace(Ca, Sa);
        pe[t] = new xe(t, 1, !1, e, null, !1, !1)
    }), "xlink:actuate xlink:arcrole xlink:role xlink:show xlink:title xlink:type".split(" ").forEach(function(e) {
        var t = e.replace(Ca, Sa);
        pe[t] = new xe(t, 1, !1, e, "http://www.w3.org/1999/xlink", !1, !1)
    }), ["xml:base", "xml:lang", "xml:space"].forEach(function(e) {
        var t = e.replace(Ca, Sa);
        pe[t] = new xe(t, 1, !1, e, "http://www.w3.org/XML/1998/namespace", !1, !1)
    }), ["tabIndex", "crossOrigin"].forEach(function(e) {
        pe[e] = new xe(e, 1, !1, e.toLowerCase(), null, !1, !1)
    }), pe.xlinkHref = new xe("xlinkHref", 1, !1, "xlink:href", "http://www.w3.org/1999/xlink", !0, !1), ["src", "href", "action", "formAction"].forEach(function(e) {
        pe[e] = new xe(e, 1, !1, e.toLowerCase(), null, !0, !0)
    });

    function xa(e, t, n, r) {
        var o = pe.hasOwnProperty(t) ? pe[t] : null;
        (o !== null ? o.type !== 0 : r || !(2 < t.length) || t[0] !== "o" && t[0] !== "O" || t[1] !== "n" && t[1] !== "N") && (jv(t, n, o, r) && (n = null), r || o === null ? Mv(t) && (n === null ? e.removeAttribute(t) : e.setAttribute(t, "" + n)) : o.mustUseProperty ? e[o.propertyName] = n === null ? o.type === 3 ? !1 : "" : n : (t = o.attributeName, r = o.attributeNamespace, n === null ? e.removeAttribute(t) : (o = o.type, n = o === 3 || o === 4 && n === !0 ? "" : "" + n, r ? e.setAttributeNS(r, t, n) : e.setAttribute(t, n))))
    }
    var pt = _v.__SECRET_INTERNALS_DO_NOT_USE_OR_YOU_WILL_BE_FIRED,
        Po = Symbol.for("react.element"),
        Mn = Symbol.for("react.portal"),
        Dn = Symbol.for("react.fragment"),
        Ea = Symbol.for("react.strict_mode"),
        ka = Symbol.for("react.profiler"),
        Ru = Symbol.for("react.provider"),
        Mu = Symbol.for("react.context"),
        Oa = Symbol.for("react.forward_ref"),
        La = Symbol.for("react.suspense"),
        Pa = Symbol.for("react.suspense_list"),
        Ia = Symbol.for("react.memo"),
        Nt = Symbol.for("react.lazy"),
        Du = Symbol.for("react.offscreen"),
        ju = Symbol.iterator;

    function Sr(e) {
        return e === null || typeof e != "object" ? null : (e = ju && e[ju] || e["@@iterator"], typeof e == "function" ? e : null)
    }
    var Q = Object.assign,
        Na;

    function xr(e) {
        if (Na === void 0) try {
            throw Error()
        } catch (n) {
            var t = n.stack.trim().match(/\n( *(at )?)/);
            Na = t && t[1] || ""
        }
        return `
` + Na + e
    }
    var _a = !1;

    function Ra(e, t) {
        if (!e || _a) return "";
        _a = !0;
        var n = Error.prepareStackTrace;
        Error.prepareStackTrace = void 0;
        try {
            if (t)
                if (t = function() {
                        throw Error()
                    }, Object.defineProperty(t.prototype, "props", {
                        set: function() {
                            throw Error()
                        }
                    }), typeof Reflect == "object" && Reflect.construct) {
                    try {
                        Reflect.construct(t, [])
                    } catch (u) {
                        var r = u
                    }
                    Reflect.construct(e, [], t)
                } else {
                    try {
                        t.call()
                    } catch (u) {
                        r = u
                    }
                    e.call(t.prototype)
                }
            else {
                try {
                    throw Error()
                } catch (u) {
                    r = u
                }
                e()
            }
        } catch (u) {
            if (u && r && typeof u.stack == "string") {
                for (var o = u.stack.split(`
`), i = r.stack.split(`
`), a = o.length - 1, l = i.length - 1; 1 <= a && 0 <= l && o[a] !== i[l];) l--;
                for (; 1 <= a && 0 <= l; a--, l--)
                    if (o[a] !== i[l]) {
                        if (a !== 1 || l !== 1)
                            do
                                if (a--, l--, 0 > l || o[a] !== i[l]) {
                                    var s = `
` + o[a].replace(" at new ", " at ");
                                    return e.displayName && s.includes("<anonymous>") && (s = s.replace("<anonymous>", e.displayName)), s
                                }
                        while (1 <= a && 0 <= l);
                        break
                    }
            }
        } finally {
            _a = !1, Error.prepareStackTrace = n
        }
        return (e = e ? e.displayName || e.name : "") ? xr(e) : ""
    }

    function zv(e) {
        switch (e.tag) {
            case 5:
                return xr(e.type);
            case 16:
                return xr("Lazy");
            case 13:
                return xr("Suspense");
            case 19:
                return xr("SuspenseList");
            case 0:
            case 2:
            case 15:
                return e = Ra(e.type, !1), e;
            case 11:
                return e = Ra(e.type.render, !1), e;
            case 1:
                return e = Ra(e.type, !0), e;
            default:
                return ""
        }
    }

    function Ma(e) {
        if (e == null) return null;
        if (typeof e == "function") return e.displayName || e.name || null;
        if (typeof e == "string") return e;
        switch (e) {
            case Dn:
                return "Fragment";
            case Mn:
                return "Portal";
            case ka:
                return "Profiler";
            case Ea:
                return "StrictMode";
            case La:
                return "Suspense";
            case Pa:
                return "SuspenseList"
        }
        if (typeof e == "object") switch (e.$$typeof) {
            case Mu:
                return (e.displayName || "Context") + ".Consumer";
            case Ru:
                return (e._context.displayName || "Context") + ".Provider";
            case Oa:
                var t = e.render;
                return e = e.displayName, e || (e = t.displayName || t.name || "", e = e !== "" ? "ForwardRef(" + e + ")" : "ForwardRef"), e;
            case Ia:
                return t = e.displayName || null, t !== null ? t : Ma(e.type) || "Memo";
            case Nt:
                t = e._payload, e = e._init;
                try {
                    return Ma(e(t))
                } catch {}
        }
        return null
    }

    function Fv(e) {
        var t = e.type;
        switch (e.tag) {
            case 24:
                return "Cache";
            case 9:
                return (t.displayName || "Context") + ".Consumer";
            case 10:
                return (t._context.displayName || "Context") + ".Provider";
            case 18:
                return "DehydratedFragment";
            case 11:
                return e = t.render, e = e.displayName || e.name || "", t.displayName || (e !== "" ? "ForwardRef(" + e + ")" : "ForwardRef");
            case 7:
                return "Fragment";
            case 5:
                return t;
            case 4:
                return "Portal";
            case 3:
                return "Root";
            case 6:
                return "Text";
            case 16:
                return Ma(t);
            case 8:
                return t === Ea ? "StrictMode" : "Mode";
            case 22:
                return "Offscreen";
            case 12:
                return "Profiler";
            case 21:
                return "Scope";
            case 13:
                return "Suspense";
            case 19:
                return "SuspenseList";
            case 25:
                return "TracingMarker";
            case 1:
            case 0:
            case 17:
            case 2:
            case 14:
            case 15:
                if (typeof t == "function") return t.displayName || t.name || null;
                if (typeof t == "string") return t
        }
        return null
    }

    function _t(e) {
        switch (typeof e) {
            case "boolean":
            case "number":
            case "string":
            case "undefined":
                return e;
            case "object":
                return e;
            default:
                return ""
        }
    }

    function zu(e) {
        var t = e.type;
        return (e = e.nodeName) && e.toLowerCase() === "input" && (t === "checkbox" || t === "radio")
    }

    function Tv(e) {
        var t = zu(e) ? "checked" : "value",
            n = Object.getOwnPropertyDescriptor(e.constructor.prototype, t),
            r = "" + e[t];
        if (!e.hasOwnProperty(t) && typeof n < "u" && typeof n.get == "function" && typeof n.set == "function") {
            var o = n.get,
                i = n.set;
            return Object.defineProperty(e, t, {
                configurable: !0,
                get: function() {
                    return o.call(this)
                },
                set: function(a) {
                    r = "" + a, i.call(this, a)
                }
            }), Object.defineProperty(e, t, {
                enumerable: n.enumerable
            }), {
                getValue: function() {
                    return r
                },
                setValue: function(a) {
                    r = "" + a
                },
                stopTracking: function() {
                    e._valueTracker = null, delete e[t]
                }
            }
        }
    }

    function Io(e) {
        e._valueTracker || (e._valueTracker = Tv(e))
    }

    function Fu(e) {
        if (!e) return !1;
        var t = e._valueTracker;
        if (!t) return !0;
        var n = t.getValue(),
            r = "";
        return e && (r = zu(e) ? e.checked ? "true" : "false" : e.value), e = r, e !== n ? (t.setValue(e), !0) : !1
    }

    function No(e) {
        if (e = e || (typeof document < "u" ? document : void 0), typeof e > "u") return null;
        try {
            return e.activeElement || e.body
        } catch {
            return e.body
        }
    }

    function Da(e, t) {
        var n = t.checked;
        return Q({}, t, {
            defaultChecked: void 0,
            defaultValue: void 0,
            value: void 0,
            checked: n ? ? e._wrapperState.initialChecked
        })
    }

    function Tu(e, t) {
        var n = t.defaultValue == null ? "" : t.defaultValue,
            r = t.checked != null ? t.checked : t.defaultChecked;
        n = _t(t.value != null ? t.value : n), e._wrapperState = {
            initialChecked: r,
            initialValue: n,
            controlled: t.type === "checkbox" || t.type === "radio" ? t.checked != null : t.value != null
        }
    }

    function bu(e, t) {
        t = t.checked, t != null && xa(e, "checked", t, !1)
    }

    function ja(e, t) {
        bu(e, t);
        var n = _t(t.value),
            r = t.type;
        if (n != null) r === "number" ? (n === 0 && e.value === "" || e.value != n) && (e.value = "" + n) : e.value !== "" + n && (e.value = "" + n);
        else if (r === "submit" || r === "reset") {
            e.removeAttribute("value");
            return
        }
        t.hasOwnProperty("value") ? za(e, t.type, n) : t.hasOwnProperty("defaultValue") && za(e, t.type, _t(t.defaultValue)), t.checked == null && t.defaultChecked != null && (e.defaultChecked = !!t.defaultChecked)
    }

    function Au(e, t, n) {
        if (t.hasOwnProperty("value") || t.hasOwnProperty("defaultValue")) {
            var r = t.type;
            if (!(r !== "submit" && r !== "reset" || t.value !== void 0 && t.value !== null)) return;
            t = "" + e._wrapperState.initialValue, n || t === e.value || (e.value = t), e.defaultValue = t
        }
        n = e.name, n !== "" && (e.name = ""), e.defaultChecked = !!e._wrapperState.initialChecked, n !== "" && (e.name = n)
    }

    function za(e, t, n) {
        (t !== "number" || No(e.ownerDocument) !== e) && (n == null ? e.defaultValue = "" + e._wrapperState.initialValue : e.defaultValue !== "" + n && (e.defaultValue = "" + n))
    }
    var Er = Array.isArray;

    function jn(e, t, n, r) {
        if (e = e.options, t) {
            t = {};
            for (var o = 0; o < n.length; o++) t["$" + n[o]] = !0;
            for (n = 0; n < e.length; n++) o = t.hasOwnProperty("$" + e[n].value), e[n].selected !== o && (e[n].selected = o), o && r && (e[n].defaultSelected = !0)
        } else {
            for (n = "" + _t(n), t = null, o = 0; o < e.length; o++) {
                if (e[o].value === n) {
                    e[o].selected = !0, r && (e[o].defaultSelected = !0);
                    return
                }
                t !== null || e[o].disabled || (t = e[o])
            }
            t !== null && (t.selected = !0)
        }
    }

    function Fa(e, t) {
        if (t.dangerouslySetInnerHTML != null) throw Error(x(91));
        return Q({}, t, {
            value: void 0,
            defaultValue: void 0,
            children: "" + e._wrapperState.initialValue
        })
    }

    function Uu(e, t) {
        var n = t.value;
        if (n == null) {
            if (n = t.children, t = t.defaultValue, n != null) {
                if (t != null) throw Error(x(92));
                if (Er(n)) {
                    if (1 < n.length) throw Error(x(93));
                    n = n[0]
                }
                t = n
            }
            t == null && (t = ""), n = t
        }
        e._wrapperState = {
            initialValue: _t(n)
        }
    }

    function Bu(e, t) {
        var n = _t(t.value),
            r = _t(t.defaultValue);
        n != null && (n = "" + n, n !== e.value && (e.value = n), t.defaultValue == null && e.defaultValue !== n && (e.defaultValue = n)), r != null && (e.defaultValue = "" + r)
    }

    function $u(e) {
        var t = e.textContent;
        t === e._wrapperState.initialValue && t !== "" && t !== null && (e.value = t)
    }

    function Vu(e) {
        switch (e) {
            case "svg":
                return "http://www.w3.org/2000/svg";
            case "math":
                return "http://www.w3.org/1998/Math/MathML";
            default:
                return "http://www.w3.org/1999/xhtml"
        }
    }

    function Ta(e, t) {
        return e == null || e === "http://www.w3.org/1999/xhtml" ? Vu(t) : e === "http://www.w3.org/2000/svg" && t === "foreignObject" ? "http://www.w3.org/1999/xhtml" : e
    }
    var _o, Hu = function(e) {
        return typeof MSApp < "u" && MSApp.execUnsafeLocalFunction ? function(t, n, r, o) {
            MSApp.execUnsafeLocalFunction(function() {
                return e(t, n, r, o)
            })
        } : e
    }(function(e, t) {
        if (e.namespaceURI !== "http://www.w3.org/2000/svg" || "innerHTML" in e) e.innerHTML = t;
        else {
            for (_o = _o || document.createElement("div"), _o.innerHTML = "<svg>" + t.valueOf().toString() + "</svg>", t = _o.firstChild; e.firstChild;) e.removeChild(e.firstChild);
            for (; t.firstChild;) e.appendChild(t.firstChild)
        }
    });

    function kr(e, t) {
        if (t) {
            var n = e.firstChild;
            if (n && n === e.lastChild && n.nodeType === 3) {
                n.nodeValue = t;
                return
            }
        }
        e.textContent = t
    }
    var Or = {
            animationIterationCount: !0,
            aspectRatio: !0,
            borderImageOutset: !0,
            borderImageSlice: !0,
            borderImageWidth: !0,
            boxFlex: !0,
            boxFlexGroup: !0,
            boxOrdinalGroup: !0,
            columnCount: !0,
            columns: !0,
            flex: !0,
            flexGrow: !0,
            flexPositive: !0,
            flexShrink: !0,
            flexNegative: !0,
            flexOrder: !0,
            gridArea: !0,
            gridRow: !0,
            gridRowEnd: !0,
            gridRowSpan: !0,
            gridRowStart: !0,
            gridColumn: !0,
            gridColumnEnd: !0,
            gridColumnSpan: !0,
            gridColumnStart: !0,
            fontWeight: !0,
            lineClamp: !0,
            lineHeight: !0,
            opacity: !0,
            order: !0,
            orphans: !0,
            tabSize: !0,
            widows: !0,
            zIndex: !0,
            zoom: !0,
            fillOpacity: !0,
            floodOpacity: !0,
            stopOpacity: !0,
            strokeDasharray: !0,
            strokeDashoffset: !0,
            strokeMiterlimit: !0,
            strokeOpacity: !0,
            strokeWidth: !0
        },
        bv = ["Webkit", "ms", "Moz", "O"];
    Object.keys(Or).forEach(function(e) {
        bv.forEach(function(t) {
            t = t + e.charAt(0).toUpperCase() + e.substring(1), Or[t] = Or[e]
        })
    });

    function Gu(e, t, n) {
        return t == null || typeof t == "boolean" || t === "" ? "" : n || typeof t != "number" || t === 0 || Or.hasOwnProperty(e) && Or[e] ? ("" + t).trim() : t + "px"
    }

    function Wu(e, t) {
        e = e.style;
        for (var n in t)
            if (t.hasOwnProperty(n)) {
                var r = n.indexOf("--") === 0,
                    o = Gu(n, t[n], r);
                n === "float" && (n = "cssFloat"), r ? e.setProperty(n, o) : e[n] = o
            }
    }
    var Av = Q({
        menuitem: !0
    }, {
        area: !0,
        base: !0,
        br: !0,
        col: !0,
        embed: !0,
        hr: !0,
        img: !0,
        input: !0,
        keygen: !0,
        link: !0,
        meta: !0,
        param: !0,
        source: !0,
        track: !0,
        wbr: !0
    });

    function ba(e, t) {
        if (t) {
            if (Av[e] && (t.children != null || t.dangerouslySetInnerHTML != null)) throw Error(x(137, e));
            if (t.dangerouslySetInnerHTML != null) {
                if (t.children != null) throw Error(x(60));
                if (typeof t.dangerouslySetInnerHTML != "object" || !("__html" in t.dangerouslySetInnerHTML)) throw Error(x(61))
            }
            if (t.style != null && typeof t.style != "object") throw Error(x(62))
        }
    }

    function Aa(e, t) {
        if (e.indexOf("-") === -1) return typeof t.is == "string";
        switch (e) {
            case "annotation-xml":
            case "color-profile":
            case "font-face":
            case "font-face-src":
            case "font-face-uri":
            case "font-face-format":
            case "font-face-name":
            case "missing-glyph":
                return !1;
            default:
                return !0
        }
    }
    var Ua = null;

    function Ba(e) {
        return e = e.target || e.srcElement || window, e.correspondingUseElement && (e = e.correspondingUseElement), e.nodeType === 3 ? e.parentNode : e
    }
    var $a = null,
        zn = null,
        Fn = null;

    function Ku(e) {
        if (e = Kr(e)) {
            if (typeof $a != "function") throw Error(x(280));
            var t = e.stateNode;
            t && (t = Xo(t), $a(e.stateNode, e.type, t))
        }
    }

    function Qu(e) {
        zn ? Fn ? Fn.push(e) : Fn = [e] : zn = e
    }

    function Yu() {
        if (zn) {
            var e = zn,
                t = Fn;
            if (Fn = zn = null, Ku(e), t)
                for (e = 0; e < t.length; e++) Ku(t[e])
        }
    }

    function Ju(e, t) {
        return e(t)
    }

    function Zu() {}
    var Va = !1;

    function qu(e, t, n) {
        if (Va) return e(t, n);
        Va = !0;
        try {
            return Ju(e, t, n)
        } finally {
            Va = !1, (zn !== null || Fn !== null) && (Zu(), Yu())
        }
    }

    function Lr(e, t) {
        var n = e.stateNode;
        if (n === null) return null;
        var r = Xo(n);
        if (r === null) return null;
        n = r[t];
        e: switch (t) {
            case "onClick":
            case "onClickCapture":
            case "onDoubleClick":
            case "onDoubleClickCapture":
            case "onMouseDown":
            case "onMouseDownCapture":
            case "onMouseMove":
            case "onMouseMoveCapture":
            case "onMouseUp":
            case "onMouseUpCapture":
            case "onMouseEnter":
                (r = !r.disabled) || (e = e.type, r = !(e === "button" || e === "input" || e === "select" || e === "textarea")), e = !r;
                break e;
            default:
                e = !1
        }
        if (e) return null;
        if (n && typeof n != "function") throw Error(x(231, t, typeof n));
        return n
    }
    var Ha = !1;
    if (dt) try {
        var Pr = {};
        Object.defineProperty(Pr, "passive", {
            get: function() {
                Ha = !0
            }
        }), window.addEventListener("test", Pr, Pr), window.removeEventListener("test", Pr, Pr)
    } catch {
        Ha = !1
    }

    function Uv(e, t, n, r, o, i, a, l, s) {
        var u = Array.prototype.slice.call(arguments, 3);
        try {
            t.apply(n, u)
        } catch (c) {
            this.onError(c)
        }
    }
    var Ir = !1,
        Ro = null,
        Mo = !1,
        Ga = null,
        Bv = {
            onError: function(e) {
                Ir = !0, Ro = e
            }
        };

    function $v(e, t, n, r, o, i, a, l, s) {
        Ir = !1, Ro = null, Uv.apply(Bv, arguments)
    }

    function Vv(e, t, n, r, o, i, a, l, s) {
        if ($v.apply(this, arguments), Ir) {
            if (Ir) {
                var u = Ro;
                Ir = !1, Ro = null
            } else throw Error(x(198));
            Mo || (Mo = !0, Ga = u)
        }
    }

    function nn(e) {
        var t = e,
            n = e;
        if (e.alternate)
            for (; t.return;) t = t.return;
        else {
            e = t;
            do t = e, t.flags & 4098 && (n = t.return), e = t.return; while (e)
        }
        return t.tag === 3 ? n : null
    }

    function Xu(e) {
        if (e.tag === 13) {
            var t = e.memoizedState;
            if (t === null && (e = e.alternate, e !== null && (t = e.memoizedState)), t !== null) return t.dehydrated
        }
        return null
    }

    function ec(e) {
        if (nn(e) !== e) throw Error(x(188))
    }

    function Hv(e) {
        var t = e.alternate;
        if (!t) {
            if (t = nn(e), t === null) throw Error(x(188));
            return t !== e ? null : e
        }
        for (var n = e, r = t;;) {
            var o = n.return;
            if (o === null) break;
            var i = o.alternate;
            if (i === null) {
                if (r = o.return, r !== null) {
                    n = r;
                    continue
                }
                break
            }
            if (o.child === i.child) {
                for (i = o.child; i;) {
                    if (i === n) return ec(o), e;
                    if (i === r) return ec(o), t;
                    i = i.sibling
                }
                throw Error(x(188))
            }
            if (n.return !== r.return) n = o, r = i;
            else {
                for (var a = !1, l = o.child; l;) {
                    if (l === n) {
                        a = !0, n = o, r = i;
                        break
                    }
                    if (l === r) {
                        a = !0, r = o, n = i;
                        break
                    }
                    l = l.sibling
                }
                if (!a) {
                    for (l = i.child; l;) {
                        if (l === n) {
                            a = !0, n = i, r = o;
                            break
                        }
                        if (l === r) {
                            a = !0, r = i, n = o;
                            break
                        }
                        l = l.sibling
                    }
                    if (!a) throw Error(x(189))
                }
            }
            if (n.alternate !== r) throw Error(x(190))
        }
        if (n.tag !== 3) throw Error(x(188));
        return n.stateNode.current === n ? e : t
    }

    function tc(e) {
        return e = Hv(e), e !== null ? nc(e) : null
    }

    function nc(e) {
        if (e.tag === 5 || e.tag === 6) return e;
        for (e = e.child; e !== null;) {
            var t = nc(e);
            if (t !== null) return t;
            e = e.sibling
        }
        return null
    }
    var rc = De.unstable_scheduleCallback,
        oc = De.unstable_cancelCallback,
        Gv = De.unstable_shouldYield,
        Wv = De.unstable_requestPaint,
        te = De.unstable_now,
        Kv = De.unstable_getCurrentPriorityLevel,
        Wa = De.unstable_ImmediatePriority,
        ic = De.unstable_UserBlockingPriority,
        Do = De.unstable_NormalPriority,
        Qv = De.unstable_LowPriority,
        ac = De.unstable_IdlePriority,
        jo = null,
        rt = null;

    function Yv(e) {
        if (rt && typeof rt.onCommitFiberRoot == "function") try {
            rt.onCommitFiberRoot(jo, e, void 0, (e.current.flags & 128) === 128)
        } catch {}
    }
    var We = Math.clz32 ? Math.clz32 : qv,
        Jv = Math.log,
        Zv = Math.LN2;

    function qv(e) {
        return e >>>= 0, e === 0 ? 32 : 31 - (Jv(e) / Zv | 0) | 0
    }
    var zo = 64,
        Fo = 4194304;

    function Nr(e) {
        switch (e & -e) {
            case 1:
                return 1;
            case 2:
                return 2;
            case 4:
                return 4;
            case 8:
                return 8;
            case 16:
                return 16;
            case 32:
                return 32;
            case 64:
            case 128:
            case 256:
            case 512:
            case 1024:
            case 2048:
            case 4096:
            case 8192:
            case 16384:
            case 32768:
            case 65536:
            case 131072:
            case 262144:
            case 524288:
            case 1048576:
            case 2097152:
                return e & 4194240;
            case 4194304:
            case 8388608:
            case 16777216:
            case 33554432:
            case 67108864:
                return e & 130023424;
            case 134217728:
                return 134217728;
            case 268435456:
                return 268435456;
            case 536870912:
                return 536870912;
            case 1073741824:
                return 1073741824;
            default:
                return e
        }
    }

    function To(e, t) {
        var n = e.pendingLanes;
        if (n === 0) return 0;
        var r = 0,
            o = e.suspendedLanes,
            i = e.pingedLanes,
            a = n & 268435455;
        if (a !== 0) {
            var l = a & ~o;
            l !== 0 ? r = Nr(l) : (i &= a, i !== 0 && (r = Nr(i)))
        } else a = n & ~o, a !== 0 ? r = Nr(a) : i !== 0 && (r = Nr(i));
        if (r === 0) return 0;
        if (t !== 0 && t !== r && !(t & o) && (o = r & -r, i = t & -t, o >= i || o === 16 && (i & 4194240) !== 0)) return t;
        if (r & 4 && (r |= n & 16), t = e.entangledLanes, t !== 0)
            for (e = e.entanglements, t &= r; 0 < t;) n = 31 - We(t), o = 1 << n, r |= e[n], t &= ~o;
        return r
    }

    function Xv(e, t) {
        switch (e) {
            case 1:
            case 2:
            case 4:
                return t + 250;
            case 8:
            case 16:
            case 32:
            case 64:
            case 128:
            case 256:
            case 512:
            case 1024:
            case 2048:
            case 4096:
            case 8192:
            case 16384:
            case 32768:
            case 65536:
            case 131072:
            case 262144:
            case 524288:
            case 1048576:
            case 2097152:
                return t + 5e3;
            case 4194304:
            case 8388608:
            case 16777216:
            case 33554432:
            case 67108864:
                return -1;
            case 134217728:
            case 268435456:
            case 536870912:
            case 1073741824:
                return -1;
            default:
                return -1
        }
    }

    function eg(e, t) {
        for (var n = e.suspendedLanes, r = e.pingedLanes, o = e.expirationTimes, i = e.pendingLanes; 0 < i;) {
            var a = 31 - We(i),
                l = 1 << a,
                s = o[a];
            s === -1 ? (!(l & n) || l & r) && (o[a] = Xv(l, t)) : s <= t && (e.expiredLanes |= l), i &= ~l
        }
    }

    function Ka(e) {
        return e = e.pendingLanes & -1073741825, e !== 0 ? e : e & 1073741824 ? 1073741824 : 0
    }

    function lc() {
        var e = zo;
        return zo <<= 1, !(zo & 4194240) && (zo = 64), e
    }

    function Qa(e) {
        for (var t = [], n = 0; 31 > n; n++) t.push(e);
        return t
    }

    function _r(e, t, n) {
        e.pendingLanes |= t, t !== 536870912 && (e.suspendedLanes = 0, e.pingedLanes = 0), e = e.eventTimes, t = 31 - We(t), e[t] = n
    }

    function tg(e, t) {
        var n = e.pendingLanes & ~t;
        e.pendingLanes = t, e.suspendedLanes = 0, e.pingedLanes = 0, e.expiredLanes &= t, e.mutableReadLanes &= t, e.entangledLanes &= t, t = e.entanglements;
        var r = e.eventTimes;
        for (e = e.expirationTimes; 0 < n;) {
            var o = 31 - We(n),
                i = 1 << o;
            t[o] = 0, r[o] = -1, e[o] = -1, n &= ~i
        }
    }

    function Ya(e, t) {
        var n = e.entangledLanes |= t;
        for (e = e.entanglements; n;) {
            var r = 31 - We(n),
                o = 1 << r;
            o & t | e[r] & t && (e[r] |= t), n &= ~o
        }
    }
    var U = 0;

    function sc(e) {
        return e &= -e, 1 < e ? 4 < e ? e & 268435455 ? 16 : 536870912 : 4 : 1
    }
    var uc, Ja, cc, fc, dc, Za = !1,
        bo = [],
        Rt = null,
        Mt = null,
        Dt = null,
        Rr = new Map,
        Mr = new Map,
        jt = [],
        ng = "mousedown mouseup touchcancel touchend touchstart auxclick dblclick pointercancel pointerdown pointerup dragend dragstart drop compositionend compositionstart keydown keypress keyup input textInput copy cut paste click change contextmenu reset submit".split(" ");

    function pc(e, t) {
        switch (e) {
            case "focusin":
            case "focusout":
                Rt = null;
                break;
            case "dragenter":
            case "dragleave":
                Mt = null;
                break;
            case "mouseover":
            case "mouseout":
                Dt = null;
                break;
            case "pointerover":
            case "pointerout":
                Rr.delete(t.pointerId);
                break;
            case "gotpointercapture":
            case "lostpointercapture":
                Mr.delete(t.pointerId)
        }
    }

    function Dr(e, t, n, r, o, i) {
        return e === null || e.nativeEvent !== i ? (e = {
            blockedOn: t,
            domEventName: n,
            eventSystemFlags: r,
            nativeEvent: i,
            targetContainers: [o]
        }, t !== null && (t = Kr(t), t !== null && Ja(t)), e) : (e.eventSystemFlags |= r, t = e.targetContainers, o !== null && t.indexOf(o) === -1 && t.push(o), e)
    }

    function rg(e, t, n, r, o) {
        switch (t) {
            case "focusin":
                return Rt = Dr(Rt, e, t, n, r, o), !0;
            case "dragenter":
                return Mt = Dr(Mt, e, t, n, r, o), !0;
            case "mouseover":
                return Dt = Dr(Dt, e, t, n, r, o), !0;
            case "pointerover":
                var i = o.pointerId;
                return Rr.set(i, Dr(Rr.get(i) || null, e, t, n, r, o)), !0;
            case "gotpointercapture":
                return i = o.pointerId, Mr.set(i, Dr(Mr.get(i) || null, e, t, n, r, o)), !0
        }
        return !1
    }

    function vc(e) {
        var t = rn(e.target);
        if (t !== null) {
            var n = nn(t);
            if (n !== null) {
                if (t = n.tag, t === 13) {
                    if (t = Xu(n), t !== null) {
                        e.blockedOn = t, dc(e.priority, function() {
                            cc(n)
                        });
                        return
                    }
                } else if (t === 3 && n.stateNode.current.memoizedState.isDehydrated) {
                    e.blockedOn = n.tag === 3 ? n.stateNode.containerInfo : null;
                    return
                }
            }
        }
        e.blockedOn = null
    }

    function Ao(e) {
        if (e.blockedOn !== null) return !1;
        for (var t = e.targetContainers; 0 < t.length;) {
            var n = Xa(e.domEventName, e.eventSystemFlags, t[0], e.nativeEvent);
            if (n === null) {
                n = e.nativeEvent;
                var r = new n.constructor(n.type, n);
                Ua = r, n.target.dispatchEvent(r), Ua = null
            } else return t = Kr(n), t !== null && Ja(t), e.blockedOn = n, !1;
            t.shift()
        }
        return !0
    }

    function gc(e, t, n) {
        Ao(e) && n.delete(t)
    }

    function og() {
        Za = !1, Rt !== null && Ao(Rt) && (Rt = null), Mt !== null && Ao(Mt) && (Mt = null), Dt !== null && Ao(Dt) && (Dt = null), Rr.forEach(gc), Mr.forEach(gc)
    }

    function jr(e, t) {
        e.blockedOn === t && (e.blockedOn = null, Za || (Za = !0, De.unstable_scheduleCallback(De.unstable_NormalPriority, og)))
    }

    function zr(e) {
        function t(o) {
            return jr(o, e)
        }
        if (0 < bo.length) {
            jr(bo[0], e);
            for (var n = 1; n < bo.length; n++) {
                var r = bo[n];
                r.blockedOn === e && (r.blockedOn = null)
            }
        }
        for (Rt !== null && jr(Rt, e), Mt !== null && jr(Mt, e), Dt !== null && jr(Dt, e), Rr.forEach(t), Mr.forEach(t), n = 0; n < jt.length; n++) r = jt[n], r.blockedOn === e && (r.blockedOn = null);
        for (; 0 < jt.length && (n = jt[0], n.blockedOn === null);) vc(n), n.blockedOn === null && jt.shift()
    }
    var Tn = pt.ReactCurrentBatchConfig,
        Uo = !0;

    function ig(e, t, n, r) {
        var o = U,
            i = Tn.transition;
        Tn.transition = null;
        try {
            U = 1, qa(e, t, n, r)
        } finally {
            U = o, Tn.transition = i
        }
    }

    function ag(e, t, n, r) {
        var o = U,
            i = Tn.transition;
        Tn.transition = null;
        try {
            U = 4, qa(e, t, n, r)
        } finally {
            U = o, Tn.transition = i
        }
    }

    function qa(e, t, n, r) {
        if (Uo) {
            var o = Xa(e, t, n, r);
            if (o === null) hl(e, t, r, Bo, n), pc(e, r);
            else if (rg(o, e, t, n, r)) r.stopPropagation();
            else if (pc(e, r), t & 4 && -1 < ng.indexOf(e)) {
                for (; o !== null;) {
                    var i = Kr(o);
                    if (i !== null && uc(i), i = Xa(e, t, n, r), i === null && hl(e, t, r, Bo, n), i === o) break;
                    o = i
                }
                o !== null && r.stopPropagation()
            } else hl(e, t, r, null, n)
        }
    }
    var Bo = null;

    function Xa(e, t, n, r) {
        if (Bo = null, e = Ba(r), e = rn(e), e !== null)
            if (t = nn(e), t === null) e = null;
            else if (n = t.tag, n === 13) {
            if (e = Xu(t), e !== null) return e;
            e = null
        } else if (n === 3) {
            if (t.stateNode.current.memoizedState.isDehydrated) return t.tag === 3 ? t.stateNode.containerInfo : null;
            e = null
        } else t !== e && (e = null);
        return Bo = e, null
    }

    function hc(e) {
        switch (e) {
            case "cancel":
            case "click":
            case "close":
            case "contextmenu":
            case "copy":
            case "cut":
            case "auxclick":
            case "dblclick":
            case "dragend":
            case "dragstart":
            case "drop":
            case "focusin":
            case "focusout":
            case "input":
            case "invalid":
            case "keydown":
            case "keypress":
            case "keyup":
            case "mousedown":
            case "mouseup":
            case "paste":
            case "pause":
            case "play":
            case "pointercancel":
            case "pointerdown":
            case "pointerup":
            case "ratechange":
            case "reset":
            case "resize":
            case "seeked":
            case "submit":
            case "touchcancel":
            case "touchend":
            case "touchstart":
            case "volumechange":
            case "change":
            case "selectionchange":
            case "textInput":
            case "compositionstart":
            case "compositionend":
            case "compositionupdate":
            case "beforeblur":
            case "afterblur":
            case "beforeinput":
            case "blur":
            case "fullscreenchange":
            case "focus":
            case "hashchange":
            case "popstate":
            case "select":
            case "selectstart":
                return 1;
            case "drag":
            case "dragenter":
            case "dragexit":
            case "dragleave":
            case "dragover":
            case "mousemove":
            case "mouseout":
            case "mouseover":
            case "pointermove":
            case "pointerout":
            case "pointerover":
            case "scroll":
            case "toggle":
            case "touchmove":
            case "wheel":
            case "mouseenter":
            case "mouseleave":
            case "pointerenter":
            case "pointerleave":
                return 4;
            case "message":
                switch (Kv()) {
                    case Wa:
                        return 1;
                    case ic:
                        return 4;
                    case Do:
                    case Qv:
                        return 16;
                    case ac:
                        return 536870912;
                    default:
                        return 16
                }
            default:
                return 16
        }
    }
    var zt = null,
        el = null,
        $o = null;

    function mc() {
        if ($o) return $o;
        var e, t = el,
            n = t.length,
            r, o = "value" in zt ? zt.value : zt.textContent,
            i = o.length;
        for (e = 0; e < n && t[e] === o[e]; e++);
        var a = n - e;
        for (r = 1; r <= a && t[n - r] === o[i - r]; r++);
        return $o = o.slice(e, 1 < r ? 1 - r : void 0)
    }

    function Vo(e) {
        var t = e.keyCode;
        return "charCode" in e ? (e = e.charCode, e === 0 && t === 13 && (e = 13)) : e = t, e === 10 && (e = 13), 32 <= e || e === 13 ? e : 0
    }

    function Ho() {
        return !0
    }

    function yc() {
        return !1
    }

    function je(e) {
        function t(n, r, o, i, a) {
            this._reactName = n, this._targetInst = o, this.type = r, this.nativeEvent = i, this.target = a, this.currentTarget = null;
            for (var l in e) e.hasOwnProperty(l) && (n = e[l], this[l] = n ? n(i) : i[l]);
            return this.isDefaultPrevented = (i.defaultPrevented != null ? i.defaultPrevented : i.returnValue === !1) ? Ho : yc, this.isPropagationStopped = yc, this
        }
        return Q(t.prototype, {
            preventDefault: function() {
                this.defaultPrevented = !0;
                var n = this.nativeEvent;
                n && (n.preventDefault ? n.preventDefault() : typeof n.returnValue != "unknown" && (n.returnValue = !1), this.isDefaultPrevented = Ho)
            },
            stopPropagation: function() {
                var n = this.nativeEvent;
                n && (n.stopPropagation ? n.stopPropagation() : typeof n.cancelBubble != "unknown" && (n.cancelBubble = !0), this.isPropagationStopped = Ho)
            },
            persist: function() {},
            isPersistent: Ho
        }), t
    }
    var bn = {
            eventPhase: 0,
            bubbles: 0,
            cancelable: 0,
            timeStamp: function(e) {
                return e.timeStamp || Date.now()
            },
            defaultPrevented: 0,
            isTrusted: 0
        },
        tl = je(bn),
        Fr = Q({}, bn, {
            view: 0,
            detail: 0
        }),
        lg = je(Fr),
        nl, rl, Tr, Go = Q({}, Fr, {
            screenX: 0,
            screenY: 0,
            clientX: 0,
            clientY: 0,
            pageX: 0,
            pageY: 0,
            ctrlKey: 0,
            shiftKey: 0,
            altKey: 0,
            metaKey: 0,
            getModifierState: il,
            button: 0,
            buttons: 0,
            relatedTarget: function(e) {
                return e.relatedTarget === void 0 ? e.fromElement === e.srcElement ? e.toElement : e.fromElement : e.relatedTarget
            },
            movementX: function(e) {
                return "movementX" in e ? e.movementX : (e !== Tr && (Tr && e.type === "mousemove" ? (nl = e.screenX - Tr.screenX, rl = e.screenY - Tr.screenY) : rl = nl = 0, Tr = e), nl)
            },
            movementY: function(e) {
                return "movementY" in e ? e.movementY : rl
            }
        }),
        wc = je(Go),
        sg = Q({}, Go, {
            dataTransfer: 0
        }),
        ug = je(sg),
        cg = Q({}, Fr, {
            relatedTarget: 0
        }),
        ol = je(cg),
        fg = Q({}, bn, {
            animationName: 0,
            elapsedTime: 0,
            pseudoElement: 0
        }),
        dg = je(fg),
        pg = Q({}, bn, {
            clipboardData: function(e) {
                return "clipboardData" in e ? e.clipboardData : window.clipboardData
            }
        }),
        vg = je(pg),
        gg = Q({}, bn, {
            data: 0
        }),
        Cc = je(gg),
        hg = {
            Esc: "Escape",
            Spacebar: " ",
            Left: "ArrowLeft",
            Up: "ArrowUp",
            Right: "ArrowRight",
            Down: "ArrowDown",
            Del: "Delete",
            Win: "OS",
            Menu: "ContextMenu",
            Apps: "ContextMenu",
            Scroll: "ScrollLock",
            MozPrintableKey: "Unidentified"
        },
        mg = {
            8: "Backspace",
            9: "Tab",
            12: "Clear",
            13: "Enter",
            16: "Shift",
            17: "Control",
            18: "Alt",
            19: "Pause",
            20: "CapsLock",
            27: "Escape",
            32: " ",
            33: "PageUp",
            34: "PageDown",
            35: "End",
            36: "Home",
            37: "ArrowLeft",
            38: "ArrowUp",
            39: "ArrowRight",
            40: "ArrowDown",
            45: "Insert",
            46: "Delete",
            112: "F1",
            113: "F2",
            114: "F3",
            115: "F4",
            116: "F5",
            117: "F6",
            118: "F7",
            119: "F8",
            120: "F9",
            121: "F10",
            122: "F11",
            123: "F12",
            144: "NumLock",
            145: "ScrollLock",
            224: "Meta"
        },
        yg = {
            Alt: "altKey",
            Control: "ctrlKey",
            Meta: "metaKey",
            Shift: "shiftKey"
        };

    function wg(e) {
        var t = this.nativeEvent;
        return t.getModifierState ? t.getModifierState(e) : (e = yg[e]) ? !!t[e] : !1
    }

    function il() {
        return wg
    }
    var Cg = Q({}, Fr, {
            key: function(e) {
                if (e.key) {
                    var t = hg[e.key] || e.key;
                    if (t !== "Unidentified") return t
                }
                return e.type === "keypress" ? (e = Vo(e), e === 13 ? "Enter" : String.fromCharCode(e)) : e.type === "keydown" || e.type === "keyup" ? mg[e.keyCode] || "Unidentified" : ""
            },
            code: 0,
            location: 0,
            ctrlKey: 0,
            shiftKey: 0,
            altKey: 0,
            metaKey: 0,
            repeat: 0,
            locale: 0,
            getModifierState: il,
            charCode: function(e) {
                return e.type === "keypress" ? Vo(e) : 0
            },
            keyCode: function(e) {
                return e.type === "keydown" || e.type === "keyup" ? e.keyCode : 0
            },
            which: function(e) {
                return e.type === "keypress" ? Vo(e) : e.type === "keydown" || e.type === "keyup" ? e.keyCode : 0
            }
        }),
        Sg = je(Cg),
        xg = Q({}, Go, {
            pointerId: 0,
            width: 0,
            height: 0,
            pressure: 0,
            tangentialPressure: 0,
            tiltX: 0,
            tiltY: 0,
            twist: 0,
            pointerType: 0,
            isPrimary: 0
        }),
        Sc = je(xg),
        Eg = Q({}, Fr, {
            touches: 0,
            targetTouches: 0,
            changedTouches: 0,
            altKey: 0,
            metaKey: 0,
            ctrlKey: 0,
            shiftKey: 0,
            getModifierState: il
        }),
        kg = je(Eg),
        Og = Q({}, bn, {
            propertyName: 0,
            elapsedTime: 0,
            pseudoElement: 0
        }),
        Lg = je(Og),
        Pg = Q({}, Go, {
            deltaX: function(e) {
                return "deltaX" in e ? e.deltaX : "wheelDeltaX" in e ? -e.wheelDeltaX : 0
            },
            deltaY: function(e) {
                return "deltaY" in e ? e.deltaY : "wheelDeltaY" in e ? -e.wheelDeltaY : "wheelDelta" in e ? -e.wheelDelta : 0
            },
            deltaZ: 0,
            deltaMode: 0
        }),
        Ig = je(Pg),
        Ng = [9, 13, 27, 32],
        al = dt && "CompositionEvent" in window,
        br = null;
    dt && "documentMode" in document && (br = document.documentMode);
    var _g = dt && "TextEvent" in window && !br,
        xc = dt && (!al || br && 8 < br && 11 >= br),
        Ec = " ",
        kc = !1;

    function Oc(e, t) {
        switch (e) {
            case "keyup":
                return Ng.indexOf(t.keyCode) !== -1;
            case "keydown":
                return t.keyCode !== 229;
            case "keypress":
            case "mousedown":
            case "focusout":
                return !0;
            default:
                return !1
        }
    }

    function Lc(e) {
        return e = e.detail, typeof e == "object" && "data" in e ? e.data : null
    }
    var An = !1;

    function Rg(e, t) {
        switch (e) {
            case "compositionend":
                return Lc(t);
            case "keypress":
                return t.which !== 32 ? null : (kc = !0, Ec);
            case "textInput":
                return e = t.data, e === Ec && kc ? null : e;
            default:
                return null
        }
    }

    function Mg(e, t) {
        if (An) return e === "compositionend" || !al && Oc(e, t) ? (e = mc(), $o = el = zt = null, An = !1, e) : null;
        switch (e) {
            case "paste":
                return null;
            case "keypress":
                if (!(t.ctrlKey || t.altKey || t.metaKey) || t.ctrlKey && t.altKey) {
                    if (t.char && 1 < t.char.length) return t.char;
                    if (t.which) return String.fromCharCode(t.which)
                }
                return null;
            case "compositionend":
                return xc && t.locale !== "ko" ? null : t.data;
            default:
                return null
        }
    }
    var Dg = {
        color: !0,
        date: !0,
        datetime: !0,
        "datetime-local": !0,
        email: !0,
        month: !0,
        number: !0,
        password: !0,
        range: !0,
        search: !0,
        tel: !0,
        text: !0,
        time: !0,
        url: !0,
        week: !0
    };

    function Pc(e) {
        var t = e && e.nodeName && e.nodeName.toLowerCase();
        return t === "input" ? !!Dg[e.type] : t === "textarea"
    }

    function Ic(e, t, n, r) {
        Qu(r), t = Jo(t, "onChange"), 0 < t.length && (n = new tl("onChange", "change", null, n, r), e.push({
            event: n,
            listeners: t
        }))
    }
    var Ar = null,
        Ur = null;

    function jg(e) {
        Wc(e, 0)
    }

    function Wo(e) {
        var t = Hn(e);
        if (Fu(t)) return e
    }

    function zg(e, t) {
        if (e === "change") return t
    }
    var Nc = !1;
    if (dt) {
        var ll;
        if (dt) {
            var sl = "oninput" in document;
            if (!sl) {
                var _c = document.createElement("div");
                _c.setAttribute("oninput", "return;"), sl = typeof _c.oninput == "function"
            }
            ll = sl
        } else ll = !1;
        Nc = ll && (!document.documentMode || 9 < document.documentMode)
    }

    function Rc() {
        Ar && (Ar.detachEvent("onpropertychange", Mc), Ur = Ar = null)
    }

    function Mc(e) {
        if (e.propertyName === "value" && Wo(Ur)) {
            var t = [];
            Ic(t, Ur, e, Ba(e)), qu(jg, t)
        }
    }

    function Fg(e, t, n) {
        e === "focusin" ? (Rc(), Ar = t, Ur = n, Ar.attachEvent("onpropertychange", Mc)) : e === "focusout" && Rc()
    }

    function Tg(e) {
        if (e === "selectionchange" || e === "keyup" || e === "keydown") return Wo(Ur)
    }

    function bg(e, t) {
        if (e === "click") return Wo(t)
    }

    function Ag(e, t) {
        if (e === "input" || e === "change") return Wo(t)
    }

    function Ug(e, t) {
        return e === t && (e !== 0 || 1 / e === 1 / t) || e !== e && t !== t
    }
    var Ke = typeof Object.is == "function" ? Object.is : Ug;

    function Br(e, t) {
        if (Ke(e, t)) return !0;
        if (typeof e != "object" || e === null || typeof t != "object" || t === null) return !1;
        var n = Object.keys(e),
            r = Object.keys(t);
        if (n.length !== r.length) return !1;
        for (r = 0; r < n.length; r++) {
            var o = n[r];
            if (!wa.call(t, o) || !Ke(e[o], t[o])) return !1
        }
        return !0
    }

    function Dc(e) {
        for (; e && e.firstChild;) e = e.firstChild;
        return e
    }

    function jc(e, t) {
        var n = Dc(e);
        e = 0;
        for (var r; n;) {
            if (n.nodeType === 3) {
                if (r = e + n.textContent.length, e <= t && r >= t) return {
                    node: n,
                    offset: t - e
                };
                e = r
            }
            e: {
                for (; n;) {
                    if (n.nextSibling) {
                        n = n.nextSibling;
                        break e
                    }
                    n = n.parentNode
                }
                n = void 0
            }
            n = Dc(n)
        }
    }

    function zc(e, t) {
        return e && t ? e === t ? !0 : e && e.nodeType === 3 ? !1 : t && t.nodeType === 3 ? zc(e, t.parentNode) : "contains" in e ? e.contains(t) : e.compareDocumentPosition ? !!(e.compareDocumentPosition(t) & 16) : !1 : !1
    }

    function Fc() {
        for (var e = window, t = No(); t instanceof e.HTMLIFrameElement;) {
            try {
                var n = typeof t.contentWindow.location.href == "string"
            } catch {
                n = !1
            }
            if (n) e = t.contentWindow;
            else break;
            t = No(e.document)
        }
        return t
    }

    function ul(e) {
        var t = e && e.nodeName && e.nodeName.toLowerCase();
        return t && (t === "input" && (e.type === "text" || e.type === "search" || e.type === "tel" || e.type === "url" || e.type === "password") || t === "textarea" || e.contentEditable === "true")
    }

    function Bg(e) {
        var t = Fc(),
            n = e.focusedElem,
            r = e.selectionRange;
        if (t !== n && n && n.ownerDocument && zc(n.ownerDocument.documentElement, n)) {
            if (r !== null && ul(n)) {
                if (t = r.start, e = r.end, e === void 0 && (e = t), "selectionStart" in n) n.selectionStart = t, n.selectionEnd = Math.min(e, n.value.length);
                else if (e = (t = n.ownerDocument || document) && t.defaultView || window, e.getSelection) {
                    e = e.getSelection();
                    var o = n.textContent.length,
                        i = Math.min(r.start, o);
                    r = r.end === void 0 ? i : Math.min(r.end, o), !e.extend && i > r && (o = r, r = i, i = o), o = jc(n, i);
                    var a = jc(n, r);
                    o && a && (e.rangeCount !== 1 || e.anchorNode !== o.node || e.anchorOffset !== o.offset || e.focusNode !== a.node || e.focusOffset !== a.offset) && (t = t.createRange(), t.setStart(o.node, o.offset), e.removeAllRanges(), i > r ? (e.addRange(t), e.extend(a.node, a.offset)) : (t.setEnd(a.node, a.offset), e.addRange(t)))
                }
            }
            for (t = [], e = n; e = e.parentNode;) e.nodeType === 1 && t.push({
                element: e,
                left: e.scrollLeft,
                top: e.scrollTop
            });
            for (typeof n.focus == "function" && n.focus(), n = 0; n < t.length; n++) e = t[n], e.element.scrollLeft = e.left, e.element.scrollTop = e.top
        }
    }
    var $g = dt && "documentMode" in document && 11 >= document.documentMode,
        Un = null,
        cl = null,
        $r = null,
        fl = !1;

    function Tc(e, t, n) {
        var r = n.window === n ? n.document : n.nodeType === 9 ? n : n.ownerDocument;
        fl || Un == null || Un !== No(r) || (r = Un, "selectionStart" in r && ul(r) ? r = {
            start: r.selectionStart,
            end: r.selectionEnd
        } : (r = (r.ownerDocument && r.ownerDocument.defaultView || window).getSelection(), r = {
            anchorNode: r.anchorNode,
            anchorOffset: r.anchorOffset,
            focusNode: r.focusNode,
            focusOffset: r.focusOffset
        }), $r && Br($r, r) || ($r = r, r = Jo(cl, "onSelect"), 0 < r.length && (t = new tl("onSelect", "select", null, t, n), e.push({
            event: t,
            listeners: r
        }), t.target = Un)))
    }

    function Ko(e, t) {
        var n = {};
        return n[e.toLowerCase()] = t.toLowerCase(), n["Webkit" + e] = "webkit" + t, n["Moz" + e] = "moz" + t, n
    }
    var Bn = {
            animationend: Ko("Animation", "AnimationEnd"),
            animationiteration: Ko("Animation", "AnimationIteration"),
            animationstart: Ko("Animation", "AnimationStart"),
            transitionend: Ko("Transition", "TransitionEnd")
        },
        dl = {},
        bc = {};
    dt && (bc = document.createElement("div").style, "AnimationEvent" in window || (delete Bn.animationend.animation, delete Bn.animationiteration.animation, delete Bn.animationstart.animation), "TransitionEvent" in window || delete Bn.transitionend.transition);

    function Qo(e) {
        if (dl[e]) return dl[e];
        if (!Bn[e]) return e;
        var t = Bn[e],
            n;
        for (n in t)
            if (t.hasOwnProperty(n) && n in bc) return dl[e] = t[n];
        return e
    }
    var Ac = Qo("animationend"),
        Uc = Qo("animationiteration"),
        Bc = Qo("animationstart"),
        $c = Qo("transitionend"),
        Vc = new Map,
        Hc = "abort auxClick cancel canPlay canPlayThrough click close contextMenu copy cut drag dragEnd dragEnter dragExit dragLeave dragOver dragStart drop durationChange emptied encrypted ended error gotPointerCapture input invalid keyDown keyPress keyUp load loadedData loadedMetadata loadStart lostPointerCapture mouseDown mouseMove mouseOut mouseOver mouseUp paste pause play playing pointerCancel pointerDown pointerMove pointerOut pointerOver pointerUp progress rateChange reset resize seeked seeking stalled submit suspend timeUpdate touchCancel touchEnd touchStart volumeChange scroll toggle touchMove waiting wheel".split(" ");

    function Ft(e, t) {
        Vc.set(e, t), tn(t, [e])
    }
    for (var pl = 0; pl < Hc.length; pl++) {
        var vl = Hc[pl],
            Vg = vl.toLowerCase(),
            Hg = vl[0].toUpperCase() + vl.slice(1);
        Ft(Vg, "on" + Hg)
    }
    Ft(Ac, "onAnimationEnd"), Ft(Uc, "onAnimationIteration"), Ft(Bc, "onAnimationStart"), Ft("dblclick", "onDoubleClick"), Ft("focusin", "onFocus"), Ft("focusout", "onBlur"), Ft($c, "onTransitionEnd"), Rn("onMouseEnter", ["mouseout", "mouseover"]), Rn("onMouseLeave", ["mouseout", "mouseover"]), Rn("onPointerEnter", ["pointerout", "pointerover"]), Rn("onPointerLeave", ["pointerout", "pointerover"]), tn("onChange", "change click focusin focusout input keydown keyup selectionchange".split(" ")), tn("onSelect", "focusout contextmenu dragend focusin keydown keyup mousedown mouseup selectionchange".split(" ")), tn("onBeforeInput", ["compositionend", "keypress", "textInput", "paste"]), tn("onCompositionEnd", "compositionend focusout keydown keypress keyup mousedown".split(" ")), tn("onCompositionStart", "compositionstart focusout keydown keypress keyup mousedown".split(" ")), tn("onCompositionUpdate", "compositionupdate focusout keydown keypress keyup mousedown".split(" "));
    var Vr = "abort canplay canplaythrough durationchange emptied encrypted ended error loadeddata loadedmetadata loadstart pause play playing progress ratechange resize seeked seeking stalled suspend timeupdate volumechange waiting".split(" "),
        Gg = new Set("cancel close invalid load scroll toggle".split(" ").concat(Vr));

    function Gc(e, t, n) {
        var r = e.type || "unknown-event";
        e.currentTarget = n, Vv(r, t, void 0, e), e.currentTarget = null
    }

    function Wc(e, t) {
        t = (t & 4) !== 0;
        for (var n = 0; n < e.length; n++) {
            var r = e[n],
                o = r.event;
            r = r.listeners;
            e: {
                var i = void 0;
                if (t)
                    for (var a = r.length - 1; 0 <= a; a--) {
                        var l = r[a],
                            s = l.instance,
                            u = l.currentTarget;
                        if (l = l.listener, s !== i && o.isPropagationStopped()) break e;
                        Gc(o, l, u), i = s
                    } else
                        for (a = 0; a < r.length; a++) {
                            if (l = r[a], s = l.instance, u = l.currentTarget, l = l.listener, s !== i && o.isPropagationStopped()) break e;
                            Gc(o, l, u), i = s
                        }
            }
        }
        if (Mo) throw e = Ga, Mo = !1, Ga = null, e
    }

    function H(e, t) {
        var n = t[xl];
        n === void 0 && (n = t[xl] = new Set);
        var r = e + "__bubble";
        n.has(r) || (Kc(t, e, 2, !1), n.add(r))
    }

    function gl(e, t, n) {
        var r = 0;
        t && (r |= 4), Kc(n, e, r, t)
    }
    var Yo = "_reactListening" + Math.random().toString(36).slice(2);

    function Hr(e) {
        if (!e[Yo]) {
            e[Yo] = !0, Iu.forEach(function(n) {
                n !== "selectionchange" && (Gg.has(n) || gl(n, !1, e), gl(n, !0, e))
            });
            var t = e.nodeType === 9 ? e : e.ownerDocument;
            t === null || t[Yo] || (t[Yo] = !0, gl("selectionchange", !1, t))
        }
    }

    function Kc(e, t, n, r) {
        switch (hc(t)) {
            case 1:
                var o = ig;
                break;
            case 4:
                o = ag;
                break;
            default:
                o = qa
        }
        n = o.bind(null, t, n, e), o = void 0, !Ha || t !== "touchstart" && t !== "touchmove" && t !== "wheel" || (o = !0), r ? o !== void 0 ? e.addEventListener(t, n, {
            capture: !0,
            passive: o
        }) : e.addEventListener(t, n, !0) : o !== void 0 ? e.addEventListener(t, n, {
            passive: o
        }) : e.addEventListener(t, n, !1)
    }

    function hl(e, t, n, r, o) {
        var i = r;
        if (!(t & 1) && !(t & 2) && r !== null) e: for (;;) {
            if (r === null) return;
            var a = r.tag;
            if (a === 3 || a === 4) {
                var l = r.stateNode.containerInfo;
                if (l === o || l.nodeType === 8 && l.parentNode === o) break;
                if (a === 4)
                    for (a = r.return; a !== null;) {
                        var s = a.tag;
                        if ((s === 3 || s === 4) && (s = a.stateNode.containerInfo, s === o || s.nodeType === 8 && s.parentNode === o)) return;
                        a = a.return
                    }
                for (; l !== null;) {
                    if (a = rn(l), a === null) return;
                    if (s = a.tag, s === 5 || s === 6) {
                        r = i = a;
                        continue e
                    }
                    l = l.parentNode
                }
            }
            r = r.return
        }
        qu(function() {
            var u = i,
                c = Ba(n),
                f = [];
            e: {
                var d = Vc.get(e);
                if (d !== void 0) {
                    var h = tl,
                        y = e;
                    switch (e) {
                        case "keypress":
                            if (Vo(n) === 0) break e;
                        case "keydown":
                        case "keyup":
                            h = Sg;
                            break;
                        case "focusin":
                            y = "focus", h = ol;
                            break;
                        case "focusout":
                            y = "blur", h = ol;
                            break;
                        case "beforeblur":
                        case "afterblur":
                            h = ol;
                            break;
                        case "click":
                            if (n.button === 2) break e;
                        case "auxclick":
                        case "dblclick":
                        case "mousedown":
                        case "mousemove":
                        case "mouseup":
                        case "mouseout":
                        case "mouseover":
                        case "contextmenu":
                            h = wc;
                            break;
                        case "drag":
                        case "dragend":
                        case "dragenter":
                        case "dragexit":
                        case "dragleave":
                        case "dragover":
                        case "dragstart":
                        case "drop":
                            h = ug;
                            break;
                        case "touchcancel":
                        case "touchend":
                        case "touchmove":
                        case "touchstart":
                            h = kg;
                            break;
                        case Ac:
                        case Uc:
                        case Bc:
                            h = dg;
                            break;
                        case $c:
                            h = Lg;
                            break;
                        case "scroll":
                            h = lg;
                            break;
                        case "wheel":
                            h = Ig;
                            break;
                        case "copy":
                        case "cut":
                        case "paste":
                            h = vg;
                            break;
                        case "gotpointercapture":
                        case "lostpointercapture":
                        case "pointercancel":
                        case "pointerdown":
                        case "pointermove":
                        case "pointerout":
                        case "pointerover":
                        case "pointerup":
                            h = Sc
                    }
                    var m = (t & 4) !== 0,
                        E = !m && e === "scroll",
                        v = m ? d !== null ? d + "Capture" : null : d;
                    m = [];
                    for (var p = u, g; p !== null;) {
                        g = p;
                        var C = g.stateNode;
                        if (g.tag === 5 && C !== null && (g = C, v !== null && (C = Lr(p, v), C != null && m.push(Gr(p, C, g)))), E) break;
                        p = p.return
                    }
                    0 < m.length && (d = new h(d, y, null, n, c), f.push({
                        event: d,
                        listeners: m
                    }))
                }
            }
            if (!(t & 7)) {
                e: {
                    if (d = e === "mouseover" || e === "pointerover", h = e === "mouseout" || e === "pointerout", d && n !== Ua && (y = n.relatedTarget || n.fromElement) && (rn(y) || y[vt])) break e;
                    if ((h || d) && (d = c.window === c ? c : (d = c.ownerDocument) ? d.defaultView || d.parentWindow : window, h ? (y = n.relatedTarget || n.toElement, h = u, y = y ? rn(y) : null, y !== null && (E = nn(y), y !== E || y.tag !== 5 && y.tag !== 6) && (y = null)) : (h = null, y = u), h !== y)) {
                        if (m = wc, C = "onMouseLeave", v = "onMouseEnter", p = "mouse", (e === "pointerout" || e === "pointerover") && (m = Sc, C = "onPointerLeave", v = "onPointerEnter", p = "pointer"), E = h == null ? d : Hn(h), g = y == null ? d : Hn(y), d = new m(C, p + "leave", h, n, c), d.target = E, d.relatedTarget = g, C = null, rn(c) === u && (m = new m(v, p + "enter", y, n, c), m.target = g, m.relatedTarget = E, C = m), E = C, h && y) t: {
                            for (m = h, v = y, p = 0, g = m; g; g = $n(g)) p++;
                            for (g = 0, C = v; C; C = $n(C)) g++;
                            for (; 0 < p - g;) m = $n(m),
                            p--;
                            for (; 0 < g - p;) v = $n(v),
                            g--;
                            for (; p--;) {
                                if (m === v || v !== null && m === v.alternate) break t;
                                m = $n(m), v = $n(v)
                            }
                            m = null
                        }
                        else m = null;
                        h !== null && Qc(f, d, h, m, !1), y !== null && E !== null && Qc(f, E, y, m, !0)
                    }
                }
                e: {
                    if (d = u ? Hn(u) : window, h = d.nodeName && d.nodeName.toLowerCase(), h === "select" || h === "input" && d.type === "file") var O = zg;
                    else if (Pc(d))
                        if (Nc) O = Ag;
                        else {
                            O = Tg;
                            var N = Fg
                        }
                    else(h = d.nodeName) && h.toLowerCase() === "input" && (d.type === "checkbox" || d.type === "radio") && (O = bg);
                    if (O && (O = O(e, u))) {
                        Ic(f, O, n, c);
                        break e
                    }
                    N && N(e, d, u),
                    e === "focusout" && (N = d._wrapperState) && N.controlled && d.type === "number" && za(d, "number", d.value)
                }
                switch (N = u ? Hn(u) : window, e) {
                    case "focusin":
                        (Pc(N) || N.contentEditable === "true") && (Un = N, cl = u, $r = null);
                        break;
                    case "focusout":
                        $r = cl = Un = null;
                        break;
                    case "mousedown":
                        fl = !0;
                        break;
                    case "contextmenu":
                    case "mouseup":
                    case "dragend":
                        fl = !1, Tc(f, n, c);
                        break;
                    case "selectionchange":
                        if ($g) break;
                    case "keydown":
                    case "keyup":
                        Tc(f, n, c)
                }
                var S;
                if (al) e: {
                    switch (e) {
                        case "compositionstart":
                            var I = "onCompositionStart";
                            break e;
                        case "compositionend":
                            I = "onCompositionEnd";
                            break e;
                        case "compositionupdate":
                            I = "onCompositionUpdate";
                            break e
                    }
                    I = void 0
                }
                else An ? Oc(e, n) && (I = "onCompositionEnd") : e === "keydown" && n.keyCode === 229 && (I = "onCompositionStart");I && (xc && n.locale !== "ko" && (An || I !== "onCompositionStart" ? I === "onCompositionEnd" && An && (S = mc()) : (zt = c, el = "value" in zt ? zt.value : zt.textContent, An = !0)), N = Jo(u, I), 0 < N.length && (I = new Cc(I, e, null, n, c), f.push({
                    event: I,
                    listeners: N
                }), S ? I.data = S : (S = Lc(n), S !== null && (I.data = S)))),
                (S = _g ? Rg(e, n) : Mg(e, n)) && (u = Jo(u, "onBeforeInput"), 0 < u.length && (c = new Cc("onBeforeInput", "beforeinput", null, n, c), f.push({
                    event: c,
                    listeners: u
                }), c.data = S))
            }
            Wc(f, t)
        })
    }

    function Gr(e, t, n) {
        return {
            instance: e,
            listener: t,
            currentTarget: n
        }
    }

    function Jo(e, t) {
        for (var n = t + "Capture", r = []; e !== null;) {
            var o = e,
                i = o.stateNode;
            o.tag === 5 && i !== null && (o = i, i = Lr(e, n), i != null && r.unshift(Gr(e, i, o)), i = Lr(e, t), i != null && r.push(Gr(e, i, o))), e = e.return
        }
        return r
    }

    function $n(e) {
        if (e === null) return null;
        do e = e.return; while (e && e.tag !== 5);
        return e || null
    }

    function Qc(e, t, n, r, o) {
        for (var i = t._reactName, a = []; n !== null && n !== r;) {
            var l = n,
                s = l.alternate,
                u = l.stateNode;
            if (s !== null && s === r) break;
            l.tag === 5 && u !== null && (l = u, o ? (s = Lr(n, i), s != null && a.unshift(Gr(n, s, l))) : o || (s = Lr(n, i), s != null && a.push(Gr(n, s, l)))), n = n.return
        }
        a.length !== 0 && e.push({
            event: t,
            listeners: a
        })
    }
    var Wg = /\r\n?/g,
        Kg = /\u0000|\uFFFD/g;

    function Yc(e) {
        return (typeof e == "string" ? e : "" + e).replace(Wg, `
`).replace(Kg, "")
    }

    function Zo(e, t, n) {
        if (t = Yc(t), Yc(e) !== t && n) throw Error(x(425))
    }

    function qo() {}
    var ml = null,
        yl = null;

    function wl(e, t) {
        return e === "textarea" || e === "noscript" || typeof t.children == "string" || typeof t.children == "number" || typeof t.dangerouslySetInnerHTML == "object" && t.dangerouslySetInnerHTML !== null && t.dangerouslySetInnerHTML.__html != null
    }
    var Cl = typeof setTimeout == "function" ? setTimeout : void 0,
        Qg = typeof clearTimeout == "function" ? clearTimeout : void 0,
        Jc = typeof Promise == "function" ? Promise : void 0,
        Yg = typeof queueMicrotask == "function" ? queueMicrotask : typeof Jc < "u" ? function(e) {
            return Jc.resolve(null).then(e).catch(Jg)
        } : Cl;

    function Jg(e) {
        setTimeout(function() {
            throw e
        })
    }

    function Sl(e, t) {
        var n = t,
            r = 0;
        do {
            var o = n.nextSibling;
            if (e.removeChild(n), o && o.nodeType === 8)
                if (n = o.data, n === "/$") {
                    if (r === 0) {
                        e.removeChild(o), zr(t);
                        return
                    }
                    r--
                } else n !== "$" && n !== "$?" && n !== "$!" || r++;
            n = o
        } while (n);
        zr(t)
    }

    function Tt(e) {
        for (; e != null; e = e.nextSibling) {
            var t = e.nodeType;
            if (t === 1 || t === 3) break;
            if (t === 8) {
                if (t = e.data, t === "$" || t === "$!" || t === "$?") break;
                if (t === "/$") return null
            }
        }
        return e
    }

    function Zc(e) {
        e = e.previousSibling;
        for (var t = 0; e;) {
            if (e.nodeType === 8) {
                var n = e.data;
                if (n === "$" || n === "$!" || n === "$?") {
                    if (t === 0) return e;
                    t--
                } else n === "/$" && t++
            }
            e = e.previousSibling
        }
        return null
    }
    var Vn = Math.random().toString(36).slice(2),
        ot = "__reactFiber$" + Vn,
        Wr = "__reactProps$" + Vn,
        vt = "__reactContainer$" + Vn,
        xl = "__reactEvents$" + Vn,
        Zg = "__reactListeners$" + Vn,
        qg = "__reactHandles$" + Vn;

    function rn(e) {
        var t = e[ot];
        if (t) return t;
        for (var n = e.parentNode; n;) {
            if (t = n[vt] || n[ot]) {
                if (n = t.alternate, t.child !== null || n !== null && n.child !== null)
                    for (e = Zc(e); e !== null;) {
                        if (n = e[ot]) return n;
                        e = Zc(e)
                    }
                return t
            }
            e = n, n = e.parentNode
        }
        return null
    }

    function Kr(e) {
        return e = e[ot] || e[vt], !e || e.tag !== 5 && e.tag !== 6 && e.tag !== 13 && e.tag !== 3 ? null : e
    }

    function Hn(e) {
        if (e.tag === 5 || e.tag === 6) return e.stateNode;
        throw Error(x(33))
    }

    function Xo(e) {
        return e[Wr] || null
    }
    var El = [],
        Gn = -1;

    function bt(e) {
        return {
            current: e
        }
    }

    function G(e) {
        0 > Gn || (e.current = El[Gn], El[Gn] = null, Gn--)
    }

    function V(e, t) {
        Gn++, El[Gn] = e.current, e.current = t
    }
    var At = {},
        me = bt(At),
        Le = bt(!1),
        on = At;

    function Wn(e, t) {
        var n = e.type.contextTypes;
        if (!n) return At;
        var r = e.stateNode;
        if (r && r.__reactInternalMemoizedUnmaskedChildContext === t) return r.__reactInternalMemoizedMaskedChildContext;
        var o = {},
            i;
        for (i in n) o[i] = t[i];
        return r && (e = e.stateNode, e.__reactInternalMemoizedUnmaskedChildContext = t, e.__reactInternalMemoizedMaskedChildContext = o), o
    }

    function Pe(e) {
        return e = e.childContextTypes, e != null
    }

    function ei() {
        G(Le), G(me)
    }

    function qc(e, t, n) {
        if (me.current !== At) throw Error(x(168));
        V(me, t), V(Le, n)
    }

    function Xc(e, t, n) {
        var r = e.stateNode;
        if (t = t.childContextTypes, typeof r.getChildContext != "function") return n;
        r = r.getChildContext();
        for (var o in r)
            if (!(o in t)) throw Error(x(108, Fv(e) || "Unknown", o));
        return Q({}, n, r)
    }

    function ti(e) {
        return e = (e = e.stateNode) && e.__reactInternalMemoizedMergedChildContext || At, on = me.current, V(me, e), V(Le, Le.current), !0
    }

    function ef(e, t, n) {
        var r = e.stateNode;
        if (!r) throw Error(x(169));
        n ? (e = Xc(e, t, on), r.__reactInternalMemoizedMergedChildContext = e, G(Le), G(me), V(me, e)) : G(Le), V(Le, n)
    }
    var gt = null,
        ni = !1,
        kl = !1;

    function tf(e) {
        gt === null ? gt = [e] : gt.push(e)
    }

    function Xg(e) {
        ni = !0, tf(e)
    }

    function Ut() {
        if (!kl && gt !== null) {
            kl = !0;
            var e = 0,
                t = U;
            try {
                var n = gt;
                for (U = 1; e < n.length; e++) {
                    var r = n[e];
                    do r = r(!0); while (r !== null)
                }
                gt = null, ni = !1
            } catch (o) {
                throw gt !== null && (gt = gt.slice(e + 1)), rc(Wa, Ut), o
            } finally {
                U = t, kl = !1
            }
        }
        return null
    }
    var Kn = [],
        Qn = 0,
        ri = null,
        oi = 0,
        Ae = [],
        Ue = 0,
        an = null,
        ht = 1,
        mt = "";

    function ln(e, t) {
        Kn[Qn++] = oi, Kn[Qn++] = ri, ri = e, oi = t
    }

    function nf(e, t, n) {
        Ae[Ue++] = ht, Ae[Ue++] = mt, Ae[Ue++] = an, an = e;
        var r = ht;
        e = mt;
        var o = 32 - We(r) - 1;
        r &= ~(1 << o), n += 1;
        var i = 32 - We(t) + o;
        if (30 < i) {
            var a = o - o % 5;
            i = (r & (1 << a) - 1).toString(32), r >>= a, o -= a, ht = 1 << 32 - We(t) + o | n << o | r, mt = i + e
        } else ht = 1 << i | n << o | r, mt = e
    }

    function Ol(e) {
        e.return !== null && (ln(e, 1), nf(e, 1, 0))
    }

    function Ll(e) {
        for (; e === ri;) ri = Kn[--Qn], Kn[Qn] = null, oi = Kn[--Qn], Kn[Qn] = null;
        for (; e === an;) an = Ae[--Ue], Ae[Ue] = null, mt = Ae[--Ue], Ae[Ue] = null, ht = Ae[--Ue], Ae[Ue] = null
    }
    var ze = null,
        Fe = null,
        K = !1,
        Qe = null;

    function rf(e, t) {
        var n = He(5, null, null, 0);
        n.elementType = "DELETED", n.stateNode = t, n.return = e, t = e.deletions, t === null ? (e.deletions = [n], e.flags |= 16) : t.push(n)
    }

    function of (e, t) {
        switch (e.tag) {
            case 5:
                var n = e.type;
                return t = t.nodeType !== 1 || n.toLowerCase() !== t.nodeName.toLowerCase() ? null : t, t !== null ? (e.stateNode = t, ze = e, Fe = Tt(t.firstChild), !0) : !1;
            case 6:
                return t = e.pendingProps === "" || t.nodeType !== 3 ? null : t, t !== null ? (e.stateNode = t, ze = e, Fe = null, !0) : !1;
            case 13:
                return t = t.nodeType !== 8 ? null : t, t !== null ? (n = an !== null ? {
                    id: ht,
                    overflow: mt
                } : null, e.memoizedState = {
                    dehydrated: t,
                    treeContext: n,
                    retryLane: 1073741824
                }, n = He(18, null, null, 0), n.stateNode = t, n.return = e, e.child = n, ze = e, Fe = null, !0) : !1;
            default:
                return !1
        }
    }

    function Pl(e) {
        return (e.mode & 1) !== 0 && (e.flags & 128) === 0
    }

    function Il(e) {
        if (K) {
            var t = Fe;
            if (t) {
                var n = t;
                if (! of (e, t)) {
                    if (Pl(e)) throw Error(x(418));
                    t = Tt(n.nextSibling);
                    var r = ze;
                    t && of (e, t) ? rf(r, n) : (e.flags = e.flags & -4097 | 2, K = !1, ze = e)
                }
            } else {
                if (Pl(e)) throw Error(x(418));
                e.flags = e.flags & -4097 | 2, K = !1, ze = e
            }
        }
    }

    function af(e) {
        for (e = e.return; e !== null && e.tag !== 5 && e.tag !== 3 && e.tag !== 13;) e = e.return;
        ze = e
    }

    function ii(e) {
        if (e !== ze) return !1;
        if (!K) return af(e), K = !0, !1;
        var t;
        if ((t = e.tag !== 3) && !(t = e.tag !== 5) && (t = e.type, t = t !== "head" && t !== "body" && !wl(e.type, e.memoizedProps)), t && (t = Fe)) {
            if (Pl(e)) throw lf(), Error(x(418));
            for (; t;) rf(e, t), t = Tt(t.nextSibling)
        }
        if (af(e), e.tag === 13) {
            if (e = e.memoizedState, e = e !== null ? e.dehydrated : null, !e) throw Error(x(317));
            e: {
                for (e = e.nextSibling, t = 0; e;) {
                    if (e.nodeType === 8) {
                        var n = e.data;
                        if (n === "/$") {
                            if (t === 0) {
                                Fe = Tt(e.nextSibling);
                                break e
                            }
                            t--
                        } else n !== "$" && n !== "$!" && n !== "$?" || t++
                    }
                    e = e.nextSibling
                }
                Fe = null
            }
        } else Fe = ze ? Tt(e.stateNode.nextSibling) : null;
        return !0
    }

    function lf() {
        for (var e = Fe; e;) e = Tt(e.nextSibling)
    }

    function Yn() {
        Fe = ze = null, K = !1
    }

    function Nl(e) {
        Qe === null ? Qe = [e] : Qe.push(e)
    }
    var eh = pt.ReactCurrentBatchConfig;

    function Qr(e, t, n) {
        if (e = n.ref, e !== null && typeof e != "function" && typeof e != "object") {
            if (n._owner) {
                if (n = n._owner, n) {
                    if (n.tag !== 1) throw Error(x(309));
                    var r = n.stateNode
                }
                if (!r) throw Error(x(147, e));
                var o = r,
                    i = "" + e;
                return t !== null && t.ref !== null && typeof t.ref == "function" && t.ref._stringRef === i ? t.ref : (t = function(a) {
                    var l = o.refs;
                    a === null ? delete l[i] : l[i] = a
                }, t._stringRef = i, t)
            }
            if (typeof e != "string") throw Error(x(284));
            if (!n._owner) throw Error(x(290, e))
        }
        return e
    }

    function ai(e, t) {
        throw e = Object.prototype.toString.call(t), Error(x(31, e === "[object Object]" ? "object with keys {" + Object.keys(t).join(", ") + "}" : e))
    }

    function sf(e) {
        var t = e._init;
        return t(e._payload)
    }

    function uf(e) {
        function t(v, p) {
            if (e) {
                var g = v.deletions;
                g === null ? (v.deletions = [p], v.flags |= 16) : g.push(p)
            }
        }

        function n(v, p) {
            if (!e) return null;
            for (; p !== null;) t(v, p), p = p.sibling;
            return null
        }

        function r(v, p) {
            for (v = new Map; p !== null;) p.key !== null ? v.set(p.key, p) : v.set(p.index, p), p = p.sibling;
            return v
        }

        function o(v, p) {
            return v = Qt(v, p), v.index = 0, v.sibling = null, v
        }

        function i(v, p, g) {
            return v.index = g, e ? (g = v.alternate, g !== null ? (g = g.index, g < p ? (v.flags |= 2, p) : g) : (v.flags |= 2, p)) : (v.flags |= 1048576, p)
        }

        function a(v) {
            return e && v.alternate === null && (v.flags |= 2), v
        }

        function l(v, p, g, C) {
            return p === null || p.tag !== 6 ? (p = Cs(g, v.mode, C), p.return = v, p) : (p = o(p, g), p.return = v, p)
        }

        function s(v, p, g, C) {
            var O = g.type;
            return O === Dn ? c(v, p, g.props.children, C, g.key) : p !== null && (p.elementType === O || typeof O == "object" && O !== null && O.$$typeof === Nt && sf(O) === p.type) ? (C = o(p, g.props), C.ref = Qr(v, p, g), C.return = v, C) : (C = _i(g.type, g.key, g.props, null, v.mode, C), C.ref = Qr(v, p, g), C.return = v, C)
        }

        function u(v, p, g, C) {
            return p === null || p.tag !== 4 || p.stateNode.containerInfo !== g.containerInfo || p.stateNode.implementation !== g.implementation ? (p = Ss(g, v.mode, C), p.return = v, p) : (p = o(p, g.children || []), p.return = v, p)
        }

        function c(v, p, g, C, O) {
            return p === null || p.tag !== 7 ? (p = gn(g, v.mode, C, O), p.return = v, p) : (p = o(p, g), p.return = v, p)
        }

        function f(v, p, g) {
            if (typeof p == "string" && p !== "" || typeof p == "number") return p = Cs("" + p, v.mode, g), p.return = v, p;
            if (typeof p == "object" && p !== null) {
                switch (p.$$typeof) {
                    case Po:
                        return g = _i(p.type, p.key, p.props, null, v.mode, g), g.ref = Qr(v, null, p), g.return = v, g;
                    case Mn:
                        return p = Ss(p, v.mode, g), p.return = v, p;
                    case Nt:
                        var C = p._init;
                        return f(v, C(p._payload), g)
                }
                if (Er(p) || Sr(p)) return p = gn(p, v.mode, g, null), p.return = v, p;
                ai(v, p)
            }
            return null
        }

        function d(v, p, g, C) {
            var O = p !== null ? p.key : null;
            if (typeof g == "string" && g !== "" || typeof g == "number") return O !== null ? null : l(v, p, "" + g, C);
            if (typeof g == "object" && g !== null) {
                switch (g.$$typeof) {
                    case Po:
                        return g.key === O ? s(v, p, g, C) : null;
                    case Mn:
                        return g.key === O ? u(v, p, g, C) : null;
                    case Nt:
                        return O = g._init, d(v, p, O(g._payload), C)
                }
                if (Er(g) || Sr(g)) return O !== null ? null : c(v, p, g, C, null);
                ai(v, g)
            }
            return null
        }

        function h(v, p, g, C, O) {
            if (typeof C == "string" && C !== "" || typeof C == "number") return v = v.get(g) || null, l(p, v, "" + C, O);
            if (typeof C == "object" && C !== null) {
                switch (C.$$typeof) {
                    case Po:
                        return v = v.get(C.key === null ? g : C.key) || null, s(p, v, C, O);
                    case Mn:
                        return v = v.get(C.key === null ? g : C.key) || null, u(p, v, C, O);
                    case Nt:
                        var N = C._init;
                        return h(v, p, g, N(C._payload), O)
                }
                if (Er(C) || Sr(C)) return v = v.get(g) || null, c(p, v, C, O, null);
                ai(p, C)
            }
            return null
        }

        function y(v, p, g, C) {
            for (var O = null, N = null, S = p, I = p = 0, $ = null; S !== null && I < g.length; I++) {
                S.index > I ? ($ = S, S = null) : $ = S.sibling;
                var z = d(v, S, g[I], C);
                if (z === null) {
                    S === null && (S = $);
                    break
                }
                e && S && z.alternate === null && t(v, S), p = i(z, p, I), N === null ? O = z : N.sibling = z, N = z, S = $
            }
            if (I === g.length) return n(v, S), K && ln(v, I), O;
            if (S === null) {
                for (; I < g.length; I++) S = f(v, g[I], C), S !== null && (p = i(S, p, I), N === null ? O = S : N.sibling = S, N = S);
                return K && ln(v, I), O
            }
            for (S = r(v, S); I < g.length; I++) $ = h(S, v, I, g[I], C), $ !== null && (e && $.alternate !== null && S.delete($.key === null ? I : $.key), p = i($, p, I), N === null ? O = $ : N.sibling = $, N = $);
            return e && S.forEach(function(Oe) {
                return t(v, Oe)
            }), K && ln(v, I), O
        }

        function m(v, p, g, C) {
            var O = Sr(g);
            if (typeof O != "function") throw Error(x(150));
            if (g = O.call(g), g == null) throw Error(x(151));
            for (var N = O = null, S = p, I = p = 0, $ = null, z = g.next(); S !== null && !z.done; I++, z = g.next()) {
                S.index > I ? ($ = S, S = null) : $ = S.sibling;
                var Oe = d(v, S, z.value, C);
                if (Oe === null) {
                    S === null && (S = $);
                    break
                }
                e && S && Oe.alternate === null && t(v, S), p = i(Oe, p, I), N === null ? O = Oe : N.sibling = Oe, N = Oe, S = $
            }
            if (z.done) return n(v, S), K && ln(v, I), O;
            if (S === null) {
                for (; !z.done; I++, z = g.next()) z = f(v, z.value, C), z !== null && (p = i(z, p, I), N === null ? O = z : N.sibling = z, N = z);
                return K && ln(v, I), O
            }
            for (S = r(v, S); !z.done; I++, z = g.next()) z = h(S, v, I, z.value, C), z !== null && (e && z.alternate !== null && S.delete(z.key === null ? I : z.key), p = i(z, p, I), N === null ? O = z : N.sibling = z, N = z);
            return e && S.forEach(function(nt) {
                return t(v, nt)
            }), K && ln(v, I), O
        }

        function E(v, p, g, C) {
            if (typeof g == "object" && g !== null && g.type === Dn && g.key === null && (g = g.props.children), typeof g == "object" && g !== null) {
                switch (g.$$typeof) {
                    case Po:
                        e: {
                            for (var O = g.key, N = p; N !== null;) {
                                if (N.key === O) {
                                    if (O = g.type, O === Dn) {
                                        if (N.tag === 7) {
                                            n(v, N.sibling), p = o(N, g.props.children), p.return = v, v = p;
                                            break e
                                        }
                                    } else if (N.elementType === O || typeof O == "object" && O !== null && O.$$typeof === Nt && sf(O) === N.type) {
                                        n(v, N.sibling), p = o(N, g.props), p.ref = Qr(v, N, g), p.return = v, v = p;
                                        break e
                                    }
                                    n(v, N);
                                    break
                                } else t(v, N);
                                N = N.sibling
                            }
                            g.type === Dn ? (p = gn(g.props.children, v.mode, C, g.key), p.return = v, v = p) : (C = _i(g.type, g.key, g.props, null, v.mode, C), C.ref = Qr(v, p, g), C.return = v, v = C)
                        }
                        return a(v);
                    case Mn:
                        e: {
                            for (N = g.key; p !== null;) {
                                if (p.key === N)
                                    if (p.tag === 4 && p.stateNode.containerInfo === g.containerInfo && p.stateNode.implementation === g.implementation) {
                                        n(v, p.sibling), p = o(p, g.children || []), p.return = v, v = p;
                                        break e
                                    } else {
                                        n(v, p);
                                        break
                                    }
                                else t(v, p);
                                p = p.sibling
                            }
                            p = Ss(g, v.mode, C),
                            p.return = v,
                            v = p
                        }
                        return a(v);
                    case Nt:
                        return N = g._init, E(v, p, N(g._payload), C)
                }
                if (Er(g)) return y(v, p, g, C);
                if (Sr(g)) return m(v, p, g, C);
                ai(v, g)
            }
            return typeof g == "string" && g !== "" || typeof g == "number" ? (g = "" + g, p !== null && p.tag === 6 ? (n(v, p.sibling), p = o(p, g), p.return = v, v = p) : (n(v, p), p = Cs(g, v.mode, C), p.return = v, v = p), a(v)) : n(v, p)
        }
        return E
    }
    var Jn = uf(!0),
        cf = uf(!1),
        li = bt(null),
        si = null,
        Zn = null,
        _l = null;

    function Rl() {
        _l = Zn = si = null
    }

    function Ml(e) {
        var t = li.current;
        G(li), e._currentValue = t
    }

    function Dl(e, t, n) {
        for (; e !== null;) {
            var r = e.alternate;
            if ((e.childLanes & t) !== t ? (e.childLanes |= t, r !== null && (r.childLanes |= t)) : r !== null && (r.childLanes & t) !== t && (r.childLanes |= t), e === n) break;
            e = e.return
        }
    }

    function qn(e, t) {
        si = e, _l = Zn = null, e = e.dependencies, e !== null && e.firstContext !== null && (e.lanes & t && (Ie = !0), e.firstContext = null)
    }

    function Be(e) {
        var t = e._currentValue;
        if (_l !== e)
            if (e = {
                    context: e,
                    memoizedValue: t,
                    next: null
                }, Zn === null) {
                if (si === null) throw Error(x(308));
                Zn = e, si.dependencies = {
                    lanes: 0,
                    firstContext: e
                }
            } else Zn = Zn.next = e;
        return t
    }
    var sn = null;

    function jl(e) {
        sn === null ? sn = [e] : sn.push(e)
    }

    function ff(e, t, n, r) {
        var o = t.interleaved;
        return o === null ? (n.next = n, jl(t)) : (n.next = o.next, o.next = n), t.interleaved = n, yt(e, r)
    }

    function yt(e, t) {
        e.lanes |= t;
        var n = e.alternate;
        for (n !== null && (n.lanes |= t), n = e, e = e.return; e !== null;) e.childLanes |= t, n = e.alternate, n !== null && (n.childLanes |= t), n = e, e = e.return;
        return n.tag === 3 ? n.stateNode : null
    }
    var Bt = !1;

    function zl(e) {
        e.updateQueue = {
            baseState: e.memoizedState,
            firstBaseUpdate: null,
            lastBaseUpdate: null,
            shared: {
                pending: null,
                interleaved: null,
                lanes: 0
            },
            effects: null
        }
    }

    function df(e, t) {
        e = e.updateQueue, t.updateQueue === e && (t.updateQueue = {
            baseState: e.baseState,
            firstBaseUpdate: e.firstBaseUpdate,
            lastBaseUpdate: e.lastBaseUpdate,
            shared: e.shared,
            effects: e.effects
        })
    }

    function wt(e, t) {
        return {
            eventTime: e,
            lane: t,
            tag: 0,
            payload: null,
            callback: null,
            next: null
        }
    }

    function $t(e, t, n) {
        var r = e.updateQueue;
        if (r === null) return null;
        if (r = r.shared, b & 2) {
            var o = r.pending;
            return o === null ? t.next = t : (t.next = o.next, o.next = t), r.pending = t, yt(e, n)
        }
        return o = r.interleaved, o === null ? (t.next = t, jl(r)) : (t.next = o.next, o.next = t), r.interleaved = t, yt(e, n)
    }

    function ui(e, t, n) {
        if (t = t.updateQueue, t !== null && (t = t.shared, (n & 4194240) !== 0)) {
            var r = t.lanes;
            r &= e.pendingLanes, n |= r, t.lanes = n, Ya(e, n)
        }
    }

    function pf(e, t) {
        var n = e.updateQueue,
            r = e.alternate;
        if (r !== null && (r = r.updateQueue, n === r)) {
            var o = null,
                i = null;
            if (n = n.firstBaseUpdate, n !== null) {
                do {
                    var a = {
                        eventTime: n.eventTime,
                        lane: n.lane,
                        tag: n.tag,
                        payload: n.payload,
                        callback: n.callback,
                        next: null
                    };
                    i === null ? o = i = a : i = i.next = a, n = n.next
                } while (n !== null);
                i === null ? o = i = t : i = i.next = t
            } else o = i = t;
            n = {
                baseState: r.baseState,
                firstBaseUpdate: o,
                lastBaseUpdate: i,
                shared: r.shared,
                effects: r.effects
            }, e.updateQueue = n;
            return
        }
        e = n.lastBaseUpdate, e === null ? n.firstBaseUpdate = t : e.next = t, n.lastBaseUpdate = t
    }

    function ci(e, t, n, r) {
        var o = e.updateQueue;
        Bt = !1;
        var i = o.firstBaseUpdate,
            a = o.lastBaseUpdate,
            l = o.shared.pending;
        if (l !== null) {
            o.shared.pending = null;
            var s = l,
                u = s.next;
            s.next = null, a === null ? i = u : a.next = u, a = s;
            var c = e.alternate;
            c !== null && (c = c.updateQueue, l = c.lastBaseUpdate, l !== a && (l === null ? c.firstBaseUpdate = u : l.next = u, c.lastBaseUpdate = s))
        }
        if (i !== null) {
            var f = o.baseState;
            a = 0, c = u = s = null, l = i;
            do {
                var d = l.lane,
                    h = l.eventTime;
                if ((r & d) === d) {
                    c !== null && (c = c.next = {
                        eventTime: h,
                        lane: 0,
                        tag: l.tag,
                        payload: l.payload,
                        callback: l.callback,
                        next: null
                    });
                    e: {
                        var y = e,
                            m = l;
                        switch (d = t, h = n, m.tag) {
                            case 1:
                                if (y = m.payload, typeof y == "function") {
                                    f = y.call(h, f, d);
                                    break e
                                }
                                f = y;
                                break e;
                            case 3:
                                y.flags = y.flags & -65537 | 128;
                            case 0:
                                if (y = m.payload, d = typeof y == "function" ? y.call(h, f, d) : y, d == null) break e;
                                f = Q({}, f, d);
                                break e;
                            case 2:
                                Bt = !0
                        }
                    }
                    l.callback !== null && l.lane !== 0 && (e.flags |= 64, d = o.effects, d === null ? o.effects = [l] : d.push(l))
                } else h = {
                    eventTime: h,
                    lane: d,
                    tag: l.tag,
                    payload: l.payload,
                    callback: l.callback,
                    next: null
                }, c === null ? (u = c = h, s = f) : c = c.next = h, a |= d;
                if (l = l.next, l === null) {
                    if (l = o.shared.pending, l === null) break;
                    d = l, l = d.next, d.next = null, o.lastBaseUpdate = d, o.shared.pending = null
                }
            } while (!0);
            if (c === null && (s = f), o.baseState = s, o.firstBaseUpdate = u, o.lastBaseUpdate = c, t = o.shared.interleaved, t !== null) {
                o = t;
                do a |= o.lane, o = o.next; while (o !== t)
            } else i === null && (o.shared.lanes = 0);
            fn |= a, e.lanes = a, e.memoizedState = f
        }
    }

    function vf(e, t, n) {
        if (e = t.effects, t.effects = null, e !== null)
            for (t = 0; t < e.length; t++) {
                var r = e[t],
                    o = r.callback;
                if (o !== null) {
                    if (r.callback = null, r = n, typeof o != "function") throw Error(x(191, o));
                    o.call(r)
                }
            }
    }
    var Yr = {},
        it = bt(Yr),
        Jr = bt(Yr),
        Zr = bt(Yr);

    function un(e) {
        if (e === Yr) throw Error(x(174));
        return e
    }

    function Fl(e, t) {
        switch (V(Zr, t), V(Jr, e), V(it, Yr), e = t.nodeType, e) {
            case 9:
            case 11:
                t = (t = t.documentElement) ? t.namespaceURI : Ta(null, "");
                break;
            default:
                e = e === 8 ? t.parentNode : t, t = e.namespaceURI || null, e = e.tagName, t = Ta(t, e)
        }
        G(it), V(it, t)
    }

    function Xn() {
        G(it), G(Jr), G(Zr)
    }

    function gf(e) {
        un(Zr.current);
        var t = un(it.current),
            n = Ta(t, e.type);
        t !== n && (V(Jr, e), V(it, n))
    }

    function Tl(e) {
        Jr.current === e && (G(it), G(Jr))
    }
    var Y = bt(0);

    function fi(e) {
        for (var t = e; t !== null;) {
            if (t.tag === 13) {
                var n = t.memoizedState;
                if (n !== null && (n = n.dehydrated, n === null || n.data === "$?" || n.data === "$!")) return t
            } else if (t.tag === 19 && t.memoizedProps.revealOrder !== void 0) {
                if (t.flags & 128) return t
            } else if (t.child !== null) {
                t.child.return = t, t = t.child;
                continue
            }
            if (t === e) break;
            for (; t.sibling === null;) {
                if (t.return === null || t.return === e) return null;
                t = t.return
            }
            t.sibling.return = t.return, t = t.sibling
        }
        return null
    }
    var bl = [];

    function Al() {
        for (var e = 0; e < bl.length; e++) bl[e]._workInProgressVersionPrimary = null;
        bl.length = 0
    }
    var di = pt.ReactCurrentDispatcher,
        Ul = pt.ReactCurrentBatchConfig,
        cn = 0,
        J = null,
        ae = null,
        ue = null,
        pi = !1,
        qr = !1,
        Xr = 0,
        th = 0;

    function ye() {
        throw Error(x(321))
    }

    function Bl(e, t) {
        if (t === null) return !1;
        for (var n = 0; n < t.length && n < e.length; n++)
            if (!Ke(e[n], t[n])) return !1;
        return !0
    }

    function $l(e, t, n, r, o, i) {
        if (cn = i, J = t, t.memoizedState = null, t.updateQueue = null, t.lanes = 0, di.current = e === null || e.memoizedState === null ? ih : ah, e = n(r, o), qr) {
            i = 0;
            do {
                if (qr = !1, Xr = 0, 25 <= i) throw Error(x(301));
                i += 1, ue = ae = null, t.updateQueue = null, di.current = lh, e = n(r, o)
            } while (qr)
        }
        if (di.current = hi, t = ae !== null && ae.next !== null, cn = 0, ue = ae = J = null, pi = !1, t) throw Error(x(300));
        return e
    }

    function Vl() {
        var e = Xr !== 0;
        return Xr = 0, e
    }

    function at() {
        var e = {
            memoizedState: null,
            baseState: null,
            baseQueue: null,
            queue: null,
            next: null
        };
        return ue === null ? J.memoizedState = ue = e : ue = ue.next = e, ue
    }

    function $e() {
        if (ae === null) {
            var e = J.alternate;
            e = e !== null ? e.memoizedState : null
        } else e = ae.next;
        var t = ue === null ? J.memoizedState : ue.next;
        if (t !== null) ue = t, ae = e;
        else {
            if (e === null) throw Error(x(310));
            ae = e, e = {
                memoizedState: ae.memoizedState,
                baseState: ae.baseState,
                baseQueue: ae.baseQueue,
                queue: ae.queue,
                next: null
            }, ue === null ? J.memoizedState = ue = e : ue = ue.next = e
        }
        return ue
    }

    function eo(e, t) {
        return typeof t == "function" ? t(e) : t
    }

    function Hl(e) {
        var t = $e(),
            n = t.queue;
        if (n === null) throw Error(x(311));
        n.lastRenderedReducer = e;
        var r = ae,
            o = r.baseQueue,
            i = n.pending;
        if (i !== null) {
            if (o !== null) {
                var a = o.next;
                o.next = i.next, i.next = a
            }
            r.baseQueue = o = i, n.pending = null
        }
        if (o !== null) {
            i = o.next, r = r.baseState;
            var l = a = null,
                s = null,
                u = i;
            do {
                var c = u.lane;
                if ((cn & c) === c) s !== null && (s = s.next = {
                    lane: 0,
                    action: u.action,
                    hasEagerState: u.hasEagerState,
                    eagerState: u.eagerState,
                    next: null
                }), r = u.hasEagerState ? u.eagerState : e(r, u.action);
                else {
                    var f = {
                        lane: c,
                        action: u.action,
                        hasEagerState: u.hasEagerState,
                        eagerState: u.eagerState,
                        next: null
                    };
                    s === null ? (l = s = f, a = r) : s = s.next = f, J.lanes |= c, fn |= c
                }
                u = u.next
            } while (u !== null && u !== i);
            s === null ? a = r : s.next = l, Ke(r, t.memoizedState) || (Ie = !0), t.memoizedState = r, t.baseState = a, t.baseQueue = s, n.lastRenderedState = r
        }
        if (e = n.interleaved, e !== null) {
            o = e;
            do i = o.lane, J.lanes |= i, fn |= i, o = o.next; while (o !== e)
        } else o === null && (n.lanes = 0);
        return [t.memoizedState, n.dispatch]
    }

    function Gl(e) {
        var t = $e(),
            n = t.queue;
        if (n === null) throw Error(x(311));
        n.lastRenderedReducer = e;
        var r = n.dispatch,
            o = n.pending,
            i = t.memoizedState;
        if (o !== null) {
            n.pending = null;
            var a = o = o.next;
            do i = e(i, a.action), a = a.next; while (a !== o);
            Ke(i, t.memoizedState) || (Ie = !0), t.memoizedState = i, t.baseQueue === null && (t.baseState = i), n.lastRenderedState = i
        }
        return [i, r]
    }

    function hf() {}

    function mf(e, t) {
        var n = J,
            r = $e(),
            o = t(),
            i = !Ke(r.memoizedState, o);
        if (i && (r.memoizedState = o, Ie = !0), r = r.queue, Wl(Cf.bind(null, n, r, e), [e]), r.getSnapshot !== t || i || ue !== null && ue.memoizedState.tag & 1) {
            if (n.flags |= 2048, to(9, wf.bind(null, n, r, o, t), void 0, null), ce === null) throw Error(x(349));
            cn & 30 || yf(n, t, o)
        }
        return o
    }

    function yf(e, t, n) {
        e.flags |= 16384, e = {
            getSnapshot: t,
            value: n
        }, t = J.updateQueue, t === null ? (t = {
            lastEffect: null,
            stores: null
        }, J.updateQueue = t, t.stores = [e]) : (n = t.stores, n === null ? t.stores = [e] : n.push(e))
    }

    function wf(e, t, n, r) {
        t.value = n, t.getSnapshot = r, Sf(t) && xf(e)
    }

    function Cf(e, t, n) {
        return n(function() {
            Sf(t) && xf(e)
        })
    }

    function Sf(e) {
        var t = e.getSnapshot;
        e = e.value;
        try {
            var n = t();
            return !Ke(e, n)
        } catch {
            return !0
        }
    }

    function xf(e) {
        var t = yt(e, 1);
        t !== null && qe(t, e, 1, -1)
    }

    function Ef(e) {
        var t = at();
        return typeof e == "function" && (e = e()), t.memoizedState = t.baseState = e, e = {
            pending: null,
            interleaved: null,
            lanes: 0,
            dispatch: null,
            lastRenderedReducer: eo,
            lastRenderedState: e
        }, t.queue = e, e = e.dispatch = oh.bind(null, J, e), [t.memoizedState, e]
    }

    function to(e, t, n, r) {
        return e = {
            tag: e,
            create: t,
            destroy: n,
            deps: r,
            next: null
        }, t = J.updateQueue, t === null ? (t = {
            lastEffect: null,
            stores: null
        }, J.updateQueue = t, t.lastEffect = e.next = e) : (n = t.lastEffect, n === null ? t.lastEffect = e.next = e : (r = n.next, n.next = e, e.next = r, t.lastEffect = e)), e
    }

    function kf() {
        return $e().memoizedState
    }

    function vi(e, t, n, r) {
        var o = at();
        J.flags |= e, o.memoizedState = to(1 | t, n, void 0, r === void 0 ? null : r)
    }

    function gi(e, t, n, r) {
        var o = $e();
        r = r === void 0 ? null : r;
        var i = void 0;
        if (ae !== null) {
            var a = ae.memoizedState;
            if (i = a.destroy, r !== null && Bl(r, a.deps)) {
                o.memoizedState = to(t, n, i, r);
                return
            }
        }
        J.flags |= e, o.memoizedState = to(1 | t, n, i, r)
    }

    function Of(e, t) {
        return vi(8390656, 8, e, t)
    }

    function Wl(e, t) {
        return gi(2048, 8, e, t)
    }

    function Lf(e, t) {
        return gi(4, 2, e, t)
    }

    function Pf(e, t) {
        return gi(4, 4, e, t)
    }

    function If(e, t) {
        if (typeof t == "function") return e = e(), t(e),
            function() {
                t(null)
            };
        if (t != null) return e = e(), t.current = e,
            function() {
                t.current = null
            }
    }

    function Nf(e, t, n) {
        return n = n != null ? n.concat([e]) : null, gi(4, 4, If.bind(null, t, e), n)
    }

    function Kl() {}

    function _f(e, t) {
        var n = $e();
        t = t === void 0 ? null : t;
        var r = n.memoizedState;
        return r !== null && t !== null && Bl(t, r[1]) ? r[0] : (n.memoizedState = [e, t], e)
    }

    function Rf(e, t) {
        var n = $e();
        t = t === void 0 ? null : t;
        var r = n.memoizedState;
        return r !== null && t !== null && Bl(t, r[1]) ? r[0] : (e = e(), n.memoizedState = [e, t], e)
    }

    function Mf(e, t, n) {
        return cn & 21 ? (Ke(n, t) || (n = lc(), J.lanes |= n, fn |= n, e.baseState = !0), t) : (e.baseState && (e.baseState = !1, Ie = !0), e.memoizedState = n)
    }

    function nh(e, t) {
        var n = U;
        U = n !== 0 && 4 > n ? n : 4, e(!0);
        var r = Ul.transition;
        Ul.transition = {};
        try {
            e(!1), t()
        } finally {
            U = n, Ul.transition = r
        }
    }

    function Df() {
        return $e().memoizedState
    }

    function rh(e, t, n) {
        var r = Wt(e);
        if (n = {
                lane: r,
                action: n,
                hasEagerState: !1,
                eagerState: null,
                next: null
            }, jf(e)) zf(t, n);
        else if (n = ff(e, t, n, r), n !== null) {
            var o = ke();
            qe(n, e, r, o), Ff(n, t, r)
        }
    }

    function oh(e, t, n) {
        var r = Wt(e),
            o = {
                lane: r,
                action: n,
                hasEagerState: !1,
                eagerState: null,
                next: null
            };
        if (jf(e)) zf(t, o);
        else {
            var i = e.alternate;
            if (e.lanes === 0 && (i === null || i.lanes === 0) && (i = t.lastRenderedReducer, i !== null)) try {
                var a = t.lastRenderedState,
                    l = i(a, n);
                if (o.hasEagerState = !0, o.eagerState = l, Ke(l, a)) {
                    var s = t.interleaved;
                    s === null ? (o.next = o, jl(t)) : (o.next = s.next, s.next = o), t.interleaved = o;
                    return
                }
            } catch {} finally {}
            n = ff(e, t, o, r), n !== null && (o = ke(), qe(n, e, r, o), Ff(n, t, r))
        }
    }

    function jf(e) {
        var t = e.alternate;
        return e === J || t !== null && t === J
    }

    function zf(e, t) {
        qr = pi = !0;
        var n = e.pending;
        n === null ? t.next = t : (t.next = n.next, n.next = t), e.pending = t
    }

    function Ff(e, t, n) {
        if (n & 4194240) {
            var r = t.lanes;
            r &= e.pendingLanes, n |= r, t.lanes = n, Ya(e, n)
        }
    }
    var hi = {
            readContext: Be,
            useCallback: ye,
            useContext: ye,
            useEffect: ye,
            useImperativeHandle: ye,
            useInsertionEffect: ye,
            useLayoutEffect: ye,
            useMemo: ye,
            useReducer: ye,
            useRef: ye,
            useState: ye,
            useDebugValue: ye,
            useDeferredValue: ye,
            useTransition: ye,
            useMutableSource: ye,
            useSyncExternalStore: ye,
            useId: ye,
            unstable_isNewReconciler: !1
        },
        ih = {
            readContext: Be,
            useCallback: function(e, t) {
                return at().memoizedState = [e, t === void 0 ? null : t], e
            },
            useContext: Be,
            useEffect: Of,
            useImperativeHandle: function(e, t, n) {
                return n = n != null ? n.concat([e]) : null, vi(4194308, 4, If.bind(null, t, e), n)
            },
            useLayoutEffect: function(e, t) {
                return vi(4194308, 4, e, t)
            },
            useInsertionEffect: function(e, t) {
                return vi(4, 2, e, t)
            },
            useMemo: function(e, t) {
                var n = at();
                return t = t === void 0 ? null : t, e = e(), n.memoizedState = [e, t], e
            },
            useReducer: function(e, t, n) {
                var r = at();
                return t = n !== void 0 ? n(t) : t, r.memoizedState = r.baseState = t, e = {
                    pending: null,
                    interleaved: null,
                    lanes: 0,
                    dispatch: null,
                    lastRenderedReducer: e,
                    lastRenderedState: t
                }, r.queue = e, e = e.dispatch = rh.bind(null, J, e), [r.memoizedState, e]
            },
            useRef: function(e) {
                var t = at();
                return e = {
                    current: e
                }, t.memoizedState = e
            },
            useState: Ef,
            useDebugValue: Kl,
            useDeferredValue: function(e) {
                return at().memoizedState = e
            },
            useTransition: function() {
                var e = Ef(!1),
                    t = e[0];
                return e = nh.bind(null, e[1]), at().memoizedState = e, [t, e]
            },
            useMutableSource: function() {},
            useSyncExternalStore: function(e, t, n) {
                var r = J,
                    o = at();
                if (K) {
                    if (n === void 0) throw Error(x(407));
                    n = n()
                } else {
                    if (n = t(), ce === null) throw Error(x(349));
                    cn & 30 || yf(r, t, n)
                }
                o.memoizedState = n;
                var i = {
                    value: n,
                    getSnapshot: t
                };
                return o.queue = i, Of(Cf.bind(null, r, i, e), [e]), r.flags |= 2048, to(9, wf.bind(null, r, i, n, t), void 0, null), n
            },
            useId: function() {
                var e = at(),
                    t = ce.identifierPrefix;
                if (K) {
                    var n = mt,
                        r = ht;
                    n = (r & ~(1 << 32 - We(r) - 1)).toString(32) + n, t = ":" + t + "R" + n, n = Xr++, 0 < n && (t += "H" + n.toString(32)), t += ":"
                } else n = th++, t = ":" + t + "r" + n.toString(32) + ":";
                return e.memoizedState = t
            },
            unstable_isNewReconciler: !1
        },
        ah = {
            readContext: Be,
            useCallback: _f,
            useContext: Be,
            useEffect: Wl,
            useImperativeHandle: Nf,
            useInsertionEffect: Lf,
            useLayoutEffect: Pf,
            useMemo: Rf,
            useReducer: Hl,
            useRef: kf,
            useState: function() {
                return Hl(eo)
            },
            useDebugValue: Kl,
            useDeferredValue: function(e) {
                var t = $e();
                return Mf(t, ae.memoizedState, e)
            },
            useTransition: function() {
                var e = Hl(eo)[0],
                    t = $e().memoizedState;
                return [e, t]
            },
            useMutableSource: hf,
            useSyncExternalStore: mf,
            useId: Df,
            unstable_isNewReconciler: !1
        },
        lh = {
            readContext: Be,
            useCallback: _f,
            useContext: Be,
            useEffect: Wl,
            useImperativeHandle: Nf,
            useInsertionEffect: Lf,
            useLayoutEffect: Pf,
            useMemo: Rf,
            useReducer: Gl,
            useRef: kf,
            useState: function() {
                return Gl(eo)
            },
            useDebugValue: Kl,
            useDeferredValue: function(e) {
                var t = $e();
                return ae === null ? t.memoizedState = e : Mf(t, ae.memoizedState, e)
            },
            useTransition: function() {
                var e = Gl(eo)[0],
                    t = $e().memoizedState;
                return [e, t]
            },
            useMutableSource: hf,
            useSyncExternalStore: mf,
            useId: Df,
            unstable_isNewReconciler: !1
        };

    function Ye(e, t) {
        if (e && e.defaultProps) {
            t = Q({}, t), e = e.defaultProps;
            for (var n in e) t[n] === void 0 && (t[n] = e[n]);
            return t
        }
        return t
    }

    function Ql(e, t, n, r) {
        t = e.memoizedState, n = n(r, t), n = n == null ? t : Q({}, t, n), e.memoizedState = n, e.lanes === 0 && (e.updateQueue.baseState = n)
    }
    var mi = {
        isMounted: function(e) {
            return (e = e._reactInternals) ? nn(e) === e : !1
        },
        enqueueSetState: function(e, t, n) {
            e = e._reactInternals;
            var r = ke(),
                o = Wt(e),
                i = wt(r, o);
            i.payload = t, n != null && (i.callback = n), t = $t(e, i, o), t !== null && (qe(t, e, o, r), ui(t, e, o))
        },
        enqueueReplaceState: function(e, t, n) {
            e = e._reactInternals;
            var r = ke(),
                o = Wt(e),
                i = wt(r, o);
            i.tag = 1, i.payload = t, n != null && (i.callback = n), t = $t(e, i, o), t !== null && (qe(t, e, o, r), ui(t, e, o))
        },
        enqueueForceUpdate: function(e, t) {
            e = e._reactInternals;
            var n = ke(),
                r = Wt(e),
                o = wt(n, r);
            o.tag = 2, t != null && (o.callback = t), t = $t(e, o, r), t !== null && (qe(t, e, r, n), ui(t, e, r))
        }
    };

    function Tf(e, t, n, r, o, i, a) {
        return e = e.stateNode, typeof e.shouldComponentUpdate == "function" ? e.shouldComponentUpdate(r, i, a) : t.prototype && t.prototype.isPureReactComponent ? !Br(n, r) || !Br(o, i) : !0
    }

    function bf(e, t, n) {
        var r = !1,
            o = At,
            i = t.contextType;
        return typeof i == "object" && i !== null ? i = Be(i) : (o = Pe(t) ? on : me.current, r = t.contextTypes, i = (r = r != null) ? Wn(e, o) : At), t = new t(n, i), e.memoizedState = t.state !== null && t.state !== void 0 ? t.state : null, t.updater = mi, e.stateNode = t, t._reactInternals = e, r && (e = e.stateNode, e.__reactInternalMemoizedUnmaskedChildContext = o, e.__reactInternalMemoizedMaskedChildContext = i), t
    }

    function Af(e, t, n, r) {
        e = t.state, typeof t.componentWillReceiveProps == "function" && t.componentWillReceiveProps(n, r), typeof t.UNSAFE_componentWillReceiveProps == "function" && t.UNSAFE_componentWillReceiveProps(n, r), t.state !== e && mi.enqueueReplaceState(t, t.state, null)
    }

    function Yl(e, t, n, r) {
        var o = e.stateNode;
        o.props = n, o.state = e.memoizedState, o.refs = {}, zl(e);
        var i = t.contextType;
        typeof i == "object" && i !== null ? o.context = Be(i) : (i = Pe(t) ? on : me.current, o.context = Wn(e, i)), o.state = e.memoizedState, i = t.getDerivedStateFromProps, typeof i == "function" && (Ql(e, t, i, n), o.state = e.memoizedState), typeof t.getDerivedStateFromProps == "function" || typeof o.getSnapshotBeforeUpdate == "function" || typeof o.UNSAFE_componentWillMount != "function" && typeof o.componentWillMount != "function" || (t = o.state, typeof o.componentWillMount == "function" && o.componentWillMount(), typeof o.UNSAFE_componentWillMount == "function" && o.UNSAFE_componentWillMount(), t !== o.state && mi.enqueueReplaceState(o, o.state, null), ci(e, n, o, r), o.state = e.memoizedState), typeof o.componentDidMount == "function" && (e.flags |= 4194308)
    }

    function er(e, t) {
        try {
            var n = "",
                r = t;
            do n += zv(r), r = r.return; while (r);
            var o = n
        } catch (i) {
            o = `
Error generating stack: ` + i.message + `
` + i.stack
        }
        return {
            value: e,
            source: t,
            stack: o,
            digest: null
        }
    }

    function Jl(e, t, n) {
        return {
            value: e,
            source: null,
            stack: n ? ? null,
            digest: t ? ? null
        }
    }

    function Zl(e, t) {
        try {
            console.error(t.value)
        } catch (n) {
            setTimeout(function() {
                throw n
            })
        }
    }
    var sh = typeof WeakMap == "function" ? WeakMap : Map;

    function Uf(e, t, n) {
        n = wt(-1, n), n.tag = 3, n.payload = {
            element: null
        };
        var r = t.value;
        return n.callback = function() {
            ki || (ki = !0, ds = r), Zl(e, t)
        }, n
    }

    function Bf(e, t, n) {
        n = wt(-1, n), n.tag = 3;
        var r = e.type.getDerivedStateFromError;
        if (typeof r == "function") {
            var o = t.value;
            n.payload = function() {
                return r(o)
            }, n.callback = function() {
                Zl(e, t)
            }
        }
        var i = e.stateNode;
        return i !== null && typeof i.componentDidCatch == "function" && (n.callback = function() {
            Zl(e, t), typeof r != "function" && (Ht === null ? Ht = new Set([this]) : Ht.add(this));
            var a = t.stack;
            this.componentDidCatch(t.value, {
                componentStack: a !== null ? a : ""
            })
        }), n
    }

    function $f(e, t, n) {
        var r = e.pingCache;
        if (r === null) {
            r = e.pingCache = new sh;
            var o = new Set;
            r.set(t, o)
        } else o = r.get(t), o === void 0 && (o = new Set, r.set(t, o));
        o.has(n) || (o.add(n), e = xh.bind(null, e, t, n), t.then(e, e))
    }

    function Vf(e) {
        do {
            var t;
            if ((t = e.tag === 13) && (t = e.memoizedState, t = t !== null ? t.dehydrated !== null : !0), t) return e;
            e = e.return
        } while (e !== null);
        return null
    }

    function Hf(e, t, n, r, o) {
        return e.mode & 1 ? (e.flags |= 65536, e.lanes = o, e) : (e === t ? e.flags |= 65536 : (e.flags |= 128, n.flags |= 131072, n.flags &= -52805, n.tag === 1 && (n.alternate === null ? n.tag = 17 : (t = wt(-1, 1), t.tag = 2, $t(n, t, 1))), n.lanes |= 1), e)
    }
    var uh = pt.ReactCurrentOwner,
        Ie = !1;

    function Ee(e, t, n, r) {
        t.child = e === null ? cf(t, null, n, r) : Jn(t, e.child, n, r)
    }

    function Gf(e, t, n, r, o) {
        n = n.render;
        var i = t.ref;
        return qn(t, o), r = $l(e, t, n, r, i, o), n = Vl(), e !== null && !Ie ? (t.updateQueue = e.updateQueue, t.flags &= -2053, e.lanes &= ~o, Ct(e, t, o)) : (K && n && Ol(t), t.flags |= 1, Ee(e, t, r, o), t.child)
    }

    function Wf(e, t, n, r, o) {
        if (e === null) {
            var i = n.type;
            return typeof i == "function" && !ws(i) && i.defaultProps === void 0 && n.compare === null && n.defaultProps === void 0 ? (t.tag = 15, t.type = i, Kf(e, t, i, r, o)) : (e = _i(n.type, null, r, t, t.mode, o), e.ref = t.ref, e.return = t, t.child = e)
        }
        if (i = e.child, !(e.lanes & o)) {
            var a = i.memoizedProps;
            if (n = n.compare, n = n !== null ? n : Br, n(a, r) && e.ref === t.ref) return Ct(e, t, o)
        }
        return t.flags |= 1, e = Qt(i, r), e.ref = t.ref, e.return = t, t.child = e
    }

    function Kf(e, t, n, r, o) {
        if (e !== null) {
            var i = e.memoizedProps;
            if (Br(i, r) && e.ref === t.ref)
                if (Ie = !1, t.pendingProps = r = i, (e.lanes & o) !== 0) e.flags & 131072 && (Ie = !0);
                else return t.lanes = e.lanes, Ct(e, t, o)
        }
        return ql(e, t, n, r, o)
    }

    function Qf(e, t, n) {
        var r = t.pendingProps,
            o = r.children,
            i = e !== null ? e.memoizedState : null;
        if (r.mode === "hidden")
            if (!(t.mode & 1)) t.memoizedState = {
                baseLanes: 0,
                cachePool: null,
                transitions: null
            }, V(nr, Te), Te |= n;
            else {
                if (!(n & 1073741824)) return e = i !== null ? i.baseLanes | n : n, t.lanes = t.childLanes = 1073741824, t.memoizedState = {
                    baseLanes: e,
                    cachePool: null,
                    transitions: null
                }, t.updateQueue = null, V(nr, Te), Te |= e, null;
                t.memoizedState = {
                    baseLanes: 0,
                    cachePool: null,
                    transitions: null
                }, r = i !== null ? i.baseLanes : n, V(nr, Te), Te |= r
            }
        else i !== null ? (r = i.baseLanes | n, t.memoizedState = null) : r = n, V(nr, Te), Te |= r;
        return Ee(e, t, o, n), t.child
    }

    function Yf(e, t) {
        var n = t.ref;
        (e === null && n !== null || e !== null && e.ref !== n) && (t.flags |= 512, t.flags |= 2097152)
    }

    function ql(e, t, n, r, o) {
        var i = Pe(n) ? on : me.current;
        return i = Wn(t, i), qn(t, o), n = $l(e, t, n, r, i, o), r = Vl(), e !== null && !Ie ? (t.updateQueue = e.updateQueue, t.flags &= -2053, e.lanes &= ~o, Ct(e, t, o)) : (K && r && Ol(t), t.flags |= 1, Ee(e, t, n, o), t.child)
    }

    function Jf(e, t, n, r, o) {
        if (Pe(n)) {
            var i = !0;
            ti(t)
        } else i = !1;
        if (qn(t, o), t.stateNode === null) wi(e, t), bf(t, n, r), Yl(t, n, r, o), r = !0;
        else if (e === null) {
            var a = t.stateNode,
                l = t.memoizedProps;
            a.props = l;
            var s = a.context,
                u = n.contextType;
            typeof u == "object" && u !== null ? u = Be(u) : (u = Pe(n) ? on : me.current, u = Wn(t, u));
            var c = n.getDerivedStateFromProps,
                f = typeof c == "function" || typeof a.getSnapshotBeforeUpdate == "function";
            f || typeof a.UNSAFE_componentWillReceiveProps != "function" && typeof a.componentWillReceiveProps != "function" || (l !== r || s !== u) && Af(t, a, r, u), Bt = !1;
            var d = t.memoizedState;
            a.state = d, ci(t, r, a, o), s = t.memoizedState, l !== r || d !== s || Le.current || Bt ? (typeof c == "function" && (Ql(t, n, c, r), s = t.memoizedState), (l = Bt || Tf(t, n, l, r, d, s, u)) ? (f || typeof a.UNSAFE_componentWillMount != "function" && typeof a.componentWillMount != "function" || (typeof a.componentWillMount == "function" && a.componentWillMount(), typeof a.UNSAFE_componentWillMount == "function" && a.UNSAFE_componentWillMount()), typeof a.componentDidMount == "function" && (t.flags |= 4194308)) : (typeof a.componentDidMount == "function" && (t.flags |= 4194308), t.memoizedProps = r, t.memoizedState = s), a.props = r, a.state = s, a.context = u, r = l) : (typeof a.componentDidMount == "function" && (t.flags |= 4194308), r = !1)
        } else {
            a = t.stateNode, df(e, t), l = t.memoizedProps, u = t.type === t.elementType ? l : Ye(t.type, l), a.props = u, f = t.pendingProps, d = a.context, s = n.contextType, typeof s == "object" && s !== null ? s = Be(s) : (s = Pe(n) ? on : me.current, s = Wn(t, s));
            var h = n.getDerivedStateFromProps;
            (c = typeof h == "function" || typeof a.getSnapshotBeforeUpdate == "function") || typeof a.UNSAFE_componentWillReceiveProps != "function" && typeof a.componentWillReceiveProps != "function" || (l !== f || d !== s) && Af(t, a, r, s), Bt = !1, d = t.memoizedState, a.state = d, ci(t, r, a, o);
            var y = t.memoizedState;
            l !== f || d !== y || Le.current || Bt ? (typeof h == "function" && (Ql(t, n, h, r), y = t.memoizedState), (u = Bt || Tf(t, n, u, r, d, y, s) || !1) ? (c || typeof a.UNSAFE_componentWillUpdate != "function" && typeof a.componentWillUpdate != "function" || (typeof a.componentWillUpdate == "function" && a.componentWillUpdate(r, y, s), typeof a.UNSAFE_componentWillUpdate == "function" && a.UNSAFE_componentWillUpdate(r, y, s)), typeof a.componentDidUpdate == "function" && (t.flags |= 4), typeof a.getSnapshotBeforeUpdate == "function" && (t.flags |= 1024)) : (typeof a.componentDidUpdate != "function" || l === e.memoizedProps && d === e.memoizedState || (t.flags |= 4), typeof a.getSnapshotBeforeUpdate != "function" || l === e.memoizedProps && d === e.memoizedState || (t.flags |= 1024), t.memoizedProps = r, t.memoizedState = y), a.props = r, a.state = y, a.context = s, r = u) : (typeof a.componentDidUpdate != "function" || l === e.memoizedProps && d === e.memoizedState || (t.flags |= 4), typeof a.getSnapshotBeforeUpdate != "function" || l === e.memoizedProps && d === e.memoizedState || (t.flags |= 1024), r = !1)
        }
        return Xl(e, t, n, r, i, o)
    }

    function Xl(e, t, n, r, o, i) {
        Yf(e, t);
        var a = (t.flags & 128) !== 0;
        if (!r && !a) return o && ef(t, n, !1), Ct(e, t, i);
        r = t.stateNode, uh.current = t;
        var l = a && typeof n.getDerivedStateFromError != "function" ? null : r.render();
        return t.flags |= 1, e !== null && a ? (t.child = Jn(t, e.child, null, i), t.child = Jn(t, null, l, i)) : Ee(e, t, l, i), t.memoizedState = r.state, o && ef(t, n, !0), t.child
    }

    function Zf(e) {
        var t = e.stateNode;
        t.pendingContext ? qc(e, t.pendingContext, t.pendingContext !== t.context) : t.context && qc(e, t.context, !1), Fl(e, t.containerInfo)
    }

    function qf(e, t, n, r, o) {
        return Yn(), Nl(o), t.flags |= 256, Ee(e, t, n, r), t.child
    }
    var es = {
        dehydrated: null,
        treeContext: null,
        retryLane: 0
    };

    function ts(e) {
        return {
            baseLanes: e,
            cachePool: null,
            transitions: null
        }
    }

    function Xf(e, t, n) {
        var r = t.pendingProps,
            o = Y.current,
            i = !1,
            a = (t.flags & 128) !== 0,
            l;
        if ((l = a) || (l = e !== null && e.memoizedState === null ? !1 : (o & 2) !== 0), l ? (i = !0, t.flags &= -129) : (e === null || e.memoizedState !== null) && (o |= 1), V(Y, o & 1), e === null) return Il(t), e = t.memoizedState, e !== null && (e = e.dehydrated, e !== null) ? (t.mode & 1 ? e.data === "$!" ? t.lanes = 8 : t.lanes = 1073741824 : t.lanes = 1, null) : (a = r.children, e = r.fallback, i ? (r = t.mode, i = t.child, a = {
            mode: "hidden",
            children: a
        }, !(r & 1) && i !== null ? (i.childLanes = 0, i.pendingProps = a) : i = Ri(a, r, 0, null), e = gn(e, r, n, null), i.return = t, e.return = t, i.sibling = e, t.child = i, t.child.memoizedState = ts(n), t.memoizedState = es, e) : ns(t, a));
        if (o = e.memoizedState, o !== null && (l = o.dehydrated, l !== null)) return ch(e, t, a, r, l, o, n);
        if (i) {
            i = r.fallback, a = t.mode, o = e.child, l = o.sibling;
            var s = {
                mode: "hidden",
                children: r.children
            };
            return !(a & 1) && t.child !== o ? (r = t.child, r.childLanes = 0, r.pendingProps = s, t.deletions = null) : (r = Qt(o, s), r.subtreeFlags = o.subtreeFlags & 14680064), l !== null ? i = Qt(l, i) : (i = gn(i, a, n, null), i.flags |= 2), i.return = t, r.return = t, r.sibling = i, t.child = r, r = i, i = t.child, a = e.child.memoizedState, a = a === null ? ts(n) : {
                baseLanes: a.baseLanes | n,
                cachePool: null,
                transitions: a.transitions
            }, i.memoizedState = a, i.childLanes = e.childLanes & ~n, t.memoizedState = es, r
        }
        return i = e.child, e = i.sibling, r = Qt(i, {
            mode: "visible",
            children: r.children
        }), !(t.mode & 1) && (r.lanes = n), r.return = t, r.sibling = null, e !== null && (n = t.deletions, n === null ? (t.deletions = [e], t.flags |= 16) : n.push(e)), t.child = r, t.memoizedState = null, r
    }

    function ns(e, t) {
        return t = Ri({
            mode: "visible",
            children: t
        }, e.mode, 0, null), t.return = e, e.child = t
    }

    function yi(e, t, n, r) {
        return r !== null && Nl(r), Jn(t, e.child, null, n), e = ns(t, t.pendingProps.children), e.flags |= 2, t.memoizedState = null, e
    }

    function ch(e, t, n, r, o, i, a) {
        if (n) return t.flags & 256 ? (t.flags &= -257, r = Jl(Error(x(422))), yi(e, t, a, r)) : t.memoizedState !== null ? (t.child = e.child, t.flags |= 128, null) : (i = r.fallback, o = t.mode, r = Ri({
            mode: "visible",
            children: r.children
        }, o, 0, null), i = gn(i, o, a, null), i.flags |= 2, r.return = t, i.return = t, r.sibling = i, t.child = r, t.mode & 1 && Jn(t, e.child, null, a), t.child.memoizedState = ts(a), t.memoizedState = es, i);
        if (!(t.mode & 1)) return yi(e, t, a, null);
        if (o.data === "$!") {
            if (r = o.nextSibling && o.nextSibling.dataset, r) var l = r.dgst;
            return r = l, i = Error(x(419)), r = Jl(i, r, void 0), yi(e, t, a, r)
        }
        if (l = (a & e.childLanes) !== 0, Ie || l) {
            if (r = ce, r !== null) {
                switch (a & -a) {
                    case 4:
                        o = 2;
                        break;
                    case 16:
                        o = 8;
                        break;
                    case 64:
                    case 128:
                    case 256:
                    case 512:
                    case 1024:
                    case 2048:
                    case 4096:
                    case 8192:
                    case 16384:
                    case 32768:
                    case 65536:
                    case 131072:
                    case 262144:
                    case 524288:
                    case 1048576:
                    case 2097152:
                    case 4194304:
                    case 8388608:
                    case 16777216:
                    case 33554432:
                    case 67108864:
                        o = 32;
                        break;
                    case 536870912:
                        o = 268435456;
                        break;
                    default:
                        o = 0
                }
                o = o & (r.suspendedLanes | a) ? 0 : o, o !== 0 && o !== i.retryLane && (i.retryLane = o, yt(e, o), qe(r, e, o, -1))
            }
            return ys(), r = Jl(Error(x(421))), yi(e, t, a, r)
        }
        return o.data === "$?" ? (t.flags |= 128, t.child = e.child, t = Eh.bind(null, e), o._reactRetry = t, null) : (e = i.treeContext, Fe = Tt(o.nextSibling), ze = t, K = !0, Qe = null, e !== null && (Ae[Ue++] = ht, Ae[Ue++] = mt, Ae[Ue++] = an, ht = e.id, mt = e.overflow, an = t), t = ns(t, r.children), t.flags |= 4096, t)
    }

    function ed(e, t, n) {
        e.lanes |= t;
        var r = e.alternate;
        r !== null && (r.lanes |= t), Dl(e.return, t, n)
    }

    function rs(e, t, n, r, o) {
        var i = e.memoizedState;
        i === null ? e.memoizedState = {
            isBackwards: t,
            rendering: null,
            renderingStartTime: 0,
            last: r,
            tail: n,
            tailMode: o
        } : (i.isBackwards = t, i.rendering = null, i.renderingStartTime = 0, i.last = r, i.tail = n, i.tailMode = o)
    }

    function td(e, t, n) {
        var r = t.pendingProps,
            o = r.revealOrder,
            i = r.tail;
        if (Ee(e, t, r.children, n), r = Y.current, r & 2) r = r & 1 | 2, t.flags |= 128;
        else {
            if (e !== null && e.flags & 128) e: for (e = t.child; e !== null;) {
                if (e.tag === 13) e.memoizedState !== null && ed(e, n, t);
                else if (e.tag === 19) ed(e, n, t);
                else if (e.child !== null) {
                    e.child.return = e, e = e.child;
                    continue
                }
                if (e === t) break e;
                for (; e.sibling === null;) {
                    if (e.return === null || e.return === t) break e;
                    e = e.return
                }
                e.sibling.return = e.return, e = e.sibling
            }
            r &= 1
        }
        if (V(Y, r), !(t.mode & 1)) t.memoizedState = null;
        else switch (o) {
            case "forwards":
                for (n = t.child, o = null; n !== null;) e = n.alternate, e !== null && fi(e) === null && (o = n), n = n.sibling;
                n = o, n === null ? (o = t.child, t.child = null) : (o = n.sibling, n.sibling = null), rs(t, !1, o, n, i);
                break;
            case "backwards":
                for (n = null, o = t.child, t.child = null; o !== null;) {
                    if (e = o.alternate, e !== null && fi(e) === null) {
                        t.child = o;
                        break
                    }
                    e = o.sibling, o.sibling = n, n = o, o = e
                }
                rs(t, !0, n, null, i);
                break;
            case "together":
                rs(t, !1, null, null, void 0);
                break;
            default:
                t.memoizedState = null
        }
        return t.child
    }

    function wi(e, t) {
        !(t.mode & 1) && e !== null && (e.alternate = null, t.alternate = null, t.flags |= 2)
    }

    function Ct(e, t, n) {
        if (e !== null && (t.dependencies = e.dependencies), fn |= t.lanes, !(n & t.childLanes)) return null;
        if (e !== null && t.child !== e.child) throw Error(x(153));
        if (t.child !== null) {
            for (e = t.child, n = Qt(e, e.pendingProps), t.child = n, n.return = t; e.sibling !== null;) e = e.sibling, n = n.sibling = Qt(e, e.pendingProps), n.return = t;
            n.sibling = null
        }
        return t.child
    }

    function fh(e, t, n) {
        switch (t.tag) {
            case 3:
                Zf(t), Yn();
                break;
            case 5:
                gf(t);
                break;
            case 1:
                Pe(t.type) && ti(t);
                break;
            case 4:
                Fl(t, t.stateNode.containerInfo);
                break;
            case 10:
                var r = t.type._context,
                    o = t.memoizedProps.value;
                V(li, r._currentValue), r._currentValue = o;
                break;
            case 13:
                if (r = t.memoizedState, r !== null) return r.dehydrated !== null ? (V(Y, Y.current & 1), t.flags |= 128, null) : n & t.child.childLanes ? Xf(e, t, n) : (V(Y, Y.current & 1), e = Ct(e, t, n), e !== null ? e.sibling : null);
                V(Y, Y.current & 1);
                break;
            case 19:
                if (r = (n & t.childLanes) !== 0, e.flags & 128) {
                    if (r) return td(e, t, n);
                    t.flags |= 128
                }
                if (o = t.memoizedState, o !== null && (o.rendering = null, o.tail = null, o.lastEffect = null), V(Y, Y.current), r) break;
                return null;
            case 22:
            case 23:
                return t.lanes = 0, Qf(e, t, n)
        }
        return Ct(e, t, n)
    }
    var nd, os, rd, od;
    nd = function(e, t) {
        for (var n = t.child; n !== null;) {
            if (n.tag === 5 || n.tag === 6) e.appendChild(n.stateNode);
            else if (n.tag !== 4 && n.child !== null) {
                n.child.return = n, n = n.child;
                continue
            }
            if (n === t) break;
            for (; n.sibling === null;) {
                if (n.return === null || n.return === t) return;
                n = n.return
            }
            n.sibling.return = n.return, n = n.sibling
        }
    }, os = function() {}, rd = function(e, t, n, r) {
        var o = e.memoizedProps;
        if (o !== r) {
            e = t.stateNode, un(it.current);
            var i = null;
            switch (n) {
                case "input":
                    o = Da(e, o), r = Da(e, r), i = [];
                    break;
                case "select":
                    o = Q({}, o, {
                        value: void 0
                    }), r = Q({}, r, {
                        value: void 0
                    }), i = [];
                    break;
                case "textarea":
                    o = Fa(e, o), r = Fa(e, r), i = [];
                    break;
                default:
                    typeof o.onClick != "function" && typeof r.onClick == "function" && (e.onclick = qo)
            }
            ba(n, r);
            var a;
            n = null;
            for (u in o)
                if (!r.hasOwnProperty(u) && o.hasOwnProperty(u) && o[u] != null)
                    if (u === "style") {
                        var l = o[u];
                        for (a in l) l.hasOwnProperty(a) && (n || (n = {}), n[a] = "")
                    } else u !== "dangerouslySetInnerHTML" && u !== "children" && u !== "suppressContentEditableWarning" && u !== "suppressHydrationWarning" && u !== "autoFocus" && (Cr.hasOwnProperty(u) ? i || (i = []) : (i = i || []).push(u, null));
            for (u in r) {
                var s = r[u];
                if (l = o != null ? o[u] : void 0, r.hasOwnProperty(u) && s !== l && (s != null || l != null))
                    if (u === "style")
                        if (l) {
                            for (a in l) !l.hasOwnProperty(a) || s && s.hasOwnProperty(a) || (n || (n = {}), n[a] = "");
                            for (a in s) s.hasOwnProperty(a) && l[a] !== s[a] && (n || (n = {}), n[a] = s[a])
                        } else n || (i || (i = []), i.push(u, n)), n = s;
                else u === "dangerouslySetInnerHTML" ? (s = s ? s.__html : void 0, l = l ? l.__html : void 0, s != null && l !== s && (i = i || []).push(u, s)) : u === "children" ? typeof s != "string" && typeof s != "number" || (i = i || []).push(u, "" + s) : u !== "suppressContentEditableWarning" && u !== "suppressHydrationWarning" && (Cr.hasOwnProperty(u) ? (s != null && u === "onScroll" && H("scroll", e), i || l === s || (i = [])) : (i = i || []).push(u, s))
            }
            n && (i = i || []).push("style", n);
            var u = i;
            (t.updateQueue = u) && (t.flags |= 4)
        }
    }, od = function(e, t, n, r) {
        n !== r && (t.flags |= 4)
    };

    function no(e, t) {
        if (!K) switch (e.tailMode) {
            case "hidden":
                t = e.tail;
                for (var n = null; t !== null;) t.alternate !== null && (n = t), t = t.sibling;
                n === null ? e.tail = null : n.sibling = null;
                break;
            case "collapsed":
                n = e.tail;
                for (var r = null; n !== null;) n.alternate !== null && (r = n), n = n.sibling;
                r === null ? t || e.tail === null ? e.tail = null : e.tail.sibling = null : r.sibling = null
        }
    }

    function we(e) {
        var t = e.alternate !== null && e.alternate.child === e.child,
            n = 0,
            r = 0;
        if (t)
            for (var o = e.child; o !== null;) n |= o.lanes | o.childLanes, r |= o.subtreeFlags & 14680064, r |= o.flags & 14680064, o.return = e, o = o.sibling;
        else
            for (o = e.child; o !== null;) n |= o.lanes | o.childLanes, r |= o.subtreeFlags, r |= o.flags, o.return = e, o = o.sibling;
        return e.subtreeFlags |= r, e.childLanes = n, t
    }

    function dh(e, t, n) {
        var r = t.pendingProps;
        switch (Ll(t), t.tag) {
            case 2:
            case 16:
            case 15:
            case 0:
            case 11:
            case 7:
            case 8:
            case 12:
            case 9:
            case 14:
                return we(t), null;
            case 1:
                return Pe(t.type) && ei(), we(t), null;
            case 3:
                return r = t.stateNode, Xn(), G(Le), G(me), Al(), r.pendingContext && (r.context = r.pendingContext, r.pendingContext = null), (e === null || e.child === null) && (ii(t) ? t.flags |= 4 : e === null || e.memoizedState.isDehydrated && !(t.flags & 256) || (t.flags |= 1024, Qe !== null && (gs(Qe), Qe = null))), os(e, t), we(t), null;
            case 5:
                Tl(t);
                var o = un(Zr.current);
                if (n = t.type, e !== null && t.stateNode != null) rd(e, t, n, r, o), e.ref !== t.ref && (t.flags |= 512, t.flags |= 2097152);
                else {
                    if (!r) {
                        if (t.stateNode === null) throw Error(x(166));
                        return we(t), null
                    }
                    if (e = un(it.current), ii(t)) {
                        r = t.stateNode, n = t.type;
                        var i = t.memoizedProps;
                        switch (r[ot] = t, r[Wr] = i, e = (t.mode & 1) !== 0, n) {
                            case "dialog":
                                H("cancel", r), H("close", r);
                                break;
                            case "iframe":
                            case "object":
                            case "embed":
                                H("load", r);
                                break;
                            case "video":
                            case "audio":
                                for (o = 0; o < Vr.length; o++) H(Vr[o], r);
                                break;
                            case "source":
                                H("error", r);
                                break;
                            case "img":
                            case "image":
                            case "link":
                                H("error", r), H("load", r);
                                break;
                            case "details":
                                H("toggle", r);
                                break;
                            case "input":
                                Tu(r, i), H("invalid", r);
                                break;
                            case "select":
                                r._wrapperState = {
                                    wasMultiple: !!i.multiple
                                }, H("invalid", r);
                                break;
                            case "textarea":
                                Uu(r, i), H("invalid", r)
                        }
                        ba(n, i), o = null;
                        for (var a in i)
                            if (i.hasOwnProperty(a)) {
                                var l = i[a];
                                a === "children" ? typeof l == "string" ? r.textContent !== l && (i.suppressHydrationWarning !== !0 && Zo(r.textContent, l, e), o = ["children", l]) : typeof l == "number" && r.textContent !== "" + l && (i.suppressHydrationWarning !== !0 && Zo(r.textContent, l, e), o = ["children", "" + l]) : Cr.hasOwnProperty(a) && l != null && a === "onScroll" && H("scroll", r)
                            }
                        switch (n) {
                            case "input":
                                Io(r), Au(r, i, !0);
                                break;
                            case "textarea":
                                Io(r), $u(r);
                                break;
                            case "select":
                            case "option":
                                break;
                            default:
                                typeof i.onClick == "function" && (r.onclick = qo)
                        }
                        r = o, t.updateQueue = r, r !== null && (t.flags |= 4)
                    } else {
                        a = o.nodeType === 9 ? o : o.ownerDocument, e === "http://www.w3.org/1999/xhtml" && (e = Vu(n)), e === "http://www.w3.org/1999/xhtml" ? n === "script" ? (e = a.createElement("div"), e.innerHTML = "<script><\/script>", e = e.removeChild(e.firstChild)) : typeof r.is == "string" ? e = a.createElement(n, {
                            is: r.is
                        }) : (e = a.createElement(n), n === "select" && (a = e, r.multiple ? a.multiple = !0 : r.size && (a.size = r.size))) : e = a.createElementNS(e, n), e[ot] = t, e[Wr] = r, nd(e, t, !1, !1), t.stateNode = e;
                        e: {
                            switch (a = Aa(n, r), n) {
                                case "dialog":
                                    H("cancel", e), H("close", e), o = r;
                                    break;
                                case "iframe":
                                case "object":
                                case "embed":
                                    H("load", e), o = r;
                                    break;
                                case "video":
                                case "audio":
                                    for (o = 0; o < Vr.length; o++) H(Vr[o], e);
                                    o = r;
                                    break;
                                case "source":
                                    H("error", e), o = r;
                                    break;
                                case "img":
                                case "image":
                                case "link":
                                    H("error", e), H("load", e), o = r;
                                    break;
                                case "details":
                                    H("toggle", e), o = r;
                                    break;
                                case "input":
                                    Tu(e, r), o = Da(e, r), H("invalid", e);
                                    break;
                                case "option":
                                    o = r;
                                    break;
                                case "select":
                                    e._wrapperState = {
                                        wasMultiple: !!r.multiple
                                    }, o = Q({}, r, {
                                        value: void 0
                                    }), H("invalid", e);
                                    break;
                                case "textarea":
                                    Uu(e, r), o = Fa(e, r), H("invalid", e);
                                    break;
                                default:
                                    o = r
                            }
                            ba(n, o),
                            l = o;
                            for (i in l)
                                if (l.hasOwnProperty(i)) {
                                    var s = l[i];
                                    i === "style" ? Wu(e, s) : i === "dangerouslySetInnerHTML" ? (s = s ? s.__html : void 0, s != null && Hu(e, s)) : i === "children" ? typeof s == "string" ? (n !== "textarea" || s !== "") && kr(e, s) : typeof s == "number" && kr(e, "" + s) : i !== "suppressContentEditableWarning" && i !== "suppressHydrationWarning" && i !== "autoFocus" && (Cr.hasOwnProperty(i) ? s != null && i === "onScroll" && H("scroll", e) : s != null && xa(e, i, s, a))
                                }
                            switch (n) {
                                case "input":
                                    Io(e), Au(e, r, !1);
                                    break;
                                case "textarea":
                                    Io(e), $u(e);
                                    break;
                                case "option":
                                    r.value != null && e.setAttribute("value", "" + _t(r.value));
                                    break;
                                case "select":
                                    e.multiple = !!r.multiple, i = r.value, i != null ? jn(e, !!r.multiple, i, !1) : r.defaultValue != null && jn(e, !!r.multiple, r.defaultValue, !0);
                                    break;
                                default:
                                    typeof o.onClick == "function" && (e.onclick = qo)
                            }
                            switch (n) {
                                case "button":
                                case "input":
                                case "select":
                                case "textarea":
                                    r = !!r.autoFocus;
                                    break e;
                                case "img":
                                    r = !0;
                                    break e;
                                default:
                                    r = !1
                            }
                        }
                        r && (t.flags |= 4)
                    }
                    t.ref !== null && (t.flags |= 512, t.flags |= 2097152)
                }
                return we(t), null;
            case 6:
                if (e && t.stateNode != null) od(e, t, e.memoizedProps, r);
                else {
                    if (typeof r != "string" && t.stateNode === null) throw Error(x(166));
                    if (n = un(Zr.current), un(it.current), ii(t)) {
                        if (r = t.stateNode, n = t.memoizedProps, r[ot] = t, (i = r.nodeValue !== n) && (e = ze, e !== null)) switch (e.tag) {
                            case 3:
                                Zo(r.nodeValue, n, (e.mode & 1) !== 0);
                                break;
                            case 5:
                                e.memoizedProps.suppressHydrationWarning !== !0 && Zo(r.nodeValue, n, (e.mode & 1) !== 0)
                        }
                        i && (t.flags |= 4)
                    } else r = (n.nodeType === 9 ? n : n.ownerDocument).createTextNode(r), r[ot] = t, t.stateNode = r
                }
                return we(t), null;
            case 13:
                if (G(Y), r = t.memoizedState, e === null || e.memoizedState !== null && e.memoizedState.dehydrated !== null) {
                    if (K && Fe !== null && t.mode & 1 && !(t.flags & 128)) lf(), Yn(), t.flags |= 98560, i = !1;
                    else if (i = ii(t), r !== null && r.dehydrated !== null) {
                        if (e === null) {
                            if (!i) throw Error(x(318));
                            if (i = t.memoizedState, i = i !== null ? i.dehydrated : null, !i) throw Error(x(317));
                            i[ot] = t
                        } else Yn(), !(t.flags & 128) && (t.memoizedState = null), t.flags |= 4;
                        we(t), i = !1
                    } else Qe !== null && (gs(Qe), Qe = null), i = !0;
                    if (!i) return t.flags & 65536 ? t : null
                }
                return t.flags & 128 ? (t.lanes = n, t) : (r = r !== null, r !== (e !== null && e.memoizedState !== null) && r && (t.child.flags |= 8192, t.mode & 1 && (e === null || Y.current & 1 ? le === 0 && (le = 3) : ys())), t.updateQueue !== null && (t.flags |= 4), we(t), null);
            case 4:
                return Xn(), os(e, t), e === null && Hr(t.stateNode.containerInfo), we(t), null;
            case 10:
                return Ml(t.type._context), we(t), null;
            case 17:
                return Pe(t.type) && ei(), we(t), null;
            case 19:
                if (G(Y), i = t.memoizedState, i === null) return we(t), null;
                if (r = (t.flags & 128) !== 0, a = i.rendering, a === null)
                    if (r) no(i, !1);
                    else {
                        if (le !== 0 || e !== null && e.flags & 128)
                            for (e = t.child; e !== null;) {
                                if (a = fi(e), a !== null) {
                                    for (t.flags |= 128, no(i, !1), r = a.updateQueue, r !== null && (t.updateQueue = r, t.flags |= 4), t.subtreeFlags = 0, r = n, n = t.child; n !== null;) i = n, e = r, i.flags &= 14680066, a = i.alternate, a === null ? (i.childLanes = 0, i.lanes = e, i.child = null, i.subtreeFlags = 0, i.memoizedProps = null, i.memoizedState = null, i.updateQueue = null, i.dependencies = null, i.stateNode = null) : (i.childLanes = a.childLanes, i.lanes = a.lanes, i.child = a.child, i.subtreeFlags = 0, i.deletions = null, i.memoizedProps = a.memoizedProps, i.memoizedState = a.memoizedState, i.updateQueue = a.updateQueue, i.type = a.type, e = a.dependencies, i.dependencies = e === null ? null : {
                                        lanes: e.lanes,
                                        firstContext: e.firstContext
                                    }), n = n.sibling;
                                    return V(Y, Y.current & 1 | 2), t.child
                                }
                                e = e.sibling
                            }
                        i.tail !== null && te() > rr && (t.flags |= 128, r = !0, no(i, !1), t.lanes = 4194304)
                    }
                else {
                    if (!r)
                        if (e = fi(a), e !== null) {
                            if (t.flags |= 128, r = !0, n = e.updateQueue, n !== null && (t.updateQueue = n, t.flags |= 4), no(i, !0), i.tail === null && i.tailMode === "hidden" && !a.alternate && !K) return we(t), null
                        } else 2 * te() - i.renderingStartTime > rr && n !== 1073741824 && (t.flags |= 128, r = !0, no(i, !1), t.lanes = 4194304);
                    i.isBackwards ? (a.sibling = t.child, t.child = a) : (n = i.last, n !== null ? n.sibling = a : t.child = a, i.last = a)
                }
                return i.tail !== null ? (t = i.tail, i.rendering = t, i.tail = t.sibling, i.renderingStartTime = te(), t.sibling = null, n = Y.current, V(Y, r ? n & 1 | 2 : n & 1), t) : (we(t), null);
            case 22:
            case 23:
                return ms(), r = t.memoizedState !== null, e !== null && e.memoizedState !== null !== r && (t.flags |= 8192), r && t.mode & 1 ? Te & 1073741824 && (we(t), t.subtreeFlags & 6 && (t.flags |= 8192)) : we(t), null;
            case 24:
                return null;
            case 25:
                return null
        }
        throw Error(x(156, t.tag))
    }

    function ph(e, t) {
        switch (Ll(t), t.tag) {
            case 1:
                return Pe(t.type) && ei(), e = t.flags, e & 65536 ? (t.flags = e & -65537 | 128, t) : null;
            case 3:
                return Xn(), G(Le), G(me), Al(), e = t.flags, e & 65536 && !(e & 128) ? (t.flags = e & -65537 | 128, t) : null;
            case 5:
                return Tl(t), null;
            case 13:
                if (G(Y), e = t.memoizedState, e !== null && e.dehydrated !== null) {
                    if (t.alternate === null) throw Error(x(340));
                    Yn()
                }
                return e = t.flags, e & 65536 ? (t.flags = e & -65537 | 128, t) : null;
            case 19:
                return G(Y), null;
            case 4:
                return Xn(), null;
            case 10:
                return Ml(t.type._context), null;
            case 22:
            case 23:
                return ms(), null;
            case 24:
                return null;
            default:
                return null
        }
    }
    var Ci = !1,
        Ce = !1,
        vh = typeof WeakSet == "function" ? WeakSet : Set,
        L = null;

    function tr(e, t) {
        var n = e.ref;
        if (n !== null)
            if (typeof n == "function") try {
                n(null)
            } catch (r) {
                q(e, t, r)
            } else n.current = null
    }

    function is(e, t, n) {
        try {
            n()
        } catch (r) {
            q(e, t, r)
        }
    }
    var id = !1;

    function gh(e, t) {
        if (ml = Uo, e = Fc(), ul(e)) {
            if ("selectionStart" in e) var n = {
                start: e.selectionStart,
                end: e.selectionEnd
            };
            else e: {
                n = (n = e.ownerDocument) && n.defaultView || window;
                var r = n.getSelection && n.getSelection();
                if (r && r.rangeCount !== 0) {
                    n = r.anchorNode;
                    var o = r.anchorOffset,
                        i = r.focusNode;
                    r = r.focusOffset;
                    try {
                        n.nodeType, i.nodeType
                    } catch {
                        n = null;
                        break e
                    }
                    var a = 0,
                        l = -1,
                        s = -1,
                        u = 0,
                        c = 0,
                        f = e,
                        d = null;
                    t: for (;;) {
                        for (var h; f !== n || o !== 0 && f.nodeType !== 3 || (l = a + o), f !== i || r !== 0 && f.nodeType !== 3 || (s = a + r), f.nodeType === 3 && (a += f.nodeValue.length), (h = f.firstChild) !== null;) d = f, f = h;
                        for (;;) {
                            if (f === e) break t;
                            if (d === n && ++u === o && (l = a), d === i && ++c === r && (s = a), (h = f.nextSibling) !== null) break;
                            f = d, d = f.parentNode
                        }
                        f = h
                    }
                    n = l === -1 || s === -1 ? null : {
                        start: l,
                        end: s
                    }
                } else n = null
            }
            n = n || {
                start: 0,
                end: 0
            }
        } else n = null;
        for (yl = {
                focusedElem: e,
                selectionRange: n
            }, Uo = !1, L = t; L !== null;)
            if (t = L, e = t.child, (t.subtreeFlags & 1028) !== 0 && e !== null) e.return = t, L = e;
            else
                for (; L !== null;) {
                    t = L;
                    try {
                        var y = t.alternate;
                        if (t.flags & 1024) switch (t.tag) {
                            case 0:
                            case 11:
                            case 15:
                                break;
                            case 1:
                                if (y !== null) {
                                    var m = y.memoizedProps,
                                        E = y.memoizedState,
                                        v = t.stateNode,
                                        p = v.getSnapshotBeforeUpdate(t.elementType === t.type ? m : Ye(t.type, m), E);
                                    v.__reactInternalSnapshotBeforeUpdate = p
                                }
                                break;
                            case 3:
                                var g = t.stateNode.containerInfo;
                                g.nodeType === 1 ? g.textContent = "" : g.nodeType === 9 && g.documentElement && g.removeChild(g.documentElement);
                                break;
                            case 5:
                            case 6:
                            case 4:
                            case 17:
                                break;
                            default:
                                throw Error(x(163))
                        }
                    } catch (C) {
                        q(t, t.return, C)
                    }
                    if (e = t.sibling, e !== null) {
                        e.return = t.return, L = e;
                        break
                    }
                    L = t.return
                }
        return y = id, id = !1, y
    }

    function ro(e, t, n) {
        var r = t.updateQueue;
        if (r = r !== null ? r.lastEffect : null, r !== null) {
            var o = r = r.next;
            do {
                if ((o.tag & e) === e) {
                    var i = o.destroy;
                    o.destroy = void 0, i !== void 0 && is(t, n, i)
                }
                o = o.next
            } while (o !== r)
        }
    }

    function Si(e, t) {
        if (t = t.updateQueue, t = t !== null ? t.lastEffect : null, t !== null) {
            var n = t = t.next;
            do {
                if ((n.tag & e) === e) {
                    var r = n.create;
                    n.destroy = r()
                }
                n = n.next
            } while (n !== t)
        }
    }

    function as(e) {
        var t = e.ref;
        if (t !== null) {
            var n = e.stateNode;
            switch (e.tag) {
                case 5:
                    e = n;
                    break;
                default:
                    e = n
            }
            typeof t == "function" ? t(e) : t.current = e
        }
    }

    function ad(e) {
        var t = e.alternate;
        t !== null && (e.alternate = null, ad(t)), e.child = null, e.deletions = null, e.sibling = null, e.tag === 5 && (t = e.stateNode, t !== null && (delete t[ot], delete t[Wr], delete t[xl], delete t[Zg], delete t[qg])), e.stateNode = null, e.return = null, e.dependencies = null, e.memoizedProps = null, e.memoizedState = null, e.pendingProps = null, e.stateNode = null, e.updateQueue = null
    }

    function ld(e) {
        return e.tag === 5 || e.tag === 3 || e.tag === 4
    }

    function sd(e) {
        e: for (;;) {
            for (; e.sibling === null;) {
                if (e.return === null || ld(e.return)) return null;
                e = e.return
            }
            for (e.sibling.return = e.return, e = e.sibling; e.tag !== 5 && e.tag !== 6 && e.tag !== 18;) {
                if (e.flags & 2 || e.child === null || e.tag === 4) continue e;
                e.child.return = e, e = e.child
            }
            if (!(e.flags & 2)) return e.stateNode
        }
    }

    function ls(e, t, n) {
        var r = e.tag;
        if (r === 5 || r === 6) e = e.stateNode, t ? n.nodeType === 8 ? n.parentNode.insertBefore(e, t) : n.insertBefore(e, t) : (n.nodeType === 8 ? (t = n.parentNode, t.insertBefore(e, n)) : (t = n, t.appendChild(e)), n = n._reactRootContainer, n != null || t.onclick !== null || (t.onclick = qo));
        else if (r !== 4 && (e = e.child, e !== null))
            for (ls(e, t, n), e = e.sibling; e !== null;) ls(e, t, n), e = e.sibling
    }

    function ss(e, t, n) {
        var r = e.tag;
        if (r === 5 || r === 6) e = e.stateNode, t ? n.insertBefore(e, t) : n.appendChild(e);
        else if (r !== 4 && (e = e.child, e !== null))
            for (ss(e, t, n), e = e.sibling; e !== null;) ss(e, t, n), e = e.sibling
    }
    var ve = null,
        Je = !1;

    function Vt(e, t, n) {
        for (n = n.child; n !== null;) ud(e, t, n), n = n.sibling
    }

    function ud(e, t, n) {
        if (rt && typeof rt.onCommitFiberUnmount == "function") try {
            rt.onCommitFiberUnmount(jo, n)
        } catch {}
        switch (n.tag) {
            case 5:
                Ce || tr(n, t);
            case 6:
                var r = ve,
                    o = Je;
                ve = null, Vt(e, t, n), ve = r, Je = o, ve !== null && (Je ? (e = ve, n = n.stateNode, e.nodeType === 8 ? e.parentNode.removeChild(n) : e.removeChild(n)) : ve.removeChild(n.stateNode));
                break;
            case 18:
                ve !== null && (Je ? (e = ve, n = n.stateNode, e.nodeType === 8 ? Sl(e.parentNode, n) : e.nodeType === 1 && Sl(e, n), zr(e)) : Sl(ve, n.stateNode));
                break;
            case 4:
                r = ve, o = Je, ve = n.stateNode.containerInfo, Je = !0, Vt(e, t, n), ve = r, Je = o;
                break;
            case 0:
            case 11:
            case 14:
            case 15:
                if (!Ce && (r = n.updateQueue, r !== null && (r = r.lastEffect, r !== null))) {
                    o = r = r.next;
                    do {
                        var i = o,
                            a = i.destroy;
                        i = i.tag, a !== void 0 && (i & 2 || i & 4) && is(n, t, a), o = o.next
                    } while (o !== r)
                }
                Vt(e, t, n);
                break;
            case 1:
                if (!Ce && (tr(n, t), r = n.stateNode, typeof r.componentWillUnmount == "function")) try {
                    r.props = n.memoizedProps, r.state = n.memoizedState, r.componentWillUnmount()
                } catch (l) {
                    q(n, t, l)
                }
                Vt(e, t, n);
                break;
            case 21:
                Vt(e, t, n);
                break;
            case 22:
                n.mode & 1 ? (Ce = (r = Ce) || n.memoizedState !== null, Vt(e, t, n), Ce = r) : Vt(e, t, n);
                break;
            default:
                Vt(e, t, n)
        }
    }

    function cd(e) {
        var t = e.updateQueue;
        if (t !== null) {
            e.updateQueue = null;
            var n = e.stateNode;
            n === null && (n = e.stateNode = new vh), t.forEach(function(r) {
                var o = kh.bind(null, e, r);
                n.has(r) || (n.add(r), r.then(o, o))
            })
        }
    }

    function Ze(e, t) {
        var n = t.deletions;
        if (n !== null)
            for (var r = 0; r < n.length; r++) {
                var o = n[r];
                try {
                    var i = e,
                        a = t,
                        l = a;
                    e: for (; l !== null;) {
                        switch (l.tag) {
                            case 5:
                                ve = l.stateNode, Je = !1;
                                break e;
                            case 3:
                                ve = l.stateNode.containerInfo, Je = !0;
                                break e;
                            case 4:
                                ve = l.stateNode.containerInfo, Je = !0;
                                break e
                        }
                        l = l.return
                    }
                    if (ve === null) throw Error(x(160));
                    ud(i, a, o), ve = null, Je = !1;
                    var s = o.alternate;
                    s !== null && (s.return = null), o.return = null
                } catch (u) {
                    q(o, t, u)
                }
            }
        if (t.subtreeFlags & 12854)
            for (t = t.child; t !== null;) fd(t, e), t = t.sibling
    }

    function fd(e, t) {
        var n = e.alternate,
            r = e.flags;
        switch (e.tag) {
            case 0:
            case 11:
            case 14:
            case 15:
                if (Ze(t, e), lt(e), r & 4) {
                    try {
                        ro(3, e, e.return), Si(3, e)
                    } catch (m) {
                        q(e, e.return, m)
                    }
                    try {
                        ro(5, e, e.return)
                    } catch (m) {
                        q(e, e.return, m)
                    }
                }
                break;
            case 1:
                Ze(t, e), lt(e), r & 512 && n !== null && tr(n, n.return);
                break;
            case 5:
                if (Ze(t, e), lt(e), r & 512 && n !== null && tr(n, n.return), e.flags & 32) {
                    var o = e.stateNode;
                    try {
                        kr(o, "")
                    } catch (m) {
                        q(e, e.return, m)
                    }
                }
                if (r & 4 && (o = e.stateNode, o != null)) {
                    var i = e.memoizedProps,
                        a = n !== null ? n.memoizedProps : i,
                        l = e.type,
                        s = e.updateQueue;
                    if (e.updateQueue = null, s !== null) try {
                        l === "input" && i.type === "radio" && i.name != null && bu(o, i), Aa(l, a);
                        var u = Aa(l, i);
                        for (a = 0; a < s.length; a += 2) {
                            var c = s[a],
                                f = s[a + 1];
                            c === "style" ? Wu(o, f) : c === "dangerouslySetInnerHTML" ? Hu(o, f) : c === "children" ? kr(o, f) : xa(o, c, f, u)
                        }
                        switch (l) {
                            case "input":
                                ja(o, i);
                                break;
                            case "textarea":
                                Bu(o, i);
                                break;
                            case "select":
                                var d = o._wrapperState.wasMultiple;
                                o._wrapperState.wasMultiple = !!i.multiple;
                                var h = i.value;
                                h != null ? jn(o, !!i.multiple, h, !1) : d !== !!i.multiple && (i.defaultValue != null ? jn(o, !!i.multiple, i.defaultValue, !0) : jn(o, !!i.multiple, i.multiple ? [] : "", !1))
                        }
                        o[Wr] = i
                    } catch (m) {
                        q(e, e.return, m)
                    }
                }
                break;
            case 6:
                if (Ze(t, e), lt(e), r & 4) {
                    if (e.stateNode === null) throw Error(x(162));
                    o = e.stateNode, i = e.memoizedProps;
                    try {
                        o.nodeValue = i
                    } catch (m) {
                        q(e, e.return, m)
                    }
                }
                break;
            case 3:
                if (Ze(t, e), lt(e), r & 4 && n !== null && n.memoizedState.isDehydrated) try {
                    zr(t.containerInfo)
                } catch (m) {
                    q(e, e.return, m)
                }
                break;
            case 4:
                Ze(t, e), lt(e);
                break;
            case 13:
                Ze(t, e), lt(e), o = e.child, o.flags & 8192 && (i = o.memoizedState !== null, o.stateNode.isHidden = i, !i || o.alternate !== null && o.alternate.memoizedState !== null || (fs = te())), r & 4 && cd(e);
                break;
            case 22:
                if (c = n !== null && n.memoizedState !== null, e.mode & 1 ? (Ce = (u = Ce) || c, Ze(t, e), Ce = u) : Ze(t, e), lt(e), r & 8192) {
                    if (u = e.memoizedState !== null, (e.stateNode.isHidden = u) && !c && e.mode & 1)
                        for (L = e, c = e.child; c !== null;) {
                            for (f = L = c; L !== null;) {
                                switch (d = L, h = d.child, d.tag) {
                                    case 0:
                                    case 11:
                                    case 14:
                                    case 15:
                                        ro(4, d, d.return);
                                        break;
                                    case 1:
                                        tr(d, d.return);
                                        var y = d.stateNode;
                                        if (typeof y.componentWillUnmount == "function") {
                                            r = d, n = d.return;
                                            try {
                                                t = r, y.props = t.memoizedProps, y.state = t.memoizedState, y.componentWillUnmount()
                                            } catch (m) {
                                                q(r, n, m)
                                            }
                                        }
                                        break;
                                    case 5:
                                        tr(d, d.return);
                                        break;
                                    case 22:
                                        if (d.memoizedState !== null) {
                                            vd(f);
                                            continue
                                        }
                                }
                                h !== null ? (h.return = d, L = h) : vd(f)
                            }
                            c = c.sibling
                        }
                    e: for (c = null, f = e;;) {
                        if (f.tag === 5) {
                            if (c === null) {
                                c = f;
                                try {
                                    o = f.stateNode, u ? (i = o.style, typeof i.setProperty == "function" ? i.setProperty("display", "none", "important") : i.display = "none") : (l = f.stateNode, s = f.memoizedProps.style, a = s != null && s.hasOwnProperty("display") ? s.display : null, l.style.display = Gu("display", a))
                                } catch (m) {
                                    q(e, e.return, m)
                                }
                            }
                        } else if (f.tag === 6) {
                            if (c === null) try {
                                f.stateNode.nodeValue = u ? "" : f.memoizedProps
                            } catch (m) {
                                q(e, e.return, m)
                            }
                        } else if ((f.tag !== 22 && f.tag !== 23 || f.memoizedState === null || f === e) && f.child !== null) {
                            f.child.return = f, f = f.child;
                            continue
                        }
                        if (f === e) break e;
                        for (; f.sibling === null;) {
                            if (f.return === null || f.return === e) break e;
                            c === f && (c = null), f = f.return
                        }
                        c === f && (c = null), f.sibling.return = f.return, f = f.sibling
                    }
                }
                break;
            case 19:
                Ze(t, e), lt(e), r & 4 && cd(e);
                break;
            case 21:
                break;
            default:
                Ze(t, e), lt(e)
        }
    }

    function lt(e) {
        var t = e.flags;
        if (t & 2) {
            try {
                e: {
                    for (var n = e.return; n !== null;) {
                        if (ld(n)) {
                            var r = n;
                            break e
                        }
                        n = n.return
                    }
                    throw Error(x(160))
                }
                switch (r.tag) {
                    case 5:
                        var o = r.stateNode;
                        r.flags & 32 && (kr(o, ""), r.flags &= -33);
                        var i = sd(e);
                        ss(e, i, o);
                        break;
                    case 3:
                    case 4:
                        var a = r.stateNode.containerInfo,
                            l = sd(e);
                        ls(e, l, a);
                        break;
                    default:
                        throw Error(x(161))
                }
            }
            catch (s) {
                q(e, e.return, s)
            }
            e.flags &= -3
        }
        t & 4096 && (e.flags &= -4097)
    }

    function hh(e, t, n) {
        L = e, dd(e)
    }

    function dd(e, t, n) {
        for (var r = (e.mode & 1) !== 0; L !== null;) {
            var o = L,
                i = o.child;
            if (o.tag === 22 && r) {
                var a = o.memoizedState !== null || Ci;
                if (!a) {
                    var l = o.alternate,
                        s = l !== null && l.memoizedState !== null || Ce;
                    l = Ci;
                    var u = Ce;
                    if (Ci = a, (Ce = s) && !u)
                        for (L = o; L !== null;) a = L, s = a.child, a.tag === 22 && a.memoizedState !== null ? gd(o) : s !== null ? (s.return = a, L = s) : gd(o);
                    for (; i !== null;) L = i, dd(i), i = i.sibling;
                    L = o, Ci = l, Ce = u
                }
                pd(e)
            } else o.subtreeFlags & 8772 && i !== null ? (i.return = o, L = i) : pd(e)
        }
    }

    function pd(e) {
        for (; L !== null;) {
            var t = L;
            if (t.flags & 8772) {
                var n = t.alternate;
                try {
                    if (t.flags & 8772) switch (t.tag) {
                        case 0:
                        case 11:
                        case 15:
                            Ce || Si(5, t);
                            break;
                        case 1:
                            var r = t.stateNode;
                            if (t.flags & 4 && !Ce)
                                if (n === null) r.componentDidMount();
                                else {
                                    var o = t.elementType === t.type ? n.memoizedProps : Ye(t.type, n.memoizedProps);
                                    r.componentDidUpdate(o, n.memoizedState, r.__reactInternalSnapshotBeforeUpdate)
                                }
                            var i = t.updateQueue;
                            i !== null && vf(t, i, r);
                            break;
                        case 3:
                            var a = t.updateQueue;
                            if (a !== null) {
                                if (n = null, t.child !== null) switch (t.child.tag) {
                                    case 5:
                                        n = t.child.stateNode;
                                        break;
                                    case 1:
                                        n = t.child.stateNode
                                }
                                vf(t, a, n)
                            }
                            break;
                        case 5:
                            var l = t.stateNode;
                            if (n === null && t.flags & 4) {
                                n = l;
                                var s = t.memoizedProps;
                                switch (t.type) {
                                    case "button":
                                    case "input":
                                    case "select":
                                    case "textarea":
                                        s.autoFocus && n.focus();
                                        break;
                                    case "img":
                                        s.src && (n.src = s.src)
                                }
                            }
                            break;
                        case 6:
                            break;
                        case 4:
                            break;
                        case 12:
                            break;
                        case 13:
                            if (t.memoizedState === null) {
                                var u = t.alternate;
                                if (u !== null) {
                                    var c = u.memoizedState;
                                    if (c !== null) {
                                        var f = c.dehydrated;
                                        f !== null && zr(f)
                                    }
                                }
                            }
                            break;
                        case 19:
                        case 17:
                        case 21:
                        case 22:
                        case 23:
                        case 25:
                            break;
                        default:
                            throw Error(x(163))
                    }
                    Ce || t.flags & 512 && as(t)
                } catch (d) {
                    q(t, t.return, d)
                }
            }
            if (t === e) {
                L = null;
                break
            }
            if (n = t.sibling, n !== null) {
                n.return = t.return, L = n;
                break
            }
            L = t.return
        }
    }

    function vd(e) {
        for (; L !== null;) {
            var t = L;
            if (t === e) {
                L = null;
                break
            }
            var n = t.sibling;
            if (n !== null) {
                n.return = t.return, L = n;
                break
            }
            L = t.return
        }
    }

    function gd(e) {
        for (; L !== null;) {
            var t = L;
            try {
                switch (t.tag) {
                    case 0:
                    case 11:
                    case 15:
                        var n = t.return;
                        try {
                            Si(4, t)
                        } catch (s) {
                            q(t, n, s)
                        }
                        break;
                    case 1:
                        var r = t.stateNode;
                        if (typeof r.componentDidMount == "function") {
                            var o = t.return;
                            try {
                                r.componentDidMount()
                            } catch (s) {
                                q(t, o, s)
                            }
                        }
                        var i = t.return;
                        try {
                            as(t)
                        } catch (s) {
                            q(t, i, s)
                        }
                        break;
                    case 5:
                        var a = t.return;
                        try {
                            as(t)
                        } catch (s) {
                            q(t, a, s)
                        }
                }
            } catch (s) {
                q(t, t.return, s)
            }
            if (t === e) {
                L = null;
                break
            }
            var l = t.sibling;
            if (l !== null) {
                l.return = t.return, L = l;
                break
            }
            L = t.return
        }
    }
    var mh = Math.ceil,
        xi = pt.ReactCurrentDispatcher,
        us = pt.ReactCurrentOwner,
        Ve = pt.ReactCurrentBatchConfig,
        b = 0,
        ce = null,
        re = null,
        ge = 0,
        Te = 0,
        nr = bt(0),
        le = 0,
        oo = null,
        fn = 0,
        Ei = 0,
        cs = 0,
        io = null,
        Ne = null,
        fs = 0,
        rr = 1 / 0,
        St = null,
        ki = !1,
        ds = null,
        Ht = null,
        Oi = !1,
        Gt = null,
        Li = 0,
        ao = 0,
        ps = null,
        Pi = -1,
        Ii = 0;

    function ke() {
        return b & 6 ? te() : Pi !== -1 ? Pi : Pi = te()
    }

    function Wt(e) {
        return e.mode & 1 ? b & 2 && ge !== 0 ? ge & -ge : eh.transition !== null ? (Ii === 0 && (Ii = lc()), Ii) : (e = U, e !== 0 || (e = window.event, e = e === void 0 ? 16 : hc(e.type)), e) : 1
    }

    function qe(e, t, n, r) {
        if (50 < ao) throw ao = 0, ps = null, Error(x(185));
        _r(e, n, r), (!(b & 2) || e !== ce) && (e === ce && (!(b & 2) && (Ei |= n), le === 4 && Kt(e, ge)), _e(e, r), n === 1 && b === 0 && !(t.mode & 1) && (rr = te() + 500, ni && Ut()))
    }

    function _e(e, t) {
        var n = e.callbackNode;
        eg(e, t);
        var r = To(e, e === ce ? ge : 0);
        if (r === 0) n !== null && oc(n), e.callbackNode = null, e.callbackPriority = 0;
        else if (t = r & -r, e.callbackPriority !== t) {
            if (n != null && oc(n), t === 1) e.tag === 0 ? Xg(md.bind(null, e)) : tf(md.bind(null, e)), Yg(function() {
                !(b & 6) && Ut()
            }), n = null;
            else {
                switch (sc(r)) {
                    case 1:
                        n = Wa;
                        break;
                    case 4:
                        n = ic;
                        break;
                    case 16:
                        n = Do;
                        break;
                    case 536870912:
                        n = ac;
                        break;
                    default:
                        n = Do
                }
                n = Od(n, hd.bind(null, e))
            }
            e.callbackPriority = t, e.callbackNode = n
        }
    }

    function hd(e, t) {
        if (Pi = -1, Ii = 0, b & 6) throw Error(x(327));
        var n = e.callbackNode;
        if (or() && e.callbackNode !== n) return null;
        var r = To(e, e === ce ? ge : 0);
        if (r === 0) return null;
        if (r & 30 || r & e.expiredLanes || t) t = Ni(e, r);
        else {
            t = r;
            var o = b;
            b |= 2;
            var i = wd();
            (ce !== e || ge !== t) && (St = null, rr = te() + 500, pn(e, t));
            do try {
                Ch();
                break
            } catch (l) {
                yd(e, l)
            }
            while (!0);
            Rl(), xi.current = i, b = o, re !== null ? t = 0 : (ce = null, ge = 0, t = le)
        }
        if (t !== 0) {
            if (t === 2 && (o = Ka(e), o !== 0 && (r = o, t = vs(e, o))), t === 1) throw n = oo, pn(e, 0), Kt(e, r), _e(e, te()), n;
            if (t === 6) Kt(e, r);
            else {
                if (o = e.current.alternate, !(r & 30) && !yh(o) && (t = Ni(e, r), t === 2 && (i = Ka(e), i !== 0 && (r = i, t = vs(e, i))), t === 1)) throw n = oo, pn(e, 0), Kt(e, r), _e(e, te()), n;
                switch (e.finishedWork = o, e.finishedLanes = r, t) {
                    case 0:
                    case 1:
                        throw Error(x(345));
                    case 2:
                        vn(e, Ne, St);
                        break;
                    case 3:
                        if (Kt(e, r), (r & 130023424) === r && (t = fs + 500 - te(), 10 < t)) {
                            if (To(e, 0) !== 0) break;
                            if (o = e.suspendedLanes, (o & r) !== r) {
                                ke(), e.pingedLanes |= e.suspendedLanes & o;
                                break
                            }
                            e.timeoutHandle = Cl(vn.bind(null, e, Ne, St), t);
                            break
                        }
                        vn(e, Ne, St);
                        break;
                    case 4:
                        if (Kt(e, r), (r & 4194240) === r) break;
                        for (t = e.eventTimes, o = -1; 0 < r;) {
                            var a = 31 - We(r);
                            i = 1 << a, a = t[a], a > o && (o = a), r &= ~i
                        }
                        if (r = o, r = te() - r, r = (120 > r ? 120 : 480 > r ? 480 : 1080 > r ? 1080 : 1920 > r ? 1920 : 3e3 > r ? 3e3 : 4320 > r ? 4320 : 1960 * mh(r / 1960)) - r, 10 < r) {
                            e.timeoutHandle = Cl(vn.bind(null, e, Ne, St), r);
                            break
                        }
                        vn(e, Ne, St);
                        break;
                    case 5:
                        vn(e, Ne, St);
                        break;
                    default:
                        throw Error(x(329))
                }
            }
        }
        return _e(e, te()), e.callbackNode === n ? hd.bind(null, e) : null
    }

    function vs(e, t) {
        var n = io;
        return e.current.memoizedState.isDehydrated && (pn(e, t).flags |= 256), e = Ni(e, t), e !== 2 && (t = Ne, Ne = n, t !== null && gs(t)), e
    }

    function gs(e) {
        Ne === null ? Ne = e : Ne.push.apply(Ne, e)
    }

    function yh(e) {
        for (var t = e;;) {
            if (t.flags & 16384) {
                var n = t.updateQueue;
                if (n !== null && (n = n.stores, n !== null))
                    for (var r = 0; r < n.length; r++) {
                        var o = n[r],
                            i = o.getSnapshot;
                        o = o.value;
                        try {
                            if (!Ke(i(), o)) return !1
                        } catch {
                            return !1
                        }
                    }
            }
            if (n = t.child, t.subtreeFlags & 16384 && n !== null) n.return = t, t = n;
            else {
                if (t === e) break;
                for (; t.sibling === null;) {
                    if (t.return === null || t.return === e) return !0;
                    t = t.return
                }
                t.sibling.return = t.return, t = t.sibling
            }
        }
        return !0
    }

    function Kt(e, t) {
        for (t &= ~cs, t &= ~Ei, e.suspendedLanes |= t, e.pingedLanes &= ~t, e = e.expirationTimes; 0 < t;) {
            var n = 31 - We(t),
                r = 1 << n;
            e[n] = -1, t &= ~r
        }
    }

    function md(e) {
        if (b & 6) throw Error(x(327));
        or();
        var t = To(e, 0);
        if (!(t & 1)) return _e(e, te()), null;
        var n = Ni(e, t);
        if (e.tag !== 0 && n === 2) {
            var r = Ka(e);
            r !== 0 && (t = r, n = vs(e, r))
        }
        if (n === 1) throw n = oo, pn(e, 0), Kt(e, t), _e(e, te()), n;
        if (n === 6) throw Error(x(345));
        return e.finishedWork = e.current.alternate, e.finishedLanes = t, vn(e, Ne, St), _e(e, te()), null
    }

    function hs(e, t) {
        var n = b;
        b |= 1;
        try {
            return e(t)
        } finally {
            b = n, b === 0 && (rr = te() + 500, ni && Ut())
        }
    }

    function dn(e) {
        Gt !== null && Gt.tag === 0 && !(b & 6) && or();
        var t = b;
        b |= 1;
        var n = Ve.transition,
            r = U;
        try {
            if (Ve.transition = null, U = 1, e) return e()
        } finally {
            U = r, Ve.transition = n, b = t, !(b & 6) && Ut()
        }
    }

    function ms() {
        Te = nr.current, G(nr)
    }

    function pn(e, t) {
        e.finishedWork = null, e.finishedLanes = 0;
        var n = e.timeoutHandle;
        if (n !== -1 && (e.timeoutHandle = -1, Qg(n)), re !== null)
            for (n = re.return; n !== null;) {
                var r = n;
                switch (Ll(r), r.tag) {
                    case 1:
                        r = r.type.childContextTypes, r != null && ei();
                        break;
                    case 3:
                        Xn(), G(Le), G(me), Al();
                        break;
                    case 5:
                        Tl(r);
                        break;
                    case 4:
                        Xn();
                        break;
                    case 13:
                        G(Y);
                        break;
                    case 19:
                        G(Y);
                        break;
                    case 10:
                        Ml(r.type._context);
                        break;
                    case 22:
                    case 23:
                        ms()
                }
                n = n.return
            }
        if (ce = e, re = e = Qt(e.current, null), ge = Te = t, le = 0, oo = null, cs = Ei = fn = 0, Ne = io = null, sn !== null) {
            for (t = 0; t < sn.length; t++)
                if (n = sn[t], r = n.interleaved, r !== null) {
                    n.interleaved = null;
                    var o = r.next,
                        i = n.pending;
                    if (i !== null) {
                        var a = i.next;
                        i.next = o, r.next = a
                    }
                    n.pending = r
                }
            sn = null
        }
        return e
    }

    function yd(e, t) {
        do {
            var n = re;
            try {
                if (Rl(), di.current = hi, pi) {
                    for (var r = J.memoizedState; r !== null;) {
                        var o = r.queue;
                        o !== null && (o.pending = null), r = r.next
                    }
                    pi = !1
                }
                if (cn = 0, ue = ae = J = null, qr = !1, Xr = 0, us.current = null, n === null || n.return === null) {
                    le = 1, oo = t, re = null;
                    break
                }
                e: {
                    var i = e,
                        a = n.return,
                        l = n,
                        s = t;
                    if (t = ge, l.flags |= 32768, s !== null && typeof s == "object" && typeof s.then == "function") {
                        var u = s,
                            c = l,
                            f = c.tag;
                        if (!(c.mode & 1) && (f === 0 || f === 11 || f === 15)) {
                            var d = c.alternate;
                            d ? (c.updateQueue = d.updateQueue, c.memoizedState = d.memoizedState, c.lanes = d.lanes) : (c.updateQueue = null, c.memoizedState = null)
                        }
                        var h = Vf(a);
                        if (h !== null) {
                            h.flags &= -257, Hf(h, a, l, i, t), h.mode & 1 && $f(i, u, t), t = h, s = u;
                            var y = t.updateQueue;
                            if (y === null) {
                                var m = new Set;
                                m.add(s), t.updateQueue = m
                            } else y.add(s);
                            break e
                        } else {
                            if (!(t & 1)) {
                                $f(i, u, t), ys();
                                break e
                            }
                            s = Error(x(426))
                        }
                    } else if (K && l.mode & 1) {
                        var E = Vf(a);
                        if (E !== null) {
                            !(E.flags & 65536) && (E.flags |= 256), Hf(E, a, l, i, t), Nl(er(s, l));
                            break e
                        }
                    }
                    i = s = er(s, l),
                    le !== 4 && (le = 2),
                    io === null ? io = [i] : io.push(i),
                    i = a;do {
                        switch (i.tag) {
                            case 3:
                                i.flags |= 65536, t &= -t, i.lanes |= t;
                                var v = Uf(i, s, t);
                                pf(i, v);
                                break e;
                            case 1:
                                l = s;
                                var p = i.type,
                                    g = i.stateNode;
                                if (!(i.flags & 128) && (typeof p.getDerivedStateFromError == "function" || g !== null && typeof g.componentDidCatch == "function" && (Ht === null || !Ht.has(g)))) {
                                    i.flags |= 65536, t &= -t, i.lanes |= t;
                                    var C = Bf(i, l, t);
                                    pf(i, C);
                                    break e
                                }
                        }
                        i = i.return
                    } while (i !== null)
                }
                Sd(n)
            } catch (O) {
                t = O, re === n && n !== null && (re = n = n.return);
                continue
            }
            break
        } while (!0)
    }

    function wd() {
        var e = xi.current;
        return xi.current = hi, e === null ? hi : e
    }

    function ys() {
        (le === 0 || le === 3 || le === 2) && (le = 4), ce === null || !(fn & 268435455) && !(Ei & 268435455) || Kt(ce, ge)
    }

    function Ni(e, t) {
        var n = b;
        b |= 2;
        var r = wd();
        (ce !== e || ge !== t) && (St = null, pn(e, t));
        do try {
            wh();
            break
        } catch (o) {
            yd(e, o)
        }
        while (!0);
        if (Rl(), b = n, xi.current = r, re !== null) throw Error(x(261));
        return ce = null, ge = 0, le
    }

    function wh() {
        for (; re !== null;) Cd(re)
    }

    function Ch() {
        for (; re !== null && !Gv();) Cd(re)
    }

    function Cd(e) {
        var t = kd(e.alternate, e, Te);
        e.memoizedProps = e.pendingProps, t === null ? Sd(e) : re = t, us.current = null
    }

    function Sd(e) {
        var t = e;
        do {
            var n = t.alternate;
            if (e = t.return, t.flags & 32768) {
                if (n = ph(n, t), n !== null) {
                    n.flags &= 32767, re = n;
                    return
                }
                if (e !== null) e.flags |= 32768, e.subtreeFlags = 0, e.deletions = null;
                else {
                    le = 6, re = null;
                    return
                }
            } else if (n = dh(n, t, Te), n !== null) {
                re = n;
                return
            }
            if (t = t.sibling, t !== null) {
                re = t;
                return
            }
            re = t = e
        } while (t !== null);
        le === 0 && (le = 5)
    }

    function vn(e, t, n) {
        var r = U,
            o = Ve.transition;
        try {
            Ve.transition = null, U = 1, Sh(e, t, n, r)
        } finally {
            Ve.transition = o, U = r
        }
        return null
    }

    function Sh(e, t, n, r) {
        do or(); while (Gt !== null);
        if (b & 6) throw Error(x(327));
        n = e.finishedWork;
        var o = e.finishedLanes;
        if (n === null) return null;
        if (e.finishedWork = null, e.finishedLanes = 0, n === e.current) throw Error(x(177));
        e.callbackNode = null, e.callbackPriority = 0;
        var i = n.lanes | n.childLanes;
        if (tg(e, i), e === ce && (re = ce = null, ge = 0), !(n.subtreeFlags & 2064) && !(n.flags & 2064) || Oi || (Oi = !0, Od(Do, function() {
                return or(), null
            })), i = (n.flags & 15990) !== 0, n.subtreeFlags & 15990 || i) {
            i = Ve.transition, Ve.transition = null;
            var a = U;
            U = 1;
            var l = b;
            b |= 4, us.current = null, gh(e, n), fd(n, e), Bg(yl), Uo = !!ml, yl = ml = null, e.current = n, hh(n), Wv(), b = l, U = a, Ve.transition = i
        } else e.current = n;
        if (Oi && (Oi = !1, Gt = e, Li = o), i = e.pendingLanes, i === 0 && (Ht = null), Yv(n.stateNode), _e(e, te()), t !== null)
            for (r = e.onRecoverableError, n = 0; n < t.length; n++) o = t[n], r(o.value, {
                componentStack: o.stack,
                digest: o.digest
            });
        if (ki) throw ki = !1, e = ds, ds = null, e;
        return Li & 1 && e.tag !== 0 && or(), i = e.pendingLanes, i & 1 ? e === ps ? ao++ : (ao = 0, ps = e) : ao = 0, Ut(), null
    }

    function or() {
        if (Gt !== null) {
            var e = sc(Li),
                t = Ve.transition,
                n = U;
            try {
                if (Ve.transition = null, U = 16 > e ? 16 : e, Gt === null) var r = !1;
                else {
                    if (e = Gt, Gt = null, Li = 0, b & 6) throw Error(x(331));
                    var o = b;
                    for (b |= 4, L = e.current; L !== null;) {
                        var i = L,
                            a = i.child;
                        if (L.flags & 16) {
                            var l = i.deletions;
                            if (l !== null) {
                                for (var s = 0; s < l.length; s++) {
                                    var u = l[s];
                                    for (L = u; L !== null;) {
                                        var c = L;
                                        switch (c.tag) {
                                            case 0:
                                            case 11:
                                            case 15:
                                                ro(8, c, i)
                                        }
                                        var f = c.child;
                                        if (f !== null) f.return = c, L = f;
                                        else
                                            for (; L !== null;) {
                                                c = L;
                                                var d = c.sibling,
                                                    h = c.return;
                                                if (ad(c), c === u) {
                                                    L = null;
                                                    break
                                                }
                                                if (d !== null) {
                                                    d.return = h, L = d;
                                                    break
                                                }
                                                L = h
                                            }
                                    }
                                }
                                var y = i.alternate;
                                if (y !== null) {
                                    var m = y.child;
                                    if (m !== null) {
                                        y.child = null;
                                        do {
                                            var E = m.sibling;
                                            m.sibling = null, m = E
                                        } while (m !== null)
                                    }
                                }
                                L = i
                            }
                        }
                        if (i.subtreeFlags & 2064 && a !== null) a.return = i, L = a;
                        else e: for (; L !== null;) {
                            if (i = L, i.flags & 2048) switch (i.tag) {
                                case 0:
                                case 11:
                                case 15:
                                    ro(9, i, i.return)
                            }
                            var v = i.sibling;
                            if (v !== null) {
                                v.return = i.return, L = v;
                                break e
                            }
                            L = i.return
                        }
                    }
                    var p = e.current;
                    for (L = p; L !== null;) {
                        a = L;
                        var g = a.child;
                        if (a.subtreeFlags & 2064 && g !== null) g.return = a, L = g;
                        else e: for (a = p; L !== null;) {
                            if (l = L, l.flags & 2048) try {
                                switch (l.tag) {
                                    case 0:
                                    case 11:
                                    case 15:
                                        Si(9, l)
                                }
                            } catch (O) {
                                q(l, l.return, O)
                            }
                            if (l === a) {
                                L = null;
                                break e
                            }
                            var C = l.sibling;
                            if (C !== null) {
                                C.return = l.return, L = C;
                                break e
                            }
                            L = l.return
                        }
                    }
                    if (b = o, Ut(), rt && typeof rt.onPostCommitFiberRoot == "function") try {
                        rt.onPostCommitFiberRoot(jo, e)
                    } catch {}
                    r = !0
                }
                return r
            } finally {
                U = n, Ve.transition = t
            }
        }
        return !1
    }

    function xd(e, t, n) {
        t = er(n, t), t = Uf(e, t, 1), e = $t(e, t, 1), t = ke(), e !== null && (_r(e, 1, t), _e(e, t))
    }

    function q(e, t, n) {
        if (e.tag === 3) xd(e, e, n);
        else
            for (; t !== null;) {
                if (t.tag === 3) {
                    xd(t, e, n);
                    break
                } else if (t.tag === 1) {
                    var r = t.stateNode;
                    if (typeof t.type.getDerivedStateFromError == "function" || typeof r.componentDidCatch == "function" && (Ht === null || !Ht.has(r))) {
                        e = er(n, e), e = Bf(t, e, 1), t = $t(t, e, 1), e = ke(), t !== null && (_r(t, 1, e), _e(t, e));
                        break
                    }
                }
                t = t.return
            }
    }

    function xh(e, t, n) {
        var r = e.pingCache;
        r !== null && r.delete(t), t = ke(), e.pingedLanes |= e.suspendedLanes & n, ce === e && (ge & n) === n && (le === 4 || le === 3 && (ge & 130023424) === ge && 500 > te() - fs ? pn(e, 0) : cs |= n), _e(e, t)
    }

    function Ed(e, t) {
        t === 0 && (e.mode & 1 ? (t = Fo, Fo <<= 1, !(Fo & 130023424) && (Fo = 4194304)) : t = 1);
        var n = ke();
        e = yt(e, t), e !== null && (_r(e, t, n), _e(e, n))
    }

    function Eh(e) {
        var t = e.memoizedState,
            n = 0;
        t !== null && (n = t.retryLane), Ed(e, n)
    }

    function kh(e, t) {
        var n = 0;
        switch (e.tag) {
            case 13:
                var r = e.stateNode,
                    o = e.memoizedState;
                o !== null && (n = o.retryLane);
                break;
            case 19:
                r = e.stateNode;
                break;
            default:
                throw Error(x(314))
        }
        r !== null && r.delete(t), Ed(e, n)
    }
    var kd;
    kd = function(e, t, n) {
        if (e !== null)
            if (e.memoizedProps !== t.pendingProps || Le.current) Ie = !0;
            else {
                if (!(e.lanes & n) && !(t.flags & 128)) return Ie = !1, fh(e, t, n);
                Ie = !!(e.flags & 131072)
            }
        else Ie = !1, K && t.flags & 1048576 && nf(t, oi, t.index);
        switch (t.lanes = 0, t.tag) {
            case 2:
                var r = t.type;
                wi(e, t), e = t.pendingProps;
                var o = Wn(t, me.current);
                qn(t, n), o = $l(null, t, r, e, o, n);
                var i = Vl();
                return t.flags |= 1, typeof o == "object" && o !== null && typeof o.render == "function" && o.$$typeof === void 0 ? (t.tag = 1, t.memoizedState = null, t.updateQueue = null, Pe(r) ? (i = !0, ti(t)) : i = !1, t.memoizedState = o.state !== null && o.state !== void 0 ? o.state : null, zl(t), o.updater = mi, t.stateNode = o, o._reactInternals = t, Yl(t, r, e, n), t = Xl(null, t, r, !0, i, n)) : (t.tag = 0, K && i && Ol(t), Ee(null, t, o, n), t = t.child), t;
            case 16:
                r = t.elementType;
                e: {
                    switch (wi(e, t), e = t.pendingProps, o = r._init, r = o(r._payload), t.type = r, o = t.tag = Lh(r), e = Ye(r, e), o) {
                        case 0:
                            t = ql(null, t, r, e, n);
                            break e;
                        case 1:
                            t = Jf(null, t, r, e, n);
                            break e;
                        case 11:
                            t = Gf(null, t, r, e, n);
                            break e;
                        case 14:
                            t = Wf(null, t, r, Ye(r.type, e), n);
                            break e
                    }
                    throw Error(x(306, r, ""))
                }
                return t;
            case 0:
                return r = t.type, o = t.pendingProps, o = t.elementType === r ? o : Ye(r, o), ql(e, t, r, o, n);
            case 1:
                return r = t.type, o = t.pendingProps, o = t.elementType === r ? o : Ye(r, o), Jf(e, t, r, o, n);
            case 3:
                e: {
                    if (Zf(t), e === null) throw Error(x(387));r = t.pendingProps,
                    i = t.memoizedState,
                    o = i.element,
                    df(e, t),
                    ci(t, r, null, n);
                    var a = t.memoizedState;
                    if (r = a.element, i.isDehydrated)
                        if (i = {
                                element: r,
                                isDehydrated: !1,
                                cache: a.cache,
                                pendingSuspenseBoundaries: a.pendingSuspenseBoundaries,
                                transitions: a.transitions
                            }, t.updateQueue.baseState = i, t.memoizedState = i, t.flags & 256) {
                            o = er(Error(x(423)), t), t = qf(e, t, r, n, o);
                            break e
                        } else if (r !== o) {
                        o = er(Error(x(424)), t), t = qf(e, t, r, n, o);
                        break e
                    } else
                        for (Fe = Tt(t.stateNode.containerInfo.firstChild), ze = t, K = !0, Qe = null, n = cf(t, null, r, n), t.child = n; n;) n.flags = n.flags & -3 | 4096, n = n.sibling;
                    else {
                        if (Yn(), r === o) {
                            t = Ct(e, t, n);
                            break e
                        }
                        Ee(e, t, r, n)
                    }
                    t = t.child
                }
                return t;
            case 5:
                return gf(t), e === null && Il(t), r = t.type, o = t.pendingProps, i = e !== null ? e.memoizedProps : null, a = o.children, wl(r, o) ? a = null : i !== null && wl(r, i) && (t.flags |= 32), Yf(e, t), Ee(e, t, a, n), t.child;
            case 6:
                return e === null && Il(t), null;
            case 13:
                return Xf(e, t, n);
            case 4:
                return Fl(t, t.stateNode.containerInfo), r = t.pendingProps, e === null ? t.child = Jn(t, null, r, n) : Ee(e, t, r, n), t.child;
            case 11:
                return r = t.type, o = t.pendingProps, o = t.elementType === r ? o : Ye(r, o), Gf(e, t, r, o, n);
            case 7:
                return Ee(e, t, t.pendingProps, n), t.child;
            case 8:
                return Ee(e, t, t.pendingProps.children, n), t.child;
            case 12:
                return Ee(e, t, t.pendingProps.children, n), t.child;
            case 10:
                e: {
                    if (r = t.type._context, o = t.pendingProps, i = t.memoizedProps, a = o.value, V(li, r._currentValue), r._currentValue = a, i !== null)
                        if (Ke(i.value, a)) {
                            if (i.children === o.children && !Le.current) {
                                t = Ct(e, t, n);
                                break e
                            }
                        } else
                            for (i = t.child, i !== null && (i.return = t); i !== null;) {
                                var l = i.dependencies;
                                if (l !== null) {
                                    a = i.child;
                                    for (var s = l.firstContext; s !== null;) {
                                        if (s.context === r) {
                                            if (i.tag === 1) {
                                                s = wt(-1, n & -n), s.tag = 2;
                                                var u = i.updateQueue;
                                                if (u !== null) {
                                                    u = u.shared;
                                                    var c = u.pending;
                                                    c === null ? s.next = s : (s.next = c.next, c.next = s), u.pending = s
                                                }
                                            }
                                            i.lanes |= n, s = i.alternate, s !== null && (s.lanes |= n), Dl(i.return, n, t), l.lanes |= n;
                                            break
                                        }
                                        s = s.next
                                    }
                                } else if (i.tag === 10) a = i.type === t.type ? null : i.child;
                                else if (i.tag === 18) {
                                    if (a = i.return, a === null) throw Error(x(341));
                                    a.lanes |= n, l = a.alternate, l !== null && (l.lanes |= n), Dl(a, n, t), a = i.sibling
                                } else a = i.child;
                                if (a !== null) a.return = i;
                                else
                                    for (a = i; a !== null;) {
                                        if (a === t) {
                                            a = null;
                                            break
                                        }
                                        if (i = a.sibling, i !== null) {
                                            i.return = a.return, a = i;
                                            break
                                        }
                                        a = a.return
                                    }
                                i = a
                            }
                    Ee(e, t, o.children, n),
                    t = t.child
                }
                return t;
            case 9:
                return o = t.type, r = t.pendingProps.children, qn(t, n), o = Be(o), r = r(o), t.flags |= 1, Ee(e, t, r, n), t.child;
            case 14:
                return r = t.type, o = Ye(r, t.pendingProps), o = Ye(r.type, o), Wf(e, t, r, o, n);
            case 15:
                return Kf(e, t, t.type, t.pendingProps, n);
            case 17:
                return r = t.type, o = t.pendingProps, o = t.elementType === r ? o : Ye(r, o), wi(e, t), t.tag = 1, Pe(r) ? (e = !0, ti(t)) : e = !1, qn(t, n), bf(t, r, o), Yl(t, r, o, n), Xl(null, t, r, !0, e, n);
            case 19:
                return td(e, t, n);
            case 22:
                return Qf(e, t, n)
        }
        throw Error(x(156, t.tag))
    };

    function Od(e, t) {
        return rc(e, t)
    }

    function Oh(e, t, n, r) {
        this.tag = e, this.key = n, this.sibling = this.child = this.return = this.stateNode = this.type = this.elementType = null, this.index = 0, this.ref = null, this.pendingProps = t, this.dependencies = this.memoizedState = this.updateQueue = this.memoizedProps = null, this.mode = r, this.subtreeFlags = this.flags = 0, this.deletions = null, this.childLanes = this.lanes = 0, this.alternate = null
    }

    function He(e, t, n, r) {
        return new Oh(e, t, n, r)
    }

    function ws(e) {
        return e = e.prototype, !(!e || !e.isReactComponent)
    }

    function Lh(e) {
        if (typeof e == "function") return ws(e) ? 1 : 0;
        if (e != null) {
            if (e = e.$$typeof, e === Oa) return 11;
            if (e === Ia) return 14
        }
        return 2
    }

    function Qt(e, t) {
        var n = e.alternate;
        return n === null ? (n = He(e.tag, t, e.key, e.mode), n.elementType = e.elementType, n.type = e.type, n.stateNode = e.stateNode, n.alternate = e, e.alternate = n) : (n.pendingProps = t, n.type = e.type, n.flags = 0, n.subtreeFlags = 0, n.deletions = null), n.flags = e.flags & 14680064, n.childLanes = e.childLanes, n.lanes = e.lanes, n.child = e.child, n.memoizedProps = e.memoizedProps, n.memoizedState = e.memoizedState, n.updateQueue = e.updateQueue, t = e.dependencies, n.dependencies = t === null ? null : {
            lanes: t.lanes,
            firstContext: t.firstContext
        }, n.sibling = e.sibling, n.index = e.index, n.ref = e.ref, n
    }

    function _i(e, t, n, r, o, i) {
        var a = 2;
        if (r = e, typeof e == "function") ws(e) && (a = 1);
        else if (typeof e == "string") a = 5;
        else e: switch (e) {
            case Dn:
                return gn(n.children, o, i, t);
            case Ea:
                a = 8, o |= 8;
                break;
            case ka:
                return e = He(12, n, t, o | 2), e.elementType = ka, e.lanes = i, e;
            case La:
                return e = He(13, n, t, o), e.elementType = La, e.lanes = i, e;
            case Pa:
                return e = He(19, n, t, o), e.elementType = Pa, e.lanes = i, e;
            case Du:
                return Ri(n, o, i, t);
            default:
                if (typeof e == "object" && e !== null) switch (e.$$typeof) {
                    case Ru:
                        a = 10;
                        break e;
                    case Mu:
                        a = 9;
                        break e;
                    case Oa:
                        a = 11;
                        break e;
                    case Ia:
                        a = 14;
                        break e;
                    case Nt:
                        a = 16, r = null;
                        break e
                }
                throw Error(x(130, e == null ? e : typeof e, ""))
        }
        return t = He(a, n, t, o), t.elementType = e, t.type = r, t.lanes = i, t
    }

    function gn(e, t, n, r) {
        return e = He(7, e, r, t), e.lanes = n, e
    }

    function Ri(e, t, n, r) {
        return e = He(22, e, r, t), e.elementType = Du, e.lanes = n, e.stateNode = {
            isHidden: !1
        }, e
    }

    function Cs(e, t, n) {
        return e = He(6, e, null, t), e.lanes = n, e
    }

    function Ss(e, t, n) {
        return t = He(4, e.children !== null ? e.children : [], e.key, t), t.lanes = n, t.stateNode = {
            containerInfo: e.containerInfo,
            pendingChildren: null,
            implementation: e.implementation
        }, t
    }

    function Ph(e, t, n, r, o) {
        this.tag = t, this.containerInfo = e, this.finishedWork = this.pingCache = this.current = this.pendingChildren = null, this.timeoutHandle = -1, this.callbackNode = this.pendingContext = this.context = null, this.callbackPriority = 0, this.eventTimes = Qa(0), this.expirationTimes = Qa(-1), this.entangledLanes = this.finishedLanes = this.mutableReadLanes = this.expiredLanes = this.pingedLanes = this.suspendedLanes = this.pendingLanes = 0, this.entanglements = Qa(0), this.identifierPrefix = r, this.onRecoverableError = o, this.mutableSourceEagerHydrationData = null
    }

    function xs(e, t, n, r, o, i, a, l, s) {
        return e = new Ph(e, t, n, l, s), t === 1 ? (t = 1, i === !0 && (t |= 8)) : t = 0, i = He(3, null, null, t), e.current = i, i.stateNode = e, i.memoizedState = {
            element: r,
            isDehydrated: n,
            cache: null,
            transitions: null,
            pendingSuspenseBoundaries: null
        }, zl(i), e
    }

    function Ih(e, t, n) {
        var r = 3 < arguments.length && arguments[3] !== void 0 ? arguments[3] : null;
        return {
            $$typeof: Mn,
            key: r == null ? null : "" + r,
            children: e,
            containerInfo: t,
            implementation: n
        }
    }

    function Ld(e) {
        if (!e) return At;
        e = e._reactInternals;
        e: {
            if (nn(e) !== e || e.tag !== 1) throw Error(x(170));
            var t = e;do {
                switch (t.tag) {
                    case 3:
                        t = t.stateNode.context;
                        break e;
                    case 1:
                        if (Pe(t.type)) {
                            t = t.stateNode.__reactInternalMemoizedMergedChildContext;
                            break e
                        }
                }
                t = t.return
            } while (t !== null);
            throw Error(x(171))
        }
        if (e.tag === 1) {
            var n = e.type;
            if (Pe(n)) return Xc(e, n, t)
        }
        return t
    }

    function Pd(e, t, n, r, o, i, a, l, s) {
        return e = xs(n, r, !0, e, o, i, a, l, s), e.context = Ld(null), n = e.current, r = ke(), o = Wt(n), i = wt(r, o), i.callback = t ? ? null, $t(n, i, o), e.current.lanes = o, _r(e, o, r), _e(e, r), e
    }

    function Mi(e, t, n, r) {
        var o = t.current,
            i = ke(),
            a = Wt(o);
        return n = Ld(n), t.context === null ? t.context = n : t.pendingContext = n, t = wt(i, a), t.payload = {
            element: e
        }, r = r === void 0 ? null : r, r !== null && (t.callback = r), e = $t(o, t, a), e !== null && (qe(e, o, a, i), ui(e, o, a)), a
    }

    function Di(e) {
        if (e = e.current, !e.child) return null;
        switch (e.child.tag) {
            case 5:
                return e.child.stateNode;
            default:
                return e.child.stateNode
        }
    }

    function Id(e, t) {
        if (e = e.memoizedState, e !== null && e.dehydrated !== null) {
            var n = e.retryLane;
            e.retryLane = n !== 0 && n < t ? n : t
        }
    }

    function Es(e, t) {
        Id(e, t), (e = e.alternate) && Id(e, t)
    }

    function Nh() {
        return null
    }
    var Nd = typeof reportError == "function" ? reportError : function(e) {
        console.error(e)
    };

    function ks(e) {
        this._internalRoot = e
    }
    ji.prototype.render = ks.prototype.render = function(e) {
        var t = this._internalRoot;
        if (t === null) throw Error(x(409));
        Mi(e, t, null, null)
    }, ji.prototype.unmount = ks.prototype.unmount = function() {
        var e = this._internalRoot;
        if (e !== null) {
            this._internalRoot = null;
            var t = e.containerInfo;
            dn(function() {
                Mi(null, e, null, null)
            }), t[vt] = null
        }
    };

    function ji(e) {
        this._internalRoot = e
    }
    ji.prototype.unstable_scheduleHydration = function(e) {
        if (e) {
            var t = fc();
            e = {
                blockedOn: null,
                target: e,
                priority: t
            };
            for (var n = 0; n < jt.length && t !== 0 && t < jt[n].priority; n++);
            jt.splice(n, 0, e), n === 0 && vc(e)
        }
    };

    function Os(e) {
        return !(!e || e.nodeType !== 1 && e.nodeType !== 9 && e.nodeType !== 11)
    }

    function zi(e) {
        return !(!e || e.nodeType !== 1 && e.nodeType !== 9 && e.nodeType !== 11 && (e.nodeType !== 8 || e.nodeValue !== " react-mount-point-unstable "))
    }

    function _d() {}

    function _h(e, t, n, r, o) {
        if (o) {
            if (typeof r == "function") {
                var i = r;
                r = function() {
                    var u = Di(a);
                    i.call(u)
                }
            }
            var a = Pd(t, r, e, 0, null, !1, !1, "", _d);
            return e._reactRootContainer = a, e[vt] = a.current, Hr(e.nodeType === 8 ? e.parentNode : e), dn(), a
        }
        for (; o = e.lastChild;) e.removeChild(o);
        if (typeof r == "function") {
            var l = r;
            r = function() {
                var u = Di(s);
                l.call(u)
            }
        }
        var s = xs(e, 0, !1, null, null, !1, !1, "", _d);
        return e._reactRootContainer = s, e[vt] = s.current, Hr(e.nodeType === 8 ? e.parentNode : e), dn(function() {
            Mi(t, s, n, r)
        }), s
    }

    function Fi(e, t, n, r, o) {
        var i = n._reactRootContainer;
        if (i) {
            var a = i;
            if (typeof o == "function") {
                var l = o;
                o = function() {
                    var s = Di(a);
                    l.call(s)
                }
            }
            Mi(t, a, e, o)
        } else a = _h(n, t, e, o, r);
        return Di(a)
    }
    uc = function(e) {
        switch (e.tag) {
            case 3:
                var t = e.stateNode;
                if (t.current.memoizedState.isDehydrated) {
                    var n = Nr(t.pendingLanes);
                    n !== 0 && (Ya(t, n | 1), _e(t, te()), !(b & 6) && (rr = te() + 500, Ut()))
                }
                break;
            case 13:
                dn(function() {
                    var r = yt(e, 1);
                    if (r !== null) {
                        var o = ke();
                        qe(r, e, 1, o)
                    }
                }), Es(e, 1)
        }
    }, Ja = function(e) {
        if (e.tag === 13) {
            var t = yt(e, 134217728);
            if (t !== null) {
                var n = ke();
                qe(t, e, 134217728, n)
            }
            Es(e, 134217728)
        }
    }, cc = function(e) {
        if (e.tag === 13) {
            var t = Wt(e),
                n = yt(e, t);
            if (n !== null) {
                var r = ke();
                qe(n, e, t, r)
            }
            Es(e, t)
        }
    }, fc = function() {
        return U
    }, dc = function(e, t) {
        var n = U;
        try {
            return U = e, t()
        } finally {
            U = n
        }
    }, $a = function(e, t, n) {
        switch (t) {
            case "input":
                if (ja(e, n), t = n.name, n.type === "radio" && t != null) {
                    for (n = e; n.parentNode;) n = n.parentNode;
                    for (n = n.querySelectorAll("input[name=" + JSON.stringify("" + t) + '][type="radio"]'), t = 0; t < n.length; t++) {
                        var r = n[t];
                        if (r !== e && r.form === e.form) {
                            var o = Xo(r);
                            if (!o) throw Error(x(90));
                            Fu(r), ja(r, o)
                        }
                    }
                }
                break;
            case "textarea":
                Bu(e, n);
                break;
            case "select":
                t = n.value, t != null && jn(e, !!n.multiple, t, !1)
        }
    }, Ju = hs, Zu = dn;
    var Rh = {
            usingClientEntryPoint: !1,
            Events: [Kr, Hn, Xo, Qu, Yu, hs]
        },
        lo = {
            findFiberByHostInstance: rn,
            bundleType: 0,
            version: "18.3.1",
            rendererPackageName: "react-dom"
        },
        Mh = {
            bundleType: lo.bundleType,
            version: lo.version,
            rendererPackageName: lo.rendererPackageName,
            rendererConfig: lo.rendererConfig,
            overrideHookState: null,
            overrideHookStateDeletePath: null,
            overrideHookStateRenamePath: null,
            overrideProps: null,
            overridePropsDeletePath: null,
            overridePropsRenamePath: null,
            setErrorHandler: null,
            setSuspenseHandler: null,
            scheduleUpdate: null,
            currentDispatcherRef: pt.ReactCurrentDispatcher,
            findHostInstanceByFiber: function(e) {
                return e = tc(e), e === null ? null : e.stateNode
            },
            findFiberByHostInstance: lo.findFiberByHostInstance || Nh,
            findHostInstancesForRefresh: null,
            scheduleRefresh: null,
            scheduleRoot: null,
            setRefreshHandler: null,
            getCurrentFiber: null,
            reconcilerVersion: "18.3.1-next-f1338f8080-20240426"
        };
    if (typeof __REACT_DEVTOOLS_GLOBAL_HOOK__ < "u") {
        var Ti = __REACT_DEVTOOLS_GLOBAL_HOOK__;
        if (!Ti.isDisabled && Ti.supportsFiber) try {
            jo = Ti.inject(Mh), rt = Ti
        } catch {}
    }
    Me.__SECRET_INTERNALS_DO_NOT_USE_OR_YOU_WILL_BE_FIRED = Rh, Me.createPortal = function(e, t) {
        var n = 2 < arguments.length && arguments[2] !== void 0 ? arguments[2] : null;
        if (!Os(t)) throw Error(x(200));
        return Ih(e, t, null, n)
    }, Me.createRoot = function(e, t) {
        if (!Os(e)) throw Error(x(299));
        var n = !1,
            r = "",
            o = Nd;
        return t != null && (t.unstable_strictMode === !0 && (n = !0), t.identifierPrefix !== void 0 && (r = t.identifierPrefix), t.onRecoverableError !== void 0 && (o = t.onRecoverableError)), t = xs(e, 1, !1, null, null, n, !1, r, o), e[vt] = t.current, Hr(e.nodeType === 8 ? e.parentNode : e), new ks(t)
    }, Me.findDOMNode = function(e) {
        if (e == null) return null;
        if (e.nodeType === 1) return e;
        var t = e._reactInternals;
        if (t === void 0) throw typeof e.render == "function" ? Error(x(188)) : (e = Object.keys(e).join(","), Error(x(268, e)));
        return e = tc(t), e = e === null ? null : e.stateNode, e
    }, Me.flushSync = function(e) {
        return dn(e)
    }, Me.hydrate = function(e, t, n) {
        if (!zi(t)) throw Error(x(200));
        return Fi(null, e, t, !0, n)
    }, Me.hydrateRoot = function(e, t, n) {
        if (!Os(e)) throw Error(x(405));
        var r = n != null && n.hydratedSources || null,
            o = !1,
            i = "",
            a = Nd;
        if (n != null && (n.unstable_strictMode === !0 && (o = !0), n.identifierPrefix !== void 0 && (i = n.identifierPrefix), n.onRecoverableError !== void 0 && (a = n.onRecoverableError)), t = Pd(t, null, e, 1, n ? ? null, o, !1, i, a), e[vt] = t.current, Hr(e), r)
            for (e = 0; e < r.length; e++) n = r[e], o = n._getVersion, o = o(n._source), t.mutableSourceEagerHydrationData == null ? t.mutableSourceEagerHydrationData = [n, o] : t.mutableSourceEagerHydrationData.push(n, o);
        return new ji(t)
    }, Me.render = function(e, t, n) {
        if (!zi(t)) throw Error(x(200));
        return Fi(null, e, t, !1, n)
    }, Me.unmountComponentAtNode = function(e) {
        if (!zi(e)) throw Error(x(40));
        return e._reactRootContainer ? (dn(function() {
            Fi(null, null, e, !1, function() {
                e._reactRootContainer = null, e[vt] = null
            })
        }), !0) : !1
    }, Me.unstable_batchedUpdates = hs, Me.unstable_renderSubtreeIntoContainer = function(e, t, n, r) {
        if (!zi(n)) throw Error(x(200));
        if (e == null || e._reactInternals === void 0) throw Error(x(38));
        return Fi(e, t, n, !1, r)
    }, Me.version = "18.3.1-next-f1338f8080-20240426";

    function Rd() {
        if (!(typeof __REACT_DEVTOOLS_GLOBAL_HOOK__ > "u" || typeof __REACT_DEVTOOLS_GLOBAL_HOOK__.checkDCE != "function")) try {
            __REACT_DEVTOOLS_GLOBAL_HOOK__.checkDCE(Rd)
        } catch (e) {
            console.error(e)
        }
    }
    Rd(), Ou.exports = Me;
    var bi = Ou.exports,
        Md = bi;
    ya.createRoot = Md.createRoot, ya.hydrateRoot = Md.hydrateRoot;
    const Dd = {
            product404: "Product not found"
        },
        ir = {
            dom: "dom-event-system",
            auto: "auto-event-system"
        };
    class Dh {
        constructor() {
            Re(this, "headers", {
                "Content-Type": "application/json"
            })
        }
        async cartAdd(t) {
            return (await fetch(`${window.Shopify.routes.root}cart/add.js?${ir.auto}`, {
                method: "POST",
                headers: this.headers,
                body: JSON.stringify(t)
            })).json()
        }
        async cartGet() {
            const t = new Date().getTime();
            return (await fetch(`${window.Shopify.routes.root}cart.js?timestamp=${t}`)).json()
        }
        async cartChange(t) {
            return (await fetch(`${window.Shopify.routes.root}cart/change.js?${ir.auto}`, {
                method: "POST",
                headers: this.headers,
                body: JSON.stringify(t)
            })).json()
        }
        async updateCartAttributes(t, n) {
            let r = {};
            r[t] = n;
            const o = {
                attributes: r
            };
            return (await fetch(`${window.Shopify.routes.root}cart/update.js?${ir.auto}`, {
                method: "POST",
                headers: {
                    "Content-Type": "application/json"
                },
                body: JSON.stringify(o)
            })).json()
        }
        async cartRemoveItem(t) {
            return await this.cartChange({
                id: t.key,
                quantity: 0,
                sections: t.sections
            })
        }
        async productGet(t) {
            const n = await fetch(`${window.Shopify.routes.root}products/${t}.js`);
            if (n.status === 404) throw new Error(Dd.product404);
            try {
                return await n.json()
            } catch {
                const o = await n.text();
                throw new Error(JSON.stringify({
                    statusCode: n.status,
                    headers: n.headers,
                    responseText: o
                }))
            }
        }
    }
    const ar = {
        CartChanged: "loop.cartChanged",
        RefreshCart: "loop.refreshCart"
    };
    var F = (e => (e.Accepted = "accepted", e.Offered = "offered", e.Rejected = "rejected", e.Unknown = "unknown", e.AutoRejected = "auto-rejected", e.Excluded = "not shown: excluded", e.LocaleNotSupported = "not shown: locale", e.ExcludedOnStore = "not shown: loop onstore", e.ExcludedPickup = "not shown: in store pickup", e.ExcludedTooValuable = "not shown: cart too valuable", e.ExcludedReturnCoverageOptimization = "not shown: return coverage optimization", e))(F || {}),
        Z = (e => (e.OfferStatus = "_returnCoverageOfferStatus", e.Product = "_returnCoverageProduct", e.DeterminedCoverageAmount = "_determinedCoverageAmount", e.ExperimentAssignment = "_lrca", e.OfferOrigin = "_coverageOfferOrigin", e.MountTarget = "_checkoutMountTarget", e.CartExperience = "_addOnCartExperience", e))(Z || {}),
        jd = (e => (e.Storefront = "Storefront", e.Checkout = "Checkout", e))(jd || {}),
        Ls = (e => (e.LoopOptimizationAssignment = "loop_optimization_assignment", e.LoopOffsetOfferStatus = "loop_offset_offer_status", e))(Ls || {}),
        zd = (e => (e.BelowShipping = "below_shipping", e.RightRail = "right_rail", e.Cart = "cart", e))(zd || {}),
        Ps = (e => (e.widget = "widget", e.alternate = "2ButtonReplacement", e))(Ps || {}),
        _ = (e => (e.Accepted = "Accepted", e.AnalyzingAttributes = "AnalyzingAttributes", e.CalculateEligibility = "CalculateEligibility", e.Empty = "Empty", e.Error = "Error", e.EvaluatingExperiments = "EvaluatingExperiments", e.AssignExperiments = "AssignExperiments", e.Excluded = "Excluded", e.IdealVariant = "IdealVariant", e.Initialization = "Initialization", e.Listen = "Listen", e.LoadingAttributes = "LoadingAttributes", e.Rejected = "Rejected", e.ResolveProduct = "ResolveProduct", e.UpdateAttributes = "UpdateAttributes", e.UpdateCartlines = "UpdateCartLines", e))(_ || {}),
        so = (e => (e.Offset = "Offset", e.OffsetShippingProtection = "OffsetShippingProtection", e.ShippingProtection = "ShippingProtection", e))(so || {});
    const Fd = {
            step: "Initialization",
            shopDomain: null,
            config: null,
            product: null,
            resolvedProduct: null,
            offerStatus: F.Unknown,
            showUI: !0,
            cartLineId: null,
            cartLinePrice: null,
            attributes: null,
            listenForCartLineChanges: !1,
            listenForLocalizationChanges: !1,
            listenForDeliveryGroupChanges: !1,
            cartLineChangeAction: null,
            cartTotal: null,
            mode: "Offset",
            mountTarget: null,
            redirectToCheckout: !1,
            experimentGroup: null,
            experimentEvaluated: !1
        },
        X = k.createContext([Fd, () => null]),
        jh = (e, t) => ({ ...e,
            ...t
        }),
        zh = "production",
        Td = "https://d1y4yqugo2tfyu.cloudfront.net/config",
        Fh = "https://d1y4yqugo2tfyu.cloudfront.net/shipping-protection/config",
        Th = "https://d1y4yqugo2tfyu.cloudfront.net/i18n/config",
        bh = "puba15a945d0aee0802b77ed711cb100691",
        Ah = "100";
    let Uh = class {
        constructor() {
            Re(this, "destinations", []);
            Re(this, "meta", {});
            Re(this, "buffer", [])
        }
        addDestination(t) {
            this.destinations.push(t)
        }
        addMetaData(t, n) {
            this.meta[t] = n
        }
        async log(t, n) {
            return this.logMessage("log", t, n)
        }
        async debug(t, n) {
            return this.logMessage("debug", t, n)
        }
        async warn(t, n) {
            return this.logMessage("warn", t, n)
        }
        async info(t, n) {
            return this.logMessage("info", t, n)
        }
        async error(t, n) {
            return this.logMessage("error", t, n)
        }
        async processBuffer() {
            return new Promise(async t => {
                if (!this.destinations.length) return console.warn("No destinations configured, erasing log message buffer"), this.buffer = [], t();
                for (const n of this.buffer) {
                    const {
                        level: r,
                        message: o,
                        context: i
                    } = n;
                    await this.fanOutMessageToAllDestinations(r, o, i)
                }
                return this.buffer = [], t()
            })
        }
        async logMessage(t, n, r) {
            return new Promise(async o => this.destinations.length ? (await this.fanOutMessageToAllDestinations(t, n, r), o()) : (this.buffer.push({
                level: t,
                message: n,
                context: r
            }), o()))
        }
        async fanOutMessageToAllDestinations(t, n, r) {
            return new Promise(async o => {
                for (const i of this.destinations) await i.log(t, n, r, this.meta);
                return o()
            })
        }
    };
    const lr = new Uh,
        bd = {
            debug: 0,
            log: 1,
            info: 2,
            warn: 3,
            error: 4
        };
    class Bh {
        constructor(t) {
            Re(this, "minLogLevel");
            Re(this, "metaData");
            this.minLogLevel = t.minLogLevel, this.metaData = t.metaData === void 0 ? {} : t.metaData
        }
        async log(t, n, r, o) {
            return new Promise(async i => {
                const a = bd[t],
                    l = bd[this.minLogLevel];
                return a >= l && (this.metaData === null ? await this.handle(t, n, r) : await this.handle(t, n, r, Object.assign(o, this.metaData))), i()
            })
        }
    }

    function $h(e) {
        return e !== 0 && Math.random() * 100 <= e
    }

    function Vh(e) {
        return e > 100 ? 100 : e < 0 ? 0 : e
    }
    class Hh extends Bh {
        constructor(n) {
            super({
                minLogLevel: n.minLogLevel
            });
            Re(this, "buffer", []);
            Re(this, "api", "");
            Re(this, "apiKey");
            Re(this, "serviceName");
            Re(this, "env");
            const {
                flushTimeout: r,
                apiKey: o,
                serviceName: i,
                env: a,
                sessionSamplingRate: l
            } = n;
            if (this.serviceName = i, this.env = a, this.apiKey = o, !this.apiKey) return;
            const s = new URLSearchParams({
                "dd-api-key": o
            });
            this.api = `https://http-intake.logs.datadoghq.com/api/v2/logs?${s.toString()}`;
            let u = Vh(l || 100);
            $h(u) && setInterval(() => {
                this.flush()
            }, r)
        }
        async handle(n, r, o, i) {
            return new Promise(a => (this.buffer.push({
                level: n,
                message: r,
                context: o,
                meta: i
            }), a()))
        }
        hasUnsentLogs() {
            return !!this.buffer.length
        }
        async flush() {
            if (!this.hasUnsentLogs()) return;
            if (!this.apiKey) {
                console.warn("No logging API key specified"), this.buffer = [];
                return
            }
            const n = this.buffer.map(r => ({
                ddtags: `env:${this.env}`,
                service: `${this.serviceName}`,
                status: r.level,
                message: r.message,
                context: r.context
            }));
            try {
                await fetch(this.api, {
                    method: "POST",
                    headers: {
                        "content-type": "application/json"
                    },
                    body: JSON.stringify(n)
                })
            } catch (r) {
                console.error(r)
            } finally {
                this.buffer = []
            }
        }
    }
    let Gh = parseInt(Ah) || 1;
    lr.addDestination(new Hh({
        minLogLevel: "debug",
        apiKey: bh,
        flushTimeout: 3e3,
        serviceName: "loop-react-shopify-checkout",
        env: zh,
        sessionSamplingRate: Gh
    }));
    const Ge = k.createContext(lr);

    function ee(...e) {
        if (self.hasOwnProperty("sessionStorage") && self.sessionStorage.getItem("offset-debug") === "yes") {
            console.log(...e);
            return
        }
    }

    function R(...e) {
        if (self.hasOwnProperty("sessionStorage") && self.sessionStorage.getItem("offset-debug") === "yes") {
            console.debug(...e);
            return
        }
    }
    const Wh = new RegExp("([\\p{Ll}\\d])(\\p{Lu})", "gu"),
        Kh = new RegExp("(\\p{Lu})([\\p{Lu}][\\p{Ll}])", "gu"),
        Qh = new RegExp("(\\d)\\p{Ll}|(\\p{L})\\d", "u"),
        Yh = /[^\p{L}\d]+/giu,
        Ad = "$1\0$2",
        Ud = "";

    function Bd(e) {
        let t = e.trim();
        t = t.replace(Wh, Ad).replace(Kh, Ad), t = t.replace(Yh, "\0");
        let n = 0,
            r = t.length;
        for (; t.charAt(n) === "\0";) n++;
        if (n === r) return [];
        for (; t.charAt(r - 1) === "\0";) r--;
        return t.slice(n, r).split(/\0/g)
    }

    function Jh(e) {
        const t = Bd(e);
        for (let n = 0; n < t.length; n++) {
            const r = t[n],
                o = Qh.exec(r);
            if (o) {
                const i = o.index + (o[1] ? ? o[2]).length;
                t.splice(n, 1, r.slice(0, i), r.slice(i))
            }
        }
        return t
    }

    function Is(e, t) {
        const [n, r, o] = em(e, t), i = Zh(t == null ? void 0 : t.locale), a = qh(t == null ? void 0 : t.locale), l = Xh(i, a);
        return n + r.map((s, u) => u === 0 ? i(s) : l(s, u)).join("") + o
    }

    function Zh(e) {
        return t => t.toLocaleLowerCase(e)
    }

    function qh(e) {
        return t => t.toLocaleUpperCase(e)
    }

    function Xh(e, t) {
        return (n, r) => {
            const o = n[0];
            return (r > 0 && o >= "0" && o <= "9" ? "_" + o : t(o)) + e(n.slice(1))
        }
    }

    function em(e, t = {}) {
        const n = t.split ? ? (t.separateNumbers ? Jh : Bd),
            r = t.prefixCharacters ? ? Ud,
            o = t.suffixCharacters ? ? Ud;
        let i = 0,
            a = e.length;
        for (; i < e.length;) {
            const l = e.charAt(i);
            if (!r.includes(l)) break;
            i++
        }
        for (; a > i;) {
            const l = a - 1,
                s = e.charAt(l);
            if (!o.includes(s)) break;
            a = l
        }
        return [e.slice(0, i), n(e.slice(i, a)), e.slice(a)]
    }
    const $d = {
            returnCoverageEnabled: !1,
            excludedProductTags: [],
            refundHandlingFee: 1e3,
            returnCoverageProductId: 123,
            returnCoverageFee: 198,
            returnCoverageProductHandle: "return-coverage",
            returnCoverageOptimizationEnabled: !1,
            returnCoverageOptimizationPercentage: 50,
            autoFulfillReturnCoverageProduct: !1,
            shippingProtectionEnabled: !1,
            shippingProtectionAndReturnCoverageProductId: 123,
            shippingProtectionAndReturnCoverageProductHandle: "shipping-protection",
            exchangeRates: {},
            i18n: {
                en: {
                    cart: {
                        title: "Pay now to unlock free returns",
                        caption: "Avoid return handling fees for all eligible items."
                    },
                    checkout: {
                        title: "Pay now to unlock free returns for {{ formatted_price }}.",
                        caption: "Avoid handling fees for all eligible items when you make a return."
                    },
                    learnMore: {
                        title: "Unlock free returns for {{ formatted_price }}",
                        body: [{
                            type: "paragraph",
                            content: [{
                                type: "text",
                                text: "By paying {{ formatted_price }} now on your order, you will qualify for a return at no extra cost, allowing you to maximize your return by avoiding higher return handling and shipping fees."
                            }]
                        }, {
                            type: "paragraph",
                            content: [{
                                type: "text",
                                text: "If you don't opt to pay the {{ formatted_price }} fee now, you can still do a return, but you will be responsible for the cost of the {{ fee_price }} handling fee."
                            }]
                        }, {
                            type: "paragraph",
                            content: [{
                                type: "text",
                                marks: [{
                                    type: "italic"
                                }],
                                text: "Store policies may exclude certain items from this service, such as items that are final sale."
                            }]
                        }]
                    }
                }
            },
            returnCoverageAlternateCartExperience: !1
        },
        tm = async (e, t) => {
            const n = {};
            return n.i18n = $d.i18n, await Promise.all([fetch(`${Td}/${e}.json`).then(async r => {
                if (!r.ok) {
                    n.returnCoverageEnabled = !1, R("Offset#resolveConfig - Error fetching return coverage config", {
                        shopDomain: e,
                        response: r
                    });
                    return
                }
                try {
                    const o = await r.json();
                    for (const [i, a] of Object.entries(o)) {
                        if (i === "EXCLUDED_PRODUCT_TAGS") {
                            n[Is(i)] = Array.isArray(a) ? a.filter(l => l).map(l => l.toLowerCase()) : [];
                            continue
                        }
                        n[Is(i)] = a
                    }
                } catch (o) {
                    t.error("Offset#resolveConfig - Error parsing return coverage config", {
                        shopDomain: e,
                        error: o
                    }), n.returnCoverageEnabled = !1
                }
            }), fetch(`${Fh}/${e}.json`).then(async r => {
                if (!r.ok) {
                    n.shippingProtectionEnabled = !1, R("Offset#resolveConfig - Error fetching shipping protection config", {
                        shopDomain: e,
                        response: r
                    });
                    return
                }
                try {
                    const o = await r.json();
                    for (const [i, a] of Object.entries(o)) i !== "RETURN_COVERAGE_ENABLED" && (n[Is(i)] = a)
                } catch (o) {
                    t.error("Offset#resolveConfig - Error parsing shipping protection config", {
                        shopDomain: e,
                        error: o
                    }), n.shippingProtectionEnabled = !1
                }
            }), fetch(`${Th}/${e}.json`).then(async r => {
                if (!r.ok) {
                    R("Offset#resolveConfig - Error fetching copy customization config", {
                        shopDomain: e,
                        response: r
                    });
                    return
                }
                try {
                    const o = await r.json();
                    for (const [i, a] of Object.entries(o))
                        if (i !== "RETURN_COVERAGE_ENABLED" && (i === "cart" && (n.i18n.en.cart = a), i === "checkout" && (n.i18n.en.checkout = a), i === "learn-more")) {
                            const l = a;
                            l.body && (n.i18n.en.learnMore.body = l.body), l.title && (n.i18n.en.learnMore.title = l.title)
                        }
                } catch (o) {
                    t.error("Offset#resolveConfig - Error parsing copy customization config", {
                        shopDomain: e,
                        error: o
                    }), n.i18n = $d.i18n
                }
            }), fetch(`${Td}/exchangeRates.json`).then(async r => {
                if (!r.ok) {
                    R("Offset#resolveConfig - Error fetching exchange rates file", {
                        shopDomain: e,
                        response: r
                    });
                    return
                }
                try {
                    return n.exchangeRates = await r.json(), n
                } catch (o) {
                    t.error("Offset#resolveConfig - Error parsing exchange rates file", {
                        shopDomain: e,
                        error: o
                    })
                }
            })]), Promise.resolve(n)
        },
        nm = e => e.shippingProtectionEnabled && e.returnCoverageEnabled ? so.OffsetShippingProtection : so.Offset;

    function rm({
        shopDomain: e,
        mountTarget: t
    }) {
        const [n, r] = k.useContext(X), o = k.useContext(Ge);
        let i;
        return k.useEffect(() => {
            ee("Offset#Initialize Mounted", {
                state: n
            }), i = { ...i,
                shopDomain: e
            };
            async function a() {
                const l = await tm(e, o);
                if (Object.keys(l).length === 0) {
                    o.error("Offset#initialize:Config - Resolved Configuration object had no data", {
                        shopDomain: e
                    }), i = { ...i,
                        step: _.Error
                    }, r(i);
                    return
                }
                if (!l.returnCoverageEnabled) {
                    o.warn("Offset#initialize:Config - returnCoverageEnabled was false", {
                        shopDomain: e,
                        resolvedConfig: l
                    });
                    return
                }
                const s = nm(l);
                o.info("Offset#initialize:Config - Config resolved", {
                    shopDomain: e,
                    resolvedConfig: l
                }), i = { ...i,
                    config: l,
                    step: _.ResolveProduct,
                    mode: s,
                    mountTarget: t
                }, r(i)
            }
            a()
        }, []), w.jsx(w.Fragment, {})
    }
    var oe = (e => (e.Inactive = "Inactive", e.Treatment = "Treatment", e.Control = "Control", e.Excluded = "Excluded", e))(oe || {});

    function om({
        resolveCartLines: e,
        resolveIsCartEligible: t,
        isLoopOnStoreActive: n,
        deliveryGroups: r
    }) {
        const [o, i] = k.useContext(X), a = k.useContext(Ge), {
            resolvedProduct: l,
            experimentEvaluated: s,
            experimentGroup: u
        } = o, c = l == null ? void 0 : l.id;
        let f = { ...o
        };
        return k.useEffect(() => {
            ee("Offset#CalculateEligibility Mounted", {
                state: o
            });
            async function d() {
                var p;
                let h = !0;
                s && u && (u === oe.Control || u !== oe.Treatment && u !== oe.Inactive) && (h = !1);
                const y = await e(),
                    m = y.find(g => g.productId === c);
                f = { ...f,
                    cartLineId: m ? m.cartLineId : null,
                    cartLinePrice: m ? m.price : null,
                    showUI: h,
                    listenForCartLineChanges: !1,
                    listenForLocalizationChanges: !1,
                    listenForDeliveryGroupChanges: !1
                };
                let E = !1;
                for (const g of r) {
                    const C = (p = g.selectedDeliveryOption) == null ? void 0 : p.handle;
                    for (const O of g.deliveryOptions) O.handle === C && O.type === "pickup" && (E = !0)
                }
                if (E) {
                    a.info("Offset#CalculateEligibility: Ineligible Cart Pickup is Selected", {
                        shopDomain: o.shopDomain,
                        state: o
                    }), f = { ...f,
                        step: _.Excluded,
                        offerStatus: F.ExcludedPickup,
                        showUI: !1
                    }, i(f);
                    return
                }
                if (n()) {
                    a.info("Offset#CalculateEligibility: Ineligible Cart Onstore is Active", {
                        shopDomain: o.shopDomain,
                        state: o
                    }), f = { ...f,
                        step: _.Excluded,
                        offerStatus: F.ExcludedOnStore,
                        showUI: !1
                    }, i(f);
                    return
                }
                const v = await t(y);
                if (!v && y.length === 0) {
                    f = { ...f,
                        step: _.UpdateCartlines
                    }, i(f);
                    return
                }
                if (!v) {
                    a.info("Offset#CalculateEligibility: Ineligible Cart Detected", {
                        shopDomain: o.shopDomain,
                        state: o
                    }), f = { ...f,
                        step: _.Excluded,
                        offerStatus: F.Excluded,
                        showUI: !1
                    }, i(f);
                    return
                }
                f = { ...f,
                    step: _.IdealVariant
                }, i(f)
            }
            d()
        }, []), w.jsx(w.Fragment, {})
    }
    const Ai = e => new Promise(t => setTimeout(t, e));
    async function xt(e, t, n, r, o, i, a = 1, l = 3, s = 300) {
        try {
            const u = await e(o, i);
            if (a < l && u.type === "error") {
                const c = s * Math.pow(2, a - 1);
                return n.warn(`Offset#${r} updateCartAttributes - Retrying cart attribute update`, {
                    key: o,
                    value: i,
                    shopDomain: t.shopDomain,
                    state: t
                }), await Ai(c), xt(e, t, n, r, o, i, a + 1, l, s)
            }
            return u.type === "error" ? (n.error(`Offset#${r} updateCartAttributes`, {
                key: o,
                value: i,
                shopDomain: t.shopDomain,
                state: t,
                response: u
            }), u) : (n.info(`Offset#${r} updateCartAttributes`, {
                key: o,
                value: i,
                shopDomain: t.shopDomain,
                state: t
            }), u)
        } catch (u) {
            return n.error(`Offset#${r} updateCartAttributes`, {
                error: u,
                key: o,
                value: i,
                shopDomain: t.shopDomain,
                state: t
            }), {
                type: "error"
            }
        }
    }
    async function Vd(e, t, n, r, o, i, a = 1, l = 3, s = 300) {
        try {
            const u = await e(o);
            if (a < l && u.type === "error") {
                const c = s * Math.pow(2, a - 1);
                return n.warn("Offset#addReturnCoverage - Retrying add to cart", {
                    delay: c,
                    currentAttempt: a,
                    maxAttempts: l,
                    shopDomain: t.shopDomain,
                    state: t,
                    errorMessage: u.message
                }), await Ai(c), Vd(e, t, n, r, o, i, a + 1, l, s)
            }
            return u.type === "error" ? (n.error(`Offset#${r} addReturnCoverage - Failed to add to cart after ${a} tries`, {
                shopDomain: t.shopDomain,
                state: t,
                errorMessage: u.message
            }), u) : (n.info(`Offset#${r} addReturnCoverage - ${i}`, {
                offerStatus: i,
                shopDomain: t.shopDomain,
                state: t
            }), u)
        } catch (u) {
            return n.error(`Offset#${r} - ${i}`, {
                error: u,
                shopDomain: t.shopDomain,
                state: t
            }), {
                type: "error"
            }
        }
    }
    async function Ui(e, t, n, r, o, i, a, l = 1, s = 3, u = 300) {
        try {
            const c = await e(o, a);
            if (l < s && c.type === "error") {
                const f = u * Math.pow(2, l - 1);
                return n.warn("Offset#removeReturnCoverage - Retrying remove from cart", {
                    shopDomain: t.shopDomain,
                    state: t,
                    message: c.message
                }), await Ai(f), Ui(e, t, n, r, o, i, a, l + 1, s, u)
            }
            return c.type === "error" ? (n.error(`Offset#${r} removeReturnCoverage - Failed to remove from cart`, {
                shopDomain: t.shopDomain,
                state: t,
                message: c.message
            }), c) : (n.info(`Offset#${r} removeReturnCoverage - ${i}`, {
                offerStatus: i,
                shopDomain: t.shopDomain,
                state: t
            }), c)
        } catch (c) {
            return n.error(`Offset#${r} - ${i}`, {
                error: c,
                shopDomain: t.shopDomain,
                state: t
            }), {
                type: "error"
            }
        }
    }
    async function Hd(e, t, n, r, o, i = 1, a = 3, l = 500) {
        if (!r) return {
            type: "error",
            message: "No config found"
        };
        try {
            const s = await e(r);
            if (i <= a && s.type === "error") {
                const u = l * Math.pow(2, i - 1);
                return await Ai(u), Hd(e, t, n, r, o, i + 1, a, l)
            }
            return s.type === "error" ? (o.error(`Offset#Initialize resolveProduct - Failed to resolve product after ${i} tries`, {
                shopDomain: t,
                state: n,
                errorMessage: s.message
            }), s) : (o.info("Offset#Initialize resolveProduct", {
                shopDomain: t,
                state: n
            }), s)
        } catch (s) {
            return o.error("Offset#Initialize resolveProduct", {
                errorMessage: s,
                shopDomain: t,
                state: n
            }), {
                type: "error",
                message: JSON.stringify(s.message)
            }
        }
    }

    function im({
        cartLines: e,
        removeFromCart: t,
        updateCartAttributes: n
    }) {
        const [r, o] = k.useContext(X), i = k.useContext(Ge);
        let a;
        return k.useEffect(() => {
            ee("Offset#Excluded Mounted", {
                state: r
            });
            async function l() {
                const {
                    cartLineId: s,
                    offerStatus: u
                } = r, c = e.find(d => d.cartLineId === s);
                if (a = { ...a,
                        listenForCartLineChanges: !1,
                        listenForLocalizationChanges: !1
                    }, await xt(n, r, i, "Excluded", Z.OfferStatus, u), r.cartLineId === null) {
                    a = { ...a,
                        step: _.UpdateCartlines
                    }, o(a);
                    return
                }
                const f = await Ui(t, r, i, "Excluded", r.cartLineId, u, (c == null ? void 0 : c.quantity) || 1);
                if ((f == null ? void 0 : f.type) === "success") {
                    a = { ...a,
                        cartLineChangeAction: "removed",
                        cartLineId: null,
                        step: _.UpdateCartlines
                    }, o(a);
                    return
                }
                i.error("Finished Excluded Step - failed removing from Cart - waiting...", {
                    shopDomain: r.shopDomain,
                    state: r
                }), a = { ...a,
                    step: _.UpdateCartlines
                }, o(a)
            }
            l()
        }, []), w.jsx(w.Fragment, {})
    }

    function am({
        resolveCartAttributes: e
    }) {
        const [t, n] = k.useContext(X);
        let r;
        return k.useEffect(() => {
            ee("Offset#LoadingAttributes Mounted", {
                state: t
            });
            async function o() {
                const i = await e();
                r = { ...r,
                    attributes: i,
                    step: _.EvaluatingExperiments
                }, n(r)
            }
            o()
        }, []), w.jsx(w.Fragment, {})
    }

    function lm() {
        const [e, t] = k.useContext(X), n = k.useContext(Ge);
        let r;
        return k.useEffect(() => {
            ee("Offset#AnalyzingAttributes Mounted", {
                state: e
            });
            async function o() {
                const {
                    attributes: i
                } = e, a = i == null ? void 0 : i.find(s => s.key === Z.OfferStatus), l = !!e.cartLineId;
                if (r = { ...r,
                        offerStatus: F.Offered,
                        step: _.UpdateCartlines
                    }, a && a.value === F.Excluded) {
                    n.info("Offset#AnalyzingAttributes - Ineligible Cart Became Eligible", {
                        state: e
                    }), t(r);
                    return
                }
                if (a && a.value === F.LocaleNotSupported) {
                    n.info("Offset#AnalyzingAttributes - Locale is now supported", {
                        state: e
                    }), t(r);
                    return
                }
                if (a && a.value === F.ExcludedOnStore) {
                    n.info("Offset#AnalyzingAttributes - Onstore turned off - cart became eligible", {
                        state: e
                    }), t(r);
                    return
                }
                if (a && a.value === F.ExcludedReturnCoverageOptimization) {
                    n.info("Offset#AnalyzingAttributes - Return Coverage Optimization Testing turned off - cart became eligible", {
                        state: e
                    }), t(r);
                    return
                }
                if (!a && !l) {
                    ee("Offset#AnalyzingAttributes - auto process"), t(r);
                    return
                }
                if ((a == null ? void 0 : a.value) === F.Rejected && !l) {
                    ee("Offset#AnalyzingAttributes - confirming rejected"), r = { ...r,
                        offerStatus: F.Rejected,
                        step: _.Rejected
                    }, t(r);
                    return
                }
                if (l) {
                    ee("Offset#AnalyzingAttributes - confirming accepted"), t({ ...r,
                        offerStatus: F.Accepted,
                        step: _.Accepted
                    });
                    return
                }
                if (a && a.value === F.Unknown) {
                    n.info("Offset#AnalyzingAttributes - Offer Status Unknown - auto add", {
                        state: e
                    }), t(r);
                    return
                }
                r = { ...r,
                    offerStatus: F.Rejected,
                    step: _.Rejected
                }, t(r)
            }
            o()
        }, []), w.jsx(w.Fragment, {})
    }

    function sm({
        addToCart: e,
        updateCartAttributes: t,
        resolveCartLines: n,
        removeFromCart: r
    }) {
        const [o, i] = k.useContext(X), a = k.useContext(Ge);
        let l;
        const {
            product: s
        } = o, u = s == null ? void 0 : s.productId;
        return k.useEffect(() => {
            ee("Offset#Accepted Mounted", {
                state: o
            });
            async function c() {
                var g;
                const f = await n(),
                    d = f == null ? void 0 : f.find(C => C.productId === u);
                let h = !0;
                l = { ...l,
                    listenForCartLineChanges: !1,
                    listenForLocalizationChanges: !1,
                    offerStatus: F.Accepted,
                    step: _.UpdateCartlines
                };
                const {
                    cartLineId: y,
                    offerStatus: m,
                    product: E
                } = o, v = !!y;
                if (!E) {
                    i({ ...l,
                        step: _.Error
                    });
                    return
                }
                const {
                    variantId: p
                } = E;
                if ((g = o.config) != null && g.shippingProtectionEnabled) o.cartLineId && (d == null ? void 0 : d.variantId) !== p && await Ui(r, o, a, "Accepted", o.cartLineId, F.Accepted, 1), o.cartLineId && (d == null ? void 0 : d.variantId) === p && (h = !1);
                else if (m === F.Accepted && v) {
                    i(l);
                    return
                }
                if (h) {
                    const C = await Vd(e, o, a, F.Accepted, p, F.Accepted, 1, 3, 300);
                    if ((C == null ? void 0 : C.type) === "success") {
                        await xt(t, o, a, "Accepted", Z.OfferStatus, F.Accepted), l = { ...l,
                            cartLineChangeAction: "added"
                        }, i(l);
                        return
                    }
                }
                a.error("Finished Accepted Step - failed adding to Cart - waiting...", {
                    shopDomain: o.shopDomain,
                    state: o
                }), i(l)
            }
            c()
        }, []), w.jsx(w.Fragment, {})
    }

    function um({
        removeFromCart: e,
        updateCartAttributes: t,
        cartLines: n
    }) {
        const [r, o] = k.useContext(X), i = k.useContext(Ge);
        let a;
        return k.useEffect(() => {
            ee("Offset#Rejected Mounted", {
                state: r
            }), a = { ...a,
                listenForCartLineChanges: !1,
                listenForLocalizationChanges: !1
            };
            async function l() {
                const {
                    cartLineId: s,
                    offerStatus: u,
                    attributes: c
                } = r, f = !!s, d = n.find(m => m.cartLineId === s), h = c == null ? void 0 : c.find(m => m.key === Z.OfferStatus);
                if (h && h.value !== F.Rejected && await xt(t, r, i, "Rejected", Z.OfferStatus, F.Rejected), u === F.Rejected && !f) {
                    a = { ...a,
                        step: _.UpdateCartlines
                    }, o(a);
                    return
                }
                if (a = { ...a,
                        offerStatus: F.Rejected,
                        step: _.UpdateCartlines
                    }, r.cartLineId === null) {
                    i.error("Finished Rejected Step - missing cartLineId - waiting...", {
                        shopDomain: r.shopDomain,
                        state: r
                    }), o(a);
                    return
                }
                const y = await Ui(e, r, i, "Rejected", r.cartLineId, F.Rejected, (d == null ? void 0 : d.quantity) || 1);
                if ((y == null ? void 0 : y.type) === "success") {
                    await xt(t, r, i, "Rejected", Z.OfferStatus, F.Rejected), a = { ...a,
                        cartLineId: null,
                        cartLineChangeAction: "removed"
                    }, o(a);
                    return
                }
                i.error("Finished Rejected Step - failed removing from Cart - waiting...", {
                    shopDomain: r.shopDomain,
                    state: r
                }), o(a)
            }
            l()
        }, []), w.jsx(w.Fragment, {})
    }

    function cm() {
        const [e] = k.useContext(X);
        return R({
            state: e
        }), w.jsx(w.Fragment, {})
    }

    function fm({
        resolveCartLines: e,
        setProductQuantityInCart: t
    }) {
        const [n, r] = k.useContext(X), {
            product: o
        } = n, i = o == null ? void 0 : o.productId;
        let a;
        return k.useEffect(() => {
            ee("Offset#UpdateCartLines Mounted", {
                state: n
            });
            async function l() {
                const u = (await e()).find(c => c.productId === i);
                a = { ...a,
                    cartLineId: u ? u.cartLineId : null
                }, ee(u ? "Offset#UpdateCartLines - RC Item is in Cart" : "Offset#UpdateCartLines - RC Item is Not in Cart"), u != null && u.quantity && (u == null ? void 0 : u.quantity) > 1 && (u != null && u.cartLineId) && (ee("Offset#UpdateCartLines - detected too many return coverage products in cart", {
                    rcLine: u
                }), await t(u.cartLineId), a = { ...a,
                    cartLineChangeAction: "quantity"
                }), R("UpdateCartLines#dispatching state to UpdateAttributes step"), a = { ...a,
                    step: _.UpdateAttributes
                }, r(a)
            }
            l()
        }, []), w.jsx(w.Fragment, {})
    }

    function dm({
        cartLines: e,
        locationProvider: t,
        updateCartAttributes: n
    }) {
        const [r, o] = k.useContext(X), {
            listenForCartLineChanges: i,
            listenForLocalizationChanges: a
        } = r, l = e.reduce((c, f) => c + f.cartLineId, "");
        R({
            state: r
        });
        let s;
        const u = k.useContext(Ge);
        return k.useEffect(() => {
            i && (s = { ...s,
                listenForCartLineChanges: !1,
                listenForLocalizationChanges: !1,
                step: _.CalculateEligibility
            }, o(s))
        }, [l]), k.useEffect(() => {
            a && (s = { ...s,
                listenForCartLineChanges: !1,
                listenForLocalizationChanges: !1,
                step: _.Initialization
            }, o(s))
        }, [t.getCountry()]), k.useEffect(() => {
            async function c() {
                s = { ...s,
                    listenForCartLineChanges: !0,
                    listenForLocalizationChanges: !0,
                    showUI: !1,
                    cartLineId: null
                }, o(s), await xt(n, r, u, "Error", Z.OfferStatus, F.LocaleNotSupported)
            }
            c()
        }, []), w.jsx(w.Fragment, {})
    }
    const Ns = {
        clear() {
            self.hasOwnProperty("localStorage") && self.localStorage.clear()
        },
        getItem(e) {
            return self.hasOwnProperty("localStorage") ? self.localStorage.getItem(e) : null
        },
        key(e) {
            return self.hasOwnProperty("localStorage") ? self.localStorage.key(e) : null
        },
        removeItem(e) {
            self.hasOwnProperty("localStorage") && self.localStorage.removeItem(e)
        },
        setItem(e, t) {
            self.hasOwnProperty("localStorage") && self.localStorage.setItem(e, t)
        },
        get length() {
            return self.hasOwnProperty("localStorage") ? self.localStorage.length : 0
        }
    };
    class Gd {
        constructor(t, n) {
            Re(this, "consentProvider");
            Re(this, "config");
            this.consentProvider = t, this.config = n
        }
        async isExperimentActive() {
            var r;
            const t = ((r = this.config) == null ? void 0 : r.returnCoverageOptimizationEnabled) ? ? !1,
                n = await this.consentProvider.obtainConsentForAnalytics();
            return R("LoopOptimization#isExperimentActive", {
                enabled: t,
                consentObtained: n
            }), t && n
        }
        async generateAssignment() {
            var o;
            const t = ((o = this.config) == null ? void 0 : o.returnCoverageOptimizationPercentage) ? ? 50,
                n = Math.round(Math.random() * 100);
            R("LoopOptimization#assignToExperimentGroup: Assigning to experiment group", {
                treatmentChance: t,
                bucket: n
            });
            const r = {
                group: n < t ? oe.Treatment : oe.Control,
                bucket: n
            };
            return await this.writeAssignment(r), R("LoopOptimization#assignToExperimentGroup: ", {
                assignment: r
            }), r
        }
        async defineAssignment() {
            return await this.isExperimentActive() ? await this.getAssignmentFromStorage() ? ? await this.generateAssignment() : (R("LoopOptimization#assignToExperimentGroup: Experiment is inactive"), {
                group: oe.Inactive,
                bucket: null
            })
        }
        async getAssignmentFromStorage() {
            const t = Ns.getItem("_lrca");
            if (!t) return null;
            try {
                return JSON.parse(t)
            } catch (n) {
                return R("LoopOptimization#getAssignmentFromStorage: Invalid JSON in localStorage for _lrca:", n), Ns.removeItem("_lrca"), null
            }
        }
        async writeAssignment(t) {
            Ns.setItem("_lrca", JSON.stringify(t))
        }
        validateAssignment(t) {
            return (t && Object.values(oe).includes(t.group)) ? ? !1
        }
    }

    function pm({
        consentProvider: e
    }) {
        const [t, n] = k.useContext(X), r = k.useContext(Ge);
        let o = { ...t,
            experimentEvaluated: !0
        };
        const i = t.config,
            a = k.useMemo(() => new Gd(e, i), [e]);
        return k.useEffect(() => {
            ee("Offset#EvaluatingExperiments Mounted", {
                state: t
            });
            async function l() {
                var f;
                const {
                    attributes: s
                } = t;
                if (!await a.isExperimentActive()) {
                    o = { ...o,
                        step: _.AnalyzingAttributes,
                        experimentGroup: oe.Inactive
                    }, n(o);
                    return
                }
                const u = (f = s == null ? void 0 : s.find(d => d.key === Z.ExperimentAssignment)) == null ? void 0 : f.value;
                let c = null;
                try {
                    c = u ? JSON.parse(u) : null
                } catch (d) {
                    R("Offset#EvaluatingExperiments: Invalid JSON in CartAttributes for _lrca:", d), o = { ...o,
                        step: _.AnalyzingAttributes,
                        experimentGroup: oe.Inactive
                    }, n(o);
                    return
                }
                if (c && c.group === oe.Control) {
                    r.info("Offset#EvaluatingExperiments: Ineligible Cart User in Offset Experiment Control Group", {
                        shopDomain: t.shopDomain,
                        state: t
                    }), o = { ...o,
                        step: _.Excluded,
                        offerStatus: F.ExcludedReturnCoverageOptimization,
                        showUI: !1,
                        experimentGroup: oe.Control
                    }, n(o);
                    return
                }
                c && c.group === oe.Treatment ? o = { ...o,
                    step: _.AnalyzingAttributes,
                    experimentGroup: oe.Treatment
                } : o = { ...o,
                    step: _.AnalyzingAttributes,
                    showUI: !1,
                    experimentGroup: (c == null ? void 0 : c.group) || oe.Excluded
                }, n(o)
            }
            l()
        }, []), w.jsx(w.Fragment, {})
    }

    function vm({
        cartLines: e,
        locationProvider: t,
        cartTotal: n,
        publishCartChangedEvent: r,
        addOnStoreListener: o,
        removeOnStoreListener: i,
        deliveryGroups: a
    }) {
        const [l, s] = k.useContext(X), {
            listenForCartLineChanges: u,
            listenForDeliveryGroupChanges: c,
            listenForLocalizationChanges: f,
            cartLineChangeAction: d
        } = l, h = e.reduce((E, v) => E + `${v.cartLineId}-${v.quantity}`, "");
        let y, m = "";
        return k.useEffect(() => {
            u && s({ ...y,
                step: _.CalculateEligibility,
                listenForCartLineChanges: !1,
                listenForLocalizationChanges: !1
            })
        }, [h, n(), m]), k.useEffect(() => {
            f && s({ ...y,
                step: _.Initialization,
                listenForCartLineChanges: !1,
                listenForLocalizationChanges: !1
            })
        }, [t.getCountry()]), k.useEffect(() => {
            c && s({ ...y,
                step: _.CalculateEligibility,
                offerStatus: F.Unknown,
                listenForCartLineChanges: !1,
                listenForLocalizationChanges: !1
            })
        }, [a.length]), k.useEffect(() => {
            ee("Offset#Listen Mounted", {
                state: l
            });
            async function E() {
                if (m = await t.getRegion(), d && (y = { ...y,
                        cartLineChangeAction: null
                    }, r({
                        action: d
                    })), l.redirectToCheckout) {
                    window.location.href = "/checkout";
                    return
                }
                ee("Offset#Listen - listening..."), y = { ...y,
                    listenForCartLineChanges: !0,
                    listenForLocalizationChanges: !0,
                    listenForDeliveryGroupChanges: !0
                }, s(y)
            }
            return E(), o(), () => i()
        }, []), w.jsx(w.Fragment, {})
    }
    const gm = new Map([
            ["AED", 2],
            ["AFN", 2],
            ["ALL", 2],
            ["AMD", 2],
            ["ANG", 2],
            ["AOA", 2],
            ["ARS", 2],
            ["AUD", 2],
            ["AWG", 2],
            ["AZN", 2],
            ["BAM", 2],
            ["BBD", 2],
            ["BDT", 2],
            ["BGN", 2],
            ["BHD", 3],
            ["BIF", 0],
            ["BMD", 2],
            ["BND", 2],
            ["BOB", 2],
            ["BRL", 2],
            ["BSD", 2],
            ["BTN", 2],
            ["BWP", 2],
            ["BYN", 2],
            ["BYR", 0],
            ["BZD", 2],
            ["CAD", 2],
            ["CDF", 2],
            ["CHF", 2],
            ["CLF", 4],
            ["CLP", 0],
            ["CNY", 2],
            ["COP", 2],
            ["CRC", 2],
            ["CUC", 2],
            ["CUP", 2],
            ["CVE", 2],
            ["CZK", 2],
            ["DJF", 0],
            ["DKK", 2],
            ["DOP", 2],
            ["DZD", 2],
            ["EGP", 2],
            ["ERN", 2],
            ["ETB", 2],
            ["EUR", 2],
            ["FJD", 2],
            ["FKP", 2],
            ["GBP", 2],
            ["GEL", 2],
            ["GHS", 2],
            ["GIP", 2],
            ["GMD", 2],
            ["GNF", 0],
            ["GTQ", 2],
            ["GYD", 2],
            ["HKD", 2],
            ["HNL", 2],
            ["HRK", 2],
            ["HTG", 2],
            ["HUF", 0],
            ["IDR", 2],
            ["ILS", 2],
            ["INR", 2],
            ["IQD", 3],
            ["IRR", 2],
            ["ISK", 0],
            ["JMD", 2],
            ["JOD", 3],
            ["JPY", 0],
            ["KES", 2],
            ["KGS", 2],
            ["KHR", 2],
            ["KMF", 0],
            ["KPW", 2],
            ["KRW", 0],
            ["KWD", 3],
            ["KYD", 2],
            ["KZT", 2],
            ["LAK", 2],
            ["LBP", 2],
            ["LKR", 2],
            ["LRD", 2],
            ["LSL", 2],
            ["LTL", 2],
            ["LVL", 2],
            ["LYD", 3],
            ["MAD", 2],
            ["MDL", 2],
            ["MGA", 5],
            ["MKD", 2],
            ["MMK", 2],
            ["MNT", 2],
            ["MOP", 2],
            ["MRO", 5],
            ["MUR", 2],
            ["MVR", 2],
            ["MWK", 2],
            ["MXN", 2],
            ["MYR", 2],
            ["MZN", 2],
            ["NAD", 2],
            ["NGN", 2],
            ["NIO", 2],
            ["NOK", 2],
            ["NPR", 2],
            ["NZD", 2],
            ["OMR", 3],
            ["PAB", 2],
            ["PEN", 2],
            ["PGK", 2],
            ["PHP", 2],
            ["PKR", 2],
            ["PLN", 2],
            ["PYG", 0],
            ["QAR", 2],
            ["RON", 2],
            ["RSD", 2],
            ["RUB", 2],
            ["RWF", 0],
            ["SAR", 2],
            ["SBD", 2],
            ["SCR", 2],
            ["SDG", 2],
            ["SEK", 2],
            ["SGD", 2],
            ["SHP", 2],
            ["SKK", 2],
            ["SLL", 2],
            ["SOS", 2],
            ["SRD", 2],
            ["SSP", 2],
            ["STD", 2],
            ["SVC", 2],
            ["SYP", 2],
            ["SZL", 2],
            ["THB", 2],
            ["TJS", 2],
            ["TMT", 2],
            ["TND", 3],
            ["TOP", 2],
            ["TRY", 2],
            ["TTD", 2],
            ["TWD", 2],
            ["TZS", 2],
            ["UAH", 2],
            ["UGX", 0],
            ["USD", 2],
            ["UYU", 2],
            ["UZS", 2],
            ["VEF", 2],
            ["VND", 0],
            ["VUV", 0],
            ["WST", 2],
            ["XAF", 0],
            ["XAG", 0],
            ["XAU", 0],
            ["XBA", 0],
            ["XBB", 0],
            ["XBC", 0],
            ["XBD", 0],
            ["XCD", 2],
            ["XDR", 0],
            ["XOF", 0],
            ["XPD", 0],
            ["XPF", 0],
            ["XPT", 0],
            ["XTS", 0],
            ["YER", 2],
            ["ZAR", 2],
            ["ZMK", 2],
            ["ZMW", 2]
        ]),
        hm = (e = 0) => +"1".padEnd(e + 1, "0"),
        Yt = (e, t = "USD", n = navigator.language) => {
            const r = gm.get(t),
                o = hm(r);
            return e !== void 0 && o ? new Intl.NumberFormat([n, "en-US"], {
                style: "currency",
                currency: t
            }).format(e / o) : ""
        },
        mm = (e, t) => {
            let n;
            return (...o) => {
                clearTimeout(n), n = setTimeout(() => e(...o), t)
            }
        },
        uo = (e, t) => (e == null ? void 0 : e.replace(/{{\s*(\w+)\s*}}/g, (n, r) => t[r] || "")) || "";

    function ym({
        openOverlay: e,
        offerStatus: t,
        product: n,
        translations: r
    }) {
        const [o, i] = k.useContext(X);
        let a;
        const l = () => {
                if (t !== F.Accepted) {
                    R("Accepting OfferStatus"), a = { ...a,
                        step: _.Accepted
                    }, i(a);
                    return
                }
                R("Rejecting OfferStatus"), a = { ...a,
                    step: _.Rejected
                }, i(a)
            },
            s = mm(() => l(), 300),
            u = () => ({
                Offset: uo(r == null ? void 0 : r.en.cart.title, {
                    formatted_price: Yt(n == null ? void 0 : n.price)
                }),
                OffsetShippingProtection: "Free Returns + Package Protection",
                ShippingProtection: "Package Protection"
            })[o.mode],
            c = () => ({
                Offset: uo(r == null ? void 0 : r.en.cart.caption, {
                    formatted_price: Yt(n == null ? void 0 : n.price)
                }),
                OffsetShippingProtection: "Avoid return handling fees and get coverage for items lost or damaged in transit.",
                ShippingProtection: "Package Protection"
            })[o.mode];
        return w.jsx("div", {
            className: "loop-return-coverage-block offset-cart-offer-container",
            children: w.jsx("section", {
                className: "loop-return-coverage",
                children: w.jsxs("div", {
                    className: "loop-return-coverage__product ",
                    children: [w.jsx("input", {
                        className: "loop-return-coverage__checkbox",
                        type: "checkbox",
                        onChange: s,
                        checked: t === F.Accepted
                    }), w.jsxs("div", {
                        children: [w.jsx("p", {
                            className: "loop-return-coverage__title",
                            children: u()
                        }), w.jsxs("p", {
                            className: "loop-return-coverage__caption",
                            children: [w.jsx("span", {
                                children: c()
                            }), w.jsx("span", {
                                children: " "
                            }), w.jsx("span", {
                                className: "loop-return-coverage__link",
                                onClick: e,
                                children: "What's this?"
                            })]
                        })]
                    }), w.jsx("div", {
                        children: w.jsx("p", {
                            children: Yt(n == null ? void 0 : n.price)
                        })
                    })]
                })
            })
        })
    }
    const wm = "data:image/svg+xml,%3csvg%20width='20'%20height='20'%20viewBox='0%200%2020%2020'%20fill='none'%20xmlns='http://www.w3.org/2000/svg'%3e%3cg%20id='info'%20clip-path='url(%23clip0_5852_2892)'%3e%3cpath%20id='Vector'%20d='M9.99984%2018.3332C14.6022%2018.3332%2018.3332%2014.6022%2018.3332%209.99984C18.3332%205.39746%2014.6022%201.6665%209.99984%201.6665C5.39746%201.6665%201.6665%205.39746%201.6665%209.99984C1.6665%2014.6022%205.39746%2018.3332%209.99984%2018.3332Z'%20stroke='%23111111'%20stroke-width='2'%20stroke-linecap='round'%20stroke-linejoin='round'/%3e%3cpath%20id='Vector_2'%20d='M10%2013.3333V10'%20stroke='%23111111'%20stroke-width='2'%20stroke-linecap='round'%20stroke-linejoin='round'/%3e%3cpath%20id='Vector_3'%20d='M10%206.6665H10.0083'%20stroke='%23111111'%20stroke-width='2'%20stroke-linecap='round'%20stroke-linejoin='round'/%3e%3c/g%3e%3cdefs%3e%3cclipPath%20id='clip0_5852_2892'%3e%3crect%20width='20'%20height='20'%20fill='white'/%3e%3c/clipPath%3e%3c/defs%3e%3c/svg%3e";

    function Cm({
        openOverlay: e,
        product: t,
        cartTotal: n,
        showUI: r
    }) {
        const [o, i] = k.useContext(X);
        let a;
        if (k.useEffect(() => {
                var h, y, m, E;
                if (r) {
                    (h = document.querySelector("#offset-cart-ui-offer > :not(.loop-return-coverage-block)")) == null || h.classList.add("loop-hidden"), (y = document.querySelector("#offset-cart-drawer-ui-offer > :not(.loop-return-coverage-block)")) == null || y.classList.add("loop-hidden");
                    return
                }(m = document.querySelector("#offset-cart-ui-offer > :not(.loop-return-coverage-block)")) == null || m.classList.remove("loop-hidden"), (E = document.querySelector("#offset-cart-drawer-ui-offer > :not(.loop-return-coverage-block)")) == null || E.classList.remove("loop-hidden")
            }, [r]), !r) return w.jsx(w.Fragment, {});
        const l = () => {
                if (o.cartLineId) {
                    window.location.href = "/checkout";
                    return
                }
                i({ ...a,
                    step: _.Accepted,
                    redirectToCheckout: !0
                })
            },
            s = () => {
                const h = (t == null ? void 0 : t.price) || 0;
                return o.cartLineId ? n() : n() + h
            },
            u = () => {
                if (o.cartLineId) {
                    i({ ...a,
                        step: _.Rejected,
                        redirectToCheckout: !0
                    });
                    return
                }
                i({ ...a,
                    step: _.UpdateAttributes,
                    redirectToCheckout: !0
                })
            },
            c = () => ({
                Offset: "Checkout +",
                OffsetShippingProtection: "Checkout+<br>with package protection",
                ShippingProtection: "Package Protection"
            })[o.mode],
            f = () => ({
                Offset: "Continue without free returns",
                OffsetShippingProtection: "Continue without coverage",
                ShippingProtection: ""
            })[o.mode],
            d = () => ({
                Offset: "Unlock free returns",
                OffsetShippingProtection: "Avoid return handling fees and get coverage for items lost or damaged in transit.",
                ShippingProtection: "Package Protection"
            })[o.mode];
        return w.jsx("div", {
            className: "loop-return-coverage-block offset-cart-offer-container",
            children: w.jsxs("section", {
                className: "loop-return-coverage-ace",
                children: [w.jsxs("div", {
                    className: "loop-return-coverage__product",
                    children: [w.jsxs("div", {
                        children: [w.jsx("p", {
                            className: "loop-return-coverage__title",
                            dangerouslySetInnerHTML: {
                                __html: c()
                            }
                        }), w.jsx("img", {
                            src: wm,
                            className: "loop-return-coverage__info",
                            alt: c(),
                            onClick: e
                        }), w.jsxs("p", {
                            className: "loop-return-coverage__caption",
                            children: [w.jsx("span", {
                                children: d()
                            }), w.jsx("span", {
                                children: " "
                            }), o.mode !== "Offset" && w.jsx("span", {
                                className: "loop-return-coverage__link",
                                onClick: e,
                                children: "What's this?"
                            })]
                        })]
                    }), w.jsx("div", {
                        children: w.jsx("p", {
                            children: Yt(t == null ? void 0 : t.price)
                        })
                    })]
                }), w.jsx("div", {
                    className: "loop-return-coverage__button",
                    children: w.jsxs("button", {
                        type: "button",
                        className: "loop-return-coverage__cta__plus",
                        onClick: l,
                        children: ["Checkout + |", " ", Yt(s())]
                    })
                }), w.jsx("div", {
                    className: "loop-return-coverage__button",
                    children: w.jsx("button", {
                        type: "button",
                        className: "loop-return-coverage__cta__standard",
                        onClick: u,
                        children: f()
                    })
                })]
            })
        })
    }

    function _s({
        openOverlay: e,
        translations: t,
        cartTotal: n,
        showUI: r
    }) {
        const [o] = k.useContext(X), {
            config: i,
            offerStatus: a,
            product: l
        } = o, s = sessionStorage.getItem("forceAce") === "true";
        return w.jsxs(w.Fragment, {
            children: [!(i != null && i.returnCoverageAlternateCartExperience) && r && !s && w.jsx(ym, {
                openOverlay: e,
                offerStatus: a,
                translations: t,
                product: l
            }), ((i == null ? void 0 : i.returnCoverageAlternateCartExperience) || s) && w.jsx(Cm, {
                openOverlay: e,
                product: l,
                cartTotal: n,
                showUI: r
            })]
        })
    }
    const Sm = "data:image/svg+xml,%3csvg%20width='37'%20height='30'%20viewBox='0%200%2037%2030'%20fill='none'%20xmlns='http://www.w3.org/2000/svg'%3e%3cpath%20d='M2.17122%2012.8579H1.60336C0.714832%2012.8579%200%2012.1415%200%2011.251V2.68076C0%202.0313%200.387479%201.4421%200.98874%201.19437C1.59%200.946635%202.27811%201.08054%202.73908%201.54253L5.51824%204.32785C11.3705%20-1.46374%2020.7969%20-1.44365%2026.6158%204.39481C32.4614%2010.2534%2032.4614%2019.7475%2026.6158%2025.6061C20.7702%2031.4646%2011.297%2031.4646%205.45143%2025.6061C4.61635%2024.7692%204.61635%2023.41%205.45143%2022.573C6.28651%2021.7361%207.64269%2021.7361%208.47778%2022.573C12.6532%2026.7577%2019.4207%2026.7577%2023.5961%2022.573C27.7716%2018.3884%2027.7716%2011.6058%2023.5961%207.42116C19.4408%203.25658%2012.7267%203.23649%208.54458%207.35421L11.2903%2010.1127C11.7513%2010.5747%2011.8849%2011.2644%2011.6377%2011.867C11.3906%2012.4696%2010.8027%2012.8579%2010.1546%2012.8579H2.17122Z'%20fill='%2325272C'/%3e%3cg%20clip-path='url(%23clip0_27_1726)'%3e%3cpath%20d='M29%2028.8223C29%2028.8223%2035%2025.6223%2035%2020.8223V15.2223L29%2012.8223L23%2015.2223V20.8223C23%2025.6223%2029%2028.8223%2029%2028.8223Z'%20fill='white'%20stroke='%2325272C'%20stroke-width='2'%20stroke-linecap='round'%20stroke-linejoin='round'/%3e%3c/g%3e%3cdefs%3e%3cclipPath%20id='clip0_27_1726'%3e%3crect%20width='36'%20height='30'%20fill='white'%20transform='translate(1)'/%3e%3c/clipPath%3e%3c/defs%3e%3c/svg%3e",
        xm = ({
            body: e,
            replacements: t
        }) => w.jsx(w.Fragment, {
            children: e.map(n => {
                if (n.content) return w.jsx("p", {
                    children: n.content.map(r => r.marks ? r.marks.reduce((o, i) => {
                        switch (i.type) {
                            case "italic":
                                o = w.jsx("i", {
                                    children: o
                                });
                                break;
                            case "bold":
                                o = w.jsx("b", {
                                    children: o
                                });
                                break;
                            case "link":
                                o = w.jsx("a", {
                                    href: i.attrs.href,
                                    target: i.attrs.target,
                                    children: o
                                });
                                break
                        }
                        return o
                    }, uo(r.text, t)) : uo(r.text, t))
                }, n.content[0].text)
            })
        });

    function Em({
        closeOverlay: e,
        translations: t
    }) {
        const [n] = k.useContext(X), {
            config: r,
            product: o
        } = n, i = {
            formatted_price: Yt(o == null ? void 0 : o.price),
            fee_price: Yt(r == null ? void 0 : r.refundHandlingFee)
        };
        return w.jsxs("div", {
            className: "container",
            children: [w.jsx("div", {
                className: "close-container",
                children: w.jsx("span", {
                    className: "close-target",
                    onClick: e,
                    children: "×"
                })
            }), w.jsx("span", {
                className: "loop-return-coverage__logo",
                children: w.jsx("img", {
                    src: Sm,
                    className: "logo",
                    alt: "Returns Coverage"
                })
            }), w.jsx("h1", {
                children: uo(t == null ? void 0 : t.en.learnMore.title, i)
            }), w.jsx(xm, {
                body: (t == null ? void 0 : t.en.learnMore.body) || [],
                replacements: i
            })]
        })
    }

    function km({
        closeOverlay: e
    }) {
        const [t] = k.useContext(X), n = t.product;
        return w.jsxs("div", {
            className: "container container-shipping-protection",
            children: [w.jsx("div", {
                className: "close-container",
                children: w.jsx("span", {
                    className: "modal-icon-wrapper",
                    onClick: e,
                    style: {
                        width: "18px"
                    },
                    children: w.jsx("svg", {
                        xmlns: "http://www.w3.org/2000/svg",
                        viewBox: "0 0 14 14",
                        focusable: "false",
                        "aria-hidden": "true",
                        className: "modal-icon",
                        children: w.jsx("path", {
                            "stroke-linecap": "round",
                            d: "M2.8 2.8 7 7m4.2 4.2L7 7m0 0 4.2-4.2M7 7l-4.2 4.2"
                        })
                    })
                })
            }), w.jsx("h5", {
                children: "Free Returns + Package Protection"
            }), w.jsx("p", {
                children: "Shop with peace of mind knowing that all eligible items in your order are protected against return fees, and covered if they are lost, stolen, or damaged in transit."
            }), w.jsxs("div", {
                className: "modal-media",
                children: [w.jsx("div", {
                    className: "modal-media-image",
                    children: w.jsx("span", {
                        className: "modal-icon-wrapper",
                        style: {
                            width: "24px"
                        },
                        children: w.jsxs("svg", {
                            xmlns: "http://www.w3.org/2000/svg",
                            viewBox: "0 0 14 14",
                            focusable: "false",
                            "aria-hidden": "true",
                            className: "modal-icon",
                            children: [w.jsx("path", {
                                "stroke-linecap": "round",
                                d: "M11.2 7a4.2 4.2 0 0 1-7.17 2.97M2.8 7a4.2 4.2 0 0 1 7.171-2.969"
                            }), w.jsx("path", {
                                "stroke-linecap": "round",
                                d: "m9.78 7.5 1.337-1.423a.1.1 0 0 1 .145 0L12.6 7.5M1.4 6.9l1.338 1.423a.1.1 0 0 0 .145 0L4.221 6.9"
                            })]
                        })
                    })
                }), w.jsxs("div", {
                    className: "modal-media-content",
                    children: [w.jsx("p", {
                        children: w.jsx("strong", {
                            children: "Free returns and exchanges"
                        })
                    }), w.jsx("p", {
                        children: "Return or exchange your items without any extra hidden fees, like handling fees or restocking fees."
                    })]
                })]
            }), w.jsxs("div", {
                className: "modal-media",
                children: [w.jsx("div", {
                    className: "modal-media-image",
                    children: w.jsx("span", {
                        className: "modal-icon-wrapper",
                        style: {
                            width: "24px"
                        },
                        children: w.jsx("svg", {
                            xmlns: "http://www.w3.org/2000/svg",
                            viewBox: "0 0 14 14",
                            focusable: "false",
                            "aria-hidden": "true",
                            className: "modal-icon",
                            children: w.jsx("path", {
                                "stroke-linecap": "round",
                                "stroke-linejoin": "round",
                                d: "M3 10.5h-.9a.7.7 0 0 1-.7-.7V3.5a.7.7 0 0 1 .7-.7h4.2a.7.7 0 0 1 .7.7v.7m-4 6.3a1.2 1.2 0 0 0 2.4 0m-2.4 0a1.2 1.2 0 0 1 2.4 0M7 7v3.5M7 7V4.2M7 7h5.6M7 10.5H5.4m1.6 0h1.6M7 4.2h2.51a.7.7 0 0 1 .495.205L12.6 7m-4 3.5a1.2 1.2 0 0 0 2.4 0m-2.4 0a1.2 1.2 0 0 1 2.4 0m0 0h.9a.7.7 0 0 0 .7-.7V7"
                            })
                        })
                    })
                }), w.jsxs("div", {
                    className: "modal-media-content",
                    children: [w.jsx("p", {
                        children: w.jsx("strong", {
                            children: "Package Protection"
                        })
                    }), w.jsx("p", {
                        children: "Simply get a refund when you report your package as lost, stolen, or damaged in transit within 7 days of its scheduled delivery."
                    })]
                })]
            }), w.jsx("hr", {}), w.jsxs("p", {
                className: "modal-terms",
                children: ["Some items may not be eligible for this service, such as items that are final sale. By opting out of this service you will be responsible for any return costs such as shipping labels, handling fees, or restocking fees. Additionally, your package won’t be protected if it is lost, stolen, or damaged in transit. The price of this service includes a", " ", Yt(n == null ? void 0 : n.configuredPrice), " ", "flat fee, plus 2% of the cart total. In certain states, sales tax may also be included in the total. For more information, please read the Package Protection", " ", w.jsx("a", {
                    href: "https://www.seel.com/terms/seel-worry-free-delivery-terms-and-conditions",
                    target: "_blank",
                    children: "Terms and Conditions"
                }), "."]
            })]
        })
    }
    const Om = e => {
            const [t, n] = k.useState({
                attributes: [],
                items: [],
                item_count: 0,
                total_price: 0,
                currency: "USD"
            }), [r, o] = k.useState([]), [i, a] = k.useState(0), [l, s] = k.useState([]), u = r.reduce((m, E) => m + `${E.id}-${E.quantity}`, ""), c = async () => {
                const m = await e.cartGet();
                return n(m), R("useCart#fetchCart: ", {
                    fetchedCart: m
                }), o(m.items), a(m.items.length), s(m.attributes), m
            }, f = k.useCallback(async m => {
                const E = parseInt(m || "");
                R("useCart#addReturnCoverage - adding ReturnCoverage product to cart", {
                    variantId: E
                });
                try {
                    const v = await e.cartAdd({
                        items: [{
                            id: E,
                            quantity: 1
                        }]
                    });
                    return R("useCart#addReturnCoverage - adding ReturnCoverage product to cart response: ", {
                        response: v
                    }), v.hasOwnProperty("items") ? {
                        type: "success"
                    } : {
                        type: "error",
                        message: JSON.stringify(v)
                    }
                } catch (v) {
                    return {
                        type: "error",
                        message: JSON.stringify(v == null ? void 0 : v.message)
                    }
                }
            }, [e]), d = k.useCallback(async (m, E) => {
                R("useCart#removeReturnCoverage - removing returns coverage product from cart", {
                    cartLines: r
                });
                const v = r.find(p => p.id === parseInt(m));
                if (!v) return R("useCart#removeReturnCoverage - could not find the returns coverage variant in the cart to remove"), {
                    type: "error"
                };
                try {
                    const p = await e.cartRemoveItem({
                        id: v.id,
                        key: v.key,
                        quantity: E
                    });
                    return R("useCart#removeReturnCoverage - removing returns coverage product from cart response: ", {
                        response: p
                    }), p.hasOwnProperty("items") ? {
                        type: "success"
                    } : {
                        type: "error",
                        message: JSON.stringify(p)
                    }
                } catch (p) {
                    return {
                        type: "error",
                        message: JSON.stringify(p == null ? void 0 : p.message)
                    }
                }
            }, [e, u]), h = async m => {
                const E = await e.cartChange({
                    id: m,
                    quantity: 1
                });
                return R("useCart#setProductQuantityInCart response: ", {
                    response: E
                }), {
                    type: "success"
                }
            }, y = k.useCallback(async (m, E) => {
                R("useCart#updateCartAttributes: ", {
                    key: m,
                    value: E
                });
                try {
                    const v = await e.updateCartAttributes(m, E);
                    return R("useCart#updateCartAttributes response: ", {
                        response: v
                    }), {
                        type: "success"
                    }
                } catch (v) {
                    return R("useCart#updateCartAttributes error: ", {
                        error: v
                    }), {
                        type: "error",
                        message: JSON.stringify(v == null ? void 0 : v.message)
                    }
                }
            }, [e]);
            return {
                cart: t,
                cartLines: r,
                cartLinesCount: i,
                cartAttributes: l,
                fetchCart: c,
                addReturnCoverage: f,
                removeReturnCoverage: d,
                setProductQuantityInCart: h,
                updateCartAttributes: y
            }
        },
        Lm = e => ({
            resolveProduct: k.useCallback(async n => {
                const r = n.shippingProtectionEnabled ? n.shippingProtectionAndReturnCoverageProductHandle ? ? "free-returns-purchase-protection" : n.returnCoverageProductHandle ? ? "pay-now-to-unlock-free-returns-later";
                try {
                    const o = await e.productGet(r);
                    if (R("Requested Product: ", o), o && o.variants && o.variants.length > 0) {
                        let i = o.variants.map(l => ({
                            id: `${l.id}`,
                            price: l.price,
                            currencyCode: "USD"
                        }));
                        return {
                            type: "success",
                            product: {
                                id: `${o.id}`,
                                slug: o.handle,
                                image: o.featured_image || "",
                                variants: i
                            }
                        }
                    }
                    return {
                        type: "error",
                        message: JSON.stringify(o)
                    }
                } catch (o) {
                    return {
                        type: "error",
                        message: JSON.stringify(o == null ? void 0 : o.message)
                    }
                }
            }, [e])
        }),
        Pm = async (e, t, n, r) => {
            if (R("running return coverage excluded check", {
                    cartLines: e,
                    product: r
                }), e.length === 0) return !0;
            const o = sessionStorage.getItem("offset-cached-products") ? JSON.parse(sessionStorage.getItem("offset-cached-products") ? ? "") : [],
                i = o.map(d => `${d.id}`),
                a = e.filter(d => !i.includes(`${d.productId}`)),
                l = await Im(a, t, n),
                s = [...o, ...l];
            sessionStorage.setItem("offset-cached-products", JSON.stringify(s));
            const c = e.filter(d => `${d.productId}` !== (r == null ? void 0 : r.id)).map(d => {
                    const h = s.find(y => d.productId === `${y.id}`);
                    return h && h.isExcluded
                }),
                f = t != null && t.shippingProtectionEnabled ? c.includes(!0) : !c.includes(!1);
            return R("is excluded:", f), f
        },
        Im = (e, t, n) => Promise.all(e.map(async r => {
            const o = await n.productGet(r.handle ? ? "");
            return {
                id: o.id,
                tags: o.tags,
                handle: o.handle,
                isExcluded: Nm(o.tags, t)
            }
        })),
        Nm = (e, t) => e.reduce((n, r) => n ? !0 : t == null ? void 0 : t.excludedProductTags.includes(r.toLowerCase()), !1),
        _m = (e, t, n, r) => {
            const o = e.reduce((a, l) => a + l.cartLineId, "");
            return {
                resolveIsCartEligible: k.useCallback(async a => !await Pm(a, t, n, r), [o, t, n, r])
            }
        };

    function Rm(e) {
        e(), new PerformanceObserver(n => {
            for (const r of n.getEntries())(r.initiatorType === "fetch" || r.initiatorType === "xmlhttprequest") && (r.name.includes("/cart/add") || r.name.includes("/cart/change") || r.name.includes("/cart/update")) && !r.name.includes(`?${ir.auto}`) && e()
        }).observe({
            entryTypes: ["resource"]
        })
    }

    function Mm(e, t, n, r) {
        function o() {
            e()
        }
        document.addEventListener(ar.RefreshCart, o);
        let i = null,
            a = null;
        return t.elementToWatchForCartUpdates && (a = document.querySelector(t.elementToWatchForCartUpdates)), a ? (i = new MutationObserver(l => {
            const s = l[0].target;
            s.isEqualNode(n) || s.isEqualNode(r) || document.dispatchEvent(new CustomEvent("loop.refreshCart"))
        }), i.observe(a, {
            childList: !0,
            subtree: !0
        }), R(`set up MutationObserver on ${a}`, {
            observer: i
        })) : R("Did not setup MutationObserver because no element found"), e(), () => {
            document.removeEventListener(ar.RefreshCart, o), R(`tearing down MutationObserver on ${a}`, {
                observer: i
            }), i == null || i.disconnect()
        }
    }

    function Dm(e) {
        var t, n, r, o;
        if (R("Triggering cart updates in the theme", e), typeof window.theme == "object" && typeof window.theme.AjaxCart == "object" && typeof window.theme.AjaxCart.fetch == "function" && window.theme.AjaxCart.fetch(), typeof window.ajaxCart == "object" && typeof window.ajaxCart.load == "function" && window.ajaxCart.load(), typeof window.cart == "object" && typeof window.cart.getCart == "function" && window.cart.getCart(), typeof window.MinimogEvents == "object" && typeof window.MinimogEvents.emit == "function" && window.MinimogEvents.emit(window.MinimogTheme.pubSubEvents.cartUpdate, {
                source: "loop"
            }), typeof window.eventBus == "object" && typeof window.eventBus.emit == "function" && (window.eventBus.emit("update:cart:drawer"), window.eventBus.emit("render:cart:drawer")), typeof window.wetheme == "object" && typeof window.wetheme.updateCartDrawer == "function" && window.wetheme.updateCartDrawer(e), typeof window.Shopify == "object" && typeof((n = (t = window.Shopify) == null ? void 0 : t.theme) == null ? void 0 : n.cart) == "object" && typeof((o = (r = window.Shopify) == null ? void 0 : r.theme) == null ? void 0 : o.ajaxCart) == "object") {
            let i = document.getElementById("cart-config");
            i = JSON.parse((i == null ? void 0 : i.innerHTML) || "{}"), i && window.Shopify.theme.cart.getCart().then(a => {
                window.Shopify.theme.ajaxCart.updateView(i, a)
            })
        }
        typeof window.publish == "function" && window.publish("cart-update", {
            source: "loop"
        }), typeof window.refreshCart == "function" && window.refreshCart(), typeof window.openCartDrawer == "function" && window.openCartDrawer(), typeof window.cartPageUpdate == "function" && window.cartPageUpdate(), typeof window.Alpine == "object" && window.Alpine.store("xMiniCart").reLoad(), typeof window.refreshMiniCart == "function" && window.location.pathname !== "/cart" && window.refreshMiniCart(e), typeof window.refreshCartPage == "function" && window.location.pathname === "/cart" && window.refreshCartPage(e), jm.forEach(i => {
            document.documentElement.dispatchEvent(new CustomEvent(i, {
                bubbles: !0,
                cancelable: !1
            }))
        }), zm.forEach(i => {
            document.dispatchEvent(new CustomEvent(i, {
                bubbles: !0,
                cancelable: !1
            }))
        })
    }
    const jm = ["cart:refresh", "theme:cartchanged"],
        zm = ["cart:build", "apps:product-added-to-cart", "dispatch:cart-drawer:refresh"],
        Fm = {
            name: "consent-tracking-api",
            version: "0.1"
        },
        Wd = () => {
            const e = async () => {
                var r;
                await ((r = window == null ? void 0 : window.Shopify) == null ? void 0 : r.loadFeatures([Fm], o => {
                    o && R("CartCustomerPrivacy#loadCustomerPrivacyFeature: Failed to load feature", o)
                }))
            };
            return {
                analyticsProcessingAllowed: async () => {
                    var r, o, i, a, l;
                    return (r = window == null ? void 0 : window.Shopify) != null && r.customerPrivacy || await e(), R("customerPrivacyApi#analyticsAllowed:", {
                        result: (i = (o = window == null ? void 0 : window.Shopify) == null ? void 0 : o.customerPrivacy) == null ? void 0 : i.analyticsProcessingAllowed()
                    }), ((l = (a = window == null ? void 0 : window.Shopify) == null ? void 0 : a.customerPrivacy) == null ? void 0 : l.analyticsProcessingAllowed()) ? ? !1
                },
                getRegion: async () => {
                    var r, o, i, a, l;
                    return (r = window == null ? void 0 : window.Shopify) != null && r.customerPrivacy || await e(), R("customerPrivacyApi#getRegion:", {
                        result: (i = (o = window == null ? void 0 : window.Shopify) == null ? void 0 : o.customerPrivacy) == null ? void 0 : i.getRegion()
                    }), ((l = (a = window == null ? void 0 : window.Shopify) == null ? void 0 : a.customerPrivacy) == null ? void 0 : l.getRegion()) ? ? ""
                }
            }
        };

    function Tm({
        resolveProduct: e,
        fireReady: t
    }) {
        const [n, r] = k.useContext(X), o = k.useContext(Ge);
        let i;
        return k.useEffect(() => {
            ee("Offset#ResolveProduct Mounted", {
                state: n
            });
            async function a() {
                const l = await Hd(e, n.shopDomain, n, n.config, o, 1, 1, 300);
                if (l.type === "success" && l.product) {
                    o.info("Offset#ResolveProduct:Product - Product resolved", {
                        shopDomain: n.shopDomain,
                        resolvedProduct: l
                    }), i = { ...i,
                        resolvedProduct: l.product
                    };
                    const s = t();
                    o.info("Offset#ResolveProduct:Timing", {
                        shopDomain: n.shopDomain,
                        timings: s
                    }), i = { ...i,
                        step: _.AssignExperiments
                    }, r(i);
                    return
                }
                l.type === "error" && l.message && JSON.parse(l.message) !== Dd.product404 && o.error("Offset#initialize:Product - Failed to resolve Return Coverage Product", {
                    shopDomain: n.shopDomain,
                    state: n,
                    errorMessage: l.message
                }), i = { ...i,
                    step: _.Error
                }, r(i)
            }
            a()
        }, []), w.jsx(w.Fragment, {})
    }
    var Kd = (e => (e[e.AZ = 0] = "AZ", e[e.DE = 0] = "DE", e[e.FL = 0] = "FL", e[e.ID = 0] = "ID", e[e.KS = 0] = "KS", e[e.MI = 0] = "MI", e[e.MT = 0] = "MT", e[e.NH = 0] = "NH", e[e.OR = 0] = "OR", e[e.UT = 0] = "UT", e[e.WY = 0] = "WY", e[e.AL = .09289] = "AL", e[e.AK = .01821] = "AK", e[e.AR = .09469] = "AR", e[e.CA = .08802] = "CA", e[e.CO = .07807] = "CO", e[e.CT = .0635] = "CT", e[e.GA = .07423] = "GA", e[e.HI = .045] = "HI", e[e.IL = .08871] = "IL", e[e.IN = .07] = "IN", e[e.IA = .06943] = "IA", e[e.KY = .06] = "KY", e[e.LA = .09565] = "LA", e[e.ME = .055] = "ME", e[e.MD = .06] = "MD", e[e.MA = .0625] = "MA", e[e.MN = .08123] = "MN", e[e.MS = .07062] = "MS", e[e.MO = .08386] = "MO", e[e.NE = .06969] = "NE", e[e.NV = .08236] = "NV", e[e.NJ = .06601] = "NJ", e[e.NM = .07626] = "NM", e[e.NY = .08532] = "NY", e[e.NC = .06996] = "NC", e[e.ND = .07044] = "ND", e[e.OH = .07238] = "OH", e[e.OK = .09003] = "OK", e[e.PA = .06431] = "PA", e[e.RI = .07] = "RI", e[e.SC = .07499] = "SC", e[e.SD = .06111] = "SD", e[e.TN = .09556] = "TN", e[e.TX = .082] = "TX", e[e.VT = .06372] = "VT", e[e.VA = .05771] = "VA", e[e.WA = .09452] = "WA", e[e.WV = .06569] = "WV", e[e.WI = .05696] = "WI", e[e.DC = .06] = "DC", e))(Kd || {}),
        Qd = (e => (e[e.AB = .05] = "AB", e[e.BC = .05] = "BC", e[e.MB = .05] = "MB", e[e.NB = .15] = "NB", e[e.NL = .15] = "NL", e[e.NT = .05] = "NT", e[e.NS = .15] = "NS", e[e.NU = .05] = "NU", e[e.ON = .13] = "ON", e[e.PE = .15] = "PE", e[e.QC = .05] = "QC", e[e.SK = .05] = "SK", e[e.YT = .05] = "YT", e))(Qd || {}),
        Yd = (e => (e[e.AU = .1] = "AU", e[e.FR = .2] = "FR", e[e.DE = .19] = "DE", e[e.NL = .21] = "NL", e[e.GB = .2] = "GB", e[e.NZ = .15] = "NZ", e))(Yd || {});
    const bm = e => {
            const {
                country: t,
                territory: n
            } = Am(e);
            return t === "US" ? Kd[n] : t === "CA" ? Qd[n] : Yd[t]
        },
        Am = e => {
            const t = e.slice(0, 2),
                n = e.slice(2);
            return {
                country: t,
                territory: n
            }
        },
        Um = (e, t) => e / t,
        Jd = (e, t) => e * t,
        Bm = .02,
        $m = 98,
        Vm = 5e5,
        Hm = (e, t, n, r, o) => {
            const i = Math.max(e * Bm, Jd($m, o));
            let a = 0;
            const l = bm(n);
            return l && (a = i * l), {
                baseAmount: i,
                returnCoverageAmount: t,
                taxAmount: a,
                total: i + a + t,
                currencyCode: r
            }
        },
        Gm = (e, t) => {
            let n = null;
            return (e == null ? void 0 : e.variants.reduce((o, i) => i.price > t && (o === null || i.price - t < o.price - t) ? i : ((n === null || i.price > n.price) && (n = i), o), null)) ? ? n
        },
        Wm = e => e == null ? void 0 : e.variants[0],
        Km = ["USD", "EUR", "AUD", "CAD", "GBP", "NZD"],
        Qm = ["US", "DE", "FR", "GB", "CA", "NZ", "AU"];

    function Ym({
        cartTotal: e,
        locationProvider: t,
        currencyCode: n,
        currencyConversionRate: r,
        updateCartAttributes: o
    }) {
        const [i, a] = k.useContext(X), l = k.useContext(Ge);
        let s;
        return k.useEffect(() => {
            ee("Offset#IdealVariant Mounted", {
                state: i
            });
            async function u() {
                var h, y, m;
                const c = i.resolvedProduct;
                let f;
                if ((h = i.config) != null && h.shippingProtectionEnabled) {
                    let E = e();
                    i.cartLineId && (E = E - (i.cartLinePrice || 0));
                    const v = Um(E, r);
                    if (v > Vm) {
                        l.info("Offset#IdealVariant: Cart total is too high for shipping protection", {
                            cartTotalConverted: v
                        }), s = { ...s,
                            showUI: !1,
                            step: _.Excluded,
                            offerStatus: F.ExcludedTooValuable
                        }, a(s);
                        return
                    }
                    if (!Km.includes(n)) {
                        l.info("Offset#IdealVariant: Shipping protection excluded currency", {
                            currencyCode: n
                        }), s = { ...s,
                            step: _.Excluded,
                            offerStatus: F.LocaleNotSupported
                        }, a(s);
                        return
                    }
                    const p = t.getCountry();
                    if (!Qm.includes(p)) {
                        l.info("Offset#IdealVariant: Shipping protection excluded country", {
                            isoCode: p
                        }), s = { ...s,
                            step: _.Excluded,
                            offerStatus: F.LocaleNotSupported
                        }, a(s);
                        return
                    }
                    const g = Hm(E, Jd((y = i.config) == null ? void 0 : y.returnCoverageFee, r), await t.getRegion(), n, r);
                    await xt(o, i, l, "IdealVariant", Z.DeterminedCoverageAmount, JSON.stringify(g)), f = Gm(c, g.total)
                } else f = Wm(c);
                if (!c || !f) {
                    l.error("Offset#IdealVariant: Error resolving product or variant", {
                        shopDomain: i.shopDomain,
                        resolvedProduct: c,
                        variant: f
                    }), s = { ...s,
                        step: _.Error
                    }, a(s);
                    return
                }
                const d = {
                    productId: c.id,
                    variantId: f.id,
                    slug: c.slug,
                    price: f.price,
                    currencyCode: f.currencyCode,
                    image: c.image,
                    configuredPrice: (m = i.config) == null ? void 0 : m.returnCoverageFee
                };
                s = { ...s,
                    product: d,
                    step: _.LoadingAttributes
                }, a(s)
            }
            u()
        }, []), w.jsx(w.Fragment, {})
    }

    function Jm({
        analyticsProvider: e,
        consentProvider: t,
        resolveCartAttributes: n,
        updateCartAttributes: r
    }) {
        const [o, i] = k.useContext(X);
        let a = { ...o,
            experimentEvaluated: !0
        };
        const l = k.useContext(Ge),
            s = o.config,
            u = k.useMemo(() => new Gd(t, s), [t]);
        return k.useEffect(() => {
            ee("Offset#AssignExperiments Mounted", {
                state: o
            });
            async function c() {
                var E;
                const f = await n();
                if (a = { ...a,
                        step: _.CalculateEligibility
                    }, !await u.isExperimentActive()) {
                    a = { ...a,
                        experimentGroup: oe.Inactive
                    }, i(a);
                    return
                }
                const d = (E = f == null ? void 0 : f.find(v => v.key === Z.ExperimentAssignment)) == null ? void 0 : E.value;
                let h = null;
                try {
                    h = d ? JSON.parse(d) : null
                } catch (v) {
                    R("Offset#AssignExperiments: Invalid JSON in CartAttributes for _lrca:", v)
                }
                let y = await u.getAssignmentFromStorage() ? ? null;
                h = u.validateAssignment(h) ? h : null, y = u.validateAssignment(y) ? y : null, h && y && h !== y && (l.warn("Offset#AssignExperiments: Experiment Group Mismatch", {
                    shopDomain: o.shopDomain,
                    assignmentFromAttributes: h,
                    assignmentFromStorage: y
                }), await u.writeAssignment(h));
                let m = h || y || await u.defineAssignment();
                if (h || (await xt(r, o, l, "AssignExperiments", Z.ExperimentAssignment, JSON.stringify(m)), await e.publish(Ls.LoopOptimizationAssignment, {
                        assignment: m
                    })), m && m.group === oe.Control) {
                    l.info("Offset#EvaluatingExperiments: Ineligible Cart User in Offset Experiment Control Group", {
                        shopDomain: o.shopDomain,
                        state: o
                    }), a = { ...a,
                        step: _.Excluded,
                        offerStatus: F.ExcludedReturnCoverageOptimization,
                        showUI: !1,
                        experimentGroup: oe.Control
                    }, i(a);
                    return
                }
                a = { ...a,
                    experimentGroup: m.group || oe.Excluded,
                    showUI: m.group === oe.Treatment
                }, i(a)
            }
            c()
        }, []), w.jsx(w.Fragment, {})
    }
    const Zm = e => {
        const {
            image: t,
            ...n
        } = e;
        return n
    };

    function qm({
        analyticsProvider: e,
        resolveCartAttributes: t,
        updateCartAttributes: n,
        offerOriginValue: r,
        cartExperience: o
    }) {
        const [i, a] = k.useContext(X), l = k.useContext(Ge), {
            product: s,
            offerStatus: u
        } = i;
        let c, f = [];
        return k.useEffect(() => {
            ee("Offset#UpdateAttributes Mounted", {
                state: i
            });
            async function d() {
                const h = await t();
                c = { ...c,
                    attributes: h
                };
                const y = h == null ? void 0 : h.find(g => g.key === Z.OfferStatus);
                (y == null ? void 0 : y.value) !== u && u !== F.Unknown && f.push({
                    key: Z.OfferStatus,
                    value: u
                });
                const m = h == null ? void 0 : h.find(g => g.key === Z.OfferOrigin);
                if (!m) {
                    const g = JSON.stringify([r]);
                    f.push({
                        key: Z.OfferOrigin,
                        value: g
                    })
                }
                if (m) {
                    const g = JSON.parse(m.value);
                    if (typeof g == "object" && !g.includes(r)) {
                        const C = JSON.stringify([...g, r]);
                        f.push({
                            key: Z.OfferOrigin,
                            value: C
                        })
                    }
                }
                const E = h == null ? void 0 : h.find(g => g.key === Z.MountTarget);
                i.mountTarget && (!E || i.mountTarget.toString() !== E.value) && f.push({
                    key: Z.MountTarget,
                    value: i.mountTarget.toString()
                }), !(h == null ? void 0 : h.find(g => g.key === Z.CartExperience)) && o && f.push({
                    key: Z.CartExperience,
                    value: o.toString()
                }), !(h == null ? void 0 : h.find(g => g.key === Z.Product)) && s && f.push({
                    key: Z.Product,
                    value: JSON.stringify(Zm(s))
                }), await Promise.all(f.map(async ({
                    key: g,
                    value: C
                }) => {
                    ee("Offset#UpdateAttributes - Pushing Attribute to Cart", {
                        key: g,
                        value: C
                    }), await xt(n, i, l, "UpdateAttributes", g, C)
                })), await e.publish(Ls.LoopOffsetOfferStatus, {
                    offerStatus: u,
                    attributes: h
                }), R("UpdateAttributes#dispatching state to Listen step"), c = { ...c,
                    step: _.Listen
                }, a(c)
            }
            d()
        }, []), w.jsx(w.Fragment, {})
    }

    function Xm() {
        var ut, yr, ct, Nn, lv;
        const [e, t] = k.useReducer(jh, Fd), n = k.useContext(ov), r = k.useContext(iv), o = k.useContext(Zd), {
            resolveProduct: i
        } = Lm(n), [, a] = k.useState(null), l = k.useRef(null), {
            analyticsProcessingAllowed: s
        } = Wd(), {
            config: u,
            resolvedProduct: c
        } = e, {
            cartLines: f,
            fetchCart: d,
            addReturnCoverage: h,
            removeReturnCoverage: y,
            setProductQuantityInCart: m,
            updateCartAttributes: E,
            cart: v
        } = Om(n), p = k.useMemo(() => f.map(A => ({
            cartLineId: `${A.id}`,
            productId: `${A.product_id}`,
            variantId: `${A.variant_id}`,
            quantity: A.quantity || 1,
            handle: A.handle,
            attributes: [],
            price: A.price
        })), [f]), {
            resolveIsCartEligible: g
        } = _m(p, u, n, c), C = {
            publish: async (A, de) => {
                var da;
                return (da = window == null ? void 0 : window.Shopify) == null ? void 0 : da.analytics.publish(A, de)
            }
        }, O = {
            obtainConsentForAnalytics: async () => s()
        }, N = document.getElementById("offset-cart-ui-offer"), S = document.getElementById("offset-cart-drawer-ui-offer"), I = document.querySelectorAll("[data-offset-ui-offer]"), $ = {
            getCountry: () => window.Shopify.country,
            getRegion: k.useMemo(() => async () => {
                const {
                    getRegion: A
                } = Wd();
                return A()
            }, [])
        }, z = k.useCallback(() => {
            var A;
            return typeof window.LoopOnstore == "object" ? ((A = window.LoopOnstore) == null ? void 0 : A.isActive()) ? ? !1 : !1
        }, []);
        k.useEffect(() => {
            R("Offset Manager Mounted!"), s().then(() => {
                R("Consent tracking feature preloaded")
            }), o.eventSystem === ir.dom ? (R("Using DOM Event System"), Mm(d, o, N, S)) : (R("Using Auto Event System"), Rm(d));
            const A = setInterval(() => {
                a(new Date)
            }, 2500);
            return () => {
                clearInterval(A)
            }
        }, []);
        const Oe = k.useCallback(async () => {
                const {
                    items: A
                } = await d();
                return A.map(de => ({
                    cartLineId: `${de.id}`,
                    productId: `${de.product_id}`,
                    variantId: `${de.variant_id}`,
                    quantity: de.quantity || 1,
                    handle: de.handle,
                    attributes: [],
                    price: de.price
                }))
            }, [d]),
            nt = k.useCallback(() => v.total_price, [v.total_price]),
            Pt = k.useCallback(async () => {
                const {
                    attributes: A
                } = await n.cartGet();
                if (A === void 0) return [];
                const de = [];
                for (const [da, eC] of Object.entries(A)) de.push({
                    key: da,
                    value: eC
                });
                return de
            }, [n]),
            fa = k.useCallback(A => {
                const de = new CustomEvent(ar.CartChanged, {
                    detail: A
                });
                if (o.eventSystem === ir.dom) {
                    R(`Dispatching ${ar.CartChanged} event - DOM system: `, {
                        event: de
                    }), document.dispatchEvent(de), lr.info("Offset#publishCartChangedEvent - DOM System", {
                        shopDomain: r
                    });
                    return
                }
                if (o.autoRefresh === "true" && o.autoRefreshOption === "every-page") {
                    R(`Dispatching ${ar.CartChanged} event - AUTO Refresh System: `, {
                        event: de
                    }), lr.info("Offset#publishCartChangedEvent - AUTO Refresh System", {
                        shopDomain: r
                    }), window.location.reload();
                    return
                }
                if (o.autoRefresh === "true" && o.autoRefreshOption === "full-cart-page-only" && window.location.pathname === "/cart") {
                    R(`Dispatching ${ar.CartChanged} event - AUTO Refresh System Cart Page Only: `, {
                        event: de
                    }), lr.info("Offset#publishCartChangedEvent - AUTO Refresh System Cart Page Only", {
                        shopDomain: r
                    }), window.location.reload();
                    return
                }
                lr.info("Offset#publishCartChangedEvent - AUTO Event System", {
                    shopDomain: r
                }), Dm(v)
            }, [v]),
            fu = () => (performance.mark("offset-ready"), performance.measure("loop-returns-coverage-ready", "domInteractive", "offset-ready")),
            hr = () => {
                t({ ...e,
                    offerStatus: F.ExcludedOnStore,
                    step: _.Excluded
                })
            },
            So = () => document.addEventListener("Loop:Activated", hr),
            P = () => document.removeEventListener("Loop:Activated", hr),
            M = (yr = (ut = window.Shopify) == null ? void 0 : ut.currency) == null ? void 0 : yr.rate,
            j = ((Nn = (ct = window.Shopify) == null ? void 0 : ct.currency) == null ? void 0 : Nn.active) || "ZZZ",
            W = () => {
                var A;
                (A = l.current) == null || A.showModal()
            },
            ne = () => {
                var A;
                (A = l.current) == null || A.close()
            },
            mr = (lv = e.config) != null && lv.returnCoverageAlternateCartExperience ? Ps.alternate : Ps.widget;
        return w.jsx(w.Fragment, {
            children: w.jsxs(X.Provider, {
                value: [e, t],
                children: [e.step === _.Accepted && w.jsx(sm, {
                    addToCart: h,
                    updateCartAttributes: E,
                    removeFromCart: y,
                    resolveCartLines: Oe
                }), e.step === _.AnalyzingAttributes && w.jsx(lm, {}), e.step === _.AssignExperiments && w.jsx(Jm, {
                    analyticsProvider: C,
                    consentProvider: O,
                    resolveCartAttributes: Pt,
                    updateCartAttributes: E
                }), e.step === _.CalculateEligibility && w.jsx(om, {
                    resolveCartLines: Oe,
                    resolveIsCartEligible: g,
                    isLoopOnStoreActive: z,
                    deliveryGroups: []
                }), e.step === _.Error && w.jsx(dm, {
                    cartLines: p,
                    locationProvider: $,
                    updateCartAttributes: E
                }), e.step === _.EvaluatingExperiments && w.jsx(pm, {
                    consentProvider: O
                }), e.step === _.Excluded && w.jsx(im, {
                    removeFromCart: y,
                    updateCartAttributes: E,
                    cartLines: p
                }), e.step === _.IdealVariant && w.jsx(Ym, {
                    cartTotal: nt,
                    locationProvider: $,
                    currencyCode: j,
                    currencyConversionRate: M,
                    updateCartAttributes: E
                }), e.step === _.Initialization && w.jsx(rm, {
                    shopDomain: r,
                    mountTarget: zd.Cart
                }), e.step === _.Listen && w.jsx(vm, {
                    cartLines: p,
                    locationProvider: $,
                    cartTotal: nt,
                    publishCartChangedEvent: fa,
                    addOnStoreListener: So,
                    removeOnStoreListener: P,
                    deliveryGroups: []
                }), e.step === _.LoadingAttributes && w.jsx(am, {
                    resolveCartAttributes: Pt
                }), e.step === _.Rejected && w.jsx(um, {
                    removeFromCart: y,
                    updateCartAttributes: E,
                    cartLines: p
                }), e.step === _.ResolveProduct && w.jsx(Tm, {
                    resolveProduct: i,
                    fireReady: fu
                }), e.step === _.UpdateAttributes && w.jsx(qm, {
                    analyticsProvider: C,
                    resolveCartAttributes: Pt,
                    updateCartAttributes: E,
                    offerOriginValue: jd.Storefront,
                    cartExperience: mr
                }), e.step === _.UpdateCartlines && w.jsx(fm, {
                    resolveCartLines: Oe,
                    setProductQuantityInCart: m
                }), N && bi.createPortal(w.jsx(_s, {
                    openOverlay: W,
                    translations: u == null ? void 0 : u.i18n,
                    cartTotal: nt,
                    showUI: e.showUI
                }), N), S && bi.createPortal(w.jsx(_s, {
                    openOverlay: W,
                    translations: u == null ? void 0 : u.i18n,
                    cartTotal: nt,
                    showUI: e.showUI
                }), S), I && Array.from(I.values()).map((A, de) => bi.createPortal(w.jsx(_s, {
                    openOverlay: W,
                    translations: u == null ? void 0 : u.i18n,
                    cartTotal: nt,
                    showUI: e.showUI
                }, de), A)), w.jsx(cm, {}), w.jsxs("dialog", {
                    ref: l,
                    "data-offset-dialog": "true",
                    children: [e.mode === so.Offset && w.jsx(Em, {
                        closeOverlay: ne,
                        translations: u == null ? void 0 : u.i18n
                    }), e.mode === so.OffsetShippingProtection && w.jsx(km, {
                        closeOverlay: ne
                    })]
                })]
            })
        })
    }
    const Rs = (av = document.querySelector("#loop-return-coverage-data")) == null ? void 0 : av.dataset,
        Zd = Lo.createContext(Rs);

    function e0() {
        return Rs ? w.jsx(Zd.Provider, {
            value: Rs,
            children: w.jsx(Xm, {})
        }) : (R("Offset#LoopManager - Config data not found in selector #loop-return-coverage-data"), w.jsx(w.Fragment, {}))
    }
    var ie = {
            log: "log",
            debug: "debug",
            info: "info",
            warn: "warn",
            error: "error"
        },
        st = console,
        hn = {};
    Object.keys(ie).forEach(function(e) {
        hn[e] = st[e]
    });
    var co = "Datadog Browser SDK:",
        se = {
            debug: hn.debug.bind(st, co),
            log: hn.log.bind(st, co),
            info: hn.info.bind(st, co),
            warn: hn.warn.bind(st, co),
            error: hn.error.bind(st, co)
        },
        Ms = "https://docs.datadoghq.com",
        qd = "".concat(Ms, "/real_user_monitoring/browser/troubleshooting"),
        Bi = "More details:";

    function Xd(e, t) {
        return function() {
            for (var n = [], r = 0; r < arguments.length; r++) n[r] = arguments[r];
            try {
                return e.apply(void 0, n)
            } catch (o) {
                se.error(t, o)
            }
        }
    }

    function $i(e) {
        return e !== 0 && Math.random() * 100 <= e
    }

    function t0(e) {
        return n0(e) && e >= 0 && e <= 100
    }

    function n0(e) {
        return typeof e == "number"
    }
    var fo = 1e3,
        mn = 60 * fo,
        r0 = 60 * mn;

    function po() {
        return new Date().getTime()
    }

    function Jt() {
        return po()
    }

    function Vi() {
        return performance.now()
    }

    function Zt() {
        return {
            relative: Vi(),
            timeStamp: Jt()
        }
    }

    function o0() {
        return {
            relative: 0,
            timeStamp: ep()
        }
    }

    function i0(e, t) {
        return t - e
    }

    function a0(e, t) {
        return e + t
    }

    function l0(e) {
        return e - ep()
    }
    var Ds;

    function ep() {
        return Ds === void 0 && (Ds = performance.timing.navigationStart), Ds
    }
    var Et = 1024,
        tp = 1024 * Et,
        s0 = /[^\u0000-\u007F]/;

    function js(e) {
        return s0.test(e) ? window.TextEncoder !== void 0 ? new TextEncoder().encode(e).length : new Blob([e]).size : e.length
    }

    function yn(e, t) {
        return e.indexOf(t) !== -1
    }

    function zs(e) {
        if (Array.from) return Array.from(e);
        var t = [];
        if (e instanceof Set) e.forEach(function(r) {
            return t.push(r)
        });
        else
            for (var n = 0; n < e.length; n++) t.push(e[n]);
        return t
    }

    function u0(e, t) {
        for (var n = 0; n < e.length; n += 1) {
            var r = e[n];
            if (t(r, n)) return r
        }
    }

    function Hi(e) {
        return Object.keys(e).map(function(t) {
            return e[t]
        })
    }

    function c0(e) {
        return Object.keys(e).map(function(t) {
            return [t, e[t]]
        })
    }

    function Fs(e, t) {
        return e.slice(0, t.length) === t
    }

    function f0(e, t) {
        return e.slice(-t.length) === t
    }

    function he(e) {
        for (var t = [], n = 1; n < arguments.length; n++) t[n - 1] = arguments[n];
        return t.forEach(function(r) {
            for (var o in r) Object.prototype.hasOwnProperty.call(r, o) && (e[o] = r[o])
        }), e
    }

    function d0(e) {
        return he({}, e)
    }

    function np(e, t) {
        return Object.keys(e).some(function(n) {
            return e[n] === t
        })
    }

    function Ts(e) {
        return Object.keys(e).length === 0
    }

    function qt() {
        if (typeof globalThis == "object") return globalThis;
        Object.defineProperty(Object.prototype, "_dd_temp_", {
            get: function() {
                return this
            },
            configurable: !0
        });
        var e = _dd_temp_;
        return delete Object.prototype._dd_temp_, typeof e != "object" && (typeof self == "object" ? e = self : typeof window == "object" ? e = window : e = {}), e
    }

    function sr(e, t) {
        var n = qt(),
            r;
        return n.Zone && typeof n.Zone.__symbol__ == "function" && (r = e[n.Zone.__symbol__(t)]), r || (r = e[t]), r
    }
    var p0 = function(e, t, n) {
            if (n || arguments.length === 2)
                for (var r = 0, o = t.length, i; r < o; r++)(i || !(r in t)) && (i || (i = Array.prototype.slice.call(t, 0, r)), i[r] = t[r]);
            return e.concat(i || Array.prototype.slice.call(t))
        },
        Gi, rp = !1;

    function v0(e) {
        Gi = e
    }

    function g0(e) {
        rp = e
    }

    function h0(e, t, n) {
        var r = n.value;
        n.value = function() {
            for (var o = [], i = 0; i < arguments.length; i++) o[i] = arguments[i];
            var a = Gi ? B(r) : r;
            return a.apply(this, o)
        }
    }

    function B(e) {
        return function() {
            return vo(e, this, arguments)
        }
    }

    function vo(e, t, n) {
        try {
            return e.apply(t, n)
        } catch (r) {
            if (bs(r), Gi) try {
                Gi(r)
            } catch (o) {
                bs(o)
            }
        }
    }

    function bs() {
        for (var e = [], t = 0; t < arguments.length; t++) e[t] = arguments[t];
        rp && se.error.apply(se, p0(["[MONITOR]"], e, !1))
    }

    function go(e, t) {
        return sr(qt(), "setTimeout")(B(e), t)
    }

    function op(e) {
        sr(qt(), "clearTimeout")(e)
    }

    function As(e, t) {
        return sr(qt(), "setInterval")(B(e), t)
    }

    function ip(e) {
        sr(qt(), "clearInterval")(e)
    }
    var fe = function() {
        function e(t) {
            this.onFirstSubscribe = t, this.observers = []
        }
        return e.prototype.subscribe = function(t) {
            var n = this;
            return this.observers.push(t), this.observers.length === 1 && this.onFirstSubscribe && (this.onLastUnsubscribe = this.onFirstSubscribe(this) || void 0), {
                unsubscribe: function() {
                    n.observers = n.observers.filter(function(r) {
                        return t !== r
                    }), !n.observers.length && n.onLastUnsubscribe && n.onLastUnsubscribe()
                }
            }
        }, e.prototype.notify = function(t) {
            this.observers.forEach(function(n) {
                return n(t)
            })
        }, e
    }();

    function ap() {
        for (var e = [], t = 0; t < arguments.length; t++) e[t] = arguments[t];
        return new fe(function(n) {
            var r = e.map(function(o) {
                return o.subscribe(function(i) {
                    return n.notify(i)
                })
            });
            return function() {
                return r.forEach(function(o) {
                    return o.unsubscribe()
                })
            }
        })
    }

    function lp(e, t, n) {
        var r = !1,
            o, i;
        return {
            throttled: function() {
                for (var a = [], l = 0; l < arguments.length; l++) a[l] = arguments[l];
                if (r) {
                    o = a;
                    return
                }
                e.apply(void 0, a), r = !0, i = go(function() {
                    o && e.apply(void 0, o), r = !1, o = void 0
                }, t)
            },
            cancel: function() {
                op(i), r = !1, o = void 0
            }
        }
    }

    function Xt() {}

    function wn(e) {
        return e ? (parseInt(e, 10) ^ Math.random() * 16 >> parseInt(e, 10) / 4).toString(16) : "".concat(1e7, "-").concat(1e3, "-").concat(4e3, "-").concat(8e3, "-").concat(1e11).replace(/[018]/g, wn)
    }
    var Wi = /([\w-]+)\s*=\s*([^;]+)/g;

    function m0(e, t) {
        for (Wi.lastIndex = 0;;) {
            var n = Wi.exec(e);
            if (n) {
                if (n[1] === t) return n[2]
            } else break
        }
    }

    function y0(e) {
        var t = new Map;
        for (Wi.lastIndex = 0;;) {
            var n = Wi.exec(e);
            if (n) t.set(n[1], n[2]);
            else break
        }
        return t
    }

    function w0(e, t, n) {
        var r = e.charCodeAt(t - 1),
            o = r >= 55296 && r <= 56319,
            i = o ? t + 1 : t;
        return e.length <= i ? e : "".concat(e.slice(0, i)).concat(n)
    }

    function C0() {
        return S0() === 1
    }
    var Ki;

    function S0() {
        return Ki ? ? (Ki = x0())
    }

    function x0(e) {
        var t;
        e === void 0 && (e = window);
        var n = e.navigator.userAgent;
        return e.chrome || /HeadlessChrome/.test(n) ? 1 : ((t = e.navigator.vendor) === null || t === void 0 ? void 0 : t.indexOf("Apple")) === 0 || /safari/i.test(n) && !/chrome|android/i.test(n) ? 2 : e.document.documentMode ? 0 : 3
    }

    function ho(e, t, n, r) {
        var o = new Date;
        o.setTime(o.getTime() + n);
        var i = "expires=".concat(o.toUTCString()),
            a = r && r.crossSite ? "none" : "strict",
            l = r && r.domain ? ";domain=".concat(r.domain) : "",
            s = r && r.secure ? ";secure" : "",
            u = r && r.partitioned ? ";partitioned" : "";
        document.cookie = "".concat(e, "=").concat(t, ";").concat(i, ";path=/;samesite=").concat(a).concat(l).concat(s).concat(u)
    }

    function Us(e) {
        return m0(document.cookie, e)
    }
    var Bs;

    function Cn(e) {
        return Bs || (Bs = y0(document.cookie)), Bs.get(e)
    }

    function sp(e, t) {
        ho(e, "", 0, t)
    }

    function E0(e) {
        if (document.cookie === void 0 || document.cookie === null) return !1;
        try {
            var t = "dd_cookie_test_".concat(wn()),
                n = "test";
            ho(t, n, mn, e);
            var r = Us(t) === n;
            return sp(t, e), r
        } catch (o) {
            return se.error(o), !1
        }
    }
    var $s;

    function k0() {
        if ($s === void 0) {
            for (var e = "dd_site_test_".concat(wn()), t = "test", n = window.location.hostname.split("."), r = n.pop(); n.length && !Us(e);) r = "".concat(n.pop(), ".").concat(r), ho(e, t, fo, {
                domain: r
            });
            sp(e, {
                domain: r
            }), $s = r
        }
        return $s
    }
    var ur = "_dd_s",
        Vs = 4 * r0,
        up = 15 * mn,
        cp = /^([a-zA-Z]+)=([a-z0-9-]+)$/,
        Hs = "&",
        O0 = "1";

    function Sn() {
        return {
            isExpired: O0
        }
    }

    function Qi(e) {
        return Ts(e)
    }

    function fp(e) {
        return !Qi(e)
    }

    function Yi(e) {
        return e.isExpired !== void 0 || !L0(e)
    }

    function L0(e) {
        return (e.created === void 0 || po() - Number(e.created) < Vs) && (e.expire === void 0 || po() < Number(e.expire))
    }

    function dp(e) {
        e.expire = String(po() + up)
    }

    function Gs(e) {
        return c0(e).map(function(t) {
            var n = t[0],
                r = t[1];
            return "".concat(n, "=").concat(r)
        }).join(Hs)
    }

    function pp(e) {
        var t = {};
        return P0(e) && e.split(Hs).forEach(function(n) {
            var r = cp.exec(n);
            if (r !== null) {
                var o = r[1],
                    i = r[2];
                t[o] = i
            }
        }), t
    }

    function P0(e) {
        return !!e && (e.indexOf(Hs) !== -1 || cp.test(e))
    }
    var I0 = "_dd",
        N0 = "_dd_r",
        _0 = "_dd_l",
        R0 = "rum",
        M0 = "logs";

    function D0(e) {
        var t = Cn(ur);
        if (!t) {
            var n = Cn(I0),
                r = Cn(N0),
                o = Cn(_0),
                i = {};
            n && (i.id = n), o && /^[01]$/.test(o) && (i[M0] = o), r && /^[012]$/.test(r) && (i[R0] = r), fp(i) && (dp(i), e.persistSession(i))
        }
    }

    function j0(e) {
        var t = A0(e);
        return E0(t) ? {
            type: "Cookie",
            cookieOptions: t
        } : void 0
    }

    function z0(e) {
        var t = {
            isLockEnabled: C0(),
            persistSession: F0(e),
            retrieveSession: b0,
            expireSession: function() {
                return T0(e)
            }
        };
        return D0(t), t
    }

    function F0(e) {
        return function(t) {
            ho(ur, Gs(t), up, e)
        }
    }

    function T0(e) {
        ho(ur, Gs(Sn()), Vs, e)
    }

    function b0() {
        var e = Us(ur);
        return pp(e)
    }

    function A0(e) {
        var t = {};
        return t.secure = !!e.useSecureSessionCookie || !!e.usePartitionedCrossSiteSessionCookie || !!e.useCrossSiteSessionCookie, t.crossSite = !!e.usePartitionedCrossSiteSessionCookie || !!e.useCrossSiteSessionCookie, t.partitioned = !!e.usePartitionedCrossSiteSessionCookie, e.trackSessionAcrossSubdomains && (t.domain = k0()), t
    }
    var U0 = "_dd_test_";

    function B0() {
        try {
            var e = wn(),
                t = "".concat(U0).concat(e);
            localStorage.setItem(t, e);
            var n = localStorage.getItem(t);
            return localStorage.removeItem(t), e === n ? {
                type: "LocalStorage"
            } : void 0
        } catch {
            return
        }
    }

    function $0() {
        return {
            isLockEnabled: !1,
            persistSession: vp,
            retrieveSession: V0,
            expireSession: H0
        }
    }

    function vp(e) {
        localStorage.setItem(ur, Gs(e))
    }

    function V0() {
        var e = localStorage.getItem(ur);
        return pp(e)
    }

    function H0() {
        vp(Sn())
    }
    var G0 = 10,
        W0 = 100,
        gp = [],
        Ji;

    function xn(e, t, n) {
        var r;
        n === void 0 && (n = 0);
        var o = t.isLockEnabled,
            i = t.persistSession,
            a = t.expireSession,
            l = function(d) {
                return i(he({}, d, {
                    lock: u
                }))
            },
            s = function() {
                var d = t.retrieveSession(),
                    h = d.lock;
                return d.lock && delete d.lock, {
                    session: d,
                    lock: h
                }
            };
        if (Ji || (Ji = e), e !== Ji) {
            gp.push(e);
            return
        }
        if (o && n >= W0) {
            hp(t);
            return
        }
        var u, c = s();
        if (o) {
            if (c.lock) {
                Zi(e, t, n);
                return
            }
            if (u = wn(), l(c.session), c = s(), c.lock !== u) {
                Zi(e, t, n);
                return
            }
        }
        var f = e.process(c.session);
        if (o && (c = s(), c.lock !== u)) {
            Zi(e, t, n);
            return
        }
        if (f && (Yi(f) ? a() : (dp(f), o ? l(f) : i(f))), o && !(f && Yi(f))) {
            if (c = s(), c.lock !== u) {
                Zi(e, t, n);
                return
            }
            i(c.session), f = c.session
        }(r = e.after) === null || r === void 0 || r.call(e, f || c.session), hp(t)
    }

    function Zi(e, t, n) {
        go(function() {
            xn(e, t, n + 1)
        }, G0)
    }

    function hp(e) {
        Ji = void 0;
        var t = gp.shift();
        t && xn(t, e)
    }
    var mp = fo;

    function K0(e) {
        var t = j0(e);
        return !t && e.allowFallbackToLocalStorage && (t = B0()), t
    }

    function Q0(e, t, n) {
        var r = new fe,
            o = new fe,
            i = new fe,
            a = e.type === "Cookie" ? z0(e.cookieOptions) : $0(),
            l = a.expireSession,
            s = As(y, mp),
            u;
        E();
        var c = lp(function() {
                xn({
                    process: function(S) {
                        if (!Qi(S)) {
                            var I = m(S);
                            return v(I), I
                        }
                    },
                    after: function(S) {
                        fp(S) && !p() && O(S), u = S
                    }
                }, a)
            }, mp),
            f = c.throttled,
            d = c.cancel;

        function h() {
            xn({
                process: function(S) {
                    return p() ? m(S) : void 0
                }
            }, a)
        }

        function y() {
            xn({
                process: function(S) {
                    return Yi(S) ? Sn() : void 0
                },
                after: m
            }, a)
        }

        function m(S) {
            return Yi(S) && (S = Sn()), p() && (g(S) ? C() : (i.notify({
                previousState: u,
                newState: S
            }), u = S)), S
        }

        function E() {
            xn({
                process: function(S) {
                    if (Qi(S)) return Sn()
                },
                after: function(S) {
                    u = S
                }
            }, a)
        }

        function v(S) {
            if (Qi(S)) return !1;
            var I = n(S[t]),
                $ = I.trackingType,
                z = I.isTracked;
            S[t] = $, delete S.isExpired, z && !S.id && (S.id = wn(), S.created = String(po()))
        }

        function p() {
            return u[t] !== void 0
        }

        function g(S) {
            return u.id !== S.id || u[t] !== S[t]
        }

        function C() {
            u = Sn(), o.notify()
        }

        function O(S) {
            u = S, r.notify()
        }

        function N(S) {
            xn({
                process: function(I) {
                    return he({}, I, S)
                },
                after: m
            }, a)
        }
        return {
            expandOrRenewSession: f,
            expandSession: h,
            getSession: function() {
                return u
            },
            renewObservable: r,
            expireObservable: o,
            sessionStateUpdateObservable: i,
            restartSession: E,
            expire: function() {
                d(), l(), m(Sn())
            },
            stop: function() {
                ip(s)
            },
            updateSessionState: N
        }
    }
    var Ws = {
        GRANTED: "granted",
        NOT_GRANTED: "not-granted"
    };

    function Y0(e) {
        var t = new fe;
        return {
            tryToInit: function(n) {
                e || (e = n)
            },
            update: function(n) {
                e = n, t.notify()
            },
            isGranted: function() {
                return e === Ws.GRANTED
            },
            observable: t
        }
    }

    function En(e, t, n) {
        if (typeof e != "object" || e === null) return JSON.stringify(e);
        var r = cr(Object.prototype),
            o = cr(Array.prototype),
            i = cr(Object.getPrototypeOf(e)),
            a = cr(e);
        try {
            return JSON.stringify(e, t, n)
        } catch {
            return "<error: unable to serialize object>"
        } finally {
            r(), o(), i(), a()
        }
    }

    function cr(e) {
        var t = e,
            n = t.toJSON;
        return n ? (delete t.toJSON, function() {
            t.toJSON = n
        }) : Xt
    }

    function Ks(e) {
        return J0(e, location.href).href
    }

    function J0(e, t) {
        var n = Z0();
        if (n) try {
            return t !== void 0 ? new n(e, t) : new n(e)
        } catch (a) {
            throw new Error("Failed to construct URL: ".concat(String(a), " ").concat(En({
                url: e,
                base: t
            })))
        }
        if (t === void 0 && !/:/.test(e)) throw new Error("Invalid URL: '".concat(e, "'"));
        var r = document,
            o = r.createElement("a");
        if (t !== void 0) {
            r = document.implementation.createHTMLDocument("");
            var i = r.createElement("base");
            i.href = t, r.head.appendChild(i), r.body.appendChild(o)
        }
        return o.href = e, o
    }
    var yp = URL,
        qi;

    function Z0() {
        if (qi === void 0) try {
            var e = new yp("http://test/path");
            qi = e.href === "http://test/path"
        } catch {
            qi = !1
        }
        return qi ? yp : void 0
    }
    var q0 = "datad0g.com",
        X0 = "dd0g-gov.com",
        fr = "datadoghq.com",
        ey = "ddog-gov.com",
        ty = "pci.browser-intake-datadoghq.com",
        ny = ["ddsource", "ddtags"];

    function mo(e, t, n) {
        var r = ry(e, t);
        return {
            build: function(o, i) {
                var a = iy(e, t, n, o, i);
                return r(a)
            },
            urlPrefix: r(""),
            trackType: t
        }
    }

    function ry(e, t) {
        var n = "/api/v2/".concat(t),
            r = e.proxy;
        if (typeof r == "string") {
            var o = Ks(r);
            return function(a) {
                return "".concat(o, "?ddforward=").concat(encodeURIComponent("".concat(n, "?").concat(a)))
            }
        }
        if (typeof r == "function") return function(a) {
            return r({
                path: n,
                parameters: a
            })
        };
        var i = oy(t, e);
        return function(a) {
            return "https://".concat(i).concat(n, "?").concat(a)
        }
    }

    function oy(e, t) {
        var n = t.site,
            r = n === void 0 ? fr : n,
            o = t.internalAnalyticsSubdomain;
        if (e === "logs" && t.usePciIntake && r === fr) return ty;
        if (o && r === fr) return "".concat(o, ".").concat(fr);
        if (r === X0) return "http-intake.logs.".concat(r);
        var i = r.split("."),
            a = i.pop();
        return "browser-intake-".concat(i.join("-"), ".").concat(a)
    }

    function iy(e, t, n, r, o) {
        var i = e.clientToken,
            a = e.internalAnalyticsSubdomain,
            l = o.retry,
            s = o.encoding,
            u = ["sdk_version:".concat("5.31.1"), "api:".concat(r)].concat(n);
        l && u.push("retry_count:".concat(l.count), "retry_after:".concat(l.lastFailureStatus));
        var c = ["ddsource=browser", "ddtags=".concat(encodeURIComponent(u.join(","))), "dd-api-key=".concat(i), "dd-evp-origin-version=".concat(encodeURIComponent("5.31.1")), "dd-evp-origin=browser", "dd-request-id=".concat(wn())];
        return s && c.push("dd-evp-encoding=".concat(s)), t === "rum" && c.push("batch_time=".concat(Jt())), a && c.reverse(), c.join("&")
    }
    var ay = 200;

    function ly(e) {
        var t = e.env,
            n = e.service,
            r = e.version,
            o = e.datacenter,
            i = [];
        return t && i.push(Xi("env", t)), n && i.push(Xi("service", n)), r && i.push(Xi("version", r)), o && i.push(Xi("datacenter", o)), i
    }

    function Xi(e, t) {
        var n = ay - e.length - 1;
        (t.length > n || sy(t)) && se.warn("".concat(e, " value doesn't meet tag requirements and will be sanitized. ").concat(Bi, " ").concat(Ms, "/getting_started/tagging/#defining-tags"));
        var r = t.replace(/,/g, "_");
        return "".concat(e, ":").concat(r)
    }

    function sy(e) {
        return uy() ? new RegExp("[^\\p{Ll}\\p{Lo}0-9_:./-]", "u").test(e) : !1
    }

    function uy() {
        try {
            return new RegExp("[\\p{Ll}]", "u"), !0
        } catch {
            return !1
        }
    }

    function cy(e) {
        var t = e.site || fr,
            n = ly(e),
            r = fy(e, n),
            o = dy(e, n);
        return he({
            replica: o,
            site: t
        }, r)
    }

    function fy(e, t) {
        return {
            logsEndpointBuilder: mo(e, "logs", t),
            rumEndpointBuilder: mo(e, "rum", t),
            sessionReplayEndpointBuilder: mo(e, "replay", t)
        }
    }

    function dy(e, t) {
        if (e.replica) {
            var n = he({}, e, {
                    site: fr,
                    clientToken: e.replica.clientToken
                }),
                r = {
                    logsEndpointBuilder: mo(n, "logs", t),
                    rumEndpointBuilder: mo(n, "rum", t)
                };
            return he({
                applicationId: e.replica.applicationId
            }, r)
        }
    }

    function py(e) {
        return ny.every(function(t) {
            return yn(e, t)
        })
    }

    function Qs(e, t) {
        return e != null && typeof e != "string" ? (se.error("".concat(t, " must be defined as a string")), !1) : !0
    }

    function vy(e) {
        return e && typeof e == "string" && !/(datadog|ddog|datad0g|dd0g)/.test(e) ? (se.error("Site should be a valid Datadog site. ".concat(Bi, " ").concat(Ms, "/getting_started/site/.")), !1) : !0
    }

    function ea(e, t) {
        return e !== void 0 && !t0(e) ? (se.error("".concat(t, " Sample Rate should be a number between 0 and 100")), !1) : !0
    }

    function gy(e) {
        var t, n, r, o, i;
        if (!e || !e.clientToken) {
            se.error("Client Token is not configured, we will not send any data.");
            return
        }
        if (!(!vy(e.site) || !ea(e.sessionSampleRate, "Session") || !ea(e.telemetrySampleRate, "Telemetry") || !ea(e.telemetryConfigurationSampleRate, "Telemetry Configuration") || !ea(e.telemetryUsageSampleRate, "Telemetry Usage") || !Qs(e.version, "Version") || !Qs(e.env, "Env") || !Qs(e.service, "Service"))) {
            if (e.trackingConsent !== void 0 && !np(Ws, e.trackingConsent)) {
                se.error('Tracking Consent should be either "granted" or "not-granted"');
                return
            }
            return he({
                beforeSend: e.beforeSend && Xd(e.beforeSend, "beforeSend threw an error:"),
                sessionStoreStrategyType: K0(e),
                sessionSampleRate: (t = e.sessionSampleRate) !== null && t !== void 0 ? t : 100,
                telemetrySampleRate: (n = e.telemetrySampleRate) !== null && n !== void 0 ? n : 20,
                telemetryConfigurationSampleRate: (r = e.telemetryConfigurationSampleRate) !== null && r !== void 0 ? r : 5,
                telemetryUsageSampleRate: (o = e.telemetryUsageSampleRate) !== null && o !== void 0 ? o : 5,
                service: e.service || void 0,
                silentMultipleInit: !!e.silentMultipleInit,
                allowUntrustedEvents: !!e.allowUntrustedEvents,
                trackingConsent: (i = e.trackingConsent) !== null && i !== void 0 ? i : Ws.GRANTED,
                storeContextsAcrossPages: !!e.storeContextsAcrossPages,
                batchBytesLimit: 16 * Et,
                eventRateLimiterThreshold: 3e3,
                maxTelemetryEventsPerPage: 15,
                flushTimeout: 30 * fo,
                batchMessagesLimit: 50,
                messageBytesLimit: 256 * Et
            }, cy(e))
        }
    }

    function hy(e) {
        return {
            session_sample_rate: e.sessionSampleRate,
            telemetry_sample_rate: e.telemetrySampleRate,
            telemetry_configuration_sample_rate: e.telemetryConfigurationSampleRate,
            telemetry_usage_sample_rate: e.telemetryUsageSampleRate,
            use_before_send: !!e.beforeSend,
            use_cross_site_session_cookie: e.useCrossSiteSessionCookie,
            use_partitioned_cross_site_session_cookie: e.usePartitionedCrossSiteSessionCookie,
            use_secure_session_cookie: e.useSecureSessionCookie,
            use_proxy: !!e.proxy,
            silent_multiple_init: e.silentMultipleInit,
            track_session_across_subdomains: e.trackSessionAcrossSubdomains,
            allow_fallback_to_local_storage: !!e.allowFallbackToLocalStorage,
            store_contexts_across_pages: !!e.storeContextsAcrossPages,
            allow_untrusted_events: !!e.allowUntrustedEvents,
            tracking_consent: e.trackingConsent
        }
    }
    var Ys;
    (function(e) {
        e.WRITABLE_RESOURCE_GRAPHQL = "writable_resource_graphql", e.REMOTE_CONFIGURATION = "remote_configuration", e.LONG_ANIMATION_FRAME = "long_animation_frame"
    })(Ys || (Ys = {}));
    var wp = new Set;

    function my(e) {
        Array.isArray(e) && yy(e.filter(function(t) {
            return np(Ys, t)
        }))
    }

    function yy(e) {
        e.forEach(function(t) {
            wp.add(t)
        })
    }

    function wy() {
        return wp
    }
    var yo = "?";

    function kt(e) {
        var t = [],
            n = Js(e, "stack"),
            r = String(e);
        return n && Fs(n, r) && (n = n.slice(r.length)), n && n.split(`
`).forEach(function(o) {
            var i = xy(o) || ky(o) || Ly(o) || Ny(o);
            i && (!i.func && i.line && (i.func = yo), t.push(i))
        }), {
            message: Js(e, "message"),
            name: Js(e, "name"),
            stack: t
        }
    }
    var Cp = "((?:file|https?|blob|chrome-extension|native|eval|webpack|snippet|<anonymous>|\\w+\\.|\\/).*?)",
        dr = "(?::(\\d+))",
        Cy = new RegExp("^\\s*at (.*?) ?\\(".concat(Cp).concat(dr, "?").concat(dr, "?\\)?\\s*$"), "i"),
        Sy = new RegExp("\\((\\S*)".concat(dr).concat(dr, "\\)"));

    function xy(e) {
        var t = Cy.exec(e);
        if (t) {
            var n = t[2] && t[2].indexOf("native") === 0,
                r = t[2] && t[2].indexOf("eval") === 0,
                o = Sy.exec(t[2]);
            return r && o && (t[2] = o[1], t[3] = o[2], t[4] = o[3]), {
                args: n ? [t[2]] : [],
                column: t[4] ? +t[4] : void 0,
                func: t[1] || yo,
                line: t[3] ? +t[3] : void 0,
                url: n ? void 0 : t[2]
            }
        }
    }
    var Ey = new RegExp("^\\s*at ?".concat(Cp).concat(dr, "?").concat(dr, "??\\s*$"), "i");

    function ky(e) {
        var t = Ey.exec(e);
        if (t) return {
            args: [],
            column: t[3] ? +t[3] : void 0,
            func: yo,
            line: t[2] ? +t[2] : void 0,
            url: t[1]
        }
    }
    var Oy = /^\s*at (?:((?:\[object object\])?.+) )?\(?((?:file|ms-appx|https?|webpack|blob):.*?):(\d+)(?::(\d+))?\)?\s*$/i;

    function Ly(e) {
        var t = Oy.exec(e);
        if (t) return {
            args: [],
            column: t[4] ? +t[4] : void 0,
            func: t[1] || yo,
            line: +t[3],
            url: t[2]
        }
    }
    var Py = /^\s*(.*?)(?:\((.*?)\))?(?:^|@)((?:file|https?|blob|chrome|webpack|resource|capacitor|\[native).*?|[^@]*bundle)(?::(\d+))?(?::(\d+))?\s*$/i,
        Iy = /(\S+) line (\d+)(?: > eval line \d+)* > eval/i;

    function Ny(e) {
        var t = Py.exec(e);
        if (t) {
            var n = t[3] && t[3].indexOf(" > eval") > -1,
                r = Iy.exec(t[3]);
            return n && r && (t[3] = r[1], t[4] = r[2], t[5] = void 0), {
                args: t[2] ? t[2].split(",") : [],
                column: t[5] ? +t[5] : void 0,
                func: t[1] || yo,
                line: t[4] ? +t[4] : void 0,
                url: t[3]
            }
        }
    }

    function Js(e, t) {
        if (!(typeof e != "object" || !e || !(t in e))) {
            var n = e[t];
            return typeof n == "string" ? n : void 0
        }
    }

    function _y(e, t, n, r) {
        var o = [{
                url: t,
                column: r,
                line: n
            }],
            i = My(e),
            a = i.name,
            l = i.message;
        return {
            name: a,
            message: l,
            stack: o
        }
    }
    var Ry = /^(?:[Uu]ncaught (?:exception: )?)?(?:((?:Eval|Internal|Range|Reference|Syntax|Type|URI|)Error): )?([\s\S]*)$/;

    function My(e) {
        var t, n, r;
        return {}.toString.call(e) === "[object String]" && (t = Ry.exec(e), n = t[1], r = t[2]), {
            name: n,
            message: r
        }
    }

    function ta() {
        var e = 2,
            t = new Error,
            n;
        if (!t.stack) try {
            throw t
        } catch {}
        return vo(function() {
            var r = kt(t);
            r.stack = r.stack.slice(e), n = kn(r)
        }), n
    }

    function kn(e) {
        var t = Sp(e);
        return e.stack.forEach(function(n) {
            var r = n.func === "?" ? "<anonymous>" : n.func,
                o = n.args && n.args.length > 0 ? "(".concat(n.args.join(", "), ")") : "",
                i = n.line ? ":".concat(n.line) : "",
                a = n.line && n.column ? ":".concat(n.column) : "";
            t += `
  at `.concat(r).concat(o, " @ ").concat(n.url).concat(i).concat(a)
        }), t
    }

    function Sp(e) {
        return "".concat(e.name || "Error", ": ").concat(e.message)
    }

    function On(e, t, n, r) {
        var o = r === void 0 ? {} : r,
            i = o.computeHandlingStack,
            a = e[t];
        if (typeof a != "function")
            if (t in e && Fs(t, "on")) a = Xt;
            else return {
                stop: Xt
            };
        var l = !1,
            s = function() {
                if (l) return a.apply(this, arguments);
                var u = zs(arguments),
                    c;
                vo(n, null, [{
                    target: this,
                    parameters: u,
                    onPostCall: function(d) {
                        c = d
                    },
                    handlingStack: i ? ta() : void 0
                }]);
                var f = a.apply(this, u);
                return c && vo(c, null, [f]), f
            };
        return e[t] = s, {
            stop: function() {
                l = !0, e[t] === s && (e[t] = a)
            }
        }
    }
    var Dy = 220 * Et,
        jy = "$",
        zy = 3;

    function Ot(e, t) {
        t === void 0 && (t = Dy);
        var n = cr(Object.prototype),
            r = cr(Array.prototype),
            o = [],
            i = new WeakMap,
            a = Zs(e, jy, void 0, o, i),
            l = JSON.stringify(a),
            s = l ? l.length : 0;
        if (s > t) {
            qs(t, "discarded", e);
            return
        }
        for (; o.length > 0 && s < t;) {
            var u = o.shift(),
                c = 0;
            if (Array.isArray(u.source))
                for (var f = 0; f < u.source.length; f++) {
                    var d = Zs(u.source[f], u.path, f, o, i);
                    if (d !== void 0 ? s += JSON.stringify(d).length : s += 4, s += c, c = 1, s > t) {
                        qs(t, "truncated", e);
                        break
                    }
                    u.target[f] = d
                } else
                    for (var f in u.source)
                        if (Object.prototype.hasOwnProperty.call(u.source, f)) {
                            var d = Zs(u.source[f], u.path, f, o, i);
                            if (d !== void 0 && (s += JSON.stringify(d).length + c + f.length + zy, c = 1), s > t) {
                                qs(t, "truncated", e);
                                break
                            }
                            u.target[f] = d
                        }
        }
        return n(), r(), a
    }

    function Zs(e, t, n, r, o) {
        var i = by(e);
        if (!i || typeof i != "object") return Fy(i);
        var a = Ty(i);
        if (a !== "[Object]" && a !== "[Array]" && a !== "[Error]") return a;
        var l = e;
        if (o.has(l)) return "[Reference seen at ".concat(o.get(l), "]");
        var s = n !== void 0 ? "".concat(t, ".").concat(n) : t,
            u = Array.isArray(i) ? [] : {};
        return o.set(l, s), r.push({
            source: i,
            target: u,
            path: s
        }), u
    }

    function Fy(e) {
        return typeof e == "bigint" ? "[BigInt] ".concat(e.toString()) : typeof e == "function" ? "[Function] ".concat(e.name || "unknown") : typeof e == "symbol" ? "[Symbol] ".concat(e.description || e.toString()) : e
    }

    function Ty(e) {
        try {
            if (e instanceof Event) return {
                isTrusted: e.isTrusted
            };
            var t = Object.prototype.toString.call(e),
                n = t.match(/\[object (.*)\]/);
            if (n && n[1]) return "[".concat(n[1], "]")
        } catch {}
        return "[Unserializable]"
    }

    function by(e) {
        var t = e;
        if (t && typeof t.toJSON == "function") try {
            return t.toJSON()
        } catch {}
        return e
    }

    function qs(e, t, n) {
        se.warn("The data provided has been ".concat(t, " as it is over the limit of ").concat(e, " characters:"), n)
    }
    var xp = "No stack, consider using an instance of Error";

    function Ep(e) {
        var t = e.stackTrace,
            n = e.originalError,
            r = e.handlingStack,
            o = e.startClocks,
            i = e.nonErrorPrefix,
            a = e.source,
            l = e.handling,
            s = n instanceof Error,
            u = Ay(t, s, i, n),
            c = Uy(s, t) ? kn(t) : xp,
            f = s ? Op(n, a) : void 0,
            d = t ? t.name : void 0,
            h = kp(n);
        return {
            startClocks: o,
            source: a,
            handling: l,
            handlingStack: r,
            originalError: n,
            type: d,
            message: u,
            stack: c,
            causes: f,
            fingerprint: h
        }
    }

    function Ay(e, t, n, r) {
        return e != null && e.message && (e != null && e.name) ? e.message : t ? "Empty message" : "".concat(n, " ").concat(En(Ot(r)))
    }

    function Uy(e, t) {
        return t === void 0 ? !1 : e ? !0 : t.stack.length > 0 && (t.stack.length > 1 || t.stack[0].url !== void 0)
    }

    function kp(e) {
        return e instanceof Error && "dd_fingerprint" in e ? String(e.dd_fingerprint) : void 0
    }

    function By(e) {
        var t;
        return (t = /@ (.+)/.exec(e)) === null || t === void 0 ? void 0 : t[1]
    }

    function Op(e, t) {
        for (var n = e, r = [];
            (n == null ? void 0 : n.cause) instanceof Error && r.length < 10;) {
            var o = kt(n.cause);
            r.push({
                message: n.cause.message,
                source: t,
                type: o == null ? void 0 : o.name,
                stack: o && kn(o)
            }), n = n.cause
        }
        return r.length ? r : void 0
    }
    var be = {
        AGENT: "agent",
        CONSOLE: "console",
        CUSTOM: "custom",
        LOGGER: "logger",
        NETWORK: "network",
        SOURCE: "source",
        REPORT: "report"
    };

    function $y(e) {
        var t = function(o, i) {
                var a = Ep({
                    stackTrace: o,
                    originalError: i,
                    startClocks: Zt(),
                    nonErrorPrefix: "Uncaught",
                    source: be.SOURCE,
                    handling: "unhandled"
                });
                e.notify(a)
            },
            n = Vy(t).stop,
            r = Hy(t).stop;
        return {
            stop: function() {
                n(), r()
            }
        }
    }

    function Vy(e) {
        return On(window, "onerror", function(t) {
            var n = t.parameters,
                r = n[0],
                o = n[1],
                i = n[2],
                a = n[3],
                l = n[4],
                s;
            l instanceof Error ? s = kt(l) : s = _y(r, o, i, a), e(s, l ? ? r)
        })
    }

    function Hy(e) {
        return On(window, "onunhandledrejection", function(t) {
            var n = t.parameters[0],
                r = n.reason || "Empty reason",
                o = kt(r);
            e(o, r)
        })
    }

    function Gy(e) {
        var t = he({
            version: "5.31.1",
            onReady: function(n) {
                n()
            }
        }, e);
        return Object.defineProperty(t, "_setDebug", {
            get: function() {
                return g0
            },
            enumerable: !1
        }), t
    }

    function Wy(e, t, n) {
        var r = e[t];
        r && !r.q && r.version && se.warn("SDK is loaded more than once. This is unsupported and might have unexpected behavior."), e[t] = n, r && r.q && r.q.forEach(function(o) {
            return Xd(o, "onReady callback threw an error:")()
        })
    }

    function Lp(e, t) {
        t.silentMultipleInit || se.error("".concat(e, " is already initialized."))
    }

    function Ln(e, t, n, r, o) {
        return Xs(e, t, [n], r, o)
    }

    function Xs(e, t, n, r, o) {
        var i = o === void 0 ? {} : o,
            a = i.once,
            l = i.capture,
            s = i.passive,
            u = B(function(y) {
                !y.isTrusted && !y.__ddIsTrusted && !e.allowUntrustedEvents || (a && h(), r(y))
            }),
            c = s ? {
                capture: l,
                passive: s
            } : l,
            f = window.EventTarget && t instanceof EventTarget ? window.EventTarget.prototype : t,
            d = sr(f, "addEventListener");
        n.forEach(function(y) {
            return d.call(t, y, u, c)
        });

        function h() {
            var y = sr(f, "removeEventListener");
            n.forEach(function(m) {
                return y.call(t, m, u, c)
            })
        }
        return {
            stop: h
        }
    }
    var na = {
        intervention: "intervention",
        deprecation: "deprecation",
        cspViolation: "csp_violation"
    };

    function Ky(e, t) {
        var n = [];
        yn(t, na.cspViolation) && n.push(Yy(e));
        var r = t.filter(function(o) {
            return o !== na.cspViolation
        });
        return r.length && n.push(Qy(r)), ap.apply(void 0, n)
    }

    function Qy(e) {
        return new fe(function(t) {
            if (window.ReportingObserver) {
                var n = B(function(o, i) {
                        return o.forEach(function(a) {
                            return t.notify(Jy(a))
                        })
                    }),
                    r = new window.ReportingObserver(n, {
                        types: e,
                        buffered: !0
                    });
                return r.observe(),
                    function() {
                        r.disconnect()
                    }
            }
        })
    }

    function Yy(e) {
        return new fe(function(t) {
            var n = Ln(e, document, "securitypolicyviolation", function(r) {
                t.notify(Zy(r))
            }).stop;
            return n
        })
    }

    function Jy(e) {
        var t = e.type,
            n = e.body;
        return Pp({
            type: n.id,
            message: "".concat(t, ": ").concat(n.message),
            originalError: e,
            stack: Ip(n.id, n.message, n.sourceFile, n.lineNumber, n.columnNumber)
        })
    }

    function Zy(e) {
        var t = "'".concat(e.blockedURI, "' blocked by '").concat(e.effectiveDirective, "' directive");
        return Pp({
            type: e.effectiveDirective,
            message: "".concat(na.cspViolation, ": ").concat(t),
            originalError: e,
            csp: {
                disposition: e.disposition
            },
            stack: Ip(e.effectiveDirective, e.originalPolicy ? "".concat(t, ' of the policy "').concat(w0(e.originalPolicy, 100, "..."), '"') : "no policy", e.sourceFile, e.lineNumber, e.columnNumber)
        })
    }

    function Pp(e) {
        return he({
            startClocks: Zt(),
            source: be.REPORT,
            handling: "unhandled"
        }, e)
    }

    function Ip(e, t, n, r, o) {
        return n ? kn({
            name: e,
            message: t,
            stack: [{
                func: "?",
                url: n,
                line: r ? ? void 0,
                column: o ? ? void 0
            }]
        }) : void 0
    }

    function Np(e, t) {
        var n = window.__ddBrowserSdkExtensionCallback;
        n && n({
            type: e,
            payload: t
        })
    }

    function eu(e) {
        return e === null ? "null" : Array.isArray(e) ? "array" : typeof e
    }

    function ra(e, t, n) {
        if (n === void 0 && (n = qy()), t === void 0) return e;
        if (typeof t != "object" || t === null) return t;
        if (t instanceof Date) return new Date(t.getTime());
        if (t instanceof RegExp) {
            var r = t.flags || [t.global ? "g" : "", t.ignoreCase ? "i" : "", t.multiline ? "m" : "", t.sticky ? "y" : "", t.unicode ? "u" : ""].join("");
            return new RegExp(t.source, r)
        }
        if (!n.hasAlreadyBeenSeen(t)) {
            if (Array.isArray(t)) {
                for (var o = Array.isArray(e) ? e : [], i = 0; i < t.length; ++i) o[i] = ra(o[i], t[i], n);
                return o
            }
            var a = eu(e) === "object" ? e : {};
            for (var l in t) Object.prototype.hasOwnProperty.call(t, l) && (a[l] = ra(a[l], t[l], n));
            return a
        }
    }

    function _p(e) {
        return ra(void 0, e)
    }

    function pr() {
        for (var e = [], t = 0; t < arguments.length; t++) e[t] = arguments[t];
        for (var n, r = 0, o = e; r < o.length; r++) {
            var i = o[r];
            i != null && (n = ra(n, i))
        }
        return n
    }

    function qy() {
        if (typeof WeakSet < "u") {
            var e = new WeakSet;
            return {
                hasAlreadyBeenSeen: function(n) {
                    var r = e.has(n);
                    return r || e.add(n), r
                }
            }
        }
        var t = [];
        return {
            hasAlreadyBeenSeen: function(n) {
                var r = t.indexOf(n) >= 0;
                return r || t.push(n), r
            }
        }
    }

    function Xy() {
        var e, t = window.navigator;
        return {
            status: t.onLine ? "connected" : "not_connected",
            interfaces: t.connection && t.connection.type ? [t.connection.type] : void 0,
            effective_type: (e = t.connection) === null || e === void 0 ? void 0 : e.effectiveType
        }
    }

    function e1(e) {
        var t = new Set;
        return e.forEach(function(n) {
            return t.add(n)
        }), zs(t)
    }

    function Rp(e, t) {
        var n = e.indexOf(t);
        n >= 0 && e.splice(n, 1)
    }
    var t1 = 500;

    function Mp() {
        var e = [],
            t = function(o) {
                var i = e.push(o);
                i > t1 && e.splice(0, 1)
            },
            n = function(o) {
                Rp(e, o)
            },
            r = function(o) {
                e.forEach(function(i) {
                    return i(o)
                }), e.length = 0
            };
        return {
            add: t,
            remove: n,
            drain: r
        }
    }
    var Pn = {
            log: "log",
            configuration: "configuration",
            usage: "usage"
        },
        n1 = ["https://www.datadoghq-browser-agent.com", "https://www.datad0g-browser-agent.com", "https://d3uc069fcn7uxw.cloudfront.net", "https://d20xtzwzcl0ceb.cloudfront.net", "http://localhost", "<anonymous>"],
        r1 = [ey],
        Dp = Mp(),
        vr = function(e) {
            Dp.add(function() {
                return vr(e)
            })
        };

    function o1(e, t) {
        var n, r, o = new fe,
            i = new Set,
            a = !yn(r1, t.site) && $i(t.telemetrySampleRate),
            l = (n = {}, n[Pn.log] = a, n[Pn.configuration] = a && $i(t.telemetryConfigurationSampleRate), n[Pn.usage] = a && $i(t.telemetryUsageSampleRate), n),
            s = i1();
        vr = function(c) {
            var f = En(c);
            if (l[c.type] && i.size < t.maxTelemetryEventsPerPage && !i.has(f)) {
                var d = u(e, c, s);
                o.notify(d), Np("telemetry", d), i.add(f)
            }
        }, v0(zp);

        function u(c, f, d) {
            return pr({
                type: "telemetry",
                date: Jt(),
                service: c,
                version: "5.31.1",
                source: "browser",
                _dd: {
                    format_version: 2
                },
                telemetry: pr(f, {
                    runtime_env: d,
                    connectivity: Xy(),
                    sdk_setup: "npm"
                }),
                experimental_features: zs(wy())
            }, r !== void 0 ? r() : {})
        }
        return {
            setContextProvider: function(c) {
                r = c
            },
            observable: o,
            enabled: a
        }
    }

    function i1() {
        return {
            is_local_file: window.location.protocol === "file:",
            is_worker: "WorkerGlobalScope" in self
        }
    }

    function a1() {
        Dp.drain()
    }

    function l1(e) {
        return e.site === q0
    }

    function jp(e, t) {
        bs(ie.debug, e, t), vr(he({
            type: Pn.log,
            message: e,
            status: "debug"
        }, t))
    }

    function zp(e, t) {
        vr(he({
            type: Pn.log,
            status: "error"
        }, c1(e), t))
    }

    function s1(e) {
        vr({
            type: Pn.configuration,
            configuration: e
        })
    }

    function u1(e) {
        vr({
            type: Pn.usage,
            usage: e
        })
    }

    function c1(e) {
        if (e instanceof Error) {
            var t = kt(e);
            return {
                error: {
                    kind: t.name,
                    stack: kn(f1(t))
                },
                message: t.message
            }
        }
        return {
            error: {
                stack: xp
            },
            message: "".concat("Uncaught", " ").concat(En(e))
        }
    }

    function f1(e) {
        return e.stack = e.stack.filter(function(t) {
            return !t.url || n1.some(function(n) {
                return Fs(t.url, n)
            })
        }), e
    }
    var oa = 1 / 0,
        d1 = mn;

    function p1(e) {
        var t = e.expireDelay,
            n = e.maxEntries,
            r = [],
            o = As(function() {
                return i()
            }, d1);

        function i() {
            for (var d = Vi() - t; r.length > 0 && r[r.length - 1].endTime < d;) r.pop()
        }

        function a(d, h) {
            var y = {
                value: d,
                startTime: h,
                endTime: oa,
                remove: function() {
                    Rp(r, y)
                },
                close: function(m) {
                    y.endTime = m
                }
            };
            return n && r.length >= n && r.pop(), r.unshift(y), y
        }

        function l(d, h) {
            d === void 0 && (d = oa), h === void 0 && (h = {
                returnInactive: !1
            });
            for (var y = 0, m = r; y < m.length; y++) {
                var E = m[y];
                if (E.startTime <= d) {
                    if (h.returnInactive || d <= E.endTime) return E.value;
                    break
                }
            }
        }

        function s(d) {
            var h = r[0];
            h && h.endTime === oa && h.close(d)
        }

        function u(d, h) {
            d === void 0 && (d = oa), h === void 0 && (h = 0);
            var y = a0(d, h);
            return r.filter(function(m) {
                return m.startTime <= y && d <= m.endTime
            }).map(function(m) {
                return m.value
            })
        }

        function c() {
            r = []
        }

        function f() {
            ip(o)
        }
        return {
            add: a,
            find: l,
            closeActive: s,
            findAll: u,
            reset: c,
            stop: f
        }
    }
    var v1 = mn,
        g1 = Vs;

    function h1(e, t, n, r) {
        var o = new fe,
            i = new fe,
            a = Q0(e.sessionStoreStrategyType, t, n),
            l = p1({
                expireDelay: g1
            });
        a.renewObservable.subscribe(function() {
            l.add(s(), Vi()), o.notify()
        }), a.expireObservable.subscribe(function() {
            i.notify(), l.closeActive(Vi())
        }), a.expandOrRenewSession(), l.add(s(), o0().relative), r.observable.subscribe(function() {
            r.isGranted() ? a.expandOrRenewSession() : a.expire()
        }), m1(e, function() {
            r.isGranted() && a.expandOrRenewSession()
        }), y1(e, function() {
            return a.expandSession()
        }), w1(e, function() {
            return a.restartSession()
        });

        function s() {
            return {
                id: a.getSession().id,
                trackingType: a.getSession()[t],
                isReplayForced: !!a.getSession().forcedReplay
            }
        }
        return {
            findSession: function(u, c) {
                return l.find(u, c)
            },
            renewObservable: o,
            expireObservable: i,
            sessionStateUpdateObservable: a.sessionStateUpdateObservable,
            expire: a.expire,
            updateSessionState: a.updateSessionState
        }
    }

    function m1(e, t) {
        Xs(e, window, ["click", "touchstart", "keydown", "scroll"], t, {
            capture: !0,
            passive: !0
        }).stop
    }

    function y1(e, t) {
        var n = function() {
            document.visibilityState === "visible" && t()
        };
        Ln(e, document, "visibilitychange", n).stop, As(n, v1)
    }

    function w1(e, t) {
        Ln(e, window, "resume", t, {
            capture: !0
        }).stop
    }

    function Fp(e) {
        return e >= 500
    }

    function C1(e) {
        try {
            return e.clone()
        } catch {
            return
        }
    }
    var S1 = 80 * Et,
        x1 = 32,
        Tp = 3 * tp,
        E1 = mn,
        bp = fo;

    function Ap(e, t, n, r, o) {
        t.transportStatus === 0 && t.queuedPayloads.size() === 0 && t.bandwidthMonitor.canHandle(e) ? Bp(e, t, n, {
            onSuccess: function() {
                return $p(0, t, n, r, o)
            },
            onFailure: function() {
                t.queuedPayloads.enqueue(e), Up(t, n, r, o)
            }
        }) : t.queuedPayloads.enqueue(e)
    }

    function Up(e, t, n, r) {
        e.transportStatus === 2 && go(function() {
            var o = e.queuedPayloads.first();
            Bp(o, e, t, {
                onSuccess: function() {
                    e.queuedPayloads.dequeue(), e.currentBackoffTime = bp, $p(1, e, t, n, r)
                },
                onFailure: function() {
                    e.currentBackoffTime = Math.min(E1, e.currentBackoffTime * 2), Up(e, t, n, r)
                }
            })
        }, e.currentBackoffTime)
    }

    function Bp(e, t, n, r) {
        var o = r.onSuccess,
            i = r.onFailure;
        t.bandwidthMonitor.add(e), n(e, function(a) {
            t.bandwidthMonitor.remove(e), k1(a) ? (t.transportStatus = t.bandwidthMonitor.ongoingRequestCount > 0 ? 1 : 2, e.retry = {
                count: e.retry ? e.retry.count + 1 : 1,
                lastFailureStatus: a.status
            }, i()) : (t.transportStatus = 0, o())
        })
    }

    function $p(e, t, n, r, o) {
        e === 0 && t.queuedPayloads.isFull() && !t.queueFullReported && (o({
            message: "Reached max ".concat(r, " events size queued for upload: ").concat(Tp / tp, "MiB"),
            source: be.AGENT,
            startClocks: Zt()
        }), t.queueFullReported = !0);
        var i = t.queuedPayloads;
        for (t.queuedPayloads = Vp(); i.size() > 0;) Ap(i.dequeue(), t, n, r, o)
    }

    function k1(e) {
        return e.type !== "opaque" && (e.status === 0 && !navigator.onLine || e.status === 408 || e.status === 429 || Fp(e.status))
    }

    function O1() {
        return {
            transportStatus: 0,
            currentBackoffTime: bp,
            bandwidthMonitor: L1(),
            queuedPayloads: Vp(),
            queueFullReported: !1
        }
    }

    function Vp() {
        var e = [];
        return {
            bytesCount: 0,
            enqueue: function(t) {
                this.isFull() || (e.push(t), this.bytesCount += t.bytesCount)
            },
            first: function() {
                return e[0]
            },
            dequeue: function() {
                var t = e.shift();
                return t && (this.bytesCount -= t.bytesCount), t
            },
            size: function() {
                return e.length
            },
            isFull: function() {
                return this.bytesCount >= Tp
            }
        }
    }

    function L1() {
        return {
            ongoingRequestCount: 0,
            ongoingByteCount: 0,
            canHandle: function(e) {
                return this.ongoingRequestCount === 0 || this.ongoingByteCount + e.bytesCount <= S1 && this.ongoingRequestCount < x1
            },
            add: function(e) {
                this.ongoingRequestCount += 1, this.ongoingByteCount += e.bytesCount
            },
            remove: function(e) {
                this.ongoingRequestCount -= 1, this.ongoingByteCount -= e.bytesCount
            }
        }
    }

    function P1(e, t, n) {
        var r = O1(),
            o = function(i, a) {
                return _1(e, t, i, a)
            };
        return {
            send: function(i) {
                Ap(i, r, o, e.trackType, n)
            },
            sendOnExit: function(i) {
                I1(e, t, i)
            }
        }
    }

    function I1(e, t, n) {
        var r = !!navigator.sendBeacon && n.bytesCount < t;
        if (r) try {
            var o = e.build("beacon", n),
                i = navigator.sendBeacon(o, n.data);
            if (i) return
        } catch (l) {
            N1(l)
        }
        var a = e.build("xhr", n);
        tu(a, n.data)
    }
    var Hp = !1;

    function N1(e) {
        Hp || (Hp = !0, zp(e))
    }

    function _1(e, t, n, r) {
        var o = R1() && n.bytesCount < t;
        if (o) {
            var i = e.build("fetch", n);
            fetch(i, {
                method: "POST",
                body: n.data,
                keepalive: !0,
                mode: "cors"
            }).then(B(function(l) {
                return r == null ? void 0 : r({
                    status: l.status,
                    type: l.type
                })
            }), B(function() {
                var l = e.build("xhr", n);
                tu(l, n.data, r)
            }))
        } else {
            var a = e.build("xhr", n);
            tu(a, n.data, r)
        }
    }

    function R1() {
        try {
            return window.Request && "keepalive" in new Request("http://a")
        } catch {
            return !1
        }
    }

    function tu(e, t, n) {
        var r = new XMLHttpRequest;
        r.open("POST", e, !0), t instanceof Blob && r.setRequestHeader("Content-Type", t.type), Ln({
            allowUntrustedEvents: !0
        }, r, "loadend", function() {
            n == null || n({
                status: r.status
            })
        }, {
            once: !0
        }), r.send(t)
    }

    function nu() {
        var e = M1();
        if (e) return {
            getCapabilities: function() {
                var t;
                return JSON.parse(((t = e.getCapabilities) === null || t === void 0 ? void 0 : t.call(e)) || "[]")
            },
            getPrivacyLevel: function() {
                var t;
                return (t = e.getPrivacyLevel) === null || t === void 0 ? void 0 : t.call(e)
            },
            getAllowedWebViewHosts: function() {
                return JSON.parse(e.getAllowedWebViewHosts())
            },
            send: function(t, n, r) {
                var o = r ? {
                    id: r
                } : void 0;
                e.send(JSON.stringify({
                    eventType: t,
                    event: n,
                    view: o
                }))
            }
        }
    }

    function ia(e) {
        var t;
        e === void 0 && (e = (t = qt().location) === null || t === void 0 ? void 0 : t.hostname);
        var n = nu();
        return !!n && n.getAllowedWebViewHosts().some(function(r) {
            return e === r || f0(e, ".".concat(r))
        })
    }

    function M1() {
        return qt().DatadogEventBridge
    }
    var aa = {
        HIDDEN: "visibility_hidden",
        UNLOADING: "before_unload",
        PAGEHIDE: "page_hide",
        FROZEN: "page_frozen"
    };

    function D1(e) {
        return new fe(function(t) {
            var n = Xs(e, window, ["visibilitychange", "freeze"], function(o) {
                    o.type === "visibilitychange" && document.visibilityState === "hidden" ? t.notify({
                        reason: aa.HIDDEN
                    }) : o.type === "freeze" && t.notify({
                        reason: aa.FROZEN
                    })
                }, {
                    capture: !0
                }).stop,
                r = Ln(e, window, "beforeunload", function() {
                    t.notify({
                        reason: aa.UNLOADING
                    })
                }).stop;
            return function() {
                n(), r()
            }
        })
    }

    function j1(e) {
        return yn(Hi(aa), e)
    }

    function z1(e) {
        var t = e.encoder,
            n = e.request,
            r = e.flushController,
            o = e.messageBytesLimit,
            i = {},
            a = r.flushObservable.subscribe(function(d) {
                return f(d)
            });

        function l(d, h, y) {
            r.notifyBeforeAddMessage(h), y !== void 0 ? (i[y] = d, r.notifyAfterAddMessage()) : t.write(t.isEmpty ? d : `
`.concat(d), function(m) {
                r.notifyAfterAddMessage(m - h)
            })
        }

        function s(d) {
            return d !== void 0 && i[d] !== void 0
        }

        function u(d) {
            var h = i[d];
            delete i[d];
            var y = t.estimateEncodedBytesCount(h);
            r.notifyAfterRemoveMessage(y)
        }

        function c(d, h) {
            var y = En(d),
                m = t.estimateEncodedBytesCount(y);
            if (m >= o) {
                se.warn("Discarded a message whose size was bigger than the maximum allowed size ".concat(o, "KB. ").concat(Bi, " ").concat(qd, "/#technical-limitations"));
                return
            }
            s(h) && u(h), l(y, m, h)
        }

        function f(d) {
            var h = Hi(i).join(`
`);
            i = {};
            var y = j1(d.reason),
                m = y ? n.sendOnExit : n.send;
            if (y && t.isAsync) {
                var E = t.finishSync();
                E.outputBytesCount && m(Gp(E));
                var v = [E.pendingData, h].filter(Boolean).join(`
`);
                v && m({
                    data: v,
                    bytesCount: js(v)
                })
            } else h && t.write(t.isEmpty ? h : `
`.concat(h)), t.finish(function(p) {
                m(Gp(p))
            })
        }
        return {
            flushController: r,
            add: c,
            upsert: c,
            stop: a.unsubscribe
        }
    }

    function Gp(e) {
        var t;
        return typeof e.output == "string" ? t = e.output : t = new Blob([e.output], {
            type: "text/plain"
        }), {
            data: t,
            bytesCount: e.outputBytesCount,
            encoding: e.encoding
        }
    }

    function F1(e) {
        var t = e.messagesLimit,
            n = e.bytesLimit,
            r = e.durationLimit,
            o = e.pageExitObservable,
            i = e.sessionExpireObservable,
            a = o.subscribe(function(m) {
                return f(m.reason)
            }),
            l = i.subscribe(function() {
                return f("session_expire")
            }),
            s = new fe(function() {
                return function() {
                    a.unsubscribe(), l.unsubscribe()
                }
            }),
            u = 0,
            c = 0;

        function f(m) {
            if (c !== 0) {
                var E = c,
                    v = u;
                c = 0, u = 0, y(), s.notify({
                    reason: m,
                    messagesCount: E,
                    bytesCount: v
                })
            }
        }
        var d;

        function h() {
            d === void 0 && (d = go(function() {
                f("duration_limit")
            }, r))
        }

        function y() {
            op(d), d = void 0
        }
        return {
            flushObservable: s,
            get messagesCount() {
                return c
            },
            notifyBeforeAddMessage: function(m) {
                u + m >= n && f("bytes_limit"), c += 1, u += m, h()
            },
            notifyAfterAddMessage: function(m) {
                m === void 0 && (m = 0), u += m, c >= t ? f("messages_limit") : u >= n && f("bytes_limit")
            },
            notifyAfterRemoveMessage: function(m) {
                u -= m, c -= 1, c === 0 && y()
            }
        }
    }

    function Wp(e, t, n, r, o, i, a) {
        a === void 0 && (a = z1);
        var l = u(e, t),
            s = n && u(e, n);

        function u(c, f) {
            var d = f.endpoint,
                h = f.encoder;
            return a({
                encoder: h,
                request: P1(d, c.batchBytesLimit, r),
                flushController: F1({
                    messagesLimit: c.batchMessagesLimit,
                    bytesLimit: c.batchBytesLimit,
                    durationLimit: c.flushTimeout,
                    pageExitObservable: o,
                    sessionExpireObservable: i
                }),
                messageBytesLimit: c.messageBytesLimit
            })
        }
        return {
            flushObservable: l.flushController.flushObservable,
            add: function(c, f) {
                f === void 0 && (f = !0), l.add(c), s && f && s.add(n.transformMessage ? n.transformMessage(c) : c)
            },
            upsert: function(c, f) {
                l.upsert(c, f), s && s.upsert(n.transformMessage ? n.transformMessage(c) : c, f)
            },
            stop: function() {
                l.stop(), s && s.stop()
            }
        }
    }

    function la() {
        var e = "",
            t = 0;
        return {
            isAsync: !1,
            get isEmpty() {
                return !e
            },
            write: function(n, r) {
                var o = js(n);
                t += o, e += n, r && r(o)
            },
            finish: function(n) {
                n(this.finishSync())
            },
            finishSync: function() {
                var n = {
                    output: e,
                    outputBytesCount: t,
                    rawBytesCount: t,
                    pendingData: ""
                };
                return e = "", t = 0, n
            },
            estimateEncodedBytesCount: function(n) {
                return n.length
            }
        }
    }
    var T1 = function() {
        function e() {
            this.callbacks = {}
        }
        return e.prototype.notify = function(t, n) {
            var r = this.callbacks[t];
            r && r.forEach(function(o) {
                return o(n)
            })
        }, e.prototype.subscribe = function(t, n) {
            var r = this;
            return this.callbacks[t] || (this.callbacks[t] = []), this.callbacks[t].push(n), {
                unsubscribe: function() {
                    r.callbacks[t] = r.callbacks[t].filter(function(o) {
                        return n !== o
                    })
                }
            }
        }, e
    }();

    function b1(e, t, n) {
        var r = 0,
            o = !1;
        return {
            isLimitReached: function() {
                if (r === 0 && go(function() {
                        r = 0
                    }, mn), r += 1, r <= t || o) return o = !1, !1;
                if (r === t + 1) {
                    o = !0;
                    try {
                        n({
                            message: "Reached max number of ".concat(e, "s by minute: ").concat(t),
                            source: be.AGENT,
                            startClocks: Zt()
                        })
                    } finally {
                        o = !1
                    }
                }
                return !0
            }
        }
    }
    var ru, ou = new WeakMap;

    function A1(e) {
        return ru || (ru = U1(e)), ru
    }

    function U1(e) {
        return new fe(function(t) {
            var n = On(XMLHttpRequest.prototype, "open", B1).stop,
                r = On(XMLHttpRequest.prototype, "send", function(i) {
                    $1(i, e, t)
                }, {
                    computeHandlingStack: !0
                }).stop,
                o = On(XMLHttpRequest.prototype, "abort", V1).stop;
            return function() {
                n(), r(), o()
            }
        })
    }

    function B1(e) {
        var t = e.target,
            n = e.parameters,
            r = n[0],
            o = n[1];
        ou.set(t, {
            state: "open",
            method: String(r).toUpperCase(),
            url: Ks(String(o))
        })
    }

    function $1(e, t, n) {
        var r = e.target,
            o = e.handlingStack,
            i = ou.get(r);
        if (i) {
            var a = i;
            a.state = "start", a.startClocks = Zt(), a.isAborted = !1, a.xhr = r, a.handlingStack = o;
            var l = !1,
                s = On(r, "onreadystatechange", function() {
                    r.readyState === XMLHttpRequest.DONE && u()
                }).stop,
                u = function() {
                    if (c(), s(), !l) {
                        l = !0;
                        var f = i;
                        f.state = "complete", f.duration = i0(a.startClocks.timeStamp, Jt()), f.status = r.status, n.notify(d0(f))
                    }
                },
                c = Ln(t, r, "loadend", u).stop;
            n.notify(a)
        }
    }

    function V1(e) {
        var t = e.target,
            n = ou.get(t);
        n && (n.isAborted = !0)
    }
    var iu;

    function Kp() {
        return iu || (iu = H1()), iu
    }

    function H1() {
        return new fe(function(e) {
            if (window.fetch) {
                var t = On(window, "fetch", function(n) {
                    return G1(n, e)
                }, {
                    computeHandlingStack: !0
                }).stop;
                return t
            }
        })
    }

    function G1(e, t) {
        var n = e.parameters,
            r = e.onPostCall,
            o = e.handlingStack,
            i = n[0],
            a = n[1],
            l = a && a.method;
        l === void 0 && i instanceof Request && (l = i.method);
        var s = l !== void 0 ? String(l).toUpperCase() : "GET",
            u = i instanceof Request ? i.url : Ks(String(i)),
            c = Zt(),
            f = {
                state: "start",
                init: a,
                input: i,
                method: s,
                startClocks: c,
                url: u,
                handlingStack: o
            };
        t.notify(f), n[0] = f.input, n[1] = f.init, r(function(d) {
            return W1(t, d, f)
        })
    }

    function W1(e, t, n) {
        var r = n;

        function o(i) {
            r.state = "resolve", he(r, i), e.notify(r)
        }
        t.then(B(function(i) {
            o({
                response: i,
                responseType: i.type,
                status: i.status,
                isAborted: !1
            })
        }), B(function(i) {
            var a, l;
            o({
                status: 0,
                isAborted: ((l = (a = r.init) === null || a === void 0 ? void 0 : a.signal) === null || l === void 0 ? void 0 : l.aborted) || i instanceof DOMException && i.code === DOMException.ABORT_ERR,
                error: i
            })
        }))
    }
    var au = {};

    function K1(e) {
        var t = e.map(function(n) {
            return au[n] || (au[n] = Q1(n)), au[n]
        });
        return ap.apply(void 0, t)
    }

    function Q1(e) {
        return new fe(function(t) {
            var n = st[e];
            return st[e] = function() {
                    for (var r = [], o = 0; o < arguments.length; o++) r[o] = arguments[o];
                    n.apply(console, r);
                    var i = ta();
                    vo(function() {
                        t.notify(Y1(r, e, i))
                    })
                },
                function() {
                    st[e] = n
                }
        })
    }

    function Y1(e, t, n) {
        var r = e.map(function(a) {
                return J1(a)
            }).join(" "),
            o;
        if (t === ie.error) {
            var i = u0(e, function(a) {
                return a instanceof Error
            });
            o = {
                stack: i ? kn(kt(i)) : void 0,
                fingerprint: kp(i),
                causes: i ? Op(i, "console") : void 0,
                startClocks: Zt(),
                message: r,
                source: be.CONSOLE,
                handling: "handled",
                handlingStack: n
            }
        }
        return {
            api: t,
            message: r,
            error: o,
            handlingStack: n
        }
    }

    function J1(e) {
        return typeof e == "string" ? Ot(e) : e instanceof Error ? Sp(kt(e)) : En(Ot(e), void 0, 2)
    }

    function lu(e) {
        var t = {},
            n = new fe,
            r = {
                getContext: function() {
                    return _p(t)
                },
                setContext: function(o) {
                    eu(o) === "object" ? (t = Ot(o), e && e.updateCustomerData(t)) : r.clearContext(), n.notify()
                },
                setContextProperty: function(o, i) {
                    t[o] = Ot(i), e && e.updateCustomerData(t), n.notify()
                },
                removeContextProperty: function(o) {
                    delete t[o], e && e.updateCustomerData(t), n.notify()
                },
                clearContext: function() {
                    t = {}, e && e.resetCustomerData(), n.notify()
                },
                changeObservable: n
            };
        return r
    }
    var Z1 = "_dd_c",
        q1 = [];

    function Qp(e, t, n, r) {
        var o = X1(n, r);
        q1.push(Ln(e, window, "storage", function(s) {
            var u = s.key;
            o === u && i()
        })), t.changeObservable.subscribe(a), t.setContext(pr(l(), t.getContext()));

        function i() {
            t.setContext(l())
        }

        function a() {
            localStorage.setItem(o, JSON.stringify(t.getContext()))
        }

        function l() {
            var s = localStorage.getItem(o);
            return s !== null ? JSON.parse(s) : {}
        }
    }

    function X1(e, t) {
        return "".concat(Z1, "_").concat(e, "_").concat(t)
    }
    var ew = 3 * Et,
        tw = 16 * Et,
        nw = 200;

    function rw(e) {
        e === void 0 && (e = 2);
        var t = new Map,
            n = !1;

        function r(o) {
            if (o === void 0 && (o = 0), !(n || e === 0)) {
                var i = e === 2 ? ew : tw,
                    a = o;
                t.forEach(function(l) {
                    a += l.getBytesCount()
                }), a > i && (ow(i), n = !0)
            }
        }
        return {
            createDetachedTracker: function() {
                var o = Yp(function() {
                    return r(o.getBytesCount())
                });
                return o
            },
            getOrCreateTracker: function(o) {
                return t.has(o) || t.set(o, Yp(r)), t.get(o)
            },
            setCompressionStatus: function(o) {
                e === 0 && (e = o, r())
            },
            getCompressionStatus: function() {
                return e
            },
            stop: function() {
                t.forEach(function(o) {
                    return o.stop()
                }), t.clear()
            }
        }
    }

    function Yp(e) {
        var t = 0,
            n = lp(function(a) {
                t = js(En(a)), e()
            }, nw),
            r = n.throttled,
            o = n.cancel,
            i = function() {
                o(), t = 0
            };
        return {
            updateCustomerData: function(a) {
                Ts(a) ? i() : r(a)
            },
            resetCustomerData: i,
            getBytesCount: function() {
                return t
            },
            stop: function() {
                o()
            }
        }
    }

    function ow(e) {
        se.warn("Customer data exceeds the recommended ".concat(e / Et, "KiB threshold. ").concat(Bi, " ").concat(qd, "/#customer-data-exceeds-the-recommended-threshold-warning"))
    }

    function iw(e, t, n) {
        var r = e.getReader(),
            o = [],
            i = 0;
        a();

        function a() {
            r.read().then(B(function(s) {
                if (s.done) {
                    l();
                    return
                }
                o.push(s.value), i += s.value.length, i > n.bytesLimit ? l() : a()
            }), B(function(s) {
                return t(s)
            }))
        }

        function l() {
            r.cancel().catch(Xt);
            var s, u; {
                var c;
                if (o.length === 1) c = o[0];
                else {
                    c = new Uint8Array(i);
                    var f = 0;
                    o.forEach(function(d) {
                        c.set(d, f), f += d.length
                    })
                }
                s = c.slice(0, n.bytesLimit), u = c.length > n.bytesLimit
            }
            t(void 0, s, u)
        }
    }
    var aw = "datadog-synthetics-public-id",
        lw = "datadog-synthetics-result-id",
        sw = "datadog-synthetics-injects-rum";

    function Jp() {
        return !!(window._DATADOG_SYNTHETICS_INJECTS_RUM || Cn(sw))
    }

    function uw() {
        var e = window._DATADOG_SYNTHETICS_PUBLIC_ID || Cn(aw);
        return typeof e == "string" ? e : void 0
    }

    function cw() {
        var e = window._DATADOG_SYNTHETICS_RESULT_ID || Cn(lw);
        return typeof e == "string" ? e : void 0
    }

    function Zp(e) {
        var t = he({}, e),
            n = ["id", "name", "email"];
        return n.forEach(function(r) {
            r in t && (t[r] = String(t[r]))
        }), t
    }

    function fw(e) {
        var t = eu(e) === "object";
        return t || se.error("Unsupported user:", e), t
    }
    var Xe;

    function sa(e, t, n) {
        var r = n.getHandler(),
            o = Array.isArray(r) ? r : [r];
        return qp[e] >= qp[n.getLevel()] && yn(o, t)
    }
    var D = {
            ok: "ok",
            debug: "debug",
            info: "info",
            notice: "notice",
            warn: "warn",
            error: "error",
            critical: "critical",
            alert: "alert",
            emerg: "emerg"
        },
        qp = (Xe = {}, Xe[D.ok] = 0, Xe[D.debug] = 1, Xe[D.info] = 2, Xe[D.notice] = 4, Xe[D.warn] = 5, Xe[D.error] = 6, Xe[D.critical] = 7, Xe[D.alert] = 8, Xe[D.emerg] = 9, Xe);

    function ua(e, t) {
        var n = t === void 0 ? {} : t,
            r = n.includeMessage,
            o = r === void 0 ? !1 : r;
        return {
            stack: e.stack,
            kind: e.type,
            message: o ? e.message : void 0,
            causes: e.causes,
            fingerprint: e.fingerprint,
            handling: e.handling
        }
    }
    var dw = function(e, t, n, r) {
            var o = arguments.length,
                i = o < 3 ? t : r === null ? r = Object.getOwnPropertyDescriptor(t, n) : r,
                a;
            if (typeof Reflect == "object" && typeof Reflect.decorate == "function") i = Reflect.decorate(e, t, n, r);
            else
                for (var l = e.length - 1; l >= 0; l--)(a = e[l]) && (i = (o < 3 ? a(i) : o > 3 ? a(t, n, i) : a(t, n)) || i);
            return o > 3 && i && Object.defineProperty(t, n, i), i
        },
        wo = {
            console: "console",
            http: "http",
            silent: "silent"
        },
        pw = Object.keys(D),
        et = function() {
            function e(t, n, r, o, i, a) {
                o === void 0 && (o = wo.http), i === void 0 && (i = D.debug), a === void 0 && (a = {}), this.handleLogStrategy = t, this.handlerType = o, this.level = i, this.contextManager = lu(n), this.contextManager.setContext(a), r && this.contextManager.setContextProperty("logger", {
                    name: r
                })
            }
            return e.prototype.logImplementation = function(t, n, r, o, i) {
                r === void 0 && (r = D.info);
                var a = Ot(n),
                    l;
                if (o != null) {
                    var s = Ep({
                        stackTrace: o instanceof Error ? kt(o) : void 0,
                        originalError: o,
                        nonErrorPrefix: "Provided",
                        source: be.LOGGER,
                        handling: "handled",
                        startClocks: Zt()
                    });
                    l = pr({
                        error: ua(s, {
                            includeMessage: !0
                        })
                    }, a)
                } else l = a;
                this.handleLogStrategy({
                    message: Ot(t),
                    context: l,
                    status: r
                }, this, i)
            }, e.prototype.log = function(t, n, r, o) {
                r === void 0 && (r = D.info);
                var i;
                sa(r, wo.http, this) && (i = ta()), this.logImplementation(t, n, r, o, i)
            }, e.prototype.setContext = function(t) {
                this.contextManager.setContext(t)
            }, e.prototype.getContext = function() {
                return this.contextManager.getContext()
            }, e.prototype.setContextProperty = function(t, n) {
                this.contextManager.setContextProperty(t, n)
            }, e.prototype.removeContextProperty = function(t) {
                this.contextManager.removeContextProperty(t)
            }, e.prototype.clearContext = function() {
                this.contextManager.clearContext()
            }, e.prototype.setHandler = function(t) {
                this.handlerType = t
            }, e.prototype.getHandler = function() {
                return this.handlerType
            }, e.prototype.setLevel = function(t) {
                this.level = t
            }, e.prototype.getLevel = function() {
                return this.level
            }, dw([h0], e.prototype, "logImplementation", null), e
        }();
    et.prototype.ok = Lt(D.ok), et.prototype.debug = Lt(D.debug), et.prototype.info = Lt(D.info), et.prototype.notice = Lt(D.notice), et.prototype.warn = Lt(D.warn), et.prototype.error = Lt(D.error), et.prototype.critical = Lt(D.critical), et.prototype.alert = Lt(D.alert), et.prototype.emerg = Lt(D.emerg);

    function Lt(e) {
        return function(t, n, r) {
            var o;
            sa(e, wo.http, this) && (o = ta()), this.logImplementation(t, n, e, r, o)
        }
    }

    function vw(e, t) {
        return {
            view: {
                referrer: document.referrer,
                url: window.location.href
            },
            context: e.getContext(),
            user: t.getContext()
        }
    }
    var gw = 32 * Et;

    function hw(e) {
        e.usePciIntake === !0 && e.site && e.site !== "datadoghq.com" && se.warn("PCI compliance for Logs is only available for Datadog organizations in the US1 site. Default intake will be used.");
        var t = gy(e),
            n = Xp(e.forwardConsoleLogs, Hi(ie), "Forward Console Logs"),
            r = Xp(e.forwardReports, Hi(na), "Forward Reports");
        if (!(!t || !n || !r)) return e.forwardErrorsToLogs && !yn(n, ie.error) && n.push(ie.error), he({
            forwardErrorsToLogs: e.forwardErrorsToLogs !== !1,
            forwardConsoleLogs: n,
            forwardReports: r,
            requestErrorResponseLengthLimit: gw,
            sendLogsAfterSessionExpiration: !!e.sendLogsAfterSessionExpiration
        }, t)
    }

    function Xp(e, t, n) {
        if (e === void 0) return [];
        if (!(e === "all" || Array.isArray(e) && e.every(function(r) {
                return yn(t, r)
            }))) {
            se.error("".concat(n, ' should be "all" or an array with allowed values "').concat(t.join('", "'), '"'));
            return
        }
        return e === "all" ? t : e1(e)
    }

    function mw(e) {
        var t = hy(e);
        return he({
            forward_errors_to_logs: e.forwardErrorsToLogs,
            forward_console_logs: e.forwardConsoleLogs,
            forward_reports: e.forwardReports,
            use_pci_intake: e.usePciIntake,
            send_logs_after_session_expiration: e.sendLogsAfterSessionExpiration
        }, t)
    }

    function yw(e, t, n) {
        var r = Mp(),
            o, i, a = t.observable.subscribe(l);

        function l() {
            if (!(!i || !o || !t.isGranted())) {
                a.unsubscribe();
                var s = n(o, i);
                r.drain(s)
            }
        }
        return {
            init: function(s) {
                if (!s) {
                    se.error("Missing configuration");
                    return
                }
                if (my(s.enableExperimentalFeatures), ia() && (s = ww(s)), o = s, i) {
                    Lp("DD_LOGS", s);
                    return
                }
                var u = hw(s);
                u && (i = u, Kp().subscribe(Xt), t.tryToInit(u.trackingConsent), l())
            },
            get initConfiguration() {
                return o
            },
            getInternalContext: Xt,
            handleLog: function(s, u, c, f, d) {
                f === void 0 && (f = e()), d === void 0 && (d = Jt()), r.add(function(h) {
                    return h.handleLog(s, u, c, f, d)
                })
            }
        }
    }

    function ww(e) {
        return he({}, e, {
            clientToken: "empty"
        })
    }
    var ev = "logs";

    function Cw(e) {
        var t = rw(),
            n = lu(t.getOrCreateTracker(2)),
            r = lu(t.getOrCreateTracker(1)),
            o = Y0();

        function i() {
            return vw(n, r)
        }
        var a = yw(i, o, function(u, c) {
                u.storeContextsAcrossPages && (Qp(c, n, ev, 2), Qp(c, r, ev, 1));
                var f = e(u, c, i, o);
                return a = Sw(u, f), f
            }),
            l = {},
            s = new et(function() {
                for (var u = [], c = 0; c < arguments.length; c++) u[c] = arguments[c];
                return a.handleLog.apply(a, u)
            }, t.createDetachedTracker());
        return Gy({
            logger: s,
            init: B(function(u) {
                return a.init(u)
            }),
            setTrackingConsent: B(function(u) {
                o.update(u), u1({
                    feature: "set-tracking-consent",
                    tracking_consent: u
                })
            }),
            getGlobalContext: B(function() {
                return n.getContext()
            }),
            setGlobalContext: B(function(u) {
                return n.setContext(u)
            }),
            setGlobalContextProperty: B(function(u, c) {
                return n.setContextProperty(u, c)
            }),
            removeGlobalContextProperty: B(function(u) {
                return n.removeContextProperty(u)
            }),
            clearGlobalContext: B(function() {
                return n.clearContext()
            }),
            createLogger: B(function(u, c) {
                return c === void 0 && (c = {}), l[u] = new et(function() {
                    for (var f = [], d = 0; d < arguments.length; d++) f[d] = arguments[d];
                    return a.handleLog.apply(a, f)
                }, t.createDetachedTracker(), Ot(u), c.handler, c.level, Ot(c.context)), l[u]
            }),
            getLogger: B(function(u) {
                return l[u]
            }),
            getInitConfiguration: B(function() {
                return _p(a.initConfiguration)
            }),
            getInternalContext: B(function(u) {
                return a.getInternalContext(u)
            }),
            setUser: B(function(u) {
                fw(u) && r.setContext(Zp(u))
            }),
            getUser: B(function() {
                return r.getContext()
            }),
            setUserProperty: B(function(u, c) {
                var f, d = Zp((f = {}, f[u] = c, f))[u];
                r.setContextProperty(u, d)
            }),
            removeUserProperty: B(function(u) {
                return r.removeContextProperty(u)
            }),
            clearUser: B(function() {
                return r.clearContext()
            })
        })
    }

    function Sw(e, t) {
        return he({
            init: function(n) {
                Lp("DD_LOGS", n)
            },
            initConfiguration: e
        }, t)
    }
    var xw = "logs";

    function Ew(e, t) {
        var n = h1(e, xw, function(r) {
            return Ow(e, r)
        }, t);
        return {
            findTrackedSession: function(r, o) {
                o === void 0 && (o = {
                    returnInactive: !1
                });
                var i = n.findSession(r, o);
                return i && i.trackingType === "1" ? {
                    id: i.id
                } : void 0
            },
            expireObservable: n.expireObservable
        }
    }

    function kw(e) {
        var t = tv(e) === "1",
            n = t ? {} : void 0;
        return {
            findTrackedSession: function() {
                return n
            },
            expireObservable: new fe
        }
    }

    function tv(e) {
        return $i(e.sessionSampleRate) ? "1" : "0"
    }

    function Ow(e, t) {
        var n = Lw(t) ? t : tv(e);
        return {
            trackingType: n,
            isTracked: n === "1"
        }
    }

    function Lw(e) {
        return e === "0" || e === "1"
    }
    var nv = !1;

    function ca(e) {
        var t = window;
        if (Jp()) {
            var n = r(t.DD_RUM_SYNTHETICS);
            return !n && !nv && (nv = !0, jp("Logs sent before RUM is injected by the synthetics worker", {
                testId: uw(),
                resultId: cw()
            })), n
        }
        return r(t.DD_RUM);

        function r(o) {
            if (o && o.getInternalContext) return o.getInternalContext(e)
        }
    }

    function Pw(e, t, n, r, o) {
        var i = pw.concat(["custom"]),
            a = {};
        i.forEach(function(l) {
            a[l] = b1(l, t.eventRateLimiterThreshold, o)
        }), n.subscribe(0, function(l) {
            var s, u, c = l.rawLogsEvent,
                f = l.messageContext,
                d = f === void 0 ? void 0 : f,
                h = l.savedCommonContext,
                y = h === void 0 ? void 0 : h,
                m = l.domainContext,
                E = l0(c.date),
                v = e.findTrackedSession(E);
            if (!(!v && (!t.sendLogsAfterSessionExpiration || !e.findTrackedSession(E, {
                    returnInactive: !0
                })))) {
                var p = y || r(),
                    g = pr({
                        service: t.service,
                        session_id: v ? v.id : void 0,
                        session: v ? {
                            id: v.id
                        } : void 0,
                        usr: Ts(p.user) ? void 0 : p.user,
                        view: p.view
                    }, p.context, ca(E), c, d);
                ((s = t.beforeSend) === null || s === void 0 ? void 0 : s.call(t, g, m)) === !1 || g.origin !== be.AGENT && ((u = a[g.status]) !== null && u !== void 0 ? u : a.custom).isLimitReached() || n.notify(1, g)
            }
        })
    }
    var In, Iw = (In = {}, In[ie.log] = D.info, In[ie.debug] = D.debug, In[ie.info] = D.info, In[ie.warn] = D.warn, In[ie.error] = D.error, In);

    function Nw(e, t) {
        var n = K1(e.forwardConsoleLogs).subscribe(function(r) {
            var o = {
                rawLogsEvent: {
                    date: Jt(),
                    message: r.message,
                    origin: be.CONSOLE,
                    error: r.error && ua(r.error),
                    status: Iw[r.api]
                },
                domainContext: {
                    handlingStack: r.handlingStack
                }
            };
            t.notify(0, o)
        });
        return {
            stop: function() {
                n.unsubscribe()
            }
        }
    }

    function _w(e, t) {
        var n = Ky(e, e.forwardReports).subscribe(function(r) {
            var o = r.message,
                i, a = r.originalError.type === "deprecation" ? D.warn : D.error;
            a === D.error ? i = ua(r) : r.stack && (o += " Found in ".concat(By(r.stack))), t.notify(0, {
                rawLogsEvent: {
                    date: Jt(),
                    message: o,
                    origin: be.REPORT,
                    error: i,
                    status: a
                }
            })
        });
        return {
            stop: function() {
                n.unsubscribe()
            }
        }
    }

    function Rw(e, t) {
        if (!e.forwardErrorsToLogs) return {
            stop: Xt
        };
        var n = A1(e).subscribe(function(i) {
                i.state === "complete" && o("xhr", i)
            }),
            r = Kp().subscribe(function(i) {
                i.state === "resolve" && o("fetch", i)
            });

        function o(i, a) {
            !py(a.url) && (zw(a) || Fp(a.status)) && ("xhr" in a ? Mw(a.xhr, e, l) : a.response ? jw(a.response, e, l) : a.error && Dw(a.error, e, l));

            function l(s) {
                var u = {
                    isAborted: a.isAborted,
                    handlingStack: a.handlingStack
                };
                t.notify(0, {
                    rawLogsEvent: {
                        message: "".concat(Fw(i), " error ").concat(a.method, " ").concat(a.url),
                        date: a.startClocks.timeStamp,
                        error: {
                            stack: s || "Failed to load",
                            handling: void 0
                        },
                        http: {
                            method: a.method,
                            status_code: a.status,
                            url: a.url
                        },
                        status: D.error,
                        origin: be.NETWORK
                    },
                    domainContext: u
                })
            }
        }
        return {
            stop: function() {
                n.unsubscribe(), r.unsubscribe()
            }
        }
    }

    function Mw(e, t, n) {
        typeof e.response == "string" ? n(su(e.response, t)) : n(e.response)
    }

    function Dw(e, t, n) {
        n(su(kn(kt(e)), t))
    }

    function jw(e, t, n) {
        var r = C1(e);
        !r || !r.body ? n() : window.TextDecoder ? Tw(r.body, t.requestErrorResponseLengthLimit, function(o, i) {
            n(o ? "Unable to retrieve response: ".concat(o) : i)
        }) : r.text().then(B(function(o) {
            return n(su(o, t))
        }), B(function(o) {
            return n("Unable to retrieve response: ".concat(o))
        }))
    }

    function zw(e) {
        return e.status === 0 && e.responseType !== "opaque"
    }

    function su(e, t) {
        return e.length > t.requestErrorResponseLengthLimit ? "".concat(e.substring(0, t.requestErrorResponseLengthLimit), "...") : e
    }

    function Fw(e) {
        return e === "xhr" ? "XHR" : "Fetch"
    }

    function Tw(e, t, n) {
        iw(e, function(r, o, i) {
            if (r) n(r);
            else {
                var a = new TextDecoder().decode(o);
                i && (a += "..."), n(void 0, a)
            }
        }, {
            bytesLimit: t,
            collectStreamBody: !0
        })
    }

    function bw(e, t) {
        if (!e.forwardErrorsToLogs) return {
            stop: Xt
        };
        var n = new fe,
            r = $y(n).stop,
            o = n.subscribe(function(i) {
                t.notify(0, {
                    rawLogsEvent: {
                        message: i.message,
                        date: i.startClocks.timeStamp,
                        error: ua(i),
                        origin: be.SOURCE,
                        status: D.error
                    }
                })
            });
        return {
            stop: function() {
                r(), o.unsubscribe()
            }
        }
    }
    var Aw = T1,
        tt;

    function Uw(e) {
        function t(n, r, o, i, a) {
            var l = pr(r.getContext(), n.context);
            if (sa(n.status, wo.console, r) && $w(n, l), sa(n.status, wo.http, r)) {
                var s = {
                    rawLogsEvent: {
                        date: a || Jt(),
                        message: n.message,
                        status: n.status,
                        origin: be.LOGGER
                    },
                    messageContext: l,
                    savedCommonContext: i
                };
                o && (s.domainContext = {
                    handlingStack: o
                }), e.notify(0, s)
            }
        }
        return {
            handleLog: t
        }
    }
    var Bw = (tt = {}, tt[D.ok] = ie.debug, tt[D.debug] = ie.debug, tt[D.info] = ie.info, tt[D.notice] = ie.info, tt[D.warn] = ie.warn, tt[D.error] = ie.error, tt[D.critical] = ie.error, tt[D.alert] = ie.error, tt[D.emerg] = ie.error, tt);

    function $w(e, t) {
        var n = e.status,
            r = e.message;
        hn[Bw[n]].call(st, r, t)
    }

    function Vw(e, t, n, r, o) {
        var i = Wp(e, {
            endpoint: e.logsEndpointBuilder,
            encoder: la()
        }, e.replica && {
            endpoint: e.replica.logsEndpointBuilder,
            encoder: la()
        }, n, r, o.expireObservable);
        return t.subscribe(1, function(a) {
            i.add(a)
        }), i
    }

    function Hw(e) {
        var t = nu();
        e.subscribe(1, function(n) {
            t.send("log", n)
        })
    }

    function Gw(e) {
        return {
            get: function(t) {
                var n = e.findTrackedSession(t);
                if (n) return {
                    session_id: n.id
                }
            }
        }
    }

    function Ww(e) {
        return function(t) {
            e.notify(0, {
                rawLogsEvent: {
                    message: t.message,
                    date: t.startClocks.timeStamp,
                    origin: be.AGENT,
                    status: D.error
                }
            }), jp("Error reported to customer", {
                "error.message": t.message
            })
        }
    }

    function Kw(e, t, n, r, o) {
        var i = o1("browser-logs-sdk", t);
        i.setContextProvider(function() {
            var f, d, h, y, m, E;
            return {
                application: {
                    id: (f = ca()) === null || f === void 0 ? void 0 : f.application_id
                },
                session: {
                    id: (d = o.findTrackedSession()) === null || d === void 0 ? void 0 : d.id
                },
                view: {
                    id: (y = (h = ca()) === null || h === void 0 ? void 0 : h.view) === null || y === void 0 ? void 0 : y.id
                },
                action: {
                    id: (E = (m = ca()) === null || m === void 0 ? void 0 : m.user_action) === null || E === void 0 ? void 0 : E.id
                }
            }
        });
        var a = [];
        if (ia()) {
            var l = nu(),
                s = i.observable.subscribe(function(f) {
                    return l.send("internal_telemetry", f)
                });
            a.push(function() {
                return s.unsubscribe()
            })
        } else {
            var u = Wp(t, {
                endpoint: t.rumEndpointBuilder,
                encoder: la()
            }, t.replica && {
                endpoint: t.replica.rumEndpointBuilder,
                encoder: la()
            }, n, r, o.expireObservable);
            a.push(function() {
                return u.stop()
            });
            var c = i.observable.subscribe(function(f) {
                return u.add(f, l1(t))
            });
            a.push(function() {
                return c.unsubscribe()
            })
        }
        return a1(), s1(mw(e)), {
            telemetry: i,
            stop: function() {
                a.forEach(function(f) {
                    return f()
                })
            }
        }
    }

    function Qw(e, t, n, r) {
        var o = new Aw,
            i = [];
        o.subscribe(1, function(h) {
            return Np("logs", h)
        });
        var a = Ww(o),
            l = D1(t),
            s = t.sessionStoreStrategyType && !ia() && !Jp() ? Ew(t, r) : kw(t),
            u = Kw(e, t, a, l, s).stop;
        i.push(function() {
            return u()
        }), Rw(t, o), bw(t, o), Nw(t, o), _w(t, o);
        var c = Uw(o).handleLog;
        if (Pw(s, t, o, n, a), ia()) Hw(o);
        else {
            var f = Vw(t, o, a, l, s).stop;
            i.push(function() {
                return f()
            })
        }
        var d = Gw(s);
        return {
            handleLog: c,
            getInternalContext: d.get,
            stop: function() {
                i.forEach(function(h) {
                    return h()
                })
            }
        }
    }
    var Co = Cw(Qw);
    Wy(qt(), "DD_LOGS", Co);
    const Yw = "puba15a945d0aee0802b77ed711cb100691",
        Jw = "production",
        Zw = parseInt("100") || 10;
    let gr = null;
    Co.init({
        clientToken: Yw,
        forwardErrorsToLogs: !1,
        sessionSampleRate: Zw,
        env: Jw,
        service: "loop-react-shopify-storefront"
    });
    const rv = new Dh;
    let uu = document.getElementById("loop-manager");
    if (window.hasOwnProperty("Shopify") || (window.Shopify = {
            shop: "default-store-config.myshopify.com"
        }), !sessionStorage.getItem("forceAce") || sessionStorage.getItem("forceAce") === "false") {
        const e = new URLSearchParams(window.location.search);
        sessionStorage.setItem("forceAce", e.get("offset_ace") || "false")
    }
    const cu = window.Shopify.shop,
        qw = {
            shopDomain: cu
        };
    Co && (Co.setGlobalContext({
        context: qw
    }), gr = Co.createLogger("reactCartLogger", {
        level: "info",
        handler: ["http"]
    }));
    const ov = Lo.createContext(rv),
        Xw = Lo.createContext(gr),
        iv = Lo.createContext(cu);
    (async () => {
        try {
            if (!uu) {
                const e = document.createElement("div");
                e.setAttribute("id", "loop-manager"), document.body.appendChild(e), uu = e
            }
            ya.createRoot(uu).render(w.jsx(iv.Provider, {
                value: cu,
                children: w.jsx(ov.Provider, {
                    value: rv,
                    children: w.jsx(Xw.Provider, {
                        value: gr,
                        children: w.jsx(e0, {})
                    })
                })
            }))
        } catch (e) {
            gr == null || gr.error("Failed to Load Loop App Extension", {}, e);
            return
        }
    })()
})();