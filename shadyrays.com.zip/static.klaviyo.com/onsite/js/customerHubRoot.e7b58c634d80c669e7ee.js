"use strict";
(self.webpackChunk_klaviyo_onsite_modules = self.webpackChunk_klaviyo_onsite_modules || []).push([
    [7473], {
        86801: function(e, t, a) {
            a.d(t, {
                X: function() {
                    return v
                }
            });
            var n = a(95775),
                r = a.n(n),
                l = a(87789),
                i = a.n(l),
                o = a(76223),
                s = a.n(o),
                c = a(49207),
                d = a(21302),
                u = a(66901),
                m = a(98956);
            const p = ["className", "size", "defaultChecked", "onChange"],
                g = c.ZP.input.withConfig({
                    displayName: "Checkbox__InternalInput",
                    componentId: "sc-vh9gfl-0"
                })(["position:absolute;width:100% !important;height:100% !important;top:0;left:0;right:0;bottom:0;opacity:0;display:block !important;margin:0 !important;cursor:pointer;&:disabled{cursor:unset;}"]),
                h = c.ZP.span.withConfig({
                    displayName: "Checkbox__VisualCheckboxWrapper",
                    componentId: "sc-vh9gfl-1"
                })(["display:flex;box-sizing:border-box;width:20px;height:20px;background-color:white;border:2px solid var(--atlas-border-dark);border-radius:4px;position:relative;color:white;align-items:center;justify-content:center;transition-property:background-color,border-color,outline;transition-duration:100ms;&:focus-within{outline:2px solid var(--atlas-primary-color);outline-offset:2px;}@supports (color:color-mix(in srgb,black,transparent)){&:focus-within{outline:4px solid color-mix(in srgb,var(--atlas-primary-color) 50%,transparent);outline-offset:0px;}}", " ", ""], (({
                    checked: e
                }) => e && (0, c.iv)(["border-color:var(--atlas-primary-color);background-color:var(--atlas-primary-color);"])), (({
                    disabled: e
                }) => e && (0, c.iv)(["background-color:var(--atlas-border-light);border-color:var(--atlas-border-dark);color:black;"]))),
                v = (0, o.forwardRef)(((e, t) => {
                    var a;
                    let {
                        className: n,
                        defaultChecked: l,
                        onChange: o
                    } = e, c = i()(e, p);
                    const [v, E] = (0, u.u)({
                        controlledProp: c.checked,
                        uncontrolledProp: l
                    });
                    return s().createElement(h, {
                        className: (0, m.A)("kl-hub-checkbox", n),
                        checked: null != v && v,
                        disabled: null != (a = null == c ? void 0 : c.disabled) && a
                    }, s().createElement(g, r()({
                        type: "checkbox",
                        checked: v,
                        className: "kl-hub-checkbox__input"
                    }, c, {
                        onChange: e => {
                            E(e.target.checked), null == o || o(e)
                        },
                        ref: t
                    })), v && s().createElement(d.KM, {
                        size: "mini"
                    }))
                }));
            v.displayName = "Checkbox"
        },
        76164: function(e, t, a) {
            a.d(t, {
                B: function() {
                    return c
                }
            });
            var n = a(76223),
                r = a.n(n),
                l = a(49207),
                i = a(39809);
            const o = l.ZP.div.withConfig({
                    displayName: "CheckboxLabelContainer__Wrapper",
                    componentId: "sc-1379tl3-0"
                })(["display:flex;align-items:flex-start;gap:var(--atlas-space-mini);"]),
                s = l.ZP.div.withConfig({
                    displayName: "CheckboxLabelContainer__CheckboxContainer",
                    componentId: "sc-1379tl3-1"
                })(["display:flex;align-items:center;height:var(--atlas-line-height-small);"]),
                c = ({
                    checkbox: e,
                    label: t,
                    className: a
                }) => r().createElement(o, {
                    className: a
                }, r().createElement(s, null, e), r().createElement(i.OA, {
                    variant: "secondary"
                }, r().createElement("label", {
                    htmlFor: e.props.id
                }, t)))
        },
        56403: function(e, t, a) {
            a.d(t, {
                o: function() {
                    return o
                }
            });
            var n = a(49207),
                r = a(39809),
                l = a(98956);
            const i = (0, n.F4)(["0%{transform:translateX(0);}25%{transform:translateX(5px);}50%{transform:translateX(-5px);}75%{transform:translateX(5px);}100%{transform:translateX(0);}"]),
                o = n.ZP.input.attrs((e => ({
                    className: (0, l.A)("kl-hub-input", e.className)
                }))).withConfig({
                    displayName: "TextInput",
                    componentId: "sc-bxjj6n-0"
                })(["background:var(--atlas-background-content);border:1px solid var(--atlas-border-dark);border-radius:", ";padding:var(--atlas-input-padding);", " ", " &:focus{border-color:var(--atlas-border-focus);outline:none;box-shadow:none;}&::placeholder{color:var(--atlas-text-placeholder);}", " &[disabled]{background-color:var(--atlas-input-background-disabled);}"], (({
                    controlSize: e = "normal"
                }) => `var(--atlas-input-border-radius-${e})`), (({
                    controlSize: e = "normal"
                }) => (0, r.cY)(e, {
                    noSpacing: !0
                })), (({
                    full: e
                }) => e && (0, n.iv)(["width:100%;"])), (({
                    invalid: e
                }) => e && (0, n.iv)(["animation:", " 300ms ease-in-out;border-color:var(--atlas-input-error);"], i)))
        },
        23077: function(e, t, a) {
            a.d(t, {
                v: function() {
                    return s
                }
            });
            var n = a(76223),
                r = a.n(n),
                l = a(49207),
                i = a(50664);
            const o = l.ZP.div.withConfig({
                    displayName: "Menu__MenuContainer",
                    componentId: "sc-4uhv8g-0"
                })(["background-color:var(--atlas-background-content);border-radius:var(--atlas-input-border-radius-normal);z-index:10;max-height:224px;overflow-y:auto;box-shadow:var(--atlas-select-panel-shadow);outline:none;"]),
                s = ({
                    children: e,
                    setIsOpen: t,
                    style: a,
                    floatingRef: n,
                    menuRef: l,
                    parentRef: s
                }) => r().createElement(o, {
                    ref: n,
                    style: Object.assign({}, a),
                    onKeyDown: e => {
                        const {
                            key: a
                        } = e, n = document.activeElement;
                        var r;
                        l.current && null != n && n instanceof HTMLElement && ("Tab" === a ? (e.preventDefault(), t(!1), null == (r = s.current) || r.focus()) : "ArrowDown" === a ? (0, i.pr)(l.current, n, i.vi) : "ArrowUp" === a && (0, i.pr)(l.current, n, i.UU))
                    },
                    tabIndex: 0,
                    role: "list",
                    "data-testid": "menu"
                }, e)
        },
        90351: function(e, t, a) {
            a.d(t, {
                W: function() {
                    return s
                }
            });
            var n = a(76223),
                r = a.n(n),
                l = a(49207),
                i = a(39809);
            const o = l.ZP.div.withConfig({
                    displayName: "MenuOption__OptionRow",
                    componentId: "sc-1e5c80m-0"
                })(["padding:var(--atlas-space-mini) var(--atlas-space-medium);cursor:pointer;user-select:none;&:hover,&:focus{background-color:var(--atlas-overlay-light);box-shadow:none;outline:none;}", " ", ""], (({
                    disabled: e
                }) => e && (0, l.iv)(["background-color:var(--atlas-border-light);cursor:unset;span{color:var(--atlas-overlay-heavy);}"])), (({
                    selected: e
                }) => e && (0, l.iv)(["padding-left:calc(var(--atlas-space-medium) - 4px);border-left:4px solid var(--atlas-primary-color);"]))),
                s = ({
                    children: e,
                    disabled: t,
                    selected: a,
                    onClick: n,
                    value: l,
                    label: s,
                    testId: c
                }) => r().createElement(o, {
                    role: "option",
                    disabled: null != t && t,
                    selected: null != a && a,
                    onClick: () => null == n ? void 0 : n(l),
                    tabIndex: a ? 0 : -1,
                    "aria-disabled": t,
                    "aria-selected": a,
                    "aria-label": s,
                    onKeyDown: e => {
                        " " !== e.key && "Enter" !== e.key || (e.preventDefault(), e.target instanceof HTMLElement && e.target.click())
                    },
                    "data-testid": c,
                    className: "kl-hub-option"
                }, "string" == typeof e ? r().createElement(i.Rw, null, e) : e)
        },
        5556: function(e, t, a) {
            a.d(t, {
                P: function() {
                    return y
                }
            });
            var n = a(95775),
                r = a.n(n),
                l = (a(60873), a(76223)),
                i = a.n(l),
                o = a(49207),
                s = a(35977),
                c = a(75656),
                d = a(72784),
                u = a(39809),
                m = a(66901),
                p = a(99112),
                g = a(50664),
                h = a(98956),
                v = a(21302),
                E = a(23077);
            const f = o.ZP.div.withConfig({
                    displayName: "Select__SelectInput",
                    componentId: "sc-1jmbkap-0"
                })(["border:1px solid var(--atlas-overlay-heavy);width:100%;background-color:var(--atlas-background-content);border-radius:var(--atlas-input-border-radius-normal);padding:var(--atlas-input-padding);line-height:var(--atlas-line-height-normal);cursor:pointer;display:flex;align-items:center;gap:4px;user-select:none;&:focus,&.kl-hub-select--active{outline:3px solid var(--atlas-focus-outline-color);outline-offset:0;border-color:var(--atlas-border-focus);box-shadow:none;}&[aria-disabled='true']{background-color:var(--atlas-input-background-disabled);pointer-events:none;}"]),
                b = o.ZP.div.withConfig({
                    displayName: "Select__SelectDisplayedValue",
                    componentId: "sc-1jmbkap-1"
                })(["flex:1;min-width:0;.kl-hub-option{white-space:nowrap;overflow:hidden;text-overflow:ellipsis;display:block;width:100%;}"]),
                y = ({
                    children: e,
                    value: t,
                    defaultValue: a,
                    className: n,
                    disabled: o,
                    onChange: y,
                    label: C,
                    labelledBy: _,
                    testId: w,
                    renderValue: x
                }) => {
                    const [I, k] = (0, l.useState)(!1), [N, T] = (0, m.u)({
                        controlledProp: t,
                        uncontrolledProp: a
                    }), S = (0, l.useRef)(null), P = (0, l.useRef)(null), O = (0, l.useRef)(!1), R = e => {
                        O.current = e
                    }, {
                        dimensions: {
                            width: D
                        },
                        measurementRef: L
                    } = (0, p.h)(), {
                        refs: H,
                        floatingStyles: A,
                        context: M
                    } = (0, s.YF)({
                        open: I,
                        onOpenChange: k,
                        middleware: [(0, c.cv)(4), (0, c.RR)(), (0, c.uY)()],
                        whileElementsMounted: d.Me,
                        strategy: "fixed"
                    }), Z = (0, s.bQ)(M), {
                        getReferenceProps: B,
                        getFloatingProps: U
                    } = (0, s.NI)([Z]);
                    let F;
                    (0, l.useEffect)((() => {
                        I && P.current ? O.current ? (0, g.pr)(P.current, P.current, g.vi) : P.current.focus() : R(!1)
                    }), [I]);
                    const z = l.Children.map(e, (e => (N === e.props.value && (F = x ? x(e.props.value) : e.props.children), (0, l.cloneElement)(e, {
                        selected: N === e.props.value,
                        onClick: t => {
                            var a;
                            null == e.props.onClick || e.props.onClick(t), T(t), null == y || y(t), k(!1), null == (a = S.current) || a.focus()
                        }
                    }))));
                    return i().createElement(i().Fragment, null, i().createElement(f, r()({
                        role: "listbox",
                        ref: e => {
                            e && (H.setReference(e), S.current = e, L.current = e)
                        },
                        onClick: () => {
                            k(!I)
                        }
                    }, B(), {
                        tabIndex: o ? -1 : 0,
                        onKeyDown: e => (0, g.Ds)(e, I, k, R),
                        className: (0, h.A)("kl-hub-select", {
                            "kl-hub-select--active": I
                        }, n),
                        "aria-label": C,
                        "aria-labelledby": _,
                        "aria-disabled": o,
                        "data-testid": w
                    }), i().createElement(b, null, "string" == typeof F ? i().createElement(u.Rw, null, F) : F), I ? i().createElement(v.wx, {
                        size: "mini"
                    }) : i().createElement(v.rs, {
                        size: "mini"
                    })), I && i().createElement(E.v, r()({
                        floatingRef: e => {
                            e && (H.setFloating(e), P.current = e)
                        },
                        setIsOpen: k,
                        menuRef: P,
                        parentRef: S,
                        style: Object.assign({}, A, {
                            border: "1px solid var(--atlas-overlay-heavy)",
                            minWidth: D
                        })
                    }, U), z))
                }
        },
        28999: function(e, t, a) {
            a.d(t, {
                CustomerHubRoot: function() {
                    return Ss
                },
                getSettings: function() {
                    return Ps
                }
            });
            a(26650);
            var n = a(76223),
                r = a.n(n),
                l = a(35977),
                i = a(16269),
                o = a(65595),
                s = a(85667),
                c = a(13732),
                d = (a(19986), a(92461), a(70818), a(43416));
            var u = a(51573),
                m = a(5656),
                p = a(2361);
            const g = (0, n.createContext)(void 0);

            function h() {
                const e = (0, n.useContext)(g);
                if ((0, u.U_)()) return {
                    isOpen: !0,
                    setIsOpen: () => {},
                    isLoading: !1
                };
                if (!e) throw new Error("useDrawerState: No DrawerStateProvider found.");
                return {
                    isOpen: e.isOpen,
                    setIsOpen: e.setIsOpen,
                    isLoading: e.isLoading
                }
            }
            const v = /^#kl?-hub/,
                E = ({
                    children: e
                }) => {
                    const [t, a] = (0, n.useState)(!1), [l, i] = (0, n.useState)(!0), o = e => {
                        a(e), i(!1), !1 === e ? window.history.pushState(void 0, "", window.location.pathname + window.location.search) : (0, m.ZD)(p.Xl.OPENED_CUSTOMER_HUB, {})
                    }, s = (0, n.useMemo)((() => ({
                        isOpen: t,
                        setIsOpen: o,
                        isLoading: l
                    })), [t, l]);
                    return (0, n.useEffect)((() => {
                        document.location.hash.match(v) && (a(!0), (0, m.ZD)(p.Xl.OPENED_CUSTOMER_HUB, {})), i(!1);
                        const e = () => {
                            document.location.hash.match(v) ? (a(!0), i(!1), (0, m.ZD)(p.Xl.OPENED_CUSTOMER_HUB, {})) : (a(!1), i(!1))
                        };
                        return window.addEventListener("popstate", e), () => {
                            window.removeEventListener("popstate", e)
                        }
                    }), []), r().createElement(g.Provider, {
                        value: s
                    }, e)
                };
            var f = a(26374),
                b = a(59487),
                y = a(28036);
            const C = (0, n.createContext)(void 0);

            function _() {
                const e = (0, n.useContext)(C);
                return null == e ? void 0 : e.title
            }

            function w(e, t = []) {
                const a = (0, n.useContext)(C),
                    r = (0, n.useCallback)(e, t);
                if (!a) throw new Error("useSetHubTitle: no HubTitleProvider found.");
                return (0, n.useEffect)((() => {
                    a.setTitle(r())
                }), [r, a]), (0, n.useEffect)((() => () => {
                    a.setTitle(void 0)
                }), [a]), a.setTitle
            }
            const x = ({
                children: e
            }) => {
                const [t, a] = (0, n.useState)(void 0), l = (0, n.useMemo)((() => ({
                    title: t,
                    setTitle: a
                })), [t]);
                return r().createElement(C.Provider, {
                    value: l
                }, e)
            };
            var I = a(17632),
                k = a(96967);
            const N = (0, n.createContext)(void 0),
                T = () => {
                    const e = (0, n.useContext)(N);
                    if (!e) throw new Error("useResolvedToken must be used within <TokenResolverProvider/>");
                    return e
                },
                S = ({
                    children: e
                }) => {
                    const t = (0, k.m)(),
                        {
                            token: a,
                            anonymousToken: l,
                            setAnonymousToken: i,
                            anonymousUserId: o,
                            setAnonymousUserId: c
                        } = (0, f.aC)(),
                        d = (0, n.useRef)(null),
                        [u, m] = (0, n.useState)(!0),
                        p = (0, n.useCallback)((async () => {
                            a || l || (d.current || (d.current = (async () => {
                                try {
                                    const e = () => "randomUUID" in window.crypto ? window.crypto.randomUUID() : void 0,
                                        a = null != o ? o : e();
                                    if (!a) throw new Error("No client identifier found");
                                    o || c(a);
                                    const n = (0, s.lk)();
                                    if (!n) throw new Error("Company ID is not available");
                                    const {
                                        token: r
                                    } = await t.getAnonymousToken(a, n);
                                    i(r), t.setAnonymousToken(r)
                                } finally {
                                    d.current = null
                                }
                            })()), await d.current)
                        }), [a, l, t, i, o, c]);
                    (0, n.useEffect)((() => {
                        let e = !1;
                        async function n() {
                            await p(), e || m(!1)
                        }
                        return o || !l || a ? u && (a || l) ? (t.setAnonymousToken(l), t.setToken(a), m(!1)) : l || a ? u && n() : (m(!0), n()) : (m(!0), n()), () => {
                            e = !0
                        }
                    }), [a, l, p, t, u, o]);
                    const g = (0, n.useMemo)((() => ({
                        resolvedToken: null != a ? a : l,
                        isResolving: u
                    })), [l, u, a]);
                    return r().createElement(N.Provider, {
                        value: g
                    }, e)
                };
            var P = a(80879);
            const O = (0, n.createContext)(void 0);

            function R() {
                const e = (0, n.useContext)(O);
                if (!e) throw new Error("useLoyaltyClient: No LoyaltyProvider found.");
                return e
            }
            const D = ({
                client: e,
                children: t
            }) => {
                const [a, l] = (0, n.useState)(!1);
                (0, n.useEffect)((() => {
                    const e = () => {
                            l(!0)
                        },
                        t = () => {
                            window.loadSmileSdk && window.loadSmileSdk()
                        };
                    return void 0 !== window.Smile ? l(!0) : "function" == typeof window.loadSmileSdk && window.loadSmileSdk(), document.addEventListener("smile-ui-loaded", e), document.addEventListener("smile-lite-loaded", t), () => {
                        document.removeEventListener("smile-ui-loaded", e), document.removeEventListener("smile-lite-loaded", t)
                    }
                }), []);
                const i = (0, n.useMemo)((() => ({
                    loyaltyClient: e,
                    isInitialized: a
                })), [e, a]);
                return r().createElement(O.Provider, {
                    value: i
                }, t)
            };
            var L = a(52901),
                H = a(35710);
            let A = function(e) {
                return e.ALL = "ALL", e.LOGGED_IN = "LOGGED_IN", e.LOGGED_OUT = "LOGGED_OUT", e.HIDE_ALL = "HIDE_ALL", e
            }({});
            var M = a(58065);
            let Z = function(e) {
                    return e.WELCOME = "welcome_message", e.EMAIL_IDENTIFICATION = "email_identification", e.CONVERSATION_CLOSED = "conversation_closed", e.TEXT = "text", e.AUTHENTICATION = "authentication", e.AUTHENTICATED = "authenticated", e.OFFICE_HOURS = "office_hours", e.AI_HANDOFF_TO_INBOX = "ai_handoff_to_inbox", e.AI_HANDOFF_TO_THIRD_PARTY = "ai_handoff_to_third_party", e.YES_NO_PROMPT = "yes_no_prompt", e.INBOX_GET_HELP = "inbox_get_help", e
                }({}),
                B = function(e) {
                    return e.ROBOT = "robot", e.CUSTOMER = "customer", e.ANONYMOUS = "anonymous", e.AGENT = "agent", e
                }({}),
                U = function(e) {
                    return e.AI_AGENT = "ai_agent", e.AUTO_RESPONDER = "auto_responder", e.OTHER = "other", e
                }({}),
                F = function(e) {
                    return e.EMAIL = "email", e.FORM = "form", e.SMS = "sms", e.WEB = "web", e
                }({}),
                z = function(e) {
                    return e.OPEN = "open", e.SNOOZED = "snoozed", e.CLOSED = "archived", e
                }({}),
                q = function(e) {
                    return e.NORMAL = "normal", e.OFFICE_HOURS = "office_hours", e.IDENTIFICATION = "identification", e.THIRD_PARTY_IDENTIFICATION_FOR_HANDOFF = "third_party_identification_for_handoff", e.THIRD_PARTY_HANDOFF = "third_party_handoff", e.AI_CHAT = "ai_chat", e.PROMPT_TO_HANDOFF = "prompt_to_handoff", e.PROMPT_TO_CONTINUE = "prompt_to_continue", e
                }({});

            function j(e) {
                const t = (0, k.m)(),
                    {
                        resolvedToken: a,
                        isResolving: n
                    } = T(),
                    r = e.ticketId !== p.Nf,
                    {
                        data: l,
                        mutate: i
                    } = (0, L.ZP)(!n && a ? M.g.activeMessages : null, (() => r ? t.getMessages(e) : []), {
                        refreshInterval: () => r ? 5e3 : 0,
                        fallbackData: []
                    });
                return {
                    data: l,
                    mutate: i
                }
            }

            function V(e) {
                const t = (0, k.m)(),
                    {
                        resolvedToken: a,
                        isResolving: n
                    } = T(),
                    r = (0, u.rV)(),
                    l = r.webChat && r.webChat.visibility !== A.HIDE_ALL && !n && a ? M.g.activeTicket(a) : null,
                    i = e ? {
                        ticketIds: [e]
                    } : {
                        statuses: [z.OPEN, z.SNOOZED]
                    };
                return (0, L.ZP)(l, (() => t.getTickets(i).then((e => e.data[0]))), {
                    refreshInterval: e => null != e && e.status && e.status !== z.CLOSED ? 1e4 : 0,
                    fallbackData: void 0,
                    revalidateOnFocus: !e
                })
            }

            function W() {
                const e = (0, k.m)();
                return (0, H.Z)(M.g.markTicketRead, ((t, {
                    arg: a
                }) => e.markTicketRead(a)))
            }
            const G = (0, n.createContext)(void 0);

            function $() {
                const {
                    ticketId: e,
                    setTicketId: t
                } = function() {
                    const e = (0, n.useContext)(G);
                    if (!e) throw new Error("useChatContext: no ChatProvider found.");
                    return {
                        ticketId: null == e ? void 0 : e.ticketId,
                        setTicketId: null == e ? void 0 : e.setTicketId
                    }
                }(), {
                    data: a,
                    mutate: r,
                    isLoading: l
                } = V(e);
                return {
                    ticket: a,
                    isLoading: l,
                    setTicketId: t,
                    updateTicketCache: (0, n.useCallback)(((e, t = !1) => {
                        r((t => Object.assign({}, null != t ? t : {}, e)), {
                            revalidate: t,
                            rollbackOnError: t
                        })
                    }), [r])
                }
            }
            const Y = ({
                children: e
            }) => {
                const [t, a] = (0, n.useState)(void 0), {
                    data: l
                } = V(t), {
                    mutate: i
                } = j({
                    ticketId: (null == l ? void 0 : l.id) || p.Nf
                }), {
                    token: o
                } = (0, f.aC)();
                (0, n.useEffect)((() => {
                    o || a(void 0)
                }), [o, a]), (0, n.useEffect)((() => {
                    !t && l && (a(l.id), i())
                }), [t, l, a, i]);
                const s = (0, n.useMemo)((() => ({
                    ticketId: t,
                    setTicketId: a
                })), [t]);
                return r().createElement(G.Provider, {
                    value: s
                }, e)
            };
            var K = a(49207),
                J = a(95775),
                X = a.n(J),
                Q = a(21302),
                ee = a(98956);
            const te = (0, K.ZP)(l.y0).withConfig({
                    displayName: "Modal__BlockingOverlay",
                    componentId: "sc-lyu2dk-0"
                })(["background-color:rgba(0,0,0,0);z-index:2147483647;overflow:visible !important;transition:background-color 250ms;&.kl-hub-modal-veil--opened{background-color:rgba(0,0,0,0.5);}"]),
                ae = ({
                    children: e,
                    className: t,
                    context: a
                }) => {
                    const {
                        status: n
                    } = (0, l.hU)(a);
                    return r().createElement(l.ll, null, r().createElement(te, {
                        lockScroll: !0,
                        className: (0, ee.A)("kl-hub-modal-veil", {
                            "kl-hub-modal-veil--opened": "open" === n
                        }, t)
                    }, r().createElement(l.wD, {
                        context: a,
                        returnFocus: !1
                    }, e)))
                };
            var ne = a(26103),
                re = a(39809),
                le = a(28040);
            const ie = K.ZP.div.withConfig({
                    displayName: "Drawer__DrawerHeader",
                    componentId: "sc-1cvr78k-0"
                })(["height:64px;width:100%;padding:var(--atlas-space-small);display:flex;justify-content:space-between;align-items:center;background-color:", ";"], (({
                    opaqueHeaderBackground: e
                }) => e ? "var(--atlas-background-content)" : "transparent")),
                oe = K.ZP.div.withConfig({
                    displayName: "Drawer__BackButtonContainer",
                    componentId: "sc-1cvr78k-1"
                })(["width:var(--atlas-button-icon-size-normal);flex-grow:1;flex-basis:0;", ""], (0, le.K)()),
                se = K.ZP.div.withConfig({
                    displayName: "Drawer__DrawerTitleContainer",
                    componentId: "sc-1cvr78k-2"
                })(["flex:1;display:flex;flex-grow:2;justify-content:center;", ""], (0, le.K)()),
                ce = K.ZP.div.withConfig({
                    displayName: "Drawer__HeaderActionsContainer",
                    componentId: "sc-1cvr78k-3"
                })(["flex:1;display:flex;justify-content:flex-end;flex-grow:1;flex-basis:0;gap:var(--atlas-space-mini);"]),
                de = {
                    bottom: "top",
                    top: "bottom",
                    left: "right",
                    right: "left"
                },
                ue = K.ZP.div.withConfig({
                    displayName: "Drawer__DrawerParent",
                    componentId: "sc-1cvr78k-4"
                })(["background-color:var(--atlas-background-main);position:absolute;transition-property:'transform';overflow:hidden;", ""], (({
                    side: e,
                    fullscreen: t
                }) => "left" === e || "right" === e ? (0, K.iv)(["", ":0;max-width:", ";", " height:100%;@media (max-width:480px){max-width:100%;}"], e, t ? "100%" : "90%", t && (0, K.iv)(["width:100%;"])) : (0, K.iv)(["", ":0;max-height:calc(100% - var(--atlas-space-small));border-", "-right-radius:var(--atlas-drawer-border-radius);border-", "-left-radius:var(--atlas-drawer-border-radius);width:100%;", ""], e, de[e], de[e], t && (0, K.iv)(["height:calc(100% - var(--atlas-space-small));"])))),
                me = K.ZP.div.withConfig({
                    displayName: "Drawer__DrawerContent",
                    componentId: "sc-1cvr78k-5"
                })(["height:calc(100% - 64px);overflow-y:auto;position:relative;"]);
            var pe = a(22950);
            const ge = () => r().createElement(o.k, null, r().createElement(o.lE, null));

            function he() {
                const [e, t] = (0, n.useState)((() => window.innerWidth <= 480));
                return (0, n.useEffect)((() => {
                    const e = () => {
                        t(window.innerWidth <= 480)
                    };
                    return window.addEventListener("resize", e), () => {
                        window.removeEventListener("resize", e)
                    }
                }), []), e
            }
            a(56816);
            var ve = a(49257);
            var Ee = a(49246),
                fe = a(93028),
                be = a(82572);

            function ye() {
                const e = (0, P.A)(),
                    {
                        redirect: t
                    } = (0, pe.HJ)(),
                    {
                        token: a,
                        anonymousToken: r,
                        setToken: l
                    } = (0, f.aC)(),
                    i = function() {
                        const {
                            setToken: e
                        } = (0, f.aC)(), t = (0, k.m)();
                        return (0, n.useCallback)((a => {
                            e(a), t.setToken(a)
                        }), [e, t])
                    }(),
                    o = (0, Ee.u)(),
                    c = (0, fe.K_)();
                return (0, H.Z)(M.g.storefrontLogin, (() => e.login(a, r)), {
                    onSuccess: e => {
                        void 0 !== e.auth_token && a !== e.auth_token && i(e.auth_token), e.email && (0, m.oG)(e.email, e.is_new_user, c)
                    },
                    onError: a => {
                        401 === a.status && (a instanceof be.Y && a.needsVerification ? t("/checkOTP", {
                            email: a.email
                        }, !0) : (o(), l(void 0), (0, s.au)(void 0), document.location.href = e.getLogoutLink()))
                    }
                })
            }
            const Ce = K.ZP.div.withConfig({
                    displayName: "Page",
                    componentId: "sc-195rebo-0"
                })(["padding:var(--atlas-space-small) var(--atlas-space-medium);width:100%;height:100%;", ""], (({
                    foreground: e
                }) => e && (0, K.iv)(["background-color:var(--atlas-background-content);"]))),
                _e = K.ZP.div.withConfig({
                    displayName: "EmptyResult__EmptyContainer",
                    componentId: "sc-4ueam4-0"
                })(["display:flex;justify-content:center;align-items:center;height:100%;width:100%;"]),
                we = ({
                    label: e
                }) => r().createElement(_e, null, r().createElement(re.d9, {
                    variant: "secondary"
                }, e));

            function xe() {
                const e = (0, k.m)(),
                    {
                        token: t
                    } = (0, f.aC)();
                return (0, L.ZP)(t ? M.g.profile : null, (() => e.getProfile()))
            }
            const Ie = (0, n.lazy)((() => Promise.all([a.e(3050), a.e(1811), a.e(3282)]).then(a.bind(a, 44969)))),
                ke = () => {
                    const e = localStorage.getItem(p.xP) ? (() => {
                        const e = localStorage.getItem(p.xP);
                        return e ? JSON.parse(e) : null
                    })() : null;
                    if (!e) return !0;
                    if (e && e.updated) {
                        const t = new Date(e.updated),
                            a = new Date,
                            n = Math.abs(a.getTime() - t.getTime());
                        return Math.ceil(n / 864e5) > 30 || "false" === e.skipped
                    }
                    return !1
                },
                Ne = () => {
                    const {
                        t: e
                    } = (0, b.ql)(), {
                        data: t,
                        isLoading: a
                    } = xe(), l = (null == t ? void 0 : t.isSmsEnabled) && !(null != t && t.smsConsent) && ke(), {
                        previousPath: i,
                        previousData: o
                    } = (0, pe.Qt)(), {
                        replace: s
                    } = (0, pe.HJ)();
                    return w((() => l ? e("customerHub.profile.complete.sms") : "")), a ? r().createElement(Ce, {
                        foreground: !0
                    }, r().createElement(ve.$, {
                        cover: !0,
                        size: "jumbo"
                    })) : t ? r().createElement(Ce, {
                        foreground: !0
                    }, r().createElement(n.Suspense, {
                        fallback: r().createElement(ve.$, {
                            cover: !0,
                            size: "jumbo"
                        })
                    }, l ? r().createElement(Ie, {
                        profile: t,
                        previousPath: i,
                        previousData: o
                    }) : r().createElement(r().Fragment, null, r().createElement(ve.$, {
                        cover: !0,
                        size: "jumbo"
                    }), s(i || "/", o)))) : r().createElement(Ce, {
                        foreground: !0
                    }, r().createElement(we, {
                        label: e("customerHub.profile.edit.no-profile")
                    }))
                },
                Te = ({
                    children: e
                }) => {
                    const {
                        token: t
                    } = (0, f.aC)(), {
                        isOpen: a
                    } = h(), l = (0, s.FV)(), i = null == l ? void 0 : l.userId, o = !t && null != i, {
                        redirect: c
                    } = (0, pe.HJ)(), [d, u] = (0, n.useState)(o), [m, p] = (0, n.useState)(!1), {
                        trigger: g
                    } = ye();
                    return (0, n.useEffect)((() => {
                        !m && a && (g().then((() => {
                            ke() && c("/smsConsent", {
                                replace: !0
                            })
                        })).finally((() => {
                            u(!1)
                        })), p(!0))
                    }), [m, a, g, c]), (0, n.useEffect)((() => {
                        a || p(!1)
                    }), [a]), (0, n.useEffect)((() => {
                        a || !m || t || p(!1)
                    }), [a, m, t]), d ? r().createElement(ve.$, {
                        cover: !0,
                        size: "large"
                    }) : r().createElement(r().Fragment, null, e)
                },
                Se = (0, K.ZP)((({
                    isOpen: e,
                    handleClose: t,
                    children: a,
                    title: i,
                    side: o = "right",
                    fullscreen: s,
                    className: c,
                    showBackButton: d = !1,
                    onBackClick: u,
                    opaqueHeaderBackground: m = !0,
                    headerActions: p = []
                }) => {
                    const {
                        t: g
                    } = (0, b.ql)(), h = (0, l.jV)(), {
                        context: v,
                        refs: E
                    } = (0, l.YF)({
                        nodeId: h,
                        open: e,
                        onOpenChange: e => {
                            e || null == t || t()
                        },
                        placement: o
                    }), f = (0, l.qs)(v), y = (0, l.bQ)(v, {
                        outsidePress: e => !(e.target instanceof Element) || !e.target.closest(".k-hub-toast"),
                        bubbles: {
                            outsidePress: !1
                        }
                    }), {
                        getFloatingProps: C
                    } = (0, l.NI)([y, f]), {
                        isMounted: _,
                        styles: w
                    } = (0, l.Y_)(v, {
                        duration: 250,
                        initial: e => ({
                            transform: {
                                top: "translateY(-100%)",
                                bottom: "translateY(100%)",
                                left: "translateX(-100%)",
                                right: "translateX(100%)"
                            }[e.side]
                        })
                    }), x = (0, l.PC)(), I = (0, n.useRef)(null);
                    if ((0, n.useEffect)((() => {
                            var e;
                            _ && (I.current && (null == (e = I.current) || e.focus()))
                        }), [_]), !_) return null;
                    const k = [...p, r().createElement(ne.zx, {
                        ref: I,
                        key: "kl-close-button",
                        role: "button",
                        variant: "icon",
                        onClick: () => null == t ? void 0 : t(),
                        "aria-label": g("customerHub.aria.label.closeDialog")
                    }, r().createElement(Q.Tw, {
                        size: "medium"
                    }))];
                    return r().createElement(l.mN, {
                        id: h
                    }, r().createElement(ae, {
                        context: v
                    }, r().createElement(ue, X()({
                        ref: E.setFloating,
                        side: o,
                        fullscreen: s,
                        style: w,
                        className: (0, ee.A)("atlas-drawer", "kl-hub-drawer", c),
                        "aria-labelledby": x,
                        "aria-modal": "true",
                        "aria-live": "polite"
                    }, C()), r().createElement(ie, {
                        className: (0, ee.A)("atlas-drawer__header", "kl-hub-drawer__header"),
                        opaqueHeaderBackground: m
                    }, r().createElement(oe, null, d && r().createElement(ne.zx, {
                        role: "button",
                        variant: "icon",
                        onClick: u,
                        "aria-label": g("customerHub.aria.label.goBack")
                    }, r().createElement(Q.rV, null))), r().createElement(se, {
                        id: x
                    }, "string" == typeof i ? r().createElement(re.k8, {
                        noSpacing: !0
                    }, i) : i), r().createElement(ce, null, k)), r().createElement(me, {
                        className: "kl-hub-drawer__content"
                    }, a))))
                })).withConfig({
                    displayName: "CustomerHubWindow__StyledDrawer",
                    componentId: "sc-9sxxeg-0"
                })(["", ""], (({
                    fullscreen: e
                }) => !e && (0, K.iv)(["width:400px;"])));
            const Pe = () => {
                const {
                    isOpen: e,
                    setIsOpen: t
                } = h(), a = he(), n = (0, pe.Qt)(), {
                    back: l,
                    canGoBack: i,
                    replace: o
                } = (0, pe.HJ)(), s = (0, pe.rM)(), c = _(), d = (0, u.rV)(), m = function(e) {
                    const t = "kl-hub-route";
                    return "/" === e ? `${t}-home` : `${t}-${e.slice(1).replace(/\d.*/,"id").replace("/","-")}`
                }(s);
                return r().createElement(Se, {
                    isOpen: e,
                    handleClose: () => t(!1),
                    side: a ? "bottom" : d.layout.positionOnDesktop,
                    fullscreen: a,
                    title: c,
                    showBackButton: !n.hideBackButton,
                    onBackClick: () => {
                        var e;
                        i ? l() : o(null != (e = n.defaultBackDestination) ? e : "/")
                    },
                    opaqueHeaderBackground: !n.transparentHeader,
                    headerActions: n.headerActions,
                    className: m
                }, r().createElement(Te, null, r().createElement(ge, null)))
            };
            a(60873);
            const Oe = K.ZP.div.withConfig({
                    displayName: "Badge__StyledBadge",
                    componentId: "sc-1m1m7rc-0"
                })(["display:inline-flex;align-items:center;padding:var(--atlas-space-mini) var(--atlas-space-small);"]),
                Re = K.ZP.div.withConfig({
                    displayName: "Badge__IconContainer",
                    componentId: "sc-1m1m7rc-1"
                })(["margin-right:var(--atlas-space-tiny);line-height:0px;"]),
                De = ({
                    size: e = "normal",
                    children: t,
                    icon: a
                }) => {
                    let l, i, o;
                    return "tiny" === e ? (l = r().createElement(re.l5, {
                        bold: !0
                    }, t), i = "mini") : "small" === e ? (l = r().createElement(re.OA, {
                        bold: !0
                    }, t), i = "small") : (l = r().createElement(re.Rw, {
                        bold: !0
                    }, t), i = "medium"), a && (o = (0, n.cloneElement)(a, {
                        size: i
                    })), r().createElement(Oe, {
                        className: "kl-hub-badge"
                    }, null != o && r().createElement(Re, null, o), l)
                };
            var Le = a(36306);
            const He = K.ZP.div.withConfig({
                    displayName: "SectionHeader__Container",
                    componentId: "sc-jwbo69-0"
                })(["height:40px;display:flex;align-items:center;justify-content:space-between;"]),
                Ae = ({
                    children: e,
                    action: t,
                    className: a
                }) => r().createElement(He, {
                    className: a
                }, r().createElement(re.k8, {
                    noSpacing: !0
                }, e), r().createElement(Le.Z, null, t));
            var Me = a(87789),
                Ze = a.n(Me);
            a(84523);

            function Be(e) {
                switch (e) {
                    case "curved":
                        return {
                            buttonNormal: 8,
                            buttonSmall: 8,
                            inputNormal: 8,
                            inputSmall: 8,
                            cardNormal: 32,
                            cardSmall: 12,
                            toast: 12,
                            tabs: 12,
                            image: 8,
                            loyalty: 4
                        };
                    case "rounded":
                        return {
                            buttonNormal: 20,
                            buttonSmall: 16,
                            inputNormal: 20,
                            inputSmall: 16,
                            cardNormal: 32,
                            cardSmall: 24,
                            toast: 24,
                            tabs: 26,
                            image: 16,
                            loyalty: 16
                        };
                    default:
                        return {
                            buttonNormal: 2,
                            buttonSmall: 2,
                            inputNormal: 2,
                            inputSmall: 2,
                            cardNormal: 2,
                            cardSmall: 2,
                            toast: 2,
                            tabs: 2,
                            image: 2,
                            loyalty: 2
                        }
                }
            }

            function Ue(e) {
                switch (e) {
                    case "curved":
                        return 8;
                    case "rounded":
                        return 50;
                    default:
                        return 2
                }
            }

            function Fe(e) {
                const t = document.createElement(e);
                t.style.display = "none", document.body.appendChild(t);
                const a = getComputedStyle(t),
                    n = a.fontFamily,
                    r = a.fontWeight;
                return t.remove(), {
                    fontFamily: n,
                    fontWeight: r
                }
            }
            const ze = ({
                    settings: e
                }) => {
                    const t = (0, n.useMemo)((() => function(e) {
                        var t, a, n;
                        const r = Be(e.layout.shape);
                        let l = e.fonts.headingFont.fontFamily,
                            i = e.fonts.headingFont.fontWeight;
                        if ("inherit" === l) {
                            const e = Fe("h1");
                            l = e.fontFamily;
                            const t = parseInt(e.fontWeight, 10);
                            i = Number.isNaN(t) ? 500 : t
                        }
                        let o = e.fonts.paragraphFont.fontFamily,
                            s = e.fonts.paragraphFont.fontWeight;
                        if ("inherit" === o) {
                            const e = Fe("p");
                            o = e.fontFamily;
                            const t = parseInt(e.fontWeight, 10);
                            s = Number.isNaN(t) ? 400 : t
                        }
                        return `\n    :root {\n      --atlas-font-family: ${o};\n      --atlas-text-primary: ${e.fonts.paragraphFont.fontColor};\n      --atlas-font-weight-normal: ${null!=s?s:400};\n      --atlas-heading-font-family: ${l};\n      --atlas-heading-text-primary: ${e.fonts.headingFont.fontColor};\n      --atlas-font-weight-heading: ${null!=i?i:500};\n      --atlas-button-primary: ${e.button.color};\n      --atlas-primary-color: ${e.button.color};\n      --atlas-button-text-transform: ${null!=(t=e.button.textTransform)?t:"none"};\n      --atlas-button-border-radius-small: ${r.buttonSmall}px;\n      --atlas-button-border-radius-normal: ${r.buttonNormal}px;\n      --atlas-input-border-radius-small: ${r.inputSmall}px;\n      --atlas-input-border-radius-normal: ${r.inputNormal}px;\n      --atlas-card-border-radius-small: ${r.cardSmall}px;\n      --atlas-card-border-radius-normal: ${r.cardNormal}px;\n      --atlas-toast-border-radius: ${r.toast}px;\n      --atlas-thumbnail-border-radius: ${r.image}px;\n      --atlas-tabs-border-radius: ${r.tabs}px;\n      --atlas-loyalty-border-radius: ${r.loyalty}px;\n      --atlas-text-primary-inverse: ${e.button.textColor};\n      --atlas-background-main: ${e.layout.backgroundColor};\n    }\n\n    ${null!=(a=null==(n=e.design)?void 0:n.customCss)?a:""}\n  `
                    }(e)), [e]);
                    return r().createElement("style", null, t)
                },
                qe = (0, n.memo)((() => {
                    const e = (0, u.rV)();
                    return r().createElement(ze, {
                        settings: e
                    })
                }));
            qe.displayName = "ConnectedCustomStyles";
            const je = ["children"],
                Ve = (0, K.iv)(["border:1px solid var(--atlas-overlay-medium);display:block;width:100%;box-sizing:border-box;background-color:var(--atlas-background-content);color:var(--atlas-text-primary);border-radius:var(--atlas-card-border-radius-small);box-shadow:none;outline-offset:0px;text-align:initial;padding:0px;overflow:hidden;"]),
                We = K.ZP.div.attrs((e => ({
                    className: (0, ee.A)("kl-hub-card", e.className)
                }))).withConfig({
                    displayName: "Card",
                    componentId: "sc-tt0xtt-0"
                })(["", ";"], Ve),
                Ge = (0, K.ZP)(We).attrs((e => ({
                    className: (0, ee.A)("kl-hub-dashed-card", e.className)
                }))).withConfig({
                    displayName: "Card__DashedCard",
                    componentId: "sc-tt0xtt-1"
                })(["", " border:none;"], (({
                    shape: e
                }) => {
                    const t = Be(e);
                    return (0, K.iv)(["background-image:url(\"data:image/svg+xml,%3csvg width='100%25' height='100%25' xmlns='http://www.w3.org/2000/svg'%3e%3crect width='100%25' height='100%25' fill='none' rx='", "' ry='", "' stroke='rgba(0,0,0,0.15)' stroke-width='4' stroke-dasharray='9%2c 9' stroke-dashoffset='0' stroke-linecap='square'/%3e%3c/svg%3e\");"], t.cardSmall, t.cardSmall)
                })),
                $e = K.ZP.div.withConfig({
                    displayName: "Card__CardContent",
                    componentId: "sc-tt0xtt-2"
                })(["padding:var(--atlas-space-large) var(--atlas-space-jumbo) var(--atlas-space-jumbo);&:not(:last-child){padding-bottom:var(--atlas-space-large);}"]),
                Ye = K.ZP.div.withConfig({
                    displayName: "Card__StyledCardHeader",
                    componentId: "sc-tt0xtt-3"
                })(["padding:var(--atlas-space-large) var(--atlas-space-medium) 0px;"]),
                Ke = e => {
                    let {
                        children: t
                    } = e, a = Ze()(e, je);
                    return r().createElement(Ye, a, "string" == typeof t ? r().createElement(re.k8, {
                        noSpacing: !0
                    }, t) : t)
                },
                Je = K.ZP.div.withConfig({
                    displayName: "Card__CardFooter",
                    componentId: "sc-tt0xtt-4"
                })(["padding:0px var(--atlas-space-jumbo) var(--atlas-space-jumbo);"]),
                Xe = ({
                    lines: e
                }) => r().createElement(r().Fragment, null, e.map((e => r().createElement(re.d9, {
                    noSpacing: !0,
                    key: e
                }, e)))),
                Qe = ({
                    address: e
                }) => {
                    const {
                        t: t
                    } = (0, b.ql)();
                    return r().createElement(We, null, e.isDefault && r().createElement(Ke, null, t("customerHub.profile.address.default")), r().createElement($e, null, r().createElement(Xe, {
                        lines: e.addressLines
                    })))
                };

            function et(e) {
                if (!e) return null;
                const t = e.replace(/\D/g, "");
                return t.length >= 4 ? t.slice(-4) : t || null
            }
            const tt = K.ZP.div.withConfig({
                    displayName: "PaymentOptionLabel__CreditCardRow",
                    componentId: "sc-klqdwk-0"
                })(["display:flex;align-items:center;"]),
                at = ({
                    company: e,
                    cardNumber: t
                }) => {
                    const {
                        t: a
                    } = (0, b.ql)();
                    return r().createElement(tt, null, r().createElement(Q.ci, {
                        style: {
                            marginRight: "var(--atlas-space-mini)"
                        }
                    }), r().createElement(re.d9, {
                        noSpacing: !0
                    }, a("customerHub.card.companyAndLastFourDigits", {
                        company: e,
                        digits: et(t)
                    })))
                },
                nt = (0, K.ZP)(Je).withConfig({
                    displayName: "SavedPayment__StyledFooter",
                    componentId: "sc-lmbe4r-0"
                })(["display:flex;gap:var(--atlas-space-small);"]),
                rt = ({
                    payment: e
                }) => {
                    const {
                        t: t
                    } = (0, b.ql)();
                    return r().createElement(We, null, r().createElement(Ke, null, r().createElement(at, {
                        cardNumber: e.cardNumber,
                        company: e.cardCompany
                    })), r().createElement($e, null, r().createElement(Xe, {
                        lines: e.addressLines
                    })), r().createElement(nt, null, r().createElement(ne.zx, {
                        variant: "secondary"
                    }, t("customerHub.profile.address.edit")), r().createElement(ne.zx, {
                        variant: "icon",
                        title: t("customerHub.profile.payment.edit"),
                        "aria-label": t("customerHub.profile.payment.edit")
                    }, r().createElement(Q.XH, null))))
                };
            var lt = a(69258),
                it = a(56403),
                ot = a(76164),
                st = a(86801);
            const ct = (0, K.ZP)(it.o).withConfig({
                    displayName: "EmailLoginForm__EmailInput",
                    componentId: "sc-16hxxq6-0"
                })(["display:block;margin-bottom:var(--atlas-space-mini);"]),
                dt = (0, K.ZP)(ot.B).withConfig({
                    displayName: "EmailLoginForm__MarketingConsentCheckbox",
                    componentId: "sc-16hxxq6-1"
                })(["margin-bottom:var(--atlas-space-mini);"]),
                ut = /^[a-zA-Z0-9._%+-]+@[a-zA-Z0-9.-]+\.[a-zA-Z]{2,4}$/,
                mt = () => {
                    const {
                        t: e
                    } = (0, b.ql)(), {
                        redirect: t
                    } = (0, pe.HJ)(), {
                        companyId: a
                    } = (0, f.aC)(), n = (0, u.rV)(), {
                        register: l,
                        handleSubmit: i,
                        clearErrors: o,
                        setValue: s,
                        setError: c,
                        formState: {
                            errors: d
                        }
                    } = (0, lt.cI)({
                        defaultValues: {
                            email: "",
                            consentToMarketing: !0
                        }
                    }), {
                        trigger: m,
                        isMutating: p
                    } = function() {
                        const e = (0, k.m)();
                        return (0, H.Z)(M.g.initiateLogin, ((t, {
                            arg: a
                        }) => e.initiateLogin(a)))
                    }();
                    return r().createElement("form", {
                        onSubmit: i((async ({
                            email: n,
                            consentToMarketing: r
                        }) => {
                            try {
                                await m({
                                    email: n,
                                    company_id: a
                                }), t("/checkOTP", {
                                    email: n,
                                    consentToMarketing: r
                                }, !0)
                            } catch (t) {
                                c("root", {
                                    type: "server",
                                    message: e("customerHub.auth.initiate.serverError")
                                })
                            }
                        }))
                    }, r().createElement(ct, X()({
                        full: !0,
                        placeholder: e("customerHub.auth.initiate.input.placeholder")
                    }, l("email", {
                        required: e("customerHub.auth.initiate.input.emailRequired"),
                        minLength: 1,
                        pattern: {
                            value: ut,
                            message: e("customerHub.auth.initiate.input.invalidEmail")
                        }
                    }), {
                        onChange: e => {
                            o("email"), s("email", e.currentTarget.value)
                        },
                        invalid: !!d.email
                    })), d.email && r().createElement(re.TB, {
                        variant: "negative"
                    }, d.email.message), n.general.marketingListId && r().createElement(dt, {
                        checkbox: r().createElement(st.X, X()({}, l("consentToMarketing"), {
                            id: "consentToMarketing",
                            defaultChecked: !0
                        })),
                        label: e("customerHub.auth.initiate.consentToMarketing")
                    }), r().createElement(ne.zx, {
                        full: !0,
                        disabled: p
                    }, e("customerHub.auth.SignIn")), d.root && r().createElement(re.TB, {
                        variant: "negative",
                        style: {
                            marginTop: "var(--atlas-space-mini)"
                        }
                    }, d.root.message))
                };
            const pt = K.ZP.div.withConfig({
                    displayName: "LoginBlock__LoginContainer",
                    componentId: "sc-16ox899-0"
                })(["padding:var(--atlas-space-huge) var(--atlas-space-medium);font-family:var(--atlas-font-family);cursor:auto;"]),
                gt = (0, K.ZP)(re.FJ).withConfig({
                    displayName: "LoginBlock__PolicyMessage",
                    componentId: "sc-16ox899-1"
                })(["text-align:center;margin-top:var(--atlas-space-small);margin-bottom:0;"]),
                ht = ({
                    label: e
                }) => {
                    var t, a;
                    const n = (0, u.rV)(),
                        {
                            t: l
                        } = (0, b.ql)(),
                        i = (0, s.FV)(),
                        o = !(null == i || !i.userId),
                        {
                            trigger: c,
                            isMutating: d
                        } = ye(),
                        m = null == n || null == (t = n.authentication) ? void 0 : t.isOtpEnabled;
                    let p;
                    n.general.privacyPolicyLink && n.general.termsOfServiceLink ? p = r().createElement(gt, {
                        variant: "secondary"
                    }, r().createElement("span", null, "By signing in, you agree to our "), r().createElement(re.rU, {
                        href: n.general.privacyPolicyLink,
                        target: "_blank"
                    }, "privacy policy"), r().createElement("span", null, " and "), r().createElement(re.rU, {
                        href: n.general.termsOfServiceLink,
                        target: "_blank"
                    }, "terms of service"), r().createElement("span", null, ".")) : n.general.privacyPolicyLink ? p = r().createElement(gt, {
                        variant: "secondary"
                    }, r().createElement("span", null, "By signing in, you agree to our "), r().createElement(re.rU, {
                        href: n.general.privacyPolicyLink,
                        target: "_blank"
                    }, "privacy policy"), r().createElement("span", null, ".")) : n.general.termsOfServiceLink && (p = r().createElement(gt, {
                        variant: "secondary"
                    }, r().createElement("span", null, "By signing in, you agree to our "), r().createElement(re.rU, {
                        href: n.general.termsOfServiceLink,
                        target: "_blank"
                    }, "terms of service"), r().createElement("span", null, ".")));
                    const g = (0, pe.rM)(),
                        h = function(e, t) {
                            if (function(e) {
                                    return e.startsWith("https://shopify.com") || e.includes("customer_authentication")
                                }(e)) return `/customer_authentication/login?return_to=${encodeURIComponent(`/#k-hub${t}`)}`;
                            return e
                        }(null != (a = null == i ? void 0 : i.storefrontRoutes.login) ? a : "", g);
                    return r().createElement(pt, null, e && r().createElement(re.XJ, null, e), m ? r().createElement(mt, null) : r().createElement(r().Fragment, null, o ? r().createElement(ne.zx, {
                        full: !0,
                        onClick: () => c(),
                        disabled: d
                    }, l("customerHub.auth.SignIn")) : r().createElement(ne.Qj, {
                        full: !0,
                        href: h
                    }, l("customerHub.auth.SignIn"))), r().createElement(Le.Z, null, p))
                },
                vt = K.ZP.section.withConfig({
                    displayName: "Profile__MainInfoContainer",
                    componentId: "sc-2jti99-0"
                })(["display:flex;flex-direction:column;align-items:center;"]),
                Et = K.ZP.div.withConfig({
                    displayName: "Profile__TopContainer",
                    componentId: "sc-2jti99-1"
                })(["background:var(--atlas-background-content);padding:0 var(--atlas-space-jumbo) var(--atlas-space-jumbo);"]),
                ft = K.ZP.div.withConfig({
                    displayName: "Profile__BottomContainer",
                    componentId: "sc-2jti99-2"
                })(["padding:var(--atlas-space-jumbo);"]),
                bt = K.ZP.section.withConfig({
                    displayName: "Profile__Buttons",
                    componentId: "sc-2jti99-3"
                })(["display:flex;flex-direction:column;margin-top:var(--atlas-space-enormous);gap:var(--atlas-space-mini);"]),
                yt = K.ZP.section.withConfig({
                    displayName: "Profile__SubscriptionContainer",
                    componentId: "sc-2jti99-4"
                })(["margin-top:var(--atlas-space-small);display:flex;flex-direction:column;align-items:center;"]),
                Ct = K.ZP.div.withConfig({
                    displayName: "Profile__CardContainer",
                    componentId: "sc-2jti99-5"
                })(["display:flex;flex-direction:column;gap:var(--atlas-space-mini);"]),
                _t = K.ZP.div.withConfig({
                    displayName: "Profile__ChannelBadges",
                    componentId: "sc-2jti99-6"
                })(["display:flex;align-items:center;gap:var(--atlas-space-small);"]),
                wt = ({
                    channel: e
                }) => {
                    const {
                        t: t
                    } = (0, b.ql)();
                    let a, n;
                    return "sms" === e ? (a = t("customerHub.profile.marketingChannel.sms"), n = r().createElement(Q._P, null)) : "email" === e && (a = t("customerHub.profile.marketingChannel.email"), n = r().createElement(Q.bV, null)), a ? r().createElement(De, {
                        icon: n,
                        size: "small"
                    }, a) : null
                },
                xt = () => {
                    const {
                        data: e,
                        isLoading: t,
                        error: a
                    } = xe(), {
                        t: n
                    } = (0, b.ql)(), {
                        navigate: l
                    } = (0, pe.HJ)(), i = (0, Ee.u)(), {
                        token: o,
                        setToken: c
                    } = (0, f.aC)(), d = (0, P.A)(), m = (0, u.rV)();
                    var p;
                    if (!o) return r().createElement(ht, {
                        label: (null == m || null == (p = m.customText) ? void 0 : p.profileActionText) || n("customerHub.auth.cta.profile")
                    });
                    if (t) return r().createElement(ve.$, {
                        size: "jumbo",
                        cover: !0
                    });
                    if (!e || a) return r().createElement(we, {
                        label: n("customerHub.profile.error")
                    });
                    const g = d.getFullProfileLink();
                    return r().createElement("div", {
                        className: "kl-hub-profile"
                    }, r().createElement(Et, {
                        className: "kl-hub-profile__top"
                    }, r().createElement(vt, null, e.name && r().createElement(re.nL, {
                        noSpacing: !0
                    }, e.name), r().createElement(re.d9, {
                        noSpacing: !0
                    }, e.email), 0 !== e.channelSubscriptions.length && r().createElement(yt, null, r().createElement(re.TB, {
                        noSpacing: !0
                    }, n("customerHub.profile.subscribedVia")), r().createElement(_t, null, e.channelSubscriptions.map((e => r().createElement(wt, {
                        channel: e,
                        key: e
                    })))))), r().createElement(bt, null, r().createElement(ne.Qj, {
                        full: !0,
                        variant: "secondary",
                        href: g,
                        target: "_blank"
                    }, n("customerHub.profile.openShopifyProfile")), r().createElement(ne.zx, {
                        full: !0,
                        variant: "secondary",
                        onClick: () => l("/profile/edit")
                    }, n("customerHub.profile.edit")), r().createElement(ne.zx, {
                        full: !0,
                        onClick: () => {
                            i(), c(void 0), (0, s.au)(void 0), (0, s.Nc)(), l("/"), document.location.href = d.getLogoutLink()
                        }
                    }, n("customerHub.profile.logout")))), r().createElement(ft, {
                        className: "kl-hub-profile__cards"
                    }, 0 !== e.savedAddresses.length && r().createElement(Ct, null, r().createElement(Ae, {
                        action: r().createElement(ne.Qj, {
                            variant: "secondary",
                            size: "small",
                            href: g
                        }, n("customerHub.profile.addresses.manage"))
                    }, n("customerHub.profile.addresses")), e.savedAddresses.map((e => r().createElement(Qe, {
                        address: e,
                        key: e.id
                    })))), 0 !== e.savedPayments.length && r().createElement(Ct, null, r().createElement(Ae, null, n("customerHub.profile.payments")), e.savedPayments.map((e => r().createElement(rt, {
                        payment: e,
                        key: e.id
                    }))))))
                },
                It = (0, n.lazy)((() => Promise.all([a.e(3050), a.e(1811), a.e(9282)]).then(a.bind(a, 36998)))),
                kt = () => {
                    const {
                        t: e
                    } = (0, b.ql)(), {
                        data: t,
                        isLoading: a
                    } = xe();
                    return w((() => e("customerHub.profile.edit"))), a ? r().createElement(Ce, {
                        foreground: !0
                    }, r().createElement(ve.$, {
                        cover: !0,
                        size: "jumbo"
                    })) : t ? r().createElement(Ce, {
                        foreground: !0
                    }, r().createElement(n.Suspense, {
                        fallback: r().createElement(ve.$, {
                            cover: !0,
                            size: "jumbo"
                        })
                    }, r().createElement(It, {
                        profile: t
                    }))) : r().createElement(Ce, {
                        foreground: !0
                    }, r().createElement(we, {
                        label: e("customerHub.profile.edit.no-profile")
                    }))
                },
                Nt = ["children", "isActive", "onClick", "onKeyDown", "value"],
                Tt = (0, K.ZP)(ne.zx).withConfig({
                    displayName: "Tab__TabButton",
                    componentId: "sc-p6h47p-0"
                })(["border:0;flex:1;background-color:transparent;position:relative;text-transform:none;&:hover:not(:disabled),&:focus:not(:disabled),&:active:not(:disabled){background-color:transparent;}", ""], (({
                    isActive: e
                }) => e && (0, K.iv)(["--kl-local-button-color:var(--atlas-text-primary-inverse);"]))),
                St = e => {
                    let {
                        children: t,
                        isActive: a,
                        onClick: n,
                        onKeyDown: l,
                        value: i
                    } = e, o = Ze()(e, Nt);
                    return r().createElement(Tt, X()({
                        variant: "secondary",
                        size: "normal",
                        isActive: a,
                        tabIndex: a ? 0 : -1,
                        onClick: e => null == n ? void 0 : n(e, i),
                        onKeyDown: e => null == l ? void 0 : l(e),
                        role: "tab",
                        className: "kl-hub-tab"
                    }, o), t)
                };
            var Pt = a(72737);
            const Ot = K.ZP.div.withConfig({
                    displayName: "Tabs__TabWrapper",
                    componentId: "sc-1d8k79d-0"
                })(["position:relative;"]),
                Rt = K.ZP.div.withConfig({
                    displayName: "Tabs__TabContainer",
                    componentId: "sc-1d8k79d-1"
                })(["border:1px solid var(--atlas-overlay-medium);border-radius:var(--atlas-tabs-border-radius);display:flex;gap:var(--atlas-space-tiny);padding:var(--atlas-space-tiny);background:var(--atlas-background-content);"]),
                Dt = K.ZP.div.withConfig({
                    displayName: "Tabs__ActiveIndicator",
                    componentId: "sc-1d8k79d-2"
                })(["position:absolute;border-radius:var(--atlas-button-border-radius-normal);transition-property:left,top;transition-duration:150ms;transition-timing-function:linear;background:var(--atlas-button-primary);", ""], (0, le.K)()),
                Lt = ({
                    children: e,
                    value: t,
                    onChange: a,
                    className: l
                }) => {
                    const i = (0, n.useRef)(null),
                        o = (0, n.useRef)(null),
                        s = new Map,
                        [c, d] = (0, n.useState)(void 0);
                    let u = 0;
                    const m = n.Children.map(e, (e => {
                            var r;
                            const l = null != (r = e.props.value) ? r : u;
                            s.set(l, u);
                            const i = l === t;
                            return u += 1, (0, n.cloneElement)(e, {
                                isActive: i,
                                onClick: n => {
                                    t !== l && (null == a || a(l)), null == e.props.onClick || e.props.onClick(n, l)
                                },
                                onKeyDown: e => {
                                    var t, a;
                                    const n = document.activeElement,
                                        r = null == (t = o.current) ? void 0 : t.firstChild,
                                        l = null == (a = o.current) ? void 0 : a.lastChild,
                                        i = (null == n ? void 0 : n.nextElementSibling) || null,
                                        s = (null == n ? void 0 : n.previousElementSibling) || null;
                                    "ArrowLeft" === e.key ? s instanceof HTMLButtonElement ? s.focus() : l instanceof HTMLButtonElement && l.focus() : "ArrowRight" === e.key && (i instanceof HTMLButtonElement ? i.focus() : r instanceof HTMLButtonElement && r.focus())
                                }
                            })
                        })),
                        p = (0, Pt.$)(((e = !0) => {
                            let a = (() => {
                                var e;
                                const a = s.get(t);
                                if (void 0 !== a && null != (e = o.current) && e.children.length) {
                                    const e = o.current.children[a];
                                    if (!e) return;
                                    const t = o.current.getBoundingClientRect(),
                                        n = e.getBoundingClientRect();
                                    return {
                                        left: n.left - t.left,
                                        top: n.top - t.top,
                                        width: n.width,
                                        height: n.height
                                    }
                                }
                            })();
                            !e && a && (a = Object.assign({}, a, {
                                transition: "none"
                            })), d(a)
                        }));
                    return (0, n.useEffect)((() => {
                        p()
                    }), [t, p, m.length]), (0, n.useEffect)((() => {
                        let e;
                        return o.current && (e = new ResizeObserver((() => {
                            p(!1)
                        })), e.observe(o.current)), () => {
                            var t;
                            null == (t = e) || t.disconnect()
                        }
                    }), [p]), r().createElement(Ot, {
                        className: (0, ee.A)("kl-hub-tabs", l)
                    }, c && r().createElement(Dt, {
                        ref: i,
                        style: c
                    }), r().createElement(Rt, {
                        role: "tablist",
                        ref: o,
                        className: "kl-hub-tabs__tablist"
                    }, m))
                };

            function Ht() {
                var e, t, a, n;
                const r = (0, u.rV)(),
                    {
                        isLoggedIn: l
                    } = (0, f.aC)();
                return {
                    webChatEnabled: "ALL" === (null == (e = r.webChat) ? void 0 : e.visibility) || l && "LOGGED_IN" === (null == (t = r.webChat) ? void 0 : t.visibility) || !l && "LOGGED_OUT" === (null == (a = r.webChat) ? void 0 : a.visibility),
                    userCanSendWebChatMessage: l || (null == (n = r.webChat) ? void 0 : n.aiAgentEnabled)
                }
            }
            const At = ["children"],
                Mt = K.ZP.div.withConfig({
                    displayName: "CustomerHubTabs__Layout",
                    componentId: "sc-1v19f6u-0"
                })(["height:100%;width:100%;display:flex;flex-direction:column;position:relative;"]),
                Zt = K.ZP.div.withConfig({
                    displayName: "CustomerHubTabs__OutletSection",
                    componentId: "sc-1v19f6u-1"
                })(["flex:1;overflow-y:auto;position:relative;"]),
                Bt = K.ZP.div.withConfig({
                    displayName: "CustomerHubTabs__TabSection",
                    componentId: "sc-1v19f6u-2"
                })(["padding:var(--atlas-space-medium);background-color:var(--atlas-background-content);border-top:1px solid var(--atlas-overlay-light);position:sticky;bottom:0;z-index:1;"]),
                Ut = K.ZP.span.withConfig({
                    displayName: "CustomerHubTabs__NotificationBadge",
                    componentId: "sc-1v19f6u-3"
                })(["position:absolute;top:4px;right:var(--atlas-space-tiny);width:var(--atlas-button-icon-size-tiny);height:var(--atlas-button-icon-size-tiny);background:var(--atlas-button-primary);border-radius:50%;"]),
                Ft = e => {
                    let {
                        children: t
                    } = e, a = Ze()(e, At);
                    const {
                        ticket: n
                    } = $(), {
                        t: l
                    } = (0, b.ql)();
                    return r().createElement(St, a, r().createElement(r().Fragment, null, t, n && !n.readByCustomer && r().createElement(Ut, {
                        role: "status",
                        "aria-label": l("customerHub.chat.unreadMessages")
                    })))
                },
                zt = () => {
                    var e;
                    const t = (0, pe.rM)(),
                        {
                            hideTabs: a
                        } = (0, pe.Qt)(),
                        {
                            navigate: l
                        } = (0, pe.HJ)(),
                        i = (0, u.rV)(),
                        o = (0, n.useRef)(null),
                        s = function() {
                            const e = (0, u.rV)(),
                                {
                                    t: t
                                } = (0, b.ql)(),
                                {
                                    webChatEnabled: a
                                } = Ht();
                            return (0, n.useMemo)((() => {
                                var n;
                                const r = [{
                                    value: "/",
                                    label: t("customerHub.tabs.forYou")
                                }, {
                                    value: "/orders",
                                    label: t("customerHub.tabs.orders")
                                }, {
                                    value: "/profile",
                                    label: t("customerHub.tabs.profile")
                                }];
                                var l;
                                return a ? r.splice(2, 0, {
                                    renderAs: "/chat",
                                    value: null != (l = e.faq) && l.enabled ? "/faq" : "/chat",
                                    label: t("customerHub.tabs.chat")
                                }) : null != (n = e.faq) && n.enabled && r.splice(2, 0, {
                                    value: "/faq",
                                    label: t("customerHub.tabs.faq")
                                }), r
                            }), [t, e.faq, a])
                        }();
                    let c = t;
                    return null != (e = i.faq) && e.enabled && "/chat" === c && (c = "/faq"), r().createElement(Mt, null, r().createElement(Zt, {
                        ref: o
                    }, r().createElement(ge, null)), !a && r().createElement(Bt, null, r().createElement(Lt, {
                        value: c,
                        className: "kl-hub-navigation-tabs"
                    }, s.map((({
                        value: e,
                        label: a,
                        renderAs: n
                    }) => {
                        const i = "/chat" === n ? Ft : St;
                        return r().createElement(i, {
                            value: e,
                            key: e,
                            onClick: (e, a) => {
                                (e => {
                                    if (e !== t) {
                                        var a;
                                        let t;
                                        t = "/" === e ? "Customer Hub Clicked For You Tab" : `Customer Hub Clicked ${e.slice(1).charAt(0).toUpperCase()+e.slice(2)} Tab`, null == (a = o.current) || a.scrollTo(0, 0), (0, m.ZD)(t, {}), l(e)
                                    }
                                })(`${a}`)
                            }
                        }, a)
                    })))))
                };

            function qt() {
                const e = (0, k.m)(),
                    t = (0, f.aC)();
                return (0, L.ZP)(t ? M.g.recentOrders : null, (() => e.getRecentOrders()))
            }
            const jt = K.ZP.div.withConfig({
                    displayName: "Carousel__CarouselScrollingContainer",
                    componentId: "sc-w0mm89-0"
                })(["width:100%;overflow-x:auto;display:flex;gap:var(--atlas-space-small);scrollbar-width:none;&::-webkit-scrollbar{display:none;}", " &:last-child{margin-right:var(--atlas-space-small);}"], (0, le.K)("flex")),
                Vt = ({
                    children: e,
                    className: t
                }) => r().createElement(jt, {
                    className: (0, ee.A)(t, "kl-hub-thumbnail-carousel")
                }, e);
            var Wt = "data:image/svg+xml;base64,PHN2ZyB2ZXJzaW9uPSIxLjEiCiAgICAgd2lkdGg9IjMwMCIgaGVpZ2h0PSIzMDAiCiAgICAgeG1sbnM9Imh0dHA6Ly93d3cudzMub3JnLzIwMDAvc3ZnIj4KICA8cmVjdCB3aWR0aD0iMTAwJSIgaGVpZ2h0PSIxMDAlIiBmaWxsPSJyZ2JhKDAsMCwwLDAuMikiIC8+Cjwvc3ZnPg==";
            const Gt = K.ZP.img.attrs((e => ({
                    className: (0, ee.A)("kl-hub-img", e.className)
                }))).withConfig({
                    displayName: "Image",
                    componentId: "sc-92jtuc-0"
                })([""]),
                $t = ["src"],
                Yt = (0, K.ZP)(Gt).withConfig({
                    displayName: "ProductThumbnail__StyledImage",
                    componentId: "sc-5vktn7-0"
                })(["", " border-radius:var(--atlas-thumbnail-border-radius);object-fit:cover;flex-shrink:0;border:1px solid var(--atlas-border-light);max-width:unset;overflow:hidden;"], (({
                    size: e = 120
                }) => (0, K.iv)(["height:", "px;width:", "px;"], e, e))),
                Kt = e => {
                    let {
                        src: t
                    } = e, a = Ze()(e, $t);
                    const [l, i] = (0, n.useState)(!1), o = l ? Wt : t;
                    return (0, n.useEffect)((() => {
                        i(!1)
                    }), [t]), r().createElement(Yt, X()({
                        src: o || Wt,
                        draggable: !1,
                        onError: e => {
                            i(!0), null == a.onError || a.onError(e)
                        }
                    }, a))
                };

            function Jt(e) {
                switch (e) {
                    case "CANCELED":
                        return "customerHub.order.status.cancelled";
                    case "REFUNDED":
                        return "customerHub.order.status.refunded";
                    case "CONFIRMED_SHIPMENT":
                    case "FULFILLED":
                    case "MARKED_AS_FULFILLED":
                        return "customerHub.order.status.shipped";
                    case "OUT_FOR_DELIVERY":
                        return "customerHub.order.status.outForDelivery";
                    case "READY_FOR_PICKUP":
                        return "customerHub.order.status.readyForPickup";
                    case "DELIVERED":
                        return "customerHub.order.status.delivered";
                    case "LABEL_PRINTED":
                    case "LABEL_PURCHASED":
                        return "customerHub.order.status.labelCreated";
                    case "ATTEMPTED_DELIVERY":
                        return "customerHub.order.status.attemptedDelivery";
                    case "CONFIRMED":
                        return "customerHub.order.status.confirmed";
                    case "IN_TRANSIT":
                        return "customerHub.order.status.inTransit";
                    case "FAILURE":
                        return "customerHub.order.status.failure";
                    case "NOT_DELIVERED":
                        return "customerHub.order.status.notDelivered";
                    default:
                        return "customerHub.order.status.placed"
                }
            }

            function Xt(e) {
                return "CANCELED" === e || "REFUNDED" === e || "DELIVERED" === e ? "COMPLETE" : "IN_PROGRESS"
            }
            const Qt = (0, K.ZP)(We).withConfig({
                    displayName: "OrderCard__StyledCard",
                    componentId: "sc-1rzwysw-0"
                })(["padding-bottom:var(--atlas-space-jumbo);cursor:pointer;"]),
                ea = (0, K.ZP)(Vt).withConfig({
                    displayName: "OrderCard__StyledCarousel",
                    componentId: "sc-1rzwysw-1"
                })(["padding:0px var(--atlas-space-jumbo);"]),
                ta = (0, K.ZP)($e).withConfig({
                    displayName: "OrderCard__OrderHeader",
                    componentId: "sc-1rzwysw-2"
                })(["display:flex;align-items:center;"]),
                aa = K.ZP.div.withConfig({
                    displayName: "OrderCard__OrderInfo",
                    componentId: "sc-1rzwysw-3"
                })(["flex:1;"]),
                na = ({
                    order: e,
                    viewSource: t
                }) => {
                    const {
                        navigate: a
                    } = (0, pe.HJ)(), {
                        t: n
                    } = (0, b.ql)(), l = (0, b.OZ)(), i = l(e.estimatedDeliveryAt, {
                        weekday: "long",
                        month: "short",
                        day: "numeric"
                    });
                    let o;
                    if ("CANCELED" === e.status) {
                        const t = l(e.cancelledAt, {
                            weekday: "long",
                            month: "short",
                            day: "numeric"
                        });
                        o = t ? n("customerHub.orders.card.cancelledOnDate", {
                            date: t
                        }) : n("customerHub.orders.card.cancelled")
                    } else o = "DELIVERED" === e.status ? i ? n("customerHub.orders.card.deliveredOnDate", {
                        date: i
                    }) : n("customerHub.order.status.delivered") : i ? n("customerHub.orders.card.arrivingOnDate", {
                        date: i
                    }) : n(Jt(e.status));
                    return r().createElement(Qt, {
                        onClick: () => {
                            (0, m.ZD)(p.Xl.CLICKED_VIEW_ORDER, {
                                [p.Ox.ORDER_ID]: e.id,
                                [p.Ox.ORDER_NAME]: e.orderName,
                                [p.Ox.VIEW_SOURCE]: t,
                                [p.Ox.ORDER]: e
                            }), a(`/orders/${e.id}`, {
                                order: e
                            })
                        }
                    }, r().createElement(ta, null, r().createElement(aa, null, r().createElement(re.d9, {
                        noSpacing: !0,
                        bold: !0
                    }, o), r().createElement(re.TB, {
                        variant: "secondary",
                        noSpacing: !0
                    }, n("customerHub.order.name", {
                        orderName: e.orderName
                    }))), r().createElement(ne.zx, {
                        variant: "secondary"
                    }, n("customerHub.orders.card.button.view"))), r().createElement(ea, null, e.lineItems.map((e => r().createElement(Kt, {
                        src: e.imageUrl,
                        title: e.name,
                        "aria-label": e.name,
                        key: e.id
                    })))))
                },
                ra = e => e ? (0, K.iv)(["background:linear-gradient( -60deg,var(--atlas-loading-skeleton-color) 40%,var(--atlas-loading-skeleton-highlight-color) 50%,var(--atlas-loading-skeleton-color) 60% );background-size:300%;background-position-x:100%;animation:shimmer 1.5s infinite linear;@keyframes shimmer{to{background-position-x:0%;}}"]) : (0, K.iv)(["background:var(--atlas-loading-skeleton-color);"]),
                la = K.ZP.div.withConfig({
                    displayName: "Skeleton__TextWrapper",
                    componentId: "sc-4bxpzx-0"
                })(["height:", ";width:", ";", " align-items:center;"], (({
                    size: e
                }) => `var(--atlas-line-height-${e})`), (({
                    width: e
                }) => e), (({
                    inline: e = !1
                }) => (0, K.iv)(["display:", ";", ""], e ? "inline-flex" : "flex", (0, le.K)(e ? "inline-flex" : "flex")))),
                ia = K.ZP.span.withConfig({
                    displayName: "Skeleton__FakeText",
                    componentId: "sc-4bxpzx-1"
                })(["display:inline-block;width:100%;--skeleton-height:", ";border-radius:calc(var(--skeleton-height) / 2);background-color:var(--atlas-loading-skeleton-color);height:var(--skeleton-height);", ""], (({
                    size: e
                }) => `var(--atlas-font-size-${e})`), (({
                    animate: e
                }) => ra(e))),
                oa = ({
                    inline: e = !1,
                    size: t = "normal",
                    width: a = "100%",
                    animate: n = !0
                }) => r().createElement(la, {
                    inline: e,
                    size: t,
                    width: a
                }, r().createElement(ia, {
                    size: t,
                    animate: n
                })),
                sa = K.ZP.div.withConfig({
                    displayName: "Skeleton__ThumbnailSkeleton",
                    componentId: "sc-4bxpzx-2"
                })(["", " border-radius:var(--atlas-thumbnail-border-radius);background-color:var(--atlas-loading-skeleton-color);", " ", ""], (0, le.K)(), (({
                    size: e
                }) => (0, K.iv)(["height:", "px;width:", "px;"], e, e)), (({
                    animate: e = !0
                }) => ra(e))),
                ca = K.ZP.div.withConfig({
                    displayName: "Skeleton__ButtonSkeleton",
                    componentId: "sc-4bxpzx-3"
                })(["", " display:inline-block;box-sizing:content-box;height:", ";padding:", ";border-radius:var(--atlas-button-border-radius-normal);background-color:var(--atlas-loading-skeleton-color);", " ", ""], (0, le.K)(), (({
                    size: e = "normal"
                }) => `calc(var(--atlas-line-height-${e}) + 2px)`), (({
                    size: e = "normal"
                }) => `var(--atlas-button-padding-${e})`), (({
                    width: e
                }) => e && (0, K.iv)(["width:", ";"], e)), (({
                    animate: e = !0
                }) => ra(e))),
                da = K.ZP.div.withConfig({
                    displayName: "Skeleton__IconSkeleton",
                    componentId: "sc-4bxpzx-4"
                })(["", " display:inline-block;border-radius:50%;background-color:var(--atlas-loading-skeleton-color);", " ", ""], (0, le.K)(), (({
                    size: e = "medium"
                }) => (0, K.iv)(["width:var(--atlas-icon-size-", ");height:var(--atlas-icon-size-", ");"], e, e)), (({
                    animate: e = !0
                }) => ra(e))),
                ua = (0, K.ZP)(Vt).withConfig({
                    displayName: "SkeletonOrderCard__StyledCarousel",
                    componentId: "sc-1xxzmgh-0"
                })(["margin-top:24px;"]),
                ma = (0, n.forwardRef)(((e, t) => r().createElement(We, {
                    ref: t
                }, r().createElement($e, null, r().createElement("div", null, r().createElement(oa, {
                    width: "50%"
                }), r().createElement(oa, {
                    size: "small",
                    width: "40%"
                })), r().createElement(ua, null, r().createElement(sa, {
                    size: 120
                }), r().createElement(sa, {
                    size: 120
                }))))));
            ma.displayName = "SkeletonOrderCard";
            const pa = K.ZP.section.withConfig({
                    displayName: "OrderCardList",
                    componentId: "sc-ekoe1h-0"
                })(["width:100%;display:flex;flex-direction:column;gap:var(--atlas-space-medium);"]),
                ga = ({
                    viewSource: e
                }) => {
                    const {
                        data: t,
                        isLoading: a
                    } = qt();
                    return a ? r().createElement(pa, null, r().createElement(ma, null)) : t ? r().createElement(pa, null, t.map((t => r().createElement(na, {
                        order: t,
                        key: t.id,
                        viewSource: e
                    })))) : null
                };
            a(78575), a(56220), a(63880);
            const ha = K.ZP.div.withConfig({
                    displayName: "CarouselEmptyState__EmptyState",
                    componentId: "sc-ytvnw9-0"
                })(["background-color:var(--atlas-empty-background);height:80px;width:100%;display:flex;justify-content:center;align-items:center;border-radius:var(--atlas-thumbnail-border-radius);border:1px solid var(--atlas-border-light);"]),
                va = ({
                    message: e
                }) => r().createElement(ha, null, r().createElement(re.OA, {
                    variant: "secondary"
                }, e)),
                Ea = K.ZP.section.withConfig({
                    displayName: "FullBleedSection",
                    componentId: "sc-xuxdai-0"
                })(["width:100%;padding-bottom:var(--atlas-space-jumbo);cursor:pointer;", " &:not(:last-child){border-bottom:1px solid var(--atlas-overlay-light);}"], (({
                    hasItems: e
                }) => !e && (0, K.iv)(["pointer-events:none;"]))),
                fa = (0, K.ZP)(Ae).withConfig({
                    displayName: "SectionHeaderWithLink__StyledSectionHeader",
                    componentId: "sc-1852tel-0"
                })(["padding:var(--atlas-space-small) var(--atlas-space-medium);box-sizing:content-box;"]),
                ba = ({
                    showLink: e,
                    label: t,
                    onClick: a
                }) => {
                    const {
                        t: n
                    } = (0, b.ql)();
                    return r().createElement(fa, {
                        action: e && r().createElement(ne.zx, {
                            variant: "icon",
                            role: "button",
                            "aria-label": n("customerHub.sectionHeader.viewMore"),
                            onClick: a
                        }, r().createElement(Q.EH, null))
                    }, t)
                },
                ya = (0, K.ZP)(Vt).withConfig({
                    displayName: "SummarySection__StyledCarousel",
                    componentId: "sc-k6krmz-0"
                })(["padding:0px var(--atlas-space-medium);min-height:80px;"]),
                Ca = K.ZP.a.withConfig({
                    displayName: "SummarySection__ThumbnailLink",
                    componentId: "sc-k6krmz-1"
                })(["min-width:unset;"]),
                _a = (0, K.ZP)(Kt).withConfig({
                    displayName: "SummarySection__StyledThumbnail",
                    componentId: "sc-k6krmz-2"
                })(["min-width:unset;"]),
                wa = ({
                    label: e,
                    onClick: t,
                    products: a,
                    loading: n = !1,
                    emptyStateMessage: l
                }) => {
                    let i;
                    const {
                        navigate: o
                    } = (0, pe.HJ)();
                    i = n && !a ? r().createElement(r().Fragment, null, r().createElement(sa, {
                        size: 80
                    }), r().createElement(sa, {
                        size: 80
                    })) : a && 0 !== a.length ? a.map((({
                        imageUrl: e,
                        name: t,
                        id: a,
                        link: n,
                        linkData: l
                    }) => {
                        const i = r().createElement(_a, {
                            src: e,
                            title: t,
                            key: a,
                            size: 80
                        });
                        return n ? n.startsWith("/") ? r().createElement(_a, {
                            src: e,
                            title: t,
                            key: a,
                            size: 80,
                            tabIndex: 0,
                            "aria-label": t,
                            onClick: e => (e.stopPropagation(), o(n, l))
                        }) : r().createElement(Ca, {
                            href: n,
                            key: a,
                            onClick: e => {
                                e.stopPropagation()
                            },
                            "aria-label": t
                        }, i) : i
                    })) : r().createElement(va, {
                        message: l
                    });
                    const s = !n && !!a && 0 !== a.length;
                    return r().createElement(Ea, {
                        onClick: t,
                        hasItems: s
                    }, r().createElement(ba, {
                        showLink: s,
                        label: e
                    }), r().createElement(ya, null, i))
                };
            var xa = a(88923),
                Ia = a(69313);

            function ka() {
                const e = (0, k.m)(),
                    {
                        token: t
                    } = (0, f.aC)(),
                    a = (0, Ia.tz)();
                return (0, xa.ZP)((() => t ? M.g.getRecentProductsKey : null), (() => e.getRecentlyViewed().then((e => 0 === e.products.length ? {
                    products: a
                } : e))), {
                    fallbackData: [{
                        products: a
                    }]
                })
            }
            const Na = () => {
                const {
                    t: e
                } = (0, b.ql)(), {
                    data: t,
                    isLoading: a
                } = ka(), {
                    navigate: n
                } = (0, pe.HJ)(), l = null == t ? void 0 : t.flatMap((e => e.products));
                return r().createElement(wa, {
                    label: e("customerHub.forYou.recentlyViewed"),
                    onClick: () => {
                        n("/recently-viewed")
                    },
                    products: l,
                    loading: a,
                    emptyStateMessage: e("customerHub.products.recentlyViewed.empty")
                })
            };

            function Ta() {
                const e = (0, k.m)(),
                    t = (0, f.aC)();
                return (0, L.ZP)(t ? M.g.recommendedProducts : null, (() => e.getRecommendedProducts().then((e => e.recommendations))))
            }
            const Sa = ["children", "className", "disablePadding", "disableGutters"],
                Pa = K.ZP.ul.withConfig({
                    displayName: "List__StyledList",
                    componentId: "sc-1827j5y-0"
                })(["list-style-type:none;padding:0;margin:0;"]),
                Oa = ({
                    children: e,
                    className: t
                }) => r().createElement(Pa, {
                    className: (0, ee.A)("kl-hub-list", t)
                }, e),
                Ra = K.ZP.li.withConfig({
                    displayName: "List__StyledListItem",
                    componentId: "sc-1827j5y-1"
                })(["display:flex;align-items:center;padding:", ";&:not(:last-child){border-bottom:1px solid var(--atlas-border-light);}"], (({
                    disablePadding: e,
                    disableGutters: t
                }) => e ? 0 : t ? "var(--atlas-space-medium) 0" : "var(--atlas-space-medium)")),
                Da = (0, n.forwardRef)(((e, t) => {
                    let {
                        children: a,
                        className: n,
                        disablePadding: l = !1,
                        disableGutters: i = !1
                    } = e, o = Ze()(e, Sa);
                    return r().createElement(Ra, X()({
                        className: (0, ee.A)("kl-hub-list-item", n),
                        disablePadding: l,
                        disableGutters: i,
                        ref: t
                    }, o), a)
                }));
            Da.displayName = "ListItem";
            const La = K.ZP.div.withConfig({
                    displayName: "List__StyledListHeader",
                    componentId: "sc-1827j5y-2"
                })(["padding:var(--atlas-space-jumbo) var(--atlas-space-medium);", ""], (({
                    divider: e
                }) => e && (0, K.iv)(["border-bottom:1px solid var(--atlas-border-light);"]))),
                Ha = ({
                    children: e,
                    className: t,
                    divider: a = !1
                }) => r().createElement(La, {
                    className: (0, ee.A)("kl-hub-list-header", t),
                    divider: a
                }, "string" == typeof e ? r().createElement(re.k8, {
                    noSpacing: !0
                }, e) : e),
                Aa = (0, K.iv)(["background:transparent;border:none;display:flex;text-align:start;align-items:center;width:100%;padding:var(--atlas-space-medium);box-shadow:none;outline:none;cursor:pointer;&:focus-visible,&:hover{background:var(--atlas-overlay-light);}"]),
                Ma = K.ZP.button.attrs((e => {
                    var t;
                    return {
                        type: null != (t = e.type) ? t : "button",
                        className: (0, ee.A)("kl-hub-list-item-button", e.className)
                    }
                })).withConfig({
                    displayName: "List__ListItemButton",
                    componentId: "sc-1827j5y-3"
                })(["", ""], Aa),
                Za = K.ZP.a.attrs((e => ({
                    className: (0, ee.A)("kl-hub-list-item-link", e.className)
                }))).withConfig({
                    displayName: "List__ListItemLinkButton",
                    componentId: "sc-1827j5y-4"
                })(["", " text-decoration:none;"], Aa),
                Ba = K.ZP.div.withConfig({
                    displayName: "List__ListItemContent",
                    componentId: "sc-1827j5y-5"
                })(["flex:1;"]),
                Ua = K.ZP.span.withConfig({
                    displayName: "List__ListItemPrefix",
                    componentId: "sc-1827j5y-6"
                })(["margin-right:var(--atlas-space-medium);line-height:0px;"]),
                Fa = K.ZP.span.withConfig({
                    displayName: "List__ListItemSuffix",
                    componentId: "sc-1827j5y-7"
                })(["margin-left:var(--atlas-space-medium);line-height:0px;"]),
                za = K.ZP.div.withConfig({
                    displayName: "SkeletonProductListItem__TopContainer",
                    componentId: "sc-1s7b509-0"
                })(["display:flex;"]),
                qa = K.ZP.div.withConfig({
                    displayName: "SkeletonProductListItem__DetailsContainer",
                    componentId: "sc-1s7b509-1"
                })(["margin-left:var(--atlas-space-medium);padding-top:var(--atlas-space-mini);flex:1;"]),
                ja = K.ZP.div.withConfig({
                    displayName: "SkeletonProductListItem__ActionsContainer",
                    componentId: "sc-1s7b509-2"
                })(["margin-top:var(--atlas-space-small);display:flex;align-items:center;justify-content:space-between;gap:var(--atlas-space-medium);"]),
                Va = (0, n.forwardRef)((({
                    showActions: e
                }, t) => r().createElement(Da, {
                    ref: t
                }, r().createElement(Ba, null, r().createElement(za, null, r().createElement(sa, {
                    size: 96
                }), r().createElement(qa, null, r().createElement(oa, {
                    size: "normal",
                    width: "75%"
                }), r().createElement(oa, {
                    size: "small",
                    width: "50%"
                }), r().createElement(oa, {
                    size: "normal",
                    width: "33%"
                }))), e && r().createElement(ja, null, r().createElement(ca, {
                    size: "small",
                    style: {
                        flex: 1
                    }
                }), r().createElement(da, null))))));
            Va.displayName = "SkeletonProductListItem";
            a(39265), a(61099);
            var Wa = a(58352),
                Ga = a(5556),
                $a = a(90351),
                Ya = a(58804);
            const Ka = {
                star_standard: {
                    props: {
                        d: "M11.1488 2.23197C10.7159 1.22183 9.28382 1.22183 8.85091 2.23197L6.95034 6.66662H2.67243C1.5588 6.66662 1.00109 8.01305 1.78854 8.8005L4.91029 11.9222L3.59487 17.1839C3.32787 18.2519 4.47191 19.1186 5.42772 18.5724L9.99984 15.9597L14.572 18.5724C15.5278 19.1186 16.6718 18.2519 16.4048 17.1839L15.0894 11.9222L18.2111 8.8005C18.9986 8.01304 18.4409 6.66662 17.3272 6.66662H13.0493L11.1488 2.23197Z"
                    },
                    elem: "path"
                },
                star_sharp: {
                    props: {
                        d: "M5.068 17.8643C4.91909 17.7487 4.82782 17.5928 4.7942 17.3968C4.76538 17.2008 4.7966 16.967 4.88787 16.6956L6.39377 12.0057L2.54616 9.11027C2.32039 8.94439 2.16428 8.77348 2.07782 8.59755C1.99135 8.42161 1.97694 8.24065 2.03459 8.05467C2.09223 7.8737 2.20511 7.73798 2.37323 7.6475C2.54136 7.55702 2.76472 7.51429 3.04332 7.51932L7.76277 7.54948L9.19661 2.83695C9.28308 2.56048 9.39116 2.35187 9.52085 2.21112C9.65535 2.07037 9.81386 2 9.9964 2C10.1837 2 10.3422 2.07037 10.4719 2.21112C10.6064 2.35187 10.7169 2.56048 10.8034 2.83695L12.2372 7.54948L16.9567 7.51932C17.2353 7.51429 17.4586 7.55702 17.6268 7.6475C17.7949 7.73798 17.9078 7.8737 17.9654 8.05467C18.0231 8.24065 18.0086 8.42161 17.9222 8.59755C17.8357 8.77348 17.6796 8.94439 17.4538 9.11027L13.6062 12.0057L15.1121 16.6956C15.2034 16.967 15.2322 17.2008 15.1986 17.3968C15.1698 17.5928 15.0809 17.7487 14.932 17.8643C14.7831 17.9849 14.615 18.0251 14.4276 17.9849C14.2403 17.9497 14.0361 17.8492 13.8152 17.6833L9.9964 14.7502L6.18481 17.6833C5.96385 17.8492 5.7597 17.9497 5.57237 17.9849C5.38503 18.0251 5.21691 17.9849 5.068 17.8643Z"
                    },
                    elem: "path"
                },
                star_round: {
                    props: {
                        d: "M11.2236 2.66353C10.6484 1.77882 9.35159 1.77882 8.77637 2.66353L6.97937 5.42743C6.79391 5.71267 6.51437 5.92413 6.18919 6.02517L3.02625 7.00799C2.07163 7.30462 1.69185 8.45048 2.28075 9.25728L4.35577 12.1C4.54537 12.3598 4.64362 12.6748 4.63524 12.9962L4.54372 16.5037C4.51676 17.537 5.54583 18.2689 6.51483 17.9057L9.48731 16.7915C9.81785 16.6676 10.1822 16.6676 10.5127 16.7915L13.4852 17.9057C14.4542 18.2689 15.4832 17.537 15.4563 16.5037L15.3648 12.9962C15.3564 12.6748 15.4546 12.3598 15.6442 12.1L17.7192 9.25728C18.3082 8.45048 17.9284 7.30462 16.9738 7.00799L13.8108 6.02517C13.4856 5.92413 13.2061 5.71267 13.0206 5.42743L11.2236 2.66353Z"
                    },
                    elem: "path"
                },
                heart_standard: {
                    props: {
                        d: "M6.25033 2.5C3.71902 2.5 1.66699 4.55203 1.66699 7.08333C1.66699 7.98779 1.78007 8.74179 2.10627 9.45942C2.42768 10.1665 2.92603 10.7709 3.57774 11.4226L8.82181 16.6667C9.47269 17.3175 10.528 17.3175 11.1788 16.6667L16.4229 11.4226C17.0746 10.7709 17.573 10.1665 17.8944 9.45942C18.2206 8.74179 18.3337 7.98779 18.3337 7.08333C18.3337 4.55203 16.2816 2.5 13.7503 2.5C12.2463 2.5 11.0292 3.14671 10.2327 4.00578L10.0003 4.23816L9.76795 4.00578C8.97149 3.14671 7.75432 2.5 6.25033 2.5Z"
                    },
                    elem: "path"
                },
                heart_angled: {
                    props: {
                        d: "M14 3L10 5L6 3L2 6.5V11L10 17L18 11V6.5L14 3Z"
                    },
                    elem: "path"
                },
                heart_round: {
                    props: {
                        d: "M10.0006 6.47461C10.0579 1.85498 18.8513 1.03079 17.9328 9.05224C17.449 13.277 11.7145 17 10.0003 17C8.28604 17 3.15483 13.7831 2.18654 9.05224C0.569405 1.15129 9.99834 1.85576 10.0006 6.47461Z"
                    },
                    elem: "path"
                },
                circle: {
                    props: {
                        cx: "10",
                        cy: "10",
                        r: "7"
                    },
                    elem: "circle"
                }
            };
            var Ja = ({
                    size: e,
                    starShape: t
                }) => {
                    const a = Ka[t];
                    if (!a) return null;
                    const {
                        props: n,
                        elem: l
                    } = a;
                    return r().createElement("svg", {
                        version: "1.1",
                        xmlns: "http://www.w3.org/2000/svg",
                        viewBox: "0 0 20 20",
                        style: {
                            width: `${e}px`,
                            height: `${e}px`,
                            display: "inline-block"
                        },
                        width: e,
                        height: e
                    }, "circle" === l ? r().createElement("circle", X()({
                        width: "20",
                        height: "20",
                        fill: "currentColor",
                        strokeWidth: "2"
                    }, n)) : r().createElement("path", X()({
                        width: "20",
                        height: "20",
                        fill: "currentColor",
                        strokeWidth: "2",
                        strokeLinejoin: "round"
                    }, n)))
                },
                Xa = a(86153);
            const Qa = () => {
                    var e;
                    const {
                        data: t
                    } = (0, Xa.Z)(M.g.reviewsSettings, (() => {
                        var e;
                        const t = null == (e = window) || null == (e = e.klaviyoModulesObject) ? void 0 : e.companyId;
                        if (!t) throw Error("companyId is missing");
                        return Wa.Z.getCustomerSettings(t)
                    })), a = null == t || null == (e = t.widgets) || null == (e = e.find((({
                        widget_type: e
                    }) => "STARS" === e))) ? void 0 : e.json_data;
                    return (a ? JSON.parse(a) : {}).star_shape || "star_standard"
                },
                en = K.ZP.div.withConfig({
                    displayName: "RatingStars__RatingContainer",
                    componentId: "sc-v17ryx-0"
                })(["display:flex;align-items:center;"]),
                tn = K.ZP.div.withConfig({
                    displayName: "RatingStars__StarsContainer",
                    componentId: "sc-v17ryx-1"
                })(["position:relative;color:var(--atlas-border-light);height:var(--atlas-line-height-small);margin-right:var(--atlas-space-mini);"]),
                an = K.ZP.div.withConfig({
                    displayName: "RatingStars__FilledStars",
                    componentId: "sc-v17ryx-2"
                })(["position:absolute;top:0;color:var(--atlas-primary-color);overflow:hidden;white-space:nowrap;"]),
                nn = [1, 2, 3, 4, 5],
                rn = ({
                    rating: e,
                    count: t
                }) => {
                    const a = Qa(),
                        n = nn.map((e => r().createElement(Ja, {
                            key: e,
                            size: 20,
                            starShape: a
                        })));
                    return r().createElement(en, null, r().createElement(tn, null, n, r().createElement(an, {
                        style: {
                            width: e / 5 * 100 + "%"
                        }
                    }, n)), null != t && r().createElement(re.TB, {
                        mono: !0,
                        noSpacing: !0,
                        variant: "secondary"
                    }, "(", t, ")"))
                };

            function ln(e, t, {
                isEnabled: a
            } = {
                isEnabled: !0
            }) {
                const n = (0, k.m)(),
                    r = (0, P.A)(),
                    {
                        token: l
                    } = (0, f.aC)();
                return (0, L.ZP)(a ? M.g.hydrateProductKey(e) : null, (() => l ? n.getHydrateProduct(e) : r.getHydrateProduct(t)), {
                    revalidateIfStale: !1,
                    revalidateOnFocus: !1,
                    revalidateOnReconnect: !1
                })
            }
            var on = a(48190);
            const sn = (0, K.ZP)(ne.zx).withConfig({
                    displayName: "AddToWishlistButton__FavoriteButton",
                    componentId: "sc-juxfe3-0"
                })(["display:flex;align-items:center;justify-content:center;"]),
                cn = ({
                    product: e,
                    activeVariant: t,
                    wishlistId: a,
                    isInWishlist: n,
                    attributionSource: l
                }) => {
                    var i, o;
                    const {
                        t: s
                    } = (0, b.ql)(), {
                        trigger: c
                    } = (0, fe.CW)(), {
                        trigger: d
                    } = (0, fe.pW)(a), m = (0, u.rV)();
                    return (null == m || null == (i = m.wishlists) ? void 0 : i.enabled) ? r().createElement(sn, {
                        "data-testid": "addToWishlist",
                        onClick: async () => {
                            n ? d({
                                product: e,
                                variantId: t.id,
                                attributionSource: l
                            }) : c({
                                product: e,
                                variantId: t.id,
                                attributionSource: l
                            })
                        },
                        variant: "icon",
                        selected: n,
                        "aria-label": s(n ? "customerHub.product.actions.inWishlistClickToRemove" : "customerHub.product.actions.addToWishlist")
                    }, r().createElement(on.X, {
                        active: n,
                        iconStyle: null == m || null == (o = m.wishlists) ? void 0 : o.iconStyle,
                        testId: n ? "inWishlistIcon" : "addToWishlistIcon"
                    })) : null
                },
                dn = K.ZP.div.withConfig({
                    displayName: "ProductListItem__TopSection",
                    componentId: "sc-e9s7u1-0"
                })(["display:flex;"]),
                un = K.ZP.div.withConfig({
                    displayName: "ProductListItem__DetailsContainer",
                    componentId: "sc-e9s7u1-1"
                })(["margin-left:var(--atlas-space-medium);padding-top:var(--atlas-space-mini);display:flex;flex-direction:column;gap:var(--atlas-space-small);flex:1;min-width:0;"]),
                mn = K.ZP.div.withConfig({
                    displayName: "ProductListItem__ActionsContainer",
                    componentId: "sc-e9s7u1-2"
                })(["margin-top:var(--atlas-space-small);display:flex;align-items:center;justify-content:flex-end;gap:var(--atlas-space-medium);"]),
                pn = (0, K.ZP)(re.rU).withConfig({
                    displayName: "ProductListItem__ProductLinkBlock",
                    componentId: "sc-e9s7u1-3"
                })(["display:block;text-decoration:none;appearance:none;pointer-events:auto;&:hover,&:focus-visible{text-decoration:underline;}"]),
                gn = (0, K.ZP)(ne.zx).withConfig({
                    displayName: "ProductListItem__ActionButton",
                    componentId: "sc-e9s7u1-4"
                })(["flex:1;"]),
                hn = ({
                    product: e,
                    shouldHydrateProduct: t = !1,
                    attributionSource: a,
                    viewEvent: l
                }) => {
                    var i, o, s, c;
                    const {
                        data: d
                    } = (0, fe.Ei)(), {
                        t: g
                    } = (0, b.ql)(), {
                        companyId: h
                    } = (0, f.aC)(), v = (0, P.A)(), E = (0, u.rV)(), y = (0, b.nB)(), [C, _] = (0, n.useState)(e.variants), [w, x] = (0, n.useState)(e.variants.find((e => e.availableForSale)) || e.variants[0]), [I, k] = (0, n.useState)(!1), N = (0, Ya.p)(), [T, S] = (0, n.useState)(void 0);
                    (0, n.useEffect)((() => {
                        (async () => {
                            var t;
                            if (!1 === (null == (t = E.reviews) ? void 0 : t.enabled)) return;
                            const a = await Wa.Z.getReviewsForProduct({
                                productId: e.id,
                                companyId: h,
                                limit: 5
                            });
                            S(a.summary)
                        })()
                    }), [E, e.id, h]);
                    const O = (null == (i = E.reviews) ? void 0 : i.enabled) && void 0 !== T && void 0 !== T.star_rating || !1,
                        {
                            data: R,
                            isLoading: D
                        } = ln(e.id, e.link, {
                            isEnabled: t
                        });
                    (0, n.useEffect)((() => {
                        R && R.product.variants && (_(R.product.variants), x(R.product.variants.find((e => e.availableForSale)) || R.product.variants[0]))
                    }), [R, C]);
                    const L = (0, n.useMemo)((() => a === p.nm.RECENTLY_VIEWED ? {
                            _source_customer_hub_add_to_cart: "true",
                            _source_customer_hub_recently_viewed: "true"
                        } : a === p.nm.RECOMMENDED ? {
                            _source_customer_hub_add_to_cart: "true",
                            _source_customer_hub_recommended: "true"
                        } : a === p.nm.FAVORITES ? {
                            _source_customer_hub_add_to_cart: "true",
                            _source_customer_hub_wishlist: "true"
                        } : {}), [a]),
                        H = (0, n.useMemo)((() => {
                            var e;
                            return D ? g("customerHub.product.actions.loading") : I ? g("customerHub.product.actions.added") : null == (e = w.availableForSale) || e ? g("customerHub.product.actions.addToCart") : g("customerHub.product.actions.soldOut")
                        }), [D, w, I, g]),
                        A = (0, n.useMemo)((() => {
                            const e = w.currency || w.priceCurrency || "";
                            return w.priceString && !R ? w.priceString : y(Number(w.price), e)
                        }), [w, y, R]),
                        M = () => {
                            (0, m.ZD)(l, {
                                [p.Ox.PRODUCT_ID]: e.id,
                                [p.Ox.VARIANT_ID]: w.id,
                                [p.Ox.IMAGE_URL]: e.imageUrl,
                                [p.Ox.PRODUCT_NAME]: e.name,
                                [p.Ox.VARIANT_NAME]: w.title,
                                [p.Ox.PRODUCT_URL]: e.link,
                                [p.Ox.VIEW_SOURCE]: a,
                                [p.Ox.PRODUCT]: e,
                                [p.Ox.VARIANT]: w
                            })
                        };
                    return r().createElement(Da, null, r().createElement(Ba, null, r().createElement(dn, null, r().createElement("a", {
                        href: e.link,
                        onClick: M,
                        "data-testid": "productLink"
                    }, r().createElement(Kt, {
                        src: null != (o = w.imageUrl) ? o : e.imageUrl,
                        size: 96
                    })), r().createElement(un, null, r().createElement(pn, {
                        href: e.link,
                        onClick: M,
                        "data-testid": "productLinkBlock"
                    }, r().createElement(re.kd, {
                        noSpacing: !0
                    }, e.name), e.category && r().createElement(re.TB, {
                        variant: "secondary",
                        noSpacing: !0
                    }, e.category), r().createElement(re.d9, {
                        noSpacing: !0
                    }, A)), O && r().createElement(rn, {
                        rating: (null == T ? void 0 : T.star_rating) || 0,
                        count: null == T ? void 0 : T.review_count
                    }), C.length > 1 && r().createElement(Ga.P, {
                        value: w.id,
                        onChange: e => {
                            const t = C.find((t => t.id === e));
                            t && x(t)
                        },
                        label: g("customerHub.product.actions.selectVariant")
                    }, C.map((e => r().createElement($a.W, {
                        value: e.id,
                        key: e.id
                    }, (e => {
                        var t;
                        return null == (t = e.availableForSale) || t ? e.title || "" : `${e.title} (${g("customerHub.product.actions.soldOut")})`
                    })(e))))))), r().createElement(mn, null, r().createElement(gn, {
                        "data-testid": "addToCart",
                        disabled: !(null == (s = null == w ? void 0 : w.availableForSale) || s),
                        variant: "secondary",
                        onClick: () => v.addToCart({
                            items: [{
                                id: w.id,
                                quantity: 1
                            }],
                            properties: L
                        }).then((() => {
                            k(!0), N({
                                label: g("customerHub.toast.addedToCart"),
                                action: {
                                    label: g("customerHub.toast.goToCart"),
                                    onClick: () => {
                                        window.location.assign("/cart")
                                    }
                                }
                            }), (0, m.ZD)(p.Xl.CLICKED_ADD_TO_CART, {
                                [p.Ox.PRODUCT_ID]: e.id,
                                [p.Ox.VARIANT_ID]: w.id,
                                [p.Ox.IMAGE_URL]: e.imageUrl,
                                [p.Ox.PRODUCT_NAME]: e.name,
                                [p.Ox.VARIANT_NAME]: w.title,
                                [p.Ox.PRODUCT_URL]: e.link,
                                [p.Ox.ADD_TO_CART_SOURCE]: a,
                                $value: w.price,
                                [p.Ox.PRODUCT]: e,
                                [p.Ox.VARIANT]: w
                            })
                        })).catch((() => {
                            N({
                                variant: "error",
                                label: g("customerHub.toast.errorAddingToCart")
                            })
                        }))
                    }, H), r().createElement(cn, {
                        product: e,
                        activeVariant: w,
                        wishlistId: (null == d || null == (c = d.wishlist) ? void 0 : c.id) || "",
                        isInWishlist: !(null == d || !d.products) && d.products.some((t => t.id === e.id)),
                        attributionSource: a
                    }))))
                },
                vn = (0, K.ZP)(Vt).withConfig({
                    displayName: "ProductCarousel__StyledCarousel",
                    componentId: "sc-12sfrdg-0"
                })(["padding:0px var(--atlas-space-medium);min-height:80px;"]),
                En = K.ZP.div.withConfig({
                    displayName: "ProductCarousel__FlatCard",
                    componentId: "sc-12sfrdg-1"
                })(["", " min-width:321px;"], Ve),
                fn = ({
                    label: e,
                    onClick: t,
                    products: a,
                    loading: n = !1,
                    emptyStateMessage: l,
                    attributionSource: i,
                    viewEvent: o
                }) => {
                    let s;
                    s = n && !a ? r().createElement(r().Fragment, null, r().createElement(En, null, r().createElement(Va, {
                        showActions: !0
                    })), r().createElement(En, null, r().createElement(Va, {
                        showActions: !0
                    }))) : a && 0 !== a.length ? a.map((e => r().createElement(En, {
                        key: e.id
                    }, r().createElement(hn, {
                        product: e,
                        attributionSource: i,
                        viewEvent: o
                    })))) : r().createElement(va, {
                        message: l
                    });
                    const c = !n && !!a && 0 !== a.length;
                    return r().createElement(Ea, {
                        hasItems: c
                    }, r().createElement(ba, {
                        showLink: c,
                        onClick: t,
                        label: e
                    }), r().createElement(vn, null, s))
                },
                bn = () => {
                    const {
                        t: e
                    } = (0, b.ql)(), {
                        data: t,
                        isLoading: a
                    } = Ta(), {
                        navigate: n
                    } = (0, pe.HJ)(), l = t;
                    return r().createElement(fn, {
                        label: e("customerHub.forYou.recommendedProducts"),
                        products: l,
                        loading: a,
                        emptyStateMessage: e("customerHub.products.recommended.empty"),
                        attributionSource: p.nm.FOR_YOU,
                        viewEvent: p.Xl.CLICKED_RECOMMENDED_PRODUCT,
                        onClick: () => {
                            n("/recommended-products")
                        }
                    })
                },
                yn = (0, K.iv)(["cursor:pointer;&:hover{border-color:var(--atlas-primary-color);}&:focus-visible{outline:3px solid var(--atlas-focus-outline-color);}"]),
                Cn = K.ZP.button.withConfig({
                    displayName: "ActionCard__CardButton",
                    componentId: "sc-e3n3rg-0"
                })(["", " ", ""], Ve, yn),
                _n = K.ZP.a.withConfig({
                    displayName: "ActionCard__CardLink",
                    componentId: "sc-e3n3rg-1"
                })(["", " ", " text-decoration:none;&:visited{color:inherit;}"], Ve, yn),
                wn = K.ZP.div.withConfig({
                    displayName: "ActionCard__MainContainer",
                    componentId: "sc-e3n3rg-2"
                })(["padding:var(--atlas-space-medium) var(--atlas-space-jumbo);min-height:48px;display:flex;align-items:center;gap:var(--atlas-space-small);"]),
                xn = K.ZP.div.withConfig({
                    displayName: "ActionCard__TextContainer",
                    componentId: "sc-e3n3rg-3"
                })(["flex:1;"]),
                In = (0, K.ZP)(Gt).withConfig({
                    displayName: "ActionCard__CustomImage",
                    componentId: "sc-e3n3rg-4"
                })(["height:184px;width:100%;object-fit:cover;display:block;"]),
                kn = (0, n.forwardRef)((({
                    title: e,
                    subtitle: t,
                    imageUrl: a,
                    imagePosition: n = "TOP",
                    onClick: l,
                    href: i,
                    target: o,
                    testId: s,
                    className: c
                }, d) => {
                    const u = a ? r().createElement(In, {
                            src: a,
                            alt: e,
                            draggable: !1
                        }) : void 0,
                        m = r().createElement(r().Fragment, null, "TOP" === n && u, r().createElement(wn, null, r().createElement(xn, null, r().createElement(re.kd, {
                            noSpacing: !0,
                            bold: !0
                        }, e), t && r().createElement(re.TB, {
                            noSpacing: !0,
                            bold: !0
                        }, t)), r().createElement(Q.di, {
                            size: "mini"
                        })), "BOTTOM" === n && u);
                    return void 0 !== i ? r().createElement(_n, {
                        href: i,
                        target: o,
                        onClick: l,
                        "data-testid": s,
                        ref: d,
                        className: (0, ee.A)("kl-hub-action-card", c)
                    }, m) : r().createElement(Cn, {
                        onClick: l,
                        "data-testid": s,
                        ref: d,
                        className: (0, ee.A)("kl-hub-action-card", c)
                    }, m)
                }));
            kn.displayName = "ActionCard";
            var Nn = a(82880);

            function Tn() {
                const e = (0, k.m)(),
                    {
                        isLoggedIn: t,
                        token: a,
                        sub: r,
                        kx: l,
                        companyId: i,
                        refreshKx: o
                    } = (0, f.aC)();
                (0, n.useEffect)((() => {
                    o()
                }), [o]);
                const {
                    queryKey: s,
                    fetcher: c
                } = (0, n.useMemo)((() => t && a ? {
                    queryKey: M.g.getContentBlocks(i, r),
                    fetcher: () => e.getContentBlocks().then((e => e.contentBlocks))
                } : l ? {
                    queryKey: M.g.getContentBlocksForIdentifiedProfile(i, l),
                    fetcher: () => e.getContentBlocksForIdentifiedProfile(i, l).then((e => e.contentBlocks))
                } : {
                    queryKey: M.g.getContentBlocksUnauthenticated(i),
                    fetcher: () => function(e) {
                        return fetch(`${Nn.EA}/content-blocks/${e}`, {
                            headers: {
                                "Content-Type": "application/json"
                            }
                        }).then((e => e.json())).then(d.k5)
                    }(i).then((e => e.contentBlocks))
                }), [t, a, r, l, i, e]);
                return (0, L.ZP)(s, c, {
                    fallbackData: []
                })
            }

            function Sn() {
                const e = (0, k.m)(),
                    {
                        token: t
                    } = (0, f.aC)();
                return (0, L.ZP)(t ? M.g.coupons : null, (() => e.getCoupons()), {
                    fallbackData: {
                        active: [],
                        used: [],
                        expired: []
                    }
                })
            }
            a(81383), a(70917), a(93677), a(84304), a(75723), a(20696), a(38528), a(72418);

            function Pn({
                elementRef: e,
                onVisible: t,
                observerOptions: a,
                delay: r,
                disabled: l
            }) {
                (0, n.useEffect)((() => {
                    if (!e.current || l) return () => {};
                    let n;
                    const i = new IntersectionObserver((e => {
                        e[0].isIntersecting ? r ? n || (n = window.setTimeout((() => {
                            t(e[0])
                        }), r)) : t(e[0]) : n && (clearTimeout(n), n = void 0)
                    }), a);
                    return i.observe(e.current), () => {
                        i.disconnect(), clearTimeout(n)
                    }
                }), [e, t, a, r, l])
            }
            const On = "kl-hub-viewed-events";
            const Rn = new Set(function() {
                try {
                    const e = sessionStorage.getItem(On);
                    return e ? JSON.parse(e) : []
                } catch (e) {
                    return []
                }
            }());

            function Dn({
                elementRef: e,
                event: t,
                eventDetails: a,
                fireOnClick: r
            }) {
                const l = JSON.stringify({
                        event: t,
                        eventDetails: a
                    }),
                    [i, o] = (0, n.useState)(Rn.has(l)),
                    s = (0, Pt.$)((() => {
                        Rn.has(l) || ((0, m.ZD)(t, a), function(e) {
                            Rn.add(e);
                            try {
                                sessionStorage.setItem(On, JSON.stringify([...Rn]))
                            } catch (e) {}
                        }(l), o(!0))
                    }));
                (0, n.useEffect)((() => {
                    if (r && !i && e.current) {
                        const t = new AbortController;
                        return e.current.addEventListener("click", (() => {
                            s()
                        }), {
                            signal: t.signal
                        }), () => {
                            t.abort()
                        }
                    }
                    return () => {}
                }), [r, i, s, e]);
                const c = (0, n.useMemo)((() => ({
                    threshold: .5
                })), []);
                Pn({
                    elementRef: e,
                    onVisible: s,
                    delay: 3e3,
                    observerOptions: c,
                    disabled: i
                })
            }
            const Ln = ({
                    block: e
                }) => {
                    var t;
                    const a = (0, n.useRef)(null);
                    return Dn({
                        elementRef: a,
                        event: p.FH.VIEWED_CONTENT_BLOCK,
                        eventDetails: {
                            [p.Ox.CONTENT_BLOCK]: e.name
                        },
                        fireOnClick: !0
                    }), r().createElement(kn, {
                        ref: a,
                        title: e.content,
                        subtitle: null != (t = e.description) ? t : void 0,
                        href: e.url,
                        target: e.target,
                        imageUrl: e.imageUrl,
                        imagePosition: e.imagePosition,
                        className: (0, ee.A)("kl-hub-content-block", `kl-hub-content-block-${l=e.name,l.trim().toLowerCase().replace(/\s/g,"-")}`),
                        onClick: () => {
                            (0, m.ZD)(p.Xl.CLICKED_CONTENT_BLOCK, {
                                [p.Ox.CONTENT_BLOCK]: e.name
                            })
                        }
                    });
                    var l
                },
                Hn = K.ZP.div.withConfig({
                    displayName: "ContentBlocks__BlockContainer",
                    componentId: "sc-1gm6hqi-0"
                })(["display:flex;flex-direction:column;gap:var(--atlas-space-mini);"]),
                An = () => {
                    var e, t, a;
                    const {
                        t: n
                    } = (0, b.ql)(), {
                        isLoggedIn: l
                    } = (0, f.aC)(), {
                        data: i
                    } = Tn(), {
                        data: o
                    } = Sn(), {
                        navigate: s
                    } = (0, pe.HJ)(), c = null != (e = null == i ? void 0 : i.filter((e => "ALL" === e.visibility || l && "LOGGED_IN" === e.visibility || !l && "LOGGED_OUT" === e.visibility)).sort(((e, t) => e.order - t.order))) ? e : [], d = null != (t = null == (a = o.active) ? void 0 : a.length) ? t : 0;
                    return 0 === c.length && 0 === d ? null : r().createElement(Hn, null, c.map((e => r().createElement(Ln, {
                        block: e,
                        key: e.id
                    }))), d > 0 && r().createElement(kn, {
                        title: n(d > 1 ? "customerHub.coupons.contentBlock" : "customerHub.coupons.contentBlockSingular", {
                            count: d
                        }),
                        subtitle: n("customerHub.coupons.contentBlockSubtitle"),
                        key: "Coupons",
                        onClick: () => {
                            (0, m.ZD)(p.Xl.CLICKED_COUPON_BLOCK, {}), s("/coupons")
                        },
                        className: "kl-hub-coupons-button"
                    }))
                },
                Mn = () => {
                    const {
                        t: e
                    } = (0, b.ql)(), {
                        data: t,
                        isLoading: a,
                        error: n
                    } = (0, fe.Ei)(), {
                        navigate: l
                    } = (0, pe.HJ)(), i = (null == t ? void 0 : t.products) || [];
                    return n ? null : r().createElement(wa, {
                        label: e("customerHub.products.wishlist"),
                        onClick: () => {
                            l("/wishlist")
                        },
                        products: i,
                        loading: a,
                        emptyStateMessage: e("customerHub.products.wishlist.empty")
                    })
                };
            var Zn = a(75516);
            const Bn = (0, K.ZP)(Zn.x).withConfig({
                    displayName: "FillLayout__ContentBox",
                    componentId: "sc-xdzotl-0"
                })(["background-color:var(--atlas-background-content);"]),
                Un = K.ZP.div.attrs((e => ({
                    className: (0, ee.A)("kl-fill-layout", e.className)
                }))).withConfig({
                    displayName: "FillLayout",
                    componentId: "sc-xdzotl-1"
                })(["min-height:100%;display:flex;flex-direction:column;& > :last-child{flex:1;}"]);
            let Fn = function(e) {
                return e.MEMBER = "member", e.CANDIDATE = "candidate", e.DISABLED = "disabled", e
            }({});

            function zn() {
                const {
                    loyaltyClient: e
                } = R(), {
                    token: t
                } = (0, f.aC)();
                return (0, L.ZP)(t ? M.g.loyaltyTiers : null, (() => e.getLoyaltyTiers()))
            }

            function qn() {
                const {
                    loyaltyClient: e
                } = R(), {
                    token: t
                } = (0, f.aC)();
                return (0, L.ZP)(t ? M.g.loyaltyCustomer : null, (() => e.getCustomer()))
            }
            const jn = () => {
                    var e;
                    const {
                        loyaltyClient: t
                    } = R(), {
                        data: a,
                        isLoading: n
                    } = qn(), l = null != (e = null == a ? void 0 : a.pointsBalance) ? e : 0;
                    return n ? r().createElement(oa, {
                        size: "normal",
                        width: "75%"
                    }) : a ? r().createElement(re.XJ, {
                        noSpacing: !0,
                        "data-testid": "loyalty-heading"
                    }, t.formatPoints(l)) : null
                },
                Vn = () => {
                    var e;
                    const {
                        t: t
                    } = (0, b.ql)(), {
                        loyaltyClient: a
                    } = R(), {
                        data: n,
                        isLoading: l
                    } = zn(), {
                        data: i,
                        isLoading: o
                    } = qn(), s = null != (e = null == i ? void 0 : i.pointsBalance) ? e : 0, c = a.getNextTier(s, n), d = a.getBestTier(s, n);
                    return l || o ? r().createElement(oa, {
                        size: "normal",
                        width: "75%"
                    }) : n && i ? 0 === s ? r().createElement(re.TB, {
                        noSpacing: !0,
                        "data-testid": "loyalty-description"
                    }, t("customerHub.loyalty.startEarningRewards")) : d ? r().createElement(re.TB, {
                        noSpacing: !0,
                        "data-testid": "loyalty-description"
                    }, t("customerHub.loyalty.redeemPointsForReward", {
                        points: a.formatPoints(d.pointsPrice),
                        reward: d.name
                    })) : c ? r().createElement(re.TB, {
                        noSpacing: !0,
                        "data-testid": "loyalty-description"
                    }, t("customerHub.loyalty.earnPointsForReward", {
                        points: a.formatPoints(c.pointsPrice - s, {
                            pointsLabelPrefix: "more "
                        }),
                        reward: c.name
                    })) : null : null
                },
                Wn = K.ZP.div.withConfig({
                    displayName: "LoyaltyProgressBar__ProgressBarContainer",
                    componentId: "sc-p6vm9e-0"
                })(["background:var(--atlas-overlay-medium-heavy);height:16px;border-radius:var(--atlas-loyalty-border-radius);width:100%;"]),
                Gn = K.ZP.div.withConfig({
                    displayName: "LoyaltyProgressBar__ProgressBar",
                    componentId: "sc-p6vm9e-1"
                })(["--progress:", "%;", ";height:16px;background:var(--atlas-button-primary);display:block;border-radius:var(--atlas-loyalty-border-radius);transition-property:width;transition-duration:300ms;animation:widen 300ms normal forwards ease-in-out;@keyframes widen{from{width:4.5%;}to{width:var(--progress);}}"], (({
                    progress: e
                }) => Math.max(e, 4.5)), (0, le.K)("block")),
                $n = ({
                    showNextTier: e = !1
                }) => {
                    var t;
                    const {
                        t: a
                    } = (0, b.ql)(), {
                        data: n,
                        isLoading: l
                    } = zn(), {
                        data: i,
                        isLoading: o
                    } = qn(), s = null != (t = null == i ? void 0 : i.pointsBalance) ? t : 0, {
                        loyaltyClient: c
                    } = R(), d = c.getNextTier(s, n), u = c.getBestTier(s, n), m = e ? null == d ? void 0 : d.pointsPrice : (null == u ? void 0 : u.pointsPrice) || (null == d ? void 0 : d.pointsPrice), p = Math.min(s / (m || 1) * 100, 100);
                    return l || o ? r().createElement(oa, {
                        size: "small",
                        width: "100%"
                    }) : "number" == typeof p && m ? r().createElement(Wn, {
                        className: "kl-hub-loyalty-meter"
                    }, r().createElement(Gn, {
                        progress: p,
                        className: "kl-hub-loyalty-meter__progress",
                        "aria-label": a("customerHub.loyalty.progressAriaLabel", {
                            pointsBalance: s,
                            nextPoints: m
                        })
                    })) : null
                },
                Yn = K.ZP.img.withConfig({
                    displayName: "LoyaltyTier__VipImage",
                    componentId: "sc-crfytx-0"
                })(["width:24px;height:24px;"]),
                Kn = K.ZP.div.withConfig({
                    displayName: "LoyaltyTier__Row",
                    componentId: "sc-crfytx-1"
                })(["display:flex;justify-content:flex-start;align-items:center;gap:var(--atlas-space-tiny);"]),
                Jn = () => {
                    var e, t, a;
                    const {
                        data: n
                    } = qn();
                    return n && null != n && n.vipTier ? r().createElement(Kn, null, (null == n || null == (e = n.vipTier) ? void 0 : e.imageUrl) && r().createElement(Yn, {
                        src: null == n || null == (t = n.vipTier) ? void 0 : t.imageUrl,
                        alt: "",
                        role: "presentation",
                        "data-testid": "loyalty-tier-image"
                    }), r().createElement(re.d9, {
                        noSpacing: !0,
                        "data-testid": "loyalty-tier"
                    }, null == n || null == (a = n.vipTier) ? void 0 : a.name)) : null
                },
                Xn = K.ZP.div.withConfig({
                    displayName: "LoyaltyMeter__Row",
                    componentId: "sc-sc8xhl-0"
                })(["display:flex;justify-content:space-between;align-items:center;padding-top:var(--atlas-space-jumbo);padding-bottom:var(--atlas-space-mini);gap:var(--atlas-space-mini);"]),
                Qn = K.ZP.div.withConfig({
                    displayName: "LoyaltyMeter__Column",
                    componentId: "sc-sc8xhl-1"
                })(["display:flex;flex-direction:column;"]),
                er = K.ZP.div.withConfig({
                    displayName: "LoyaltyMeter__LoyaltyContainer",
                    componentId: "sc-sc8xhl-2"
                })(["display:flex;flex-direction:column;cursor:pointer;margin-bottom:var(--atlas-space-huge);border-radius:var(--atlas-card-border-radius-small);box-shadow:none;.kl-hub-icon{transition:color 300ms ease-in-out;color:var(--atlas-text-primary);}&:focus-visible{outline:3px solid var(--atlas-focus-outline-color);outline-offset:0;}&:hover,&:focus-visible,&:active{.kl-hub-icon{color:var(--atlas-primary);}}"]),
                tr = () => {
                    var e;
                    const {
                        t: t
                    } = (0, b.ql)(), {
                        navigate: a
                    } = (0, pe.HJ)(), {
                        loyaltyClient: n
                    } = R(), {
                        data: l,
                        isLoading: i
                    } = zn(), {
                        data: o
                    } = qn(), s = null != (e = null == o ? void 0 : o.pointsBalance) ? e : 0;
                    return o && o.state === Fn.MEMBER ? r().createElement(er, {
                        role: "button",
                        onClick: () => {
                            if (i) return;
                            const e = n.getNextTier(s, l),
                                t = n.getBestTier(s, l);
                            (0, m.ZD)(p.Xl.LOYALTY_CLICKED_PROGRESS_BAR, {
                                [p.Ox.POINTS_BALANCE]: s,
                                [p.Ox.BEST_TIER_NAME]: (null == t ? void 0 : t.name) || "",
                                [p.Ox.BEST_TIER_ID]: (null == t ? void 0 : t.pointsProduct.id) || "",
                                [p.Ox.NEXT_TIER_NAME]: (null == e ? void 0 : e.name) || "",
                                [p.Ox.NEXT_TIER_ID]: (null == e ? void 0 : e.pointsProduct.id) || "",
                                [p.Ox.BEST_TIER]: t || {},
                                [p.Ox.NEXT_TIER]: e || {}
                            }), a("/rewards")
                        },
                        tabIndex: 0,
                        "data-testid": "loyalty-meter"
                    }, r().createElement(Jn, null), r().createElement(Xn, null, r().createElement(Qn, null, r().createElement(jn, null), r().createElement(Vn, null)), r().createElement(Qn, null, r().createElement(Q.di, {
                        size: "mini",
                        "aria-label": t("customerHub.loyalty.viewPoints")
                    }))), r().createElement($n, null)) : null
                },
                ar = () => {
                    const {
                        isInitialized: e
                    } = R();
                    return e ? r().createElement(tr, null) : null
                },
                nr = (0, K.ZP)(re.Rk).withConfig({
                    displayName: "CustomerSummary__WelcomeHeading",
                    componentId: "sc-1g9n30m-0"
                })(["white-space:pre-line;"]),
                rr = (0, K.ZP)(Zn.x).withConfig({
                    displayName: "CustomerSummary__BlocksContainer",
                    componentId: "sc-1g9n30m-1"
                })(["&:empty{display:none;}"]),
                lr = K.ZP.div.withConfig({
                    displayName: "CustomerSummary__TopSection",
                    componentId: "sc-1g9n30m-2"
                })(["padding:0px var(--atlas-space-medium) var(--atlas-space-jumbo);"]),
                ir = (0, K.ZP)(Bn).withConfig({
                    displayName: "CustomerSummary__CarouselsSection",
                    componentId: "sc-1g9n30m-3"
                })(["border-top:1px solid var(--atlas-overlay-light);"]),
                or = () => {
                    var e, t, a, n;
                    const {
                        t: l
                    } = (0, b.ql)(), {
                        token: i,
                        firstName: o
                    } = (0, f.aC)(), s = (0, u.rV)(), c = (null == s || null == (e = s.feedSettings) ? void 0 : e.feedEnabled) && i, d = null == s || null == (t = s.wishlists) ? void 0 : t.enabled, m = null == s || null == (a = s.loyalty) ? void 0 : a.enabled, g = o ? l("customerHub.titles.forYou", {
                        name: o
                    }) : l("customerHub.titles.newUser");
                    return r().createElement(Un, {
                        className: "kl-hub-summary"
                    }, r().createElement("div", {
                        className: "kl-hub-summary__top"
                    }, !i && r().createElement(ht, {
                        label: (null == s || null == (n = s.customText) ? void 0 : n.actionText) || l("customerHub.auth.cta.authPage")
                    }), r().createElement(lr, null, i && r().createElement(nr, {
                        noSpacing: !0
                    }, g), r().createElement(rr, {
                        gap: 16,
                        display: "flex",
                        flexDirection: "column",
                        marginTop: 24
                    }, i && r().createElement(r().Fragment, null, r().createElement(ga, {
                        viewSource: p.nm.FOR_YOU
                    }), m && r().createElement(ar, null)), r().createElement(An, null)))), r().createElement(ir, {
                        className: "kl-hub-summary__carousels",
                        flex: 1
                    }, r().createElement(Na, null), d && r().createElement(Mn, null), c && r().createElement(bn, null)))
                };
            const sr = K.ZP.div.withConfig({
                    displayName: "MultiThumbnail__ImagesContainer",
                    componentId: "sc-1ax2hkv-0"
                })(["display:grid;border-radius:var(--atlas-thumbnail-border-radius);gap:2px;height:", "px;width:", "px;grid-template-rows:1fr 1fr;grid-template-columns:1fr 1fr;overflow:hidden;"], (({
                    size: e
                }) => e), (({
                    size: e
                }) => e)),
                cr = K.ZP.div.withConfig({
                    displayName: "MultiThumbnail__ImageContainer",
                    componentId: "sc-1ax2hkv-1"
                })(["height:100%;width:100%;"]),
                dr = (0, K.ZP)(Gt).withConfig({
                    displayName: "MultiThumbnail__ThumbnailImage",
                    componentId: "sc-1ax2hkv-2"
                })(["display:block;width:100%;height:100%;object-fit:cover;max-width:unset;"]);
            const ur = ({
                    images: e,
                    size: t = 64,
                    className: a
                }) => {
                    const n = 1 === (l = e.length) ? [{
                        gridColumn: "1 / 3",
                        gridRow: "1 / 3"
                    }] : 2 === l ? [{
                        gridColumn: "1 / 2",
                        gridRow: "1 / 3"
                    }, {
                        gridColumn: "2 / 3",
                        gridRow: "1 / 3"
                    }] : 3 === l ? [{
                        gridColumn: "1 / 2",
                        gridRow: "1 / 3"
                    }, {
                        gridColumn: "2 / 3",
                        gridRow: "1 / 2"
                    }, {
                        gridColumn: "2 / 3",
                        gridRow: "2 / 3"
                    }] : [{
                        gridColumn: "1 / 2",
                        gridRow: "1 / 2"
                    }, {
                        gridColumn: "2 / 3",
                        gridRow: "1 / 2"
                    }, {
                        gridColumn: "1 / 2",
                        gridRow: "2 / 3"
                    }, {
                        gridColumn: "2 / 3",
                        gridRow: "2 / 3"
                    }];
                    var l;
                    return r().createElement(sr, {
                        size: t,
                        className: (0, ee.A)("kl-hub-multi-thumbnail", a)
                    }, e.slice(0, 4).map(((e, t) => r().createElement(cr, {
                        key: e.id,
                        style: n[t]
                    }, r().createElement(dr, {
                        src: e.src || Wt,
                        alt: e.alt,
                        draggable: !1
                    })))))
                },
                mr = ({
                    order: e
                }) => {
                    const {
                        t: t
                    } = (0, b.ql)(), {
                        navigate: a
                    } = (0, pe.HJ)(), n = (0, b.OZ)(), l = "COMPLETE" === Xt(e.status), i = n("CANCELED" === e.status ? e.cancelledAt : e.estimatedDeliveryAt, {
                        month: "short",
                        day: "numeric",
                        year: "numeric"
                    });
                    return r().createElement(Da, {
                        disablePadding: !0
                    }, r().createElement(Ma, {
                        onClick: () => {
                            (0, m.ZD)(p.Xl.CLICKED_VIEW_ORDER, {
                                [p.Ox.ORDER_ID]: e.id,
                                [p.Ox.ORDER_NAME]: e.orderName,
                                [p.Ox.VIEW_SOURCE]: p.nm.ORDERS,
                                [p.Ox.ORDER]: e
                            }), a(`/orders/${e.id}`, {
                                order: e
                            })
                        },
                        "aria-label": e.orderName
                    }, r().createElement(Ua, null, r().createElement(ur, {
                        images: e.lineItems.map((e => ({
                            src: e.imageUrl,
                            alt: e.name,
                            id: e.id
                        }))),
                        size: 64
                    })), r().createElement(Ba, null, r().createElement(re.kd, {
                        noSpacing: !0
                    }, t(Jt(e.status))), r().createElement(re.TB, {
                        noSpacing: !0,
                        variant: "secondary"
                    }, e.orderName), r().createElement(re.TB, {
                        noSpacing: !0,
                        variant: "secondary"
                    }, l ? i : t("customerHub.order.expectedDate", {
                        date: i
                    }))), r().createElement(Fa, null, r().createElement(Q.di, {
                        size: "mini",
                        color: "heavy"
                    }))))
                },
                pr = (0, n.forwardRef)(((e, t) => r().createElement(Da, {
                    ref: t
                }, r().createElement(Ua, null, r().createElement(sa, {
                    size: 64
                })), r().createElement(Ba, null, r().createElement(oa, {
                    size: "small",
                    width: "30%"
                }), r().createElement(oa, {
                    size: "normal",
                    width: "50%"
                }), r().createElement(oa, {
                    size: "small",
                    width: "30%"
                })))));
            pr.displayName = "SkeletonOrderListItem";
            const gr = () => {
                var e;
                const {
                    t: t
                } = (0, b.ql)(), a = (0, n.useRef)(null), {
                    token: l
                } = (0, f.aC)(), i = (0, u.rV)(), {
                    data: o,
                    isLoading: s,
                    size: c,
                    setSize: d,
                    isValidating: m
                } = function() {
                    const e = (0, k.m)(),
                        {
                            token: t
                        } = (0, f.aC)();
                    return (0, xa.ZP)(((e, a) => t ? 0 === e ? Nn.iu.ordersUrl : a && a.next ? a.next : null : null), (t => e.getOrders({
                        url: t
                    })))
                }(), {
                    data: g,
                    isLoading: h
                } = qt(), {
                    hasMoreData: v,
                    emptyResults: E
                } = {
                    hasMoreData: !!((y = o) && y.length && y[y.length - 1].next),
                    emptyResults: (null == y || null == (C = y[0]) ? void 0 : C.results) && y[0].results.length < 1
                };
                var y, C, _;
                if (function({
                        hasMore: e,
                        triggerRef: t,
                        onLoadMore: a,
                        isLoading: n
                    }) {
                        Pn({
                            elementRef: t,
                            onVisible: (0, Pt.$)((() => a())),
                            disabled: !e || n
                        })
                    }({
                        triggerRef: a,
                        hasMore: v,
                        isLoading: m,
                        onLoadMore: () => {
                            d(c + 1)
                        }
                    }), s || h) return r().createElement(Zn.x, {
                    paddingY: 24,
                    paddingX: 16
                }, r().createElement(pa, null, r().createElement(ma, null), r().createElement(ma, null)));
                if (!l) return r().createElement(ht, {
                    label: (null == i || null == (_ = i.customText) ? void 0 : _.ordersActionText) || t("customerHub.auth.cta.orders")
                });
                if (!o || E) return r().createElement(we, {
                    label: t("customerHub.orders.empty")
                });
                const w = null != (e = null == g ? void 0 : g.map((e => e.id))) ? e : [],
                    x = o.flatMap((e => e.results)).filter((e => !w.includes(e.id)));
                return r().createElement(Un, {
                    className: "kl-hub-orders"
                }, 0 !== (null == g ? void 0 : g.length) && r().createElement(Zn.x, {
                    className: "kl-hub-orders__recent",
                    paddingY: 24,
                    paddingX: 16
                }, r().createElement(ga, {
                    viewSource: p.nm.ORDERS
                })), 0 !== x.length && r().createElement(Bn, {
                    className: "kl-hub-orders__past"
                }, r().createElement(Ha, null, t("customerHub.forYou.viewPastOrders")), r().createElement(Oa, null, x.map((e => r().createElement(mr, {
                    order: e,
                    key: e.id
                }))), v && r().createElement(pr, {
                    ref: a
                }))))
            };
            var hr = a(75656),
                vr = a(72784),
                Er = a(99112),
                fr = a(50664),
                br = a(23077);
            const yr = ({
                    children: e,
                    className: t,
                    disabled: a = !1,
                    label: i = "More actions",
                    testId: o
                }) => {
                    const [s, c] = (0, n.useState)(!1), d = (0, n.useRef)(null), u = (0, n.useRef)(null), m = (0, n.useRef)(!1), p = e => {
                        m.current = e
                    }, {
                        dimensions: {
                            width: g
                        },
                        measurementRef: h
                    } = (0, Er.h)(), {
                        refs: v,
                        floatingStyles: E,
                        context: f
                    } = (0, l.YF)({
                        open: s,
                        onOpenChange: c,
                        middleware: [(0, hr.cv)(4), (0, hr.uY)()],
                        whileElementsMounted: vr.Me,
                        placement: "bottom-end",
                        strategy: "fixed"
                    }), b = (0, l.bQ)(f), {
                        getReferenceProps: y,
                        getFloatingProps: C
                    } = (0, l.NI)([b]);
                    (0, n.useEffect)((() => {
                        s && u.current ? m.current ? (0, fr.pr)(u.current, u.current, fr.vi) : u.current.focus() : p(!1)
                    }), [s]);
                    const _ = n.Children.map(e, (e => (0, n.cloneElement)(e, {
                        onClick: t => {
                            var a;
                            null == e.props.onClick || e.props.onClick(t), c(!1), null == (a = d.current) || a.focus()
                        }
                    })));
                    return r().createElement(r().Fragment, null, r().createElement(ne.zx, X()({
                        role: "listbox",
                        variant: "icon",
                        disabled: a,
                        ref: e => {
                            e && (v.setReference(e), d.current = e, h.current = e)
                        },
                        onClick: () => {
                            c(!s)
                        }
                    }, y(), {
                        tabIndex: a ? -1 : 0,
                        onKeyDown: e => (0, fr.Ds)(e, s, c, p),
                        className: t,
                        "aria-label": i,
                        "aria-disabled": a,
                        "data-testid": o
                    }), r().createElement(Q.XW, {
                        size: "medium"
                    })), s && r().createElement(br.v, X()({
                        floatingRef: e => {
                            e && (v.setFloating(e), u.current = e)
                        },
                        setIsOpen: c,
                        menuRef: u,
                        parentRef: d,
                        style: Object.assign({}, E, {
                            border: "2px solid var(--atlas-overlay-light)",
                            minWidth: g
                        })
                    }, C), _))
                },
                Cr = () => {
                    const {
                        t: e
                    } = (0, b.ql)(), {
                        trigger: t
                    } = function() {
                        const e = (0, k.m)();
                        return (0, H.Z)(M.g.closeTicket, ((t, {
                            arg: a
                        }) => e.closeTicket(a)))
                    }(), {
                        ticket: a,
                        updateTicketCache: n
                    } = $(), {
                        mutate: l
                    } = (0, L.kY)(), i = [];
                    return a && a.status !== z.CLOSED && i.push({
                        value: a.id,
                        children: e("customerHub.chat.endConversation"),
                        onClick: async e => {
                            await t(e), n(Object.assign({}, a, {
                                status: z.CLOSED
                            }), !0), l(M.g.activeMessages)
                        }
                    }), r().createElement(yr, {
                        disabled: !i.length
                    }, i.map((e => r().createElement($a.W, X()({
                        key: e.value
                    }, e)))))
                },
                _r = r().createElement(Cr, {
                    key: "chat-action-menu"
                });
            var wr = a(32681);
            a(3545);
            const xr = K.ZP.div.withConfig({
                    displayName: "Conversation__ConversationContainer",
                    componentId: "sc-yy2y1j-0"
                })(["display:flex;flex-direction:column;margin-top:auto;gap:var(--atlas-space-mini);scrollbar-width:none;padding:var(--atlas-space-jumbo) var(--atlas-space-medium);&::-webkit-scrollbar{display:none;}", ""], (0, le.K)("flex")),
                Ir = ({
                    children: e,
                    className: t
                }) => {
                    const {
                        t: a
                    } = (0, b.ql)();
                    return r().createElement(xr, {
                        className: t,
                        "aria-label": a("customerHub.aria.label.chatConversation")
                    }, e)
                },
                kr = /\bhttp[s]?:\/\/\w+(\.\w+)+([\/\-?=@%]+\w+)*\/?/g;
            var Nr = function(e) {
                return e.TEXT = "text", e.LINK = "link", e
            }(Nr || {});
            const Tr = K.ZP.a.withConfig({
                    displayName: "TextMessage__ChatLink",
                    componentId: "sc-1ctvxdu-0"
                })(["color:", ";text-decoration:none;font-weight:600;"], (({
                    variant: e
                }) => "outgoing" === e ? "var(--atlas-text-primary-inverse);" : "var(--atlas-button-primary)")),
                Sr = (0, K.ZP)(re.l5).withConfig({
                    displayName: "TextMessage__DisplayName",
                    componentId: "sc-1ctvxdu-1"
                })(["padding-bottom:4px;color:var(--atlas-chat-bubble-display-name);"]),
                Pr = K.ZP.div.withConfig({
                    displayName: "TextMessage__TextMessageContainer",
                    componentId: "sc-1ctvxdu-2"
                })(["display:block;padding:var(--atlas-space-mini) var(--atlas-space-small);border-radius:var(--atlas-message-border-radius);word-wrap:break-word;word-break:break-word;white-space:pre-wrap;font-size:var(--atlas-font-size-small);font-family:var(--atlas-font-family);align-self:", ";", " h1,h2,h3,h4,h5,h6{font-family:var(--atlas-heading-font-family);}*{margin-block-start:0;margin-block-end:0;}li{white-space:normal;}"], (({
                    variant: e
                }) => "outgoing" === e ? "flex-end" : "flex-start"), (({
                    variant: e
                }) => "outgoing" === e ? "\n    background: var(--atlas-button-primary);\n    color: var(--atlas-text-primary-inverse);\n    margin-left: 48px;\n  " : "\n    color: var(--atlas-chat-bubble-text-primary);\n    background: var(--atlas-chat-bubble-background);\n    margin-right: 48px;\n  ")),
                Or = ({
                    variant: e = "incoming",
                    children: t,
                    className: a,
                    showDisplayName: n,
                    displayName: l
                }) => r().createElement(Pr, {
                    className: (0, ee.A)("kl-hub-message", a),
                    variant: e
                }, n && l && r().createElement(Sr, null, l), "string" == typeof t ? (e => {
                    const t = e.match(kr);
                    if (null == t || !t.length) return [{
                        type: Nr.TEXT,
                        content: e
                    }];
                    const a = [];
                    let n = e;
                    for (let r = 0; r < t.length; r += 1) {
                        const l = t[r],
                            i = n.indexOf(l);
                        if (-1 === i) return [{
                            type: Nr.TEXT,
                            content: e
                        }];
                        a.push({
                            type: Nr.TEXT,
                            content: n.substring(0, i)
                        }), a.push({
                            type: Nr.LINK,
                            content: l
                        }), n = n.substring(i + l.length)
                    }
                    return n.length && a.push({
                        type: Nr.TEXT,
                        content: n
                    }), a
                })(t).map((t => "text" === t.type ? t.content : r().createElement(Tr, {
                    variant: e,
                    key: t.content,
                    href: t.content,
                    target: "_blank"
                }, t.content))) : t),
                Rr = (0, K.F4)(["0%,80%,100%{transform:scale(0);}40%{transform:scale(1);}"]),
                Dr = K.ZP.div.withConfig({
                    displayName: "TypingIndicator__IndicatorContainer",
                    componentId: "sc-1fqhpm5-0"
                })(["display:flex;justify-content:center;align-items:center;gap:5px;padding:8px;"]),
                Lr = K.ZP.span.withConfig({
                    displayName: "TypingIndicator__IndicatorBubble",
                    componentId: "sc-1fqhpm5-1"
                })(["width:6px !important;height:6px !important;background-color:", ";border-radius:50%;animation:", " 1.5s infinite ease-in-out;&:nth-child(2){animation-delay:0.2s;}&:nth-child(3){animation-delay:0.4s;}"], (({
                    color: e
                }) => null != e ? e : "#8d8d8d"), Rr),
                Hr = ({
                    color: e
                }) => r().createElement(Dr, null, r().createElement(Lr, {
                    color: e
                }), r().createElement(Lr, {
                    color: e
                }), r().createElement(Lr, {
                    color: e
                })),
                Ar = K.ZP.div.withConfig({
                    displayName: "StatusChangeMessage__Container",
                    componentId: "sc-1mf0q13-0"
                })(["display:flex;align-items:center;gap:6px;font-size:12px;color:var(--atlas-overlay-heavy);padding:24px 0px;font-family:var(--atlas-font-family);"]),
                Mr = K.ZP.span.withConfig({
                    displayName: "StatusChangeMessage__Line",
                    componentId: "sc-1mf0q13-1"
                })(["flex-grow:1;height:1px;border-bottom:1px solid var(--atlas-overlay-medium);"]),
                Zr = K.ZP.span.withConfig({
                    displayName: "StatusChangeMessage__Message",
                    componentId: "sc-1mf0q13-2"
                })(["flex-grow:0;"]),
                Br = ({
                    text: e
                }) => r().createElement(Ar, null, r().createElement(Mr, null), r().createElement(Zr, null, e), r().createElement(Mr, null)),
                Ur = K.ZP.div.withConfig({
                    displayName: "ChatClosed__LinkContainer",
                    componentId: "sc-urefkh-0"
                })(["display:flex;flex-direction:column;gap:6px;"]);
            const Fr = ({
                closedBy: e,
                resetChat: t
            }) => {
                const {
                    t: a
                } = (0, b.ql)(), {
                    navigate: l
                } = (0, pe.HJ)(), i = (0, n.useMemo)((() => {
                    return "customer" === (t = e) || "anonymous" === t ? a("customerHub.chat.closedBy.customer") : function(e) {
                        return "agent" === e
                    }(e) ? a("customerHub.chat.closedBy.agent") : a("customerHub.chat.closedBy.automatic");
                    var t
                }), [e, a]);
                return r().createElement(r().Fragment, null, r().createElement(Br, {
                    text: i
                }), r().createElement(Ur, null, r().createElement("div", null, r().createElement(ne.zx, {
                    variant: "secondary",
                    onClick: t,
                    size: "small"
                }, a("customerHub.chat.actions.chat"))), r().createElement("div", null, r().createElement(ne.zx, {
                    variant: "secondary",
                    onClick: () => {
                        l("/")
                    },
                    size: "small"
                }, a("customerHub.chat.actions.home"))), r().createElement("div", null, r().createElement(ne.zx, {
                    variant: "secondary",
                    onClick: () => {
                        l("/recently-viewed")
                    },
                    size: "small"
                }, a("customerHub.chat.actions.recent")))))
            };
            var zr = a(37153);
            var qr = ({
                getSanitizer: e,
                sanitize: t
            }) => {
                const a = e();
                return () => {
                    const e = (0, n.useRef)();
                    return (0, n.useRef)((n => {
                        var r;
                        if ((null == (r = e.current) ? void 0 : r.content) === n) return e.current.result;
                        const l = t(n, a);
                        return e.current = {
                            content: n,
                            result: l
                        }, l
                    })).current
                }
            };
            const jr = ["content"],
                Vr = qr({
                    getSanitizer: () => zr.Z,
                    sanitize: (e, t) => t.sanitize(e, {
                        ADD_ATTR: ["target"]
                    })
                }),
                Wr = e => {
                    let {
                        content: t
                    } = e, a = Ze()(e, jr);
                    const n = Vr();
                    return r().createElement(Or, a, r().createElement("div", {
                        dangerouslySetInnerHTML: {
                            __html: n(t)
                        }
                    }))
                };

            function Gr(e) {
                return [null, Z.TEXT, Z.OFFICE_HOURS, Z.WELCOME].includes(e.messageType)
            }

            function $r(e) {
                return e.senderIdentityType === B.ROBOT
            }

            function Yr(e, t) {
                return $r(e) ? [Z.OFFICE_HOURS, Z.WELCOME].includes(e.messageType) || e.robotType === U.AUTO_RESPONDER ? t("customerHub.chatMessage.displayName.automatedMessage") : t("customerHub.chatMessage.displayName.aiAssistant.label") : ""
            }
            const Kr = (0, K.ZP)(Gt).withConfig({
                    displayName: "HelpRequestMessage__ImageContainer",
                    componentId: "sc-18s0wrv-0"
                })(["max-width:75px;max-height:75px;padding:8px;border:1px solid rgba(0,0,0,0.15);border-radius:var(--atlas-thumbnail-border-radius);"]),
                Jr = (0, K.ZP)($e).withConfig({
                    displayName: "HelpRequestMessage__StyledCardBody",
                    componentId: "sc-18s0wrv-1"
                })(["padding:var(--atlas-space-medium);"]),
                Xr = ({
                    message: e
                }) => {
                    var t;
                    const {
                        t: a
                    } = (0, b.ql)(), n = (0, b.nB)();
                    return r().createElement(We, {
                        style: {
                            cursor: "default"
                        }
                    }, r().createElement(Ke, null, r().createElement(re.aC, {
                        noSpacing: !0
                    }, a("customerHub.order.number", {
                        orderNumber: null == (t = e.context.order) ? void 0 : t.orderId
                    }))), r().createElement(Jr, null, e.context.order && e.context.order.lineItems && e.context.order.lineItems.length > 0 && r().createElement(r().Fragment, null, e.context.order.lineItems.length > 1 ? r().createElement(Vt, null, r().createElement(Zn.x, {
                        display: "flex",
                        flexDirection: "row",
                        gap: 16
                    }, e.context.order.lineItems.map((e => r().createElement(Kr, {
                        src: e.imageUrl,
                        alt: e.name,
                        key: e.id
                    }))))) : r().createElement(Zn.x, {
                        display: "flex",
                        flexDirection: "row",
                        gap: 16
                    }, e.context.order.lineItems.map((e => r().createElement(r().Fragment, null, r().createElement(Kr, {
                        src: e.imageUrl,
                        alt: e.name,
                        key: e.id
                    }), r().createElement(Zn.x, {
                        display: "flex",
                        flexDirection: "column",
                        gap: 8
                    }, r().createElement(re.Rw, {
                        bold: !0
                    }, e.name), r().createElement(re.OA, {
                        bold: !0
                    }, n(+e.price, e.currencyCode))))))))))
                };
            a(23018);
            const Qr = K.ZP.div.withConfig({
                    displayName: "PromptMessage__LinkContainer",
                    componentId: "sc-t0jmcr-0"
                })(["display:flex;flex-direction:column;gap:6px;"]),
                el = ({
                    prompts: e,
                    onPromptSelected: t
                }) => r().createElement(Qr, null, e.map(((e, a) => r().createElement("div", {
                    key: e.trim().replaceAll(" ", "")
                }, r().createElement(ne.zx, {
                    variant: "secondary",
                    onClick: () => t(e, a),
                    size: "small"
                }, e)))));

            function tl(e) {
                return Object.assign({}, e, {
                    id: -Date.now(),
                    contentType: "text/plain",
                    senderIdentityType: B.CUSTOMER,
                    channelType: F.WEB,
                    senderVisibleData: "",
                    createdAt: (new Date).toISOString(),
                    messageType: Z.TEXT,
                    context: {},
                    robotType: null
                })
            }
            const al = () => {
                const {
                    mutate: e
                } = (0, L.kY)();
                return (t, a) => e(M.g.activeMessages, a, {
                    optimisticData: e => [tl({
                        content: t
                    }), ...e],
                    populateCache: (e, t) => [e, ...t],
                    rollbackOnError: !0,
                    revalidate: !1
                })
            };

            function nl() {
                const e = (0, k.m)(),
                    t = al(),
                    a = (0, H.Z)(M.g.sendMessage, ((t, {
                        arg: a
                    }) => e.sendMessage(a)));
                return Object.assign({}, a, {
                    trigger: (e, n) => t(e.content, a.trigger(e, n))
                })
            }
            const rl = ({
                ticketId: e,
                prompts: t,
                onHandoff: a
            }) => {
                const {
                    trigger: l
                } = function() {
                    const e = (0, k.m)(),
                        t = al(),
                        a = (0, H.Z)(M.g.sendYesNoResponseMessage, ((t, {
                            arg: a
                        }) => e.sendYesNoResponseMessage(a)));
                    return Object.assign({}, a, {
                        trigger: e => t(e.message, a.trigger(e).then((() => tl({
                            content: e.message
                        }))))
                    })
                }(), i = (0, n.useCallback)(((t, n) => {
                    e && (l({
                        ticketId: e,
                        yes: 0 === n,
                        message: t
                    }), 0 === n && (null == a || a()))
                }), [l, e, a]);
                return r().createElement(el, {
                    prompts: t,
                    onPromptSelected: i
                })
            };
            const ll = K.ZP.div.withConfig({
                    displayName: "EmailCollectionMessage__MessageCard",
                    componentId: "sc-1x9aqwj-0"
                })(["display:flex;flex-direction:column;align-self:flex-start;background:var(--atlas-background-content);color:var(--atlas-button-primary);padding:var(--atlas-space-medium);margin-bottom:var(--atlas-space-small);border-radius:var(--atlas-message-border-radius);word-wrap:break-word;word-break:break-word;border:1px solid var(--atlas-border-light);max-width:100%;width:100%;"]),
                il = K.ZP.div.withConfig({
                    displayName: "EmailCollectionMessage__Title",
                    componentId: "sc-1x9aqwj-1"
                })(["font-size:var(--atlas-font-size-small);font-weight:var(--atlas-font-weight-bold);margin-bottom:var(--atlas-space-mini);color:var(--atlas-heading-text-primary);font-family:var(--atlas-heading-font-family);"]),
                ol = K.ZP.label.withConfig({
                    displayName: "EmailCollectionMessage__Label",
                    componentId: "sc-1x9aqwj-2"
                })(["font-size:var(--atlas-font-size-small);margin-bottom:var(--atlas-space-mini);font-family:var(--atlas-font-family);"]),
                sl = K.ZP.form.withConfig({
                    displayName: "EmailCollectionMessage__FormRow",
                    componentId: "sc-1x9aqwj-3"
                })(["display:flex;align-items:center;gap:var(--atlas-space-small);margin-top:var(--atlas-space-mini);"]),
                cl = (0, K.ZP)(it.o).withConfig({
                    displayName: "EmailCollectionMessage__Input",
                    componentId: "sc-1x9aqwj-4"
                })(["flex:1;border:1px solid ", ";transition:border-color 0.2s ease;&:focus,&:focus-visible{border-color:", ";}"], (({
                    invalid: e
                }) => e ? "var(--atlas-input-error)" : "var(--atlas-border-light)"), (({
                    invalid: e
                }) => e ? "var(--atlas-input-error)" : "var(--atlas-border-focus)")),
                dl = (0, K.ZP)(ne.zx).withConfig({
                    displayName: "EmailCollectionMessage__SubmitButton",
                    componentId: "sc-1x9aqwj-5"
                })(["min-width:40px;height:40px;display:flex;align-items:center;justify-content:center;transition:opacity 0.2s ease;&:hover{opacity:0.9;}"]),
                ul = K.ZP.div.withConfig({
                    displayName: "EmailCollectionMessage__ErrorMessage",
                    componentId: "sc-1x9aqwj-6"
                })(["color:var(--atlas-text-negative);font-size:var(--atlas-font-size-small);font-family:var(--atlas-font-family);margin-top:var(--atlas-space-small);padding:0 var(--atlas-space-mini);line-height:1.4;"]),
                ml = ({
                    message: e,
                    disabled: t,
                    onEmailSubmit: a
                }) => {
                    const [n, l] = r().useState(""), [i, o] = r().useState(null), {
                        t: s
                    } = (0, b.ql)();
                    return r().createElement(ll, null, r().createElement(il, null, s("customerHub.chat.emailCollectionMessage.title")), r().createElement(ol, {
                        htmlFor: "email-input"
                    }, e.content), r().createElement(sl, {
                        onSubmit: e => {
                            e.preventDefault(), ! function(e) {
                                return /^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(e)
                            }(n) ? o(s("customerHub.chat.emailCollectionMessage.error")) : (o(null), null == a || a(n))
                        }
                    }, r().createElement(cl, {
                        id: "email-input",
                        type: "email",
                        value: n,
                        onChange: e => l(e.currentTarget.value),
                        placeholder: s("customerHub.chat.emailCollectionMessage.placeholder"),
                        invalid: Boolean(i),
                        "aria-label": s("customerHub.aria.label.emailInput"),
                        disabled: t
                    }), r().createElement(dl, {
                        type: "submit",
                        "aria-label": s("customerHub.aria.label.submitEmail"),
                        disabled: t
                    }, r().createElement(Q.di, null))), i && r().createElement(ul, null, i))
                },
                pl = ({
                    ticketId: e
                }) => {
                    const {
                        t: t
                    } = (0, b.ql)(), {
                        trigger: a,
                        isMutating: l
                    } = function() {
                        const e = (0, k.m)(),
                            t = al(),
                            a = (0, H.Z)(M.g.sendEmailIdentificationMessage, ((t, {
                                arg: a
                            }) => e.sendEmailIdentificationMessage(a)));
                        return Object.assign({}, a, {
                            trigger: e => t(e.email, a.trigger(e).then((() => tl({
                                content: e.email
                            }))))
                        })
                    }(), i = (0, n.useCallback)((t => {
                        e && a({
                            email: t,
                            ticketId: e
                        })
                    }), [a, e]);
                    return r().createElement(ml, {
                        message: {
                            content: t("customerHub.chat.emailCollectionMessage.helpText")
                        },
                        onEmailSubmit: i,
                        disabled: l
                    })
                },
                gl = ({
                    message: e,
                    ticket: t,
                    isLast: a,
                    onHandoff: n
                }) => {
                    const {
                        t: l
                    } = (0, b.ql)(), i = (o = e.senderIdentityType) === B.AGENT || o === B.ROBOT ? p.Fo : p.QE;
                    var o, s;
                    return function(e) {
                        return e.messageType === Z.AUTHENTICATION
                    }(e) && (null == t ? void 0 : t.status) === z.OPEN && (null == t ? void 0 : t.state) === q.IDENTIFICATION && a ? r().createElement(We, {
                        key: e.id
                    }, r().createElement(ht, {
                        key: e.id,
                        label: l("customerHub.chat.authCollectionMessage.helpText")
                    })) : function(e) {
                        return e.messageType === Z.EMAIL_IDENTIFICATION
                    }(e) && (null == t ? void 0 : t.status) === z.OPEN && (null == t ? void 0 : t.state) === q.THIRD_PARTY_IDENTIFICATION_FOR_HANDOFF && a ? r().createElement(pl, {
                        key: e.id,
                        ticketId: null == t ? void 0 : t.id
                    }) : function(e) {
                        return e.messageType === Z.YES_NO_PROMPT
                    }(e) && (null == t ? void 0 : t.status) === z.OPEN && a ? (null == t ? void 0 : t.state) === q.PROMPT_TO_HANDOFF ? r().createElement(rl, {
                        key: e.id,
                        ticketId: null == t ? void 0 : t.id,
                        prompts: [l("customerHub.chat.prompt.yesHandoff"), l("customerHub.chat.prompt.noHandoff")],
                        onHandoff: n
                    }) : (null == t ? void 0 : t.state) === q.PROMPT_TO_CONTINUE ? r().createElement(rl, {
                        key: e.id,
                        ticketId: null == t ? void 0 : t.id,
                        prompts: [l("customerHub.chat.prompt.yesContinue"), l("customerHub.chat.prompt.noContinue")]
                    }) : null : function(e) {
                        return Gr(e) && "text/html" === e.contentType
                    }(e) ? r().createElement(Wr, {
                        key: e.id,
                        variant: i,
                        showDisplayName: $r(e),
                        displayName: Yr(e, l),
                        content: e.content
                    }) : Gr(e) ? r().createElement(Or, {
                        key: e.id,
                        variant: i,
                        showDisplayName: $r(e),
                        displayName: Yr(e, l)
                    }, null == (s = e.content) ? void 0 : s.replace(/[^\S\n]+/g, " ").trim()) : function(e) {
                        return e.messageType === Z.INBOX_GET_HELP
                    }(e) ? r().createElement(Xr, {
                        message: e
                    }) : null
                },
                hl = (0, K.ZP)(re.l5).withConfig({
                    displayName: "ChatToS__ToSContainer",
                    componentId: "sc-1nbpxjj-0"
                })(["text-align:center;"]),
                vl = K.ZP.a.withConfig({
                    displayName: "ChatToS__ToSLink",
                    componentId: "sc-1nbpxjj-1"
                })(["font-size:var(--atlas-font-size-tiny);color:var(--atlas-text-secondary);"]),
                El = K.ZP.div.withConfig({
                    displayName: "ChatMessages__ConversationContainer",
                    componentId: "sc-dka1lb-0"
                })(["overflow-y:auto;height:100%;display:flex;flex-flow:column nowrap;scroll-behavior:smooth;"]),
                fl = (0, K.ZP)((({
                    className: e
                }) => {
                    const {
                        t: t
                    } = (0, b.ql)(), a = (0, u.rV)().general.privacyPolicyLink;
                    return r().createElement(hl, {
                        className: e,
                        variant: "secondary"
                    }, a ? r().createElement(r().Fragment, null, r().createElement("span", null, t("customerHub.tos.privacyPolicy.withLink")), r().createElement(vl, {
                        href: a,
                        target: "_blank"
                    }, t("customerHub.tos.privacyPolicy.linkText"))) : r().createElement("span", null, t("customerHub.tos.privacyPolicy.withoutLink")))
                })).withConfig({
                    displayName: "ChatMessages__StyledChatToS",
                    componentId: "sc-dka1lb-1"
                })(["margin-bottom:var(--atlas-space-medium);"]),
                bl = ({
                    ticket: e,
                    showTypingIndicator: t,
                    aiStreamingText: a,
                    onStopAiStreaming: l,
                    onHandoff: i
                }) => {
                    var o;
                    const {
                        setTicketId: s
                    } = $(), {
                        data: c
                    } = j({
                        ticketId: (null == e ? void 0 : e.id) || p.Nf
                    }), d = (0, n.useRef)(null), m = (0, u.rV)(), {
                        t: g
                    } = (0, b.ql)(), {
                        resolvedToken: h
                    } = T(), {
                        mutate: v
                    } = (0, L.kY)(), [E, f] = (0, n.useState)();
                    (0, n.useEffect)((() => {
                        const e = null == c ? void 0 : c.find((e => e.messageType === Z.CONVERSATION_CLOSED));
                        e && !E && f(e.senderIdentityType)
                    }), [c, E]);
                    const y = (0, n.useMemo)((() => [...c].reverse()), [c]);
                    (0, n.useEffect)((() => {
                        d.current && d.current.scrollTo({
                            top: d.current.scrollHeight
                        })
                    }), [y, t, a, E, null == e ? void 0 : e.state]);
                    const C = (0, n.useMemo)((() => {
                        var e;
                        return (null == (e = y[y.length - 1]) ? void 0 : e.senderIdentityType) === p.eb
                    }), [y]);
                    (0, n.useEffect)((() => {
                        C && (null == l || l())
                    }), [C, l]);
                    const _ = (0, n.useCallback)((() => {
                            s(void 0), f(void 0), v(M.g.activeTicket(h), void 0, {
                                revalidate: !1
                            }), v(M.g.activeMessages, void 0, {
                                revalidate: !1
                            })
                        }), [h, s, f, v]),
                        w = null != (o = m.webChat) && o.welcomeMessage ? [{
                            id: -1,
                            content: m.webChat.welcomeMessage.trim(),
                            senderIdentityType: B.ROBOT,
                            contentType: "text",
                            channelType: F.WEB,
                            senderVisibleData: "",
                            createdAt: (new Date).toISOString(),
                            messageType: Z.WELCOME,
                            context: {},
                            robotType: null
                        }, ...y] : y;
                    return r().createElement(El, {
                        ref: d
                    }, r().createElement(Ir, null, !e && r().createElement(fl, null), w.map(((t, a) => r().createElement(gl, {
                        key: t.id,
                        ticket: e,
                        message: t,
                        isLast: a === w.length - 1,
                        onHandoff: i
                    }))), t && r().createElement(Or, {
                        variant: "incoming"
                    }, r().createElement(Hr, {
                        color: "var(--atlas-chat-bubble-text-primary)"
                    })), a && !C && r().createElement(Wr, {
                        variant: "incoming",
                        showDisplayName: !0,
                        displayName: g("customerHub.chatMessage.displayName.aiAssistant.label"),
                        content: a.replace(/[^\S\n]+/g, " ").trim()
                    }), E && (null == e ? void 0 : e.status) === z.CLOSED && r().createElement(Fr, {
                        closedBy: E,
                        resetChat: _
                    })))
                },
                yl = (0, K.F4)(["0%{transform:translateX(0);}25%{transform:translateX(5px);}50%{transform:translateX(-5px);}75%{transform:translateX(5px);}100%{transform:translateX(0);}"]),
                Cl = K.ZP.textarea.attrs((e => ({
                    className: (0, ee.A)("kl-hub-input", e.className)
                }))).withConfig({
                    displayName: "TextArea",
                    componentId: "sc-1v88v8x-0"
                })(["background:var(--atlas-background-content);border:1px solid var(--atlas-border-dark);border-radius:", ";padding:var(--atlas-input-padding);", " ", " &:focus{border-color:var(--atlas-border-focus);outline:none;box-shadow:none;}&::placeholder{color:var(--atlas-text-placeholder);}", " &[disabled]{background-color:var(--atlas-input-background-disabled);}"], (({
                    size: e = "normal"
                }) => `var(--atlas-input-border-radius-${e})`), (({
                    size: e = "normal"
                }) => (0, re.cY)(e, {
                    noSpacing: !0
                })), (({
                    full: e
                }) => e && (0, K.iv)(["width:100%;"])), (({
                    invalid: e
                }) => e && (0, K.iv)(["animation:", " 300ms ease-in-out;border-color:var(--atlas-input-error);"], yl))),
                _l = K.ZP.div.withConfig({
                    displayName: "MessageInput__MessageInputContainer",
                    componentId: "sc-1pi1tpu-0"
                })(["position:relative;"]),
                wl = (0, K.ZP)(Cl).withConfig({
                    displayName: "MessageInput__InputField",
                    componentId: "sc-1pi1tpu-1"
                })(["border-radius:var(--atlas-button-border-radius-normal);border:1px solid var(--atlas-overlay-heavy);appearance:none;font-size:var(--atlas-font-size-normal);line-height:var(--atlas-line-height-normal);width:100%;padding:var(--atlas-chat-input-padding);resize:none;overflow:hidden;field-sizing:content;"]),
                xl = (0, K.ZP)(ne.zx).withConfig({
                    displayName: "MessageInput__SubmitButton",
                    componentId: "sc-1pi1tpu-2"
                })(["position:absolute;top:var(--atlas-space-small);right:var(--atlas-space-small);border:1px solid var(--atlas-button-primary);", ""], (({
                    disabled: e
                }) => e && "\n    &:hover {\n      border: 1px solid var(--atlas-button-disabled-color);\n      cursor: not-allowed;\n    }\n  ")),
                Il = ({
                    onSubmit: e,
                    busy: t,
                    disabled: a,
                    onChange: l
                }) => {
                    const {
                        t: i
                    } = (0, b.ql)(), {
                        register: o,
                        handleSubmit: s,
                        reset: c,
                        watch: d
                    } = (0, lt.cI)(), u = 0 === d("content", "").trim().length, m = (0, Ya.p)(), p = (0, n.useRef)(null);
                    return r().createElement("form", {
                        ref: p,
                        onSubmit: s((t => {
                            t.content.length > 500 ? m({
                                label: i("customerHub.chat.characterLimit")
                            }) : t.content && (e(t), c())
                        }))
                    }, r().createElement(_l, {
                        className: "kl-hub-chat-input-wrapper"
                    }, r().createElement(wl, X()({
                        onKeyDown: e => {
                            var n;
                            e.shiftKey || "Enter" !== e.key || (e.preventDefault(), t || a || null == (n = p.current) || n.requestSubmit())
                        },
                        placeholder: i("customerHub.chat.inputPlaceholder"),
                        full: !0
                    }, o("content", {
                        onChange: () => null == l ? void 0 : l()
                    }), {
                        disabled: a,
                        "aria-label": i("customerHub.aria.label.chatInput"),
                        className: "kl-hub-chat-input"
                    })), r().createElement(xl, {
                        type: "submit",
                        variant: "icon",
                        size: "small",
                        disabled: t || u || a,
                        "aria-label": i("customerHub.aria.label.submitMessage")
                    }, r().createElement(Q.di, {
                        size: "mini",
                        color: t || u || a ? "inherit" : "primary"
                    }))))
                },
                kl = ({
                    onSubmit: e,
                    busy: t,
                    disabled: a,
                    activeTicket: l
                }) => {
                    const {
                        trigger: i
                    } = function() {
                        const e = (0, k.m)();
                        return (0, H.Z)(M.g.indicateUserTyping, ((t, {
                            arg: a
                        }) => e.indicateUserTyping(a)))
                    }(), {
                        onUserTyping: o
                    } = (e => {
                        const t = (0, n.useRef)();
                        return (0, n.useEffect)((() => () => clearTimeout(t.current)), []), {
                            onUserTyping: () => {
                                t.current || (e(), t.current = setTimeout((() => {
                                    t.current = void 0
                                }), 2e3))
                            }
                        }
                    })((() => {
                        l && (e => {
                            var t;
                            const a = null != (t = null == e ? void 0 : e.state) ? t : q.NORMAL;
                            return !!e.id && [q.NORMAL, q.OFFICE_HOURS].includes(a)
                        })(l) && i(l.id)
                    }));
                    return r().createElement(Il, {
                        onSubmit: e,
                        busy: t,
                        disabled: a,
                        onChange: o
                    })
                };

            function Nl() {
                const e = (0, k.m)(),
                    {
                        mutate: t
                    } = (0, L.kY)(),
                    {
                        setTicketId: a
                    } = $(),
                    {
                        resolvedToken: n
                    } = T(),
                    r = (0, H.Z)(M.g.createTicket, ((t, {
                        arg: a
                    }) => e.createTicket(a)));
                return Object.assign({}, r, {
                    trigger: (e, l) => {
                        const i = tl(e);
                        t(M.g.activeMessages, r.trigger(e, l).then((e => (a(e.id), t(M.g.activeTicket(n), e).then((() => e.lastMessage))))), {
                            optimisticData: e => [i, ...null != e ? e : []],
                            populateCache: (e, t = []) => [e, ...t],
                            rollbackOnError: !0,
                            revalidate: !0
                        })
                    }
                })
            }
            var Tl = a(62826);
            let Sl = function(e) {
                return e.CONVERSATION_CLOSED = "chat.end", e.MESSAGE = "chat.message", e.AI_MESSAGE = "chat.ai_message", e.TYPING = "chat.typing", e.PING = "ping", e.PONG = "pong", e.IDENTIFIED_CUSTOMER = "chat.identified_customer", e.STATE_CHANGED = "chat.state_changed", e
            }({});
            const Pl = ({
                    product: e,
                    attributionSource: t,
                    viewEvent: a
                }) => r().createElement(We, null, r().createElement(hn, {
                    product: e,
                    attributionSource: t,
                    viewEvent: a,
                    shouldHydrateProduct: !0
                })),
                Ol = K.ZP.div.withConfig({
                    displayName: "Chat__ChatWindow",
                    componentId: "sc-4axxop-0"
                })(["display:flex;flex-direction:column;height:100%;background:var(--atlas-background-content);"]),
                Rl = K.ZP.div.withConfig({
                    displayName: "Chat__ChatFooter",
                    componentId: "sc-4axxop-1"
                })(["display:flex;flex-direction:column;padding:var(--atlas-space-medium);border-top:1px solid var(--atlas-overlay-light);background:var(--atlas-background-content);"]),
                Dl = K.ZP.div.withConfig({
                    displayName: "Chat__MessagesContainer",
                    componentId: "sc-4axxop-2"
                })(["flex:1;overflow-y:hidden;", ""], (0, le.K)()),
                Ll = () => {
                    var e, t, a;
                    w((() => "Chat"));
                    const {
                        mutate: l
                    } = (0, L.kY)(), {
                        t: i
                    } = (0, b.ql)(), o = (0, u.rV)(), {
                        replace: c
                    } = (0, pe.HJ)(), {
                        trigger: d,
                        isMutating: g
                    } = nl(), {
                        trigger: h,
                        isMutating: v
                    } = Nl(), {
                        trigger: E
                    } = W(), y = (0, Ya.p)(), {
                        token: C,
                        anonymousToken: _
                    } = (0, f.aC)(), x = (0, wr.af)(), I = (0, wr.pN)(), k = (0, s.FV)(), N = he(), {
                        resolvedToken: S
                    } = T(), {
                        ticket: P,
                        updateTicketCache: O
                    } = $(), R = (0, n.useMemo)((() => C ? p.Wg.AUTHENTICATED : I ? p.Wg.IDENTIFIED : p.Wg.ANONYMOUS), [C, I]);
                    (0, n.useEffect)((() => {
                        var e, t, a;
                        ("HIDE_ALL" === (null == (e = o.webChat) ? void 0 : e.visibility) || R !== p.Wg.AUTHENTICATED && "LOGGED_IN" === (null == (t = o.webChat) ? void 0 : t.visibility) || R === p.Wg.AUTHENTICATED && "LOGGED_OUT" === (null == (a = o.webChat) ? void 0 : a.visibility)) && c("/")
                    }), [R, c, null == (e = o.webChat) ? void 0 : e.visibility]);
                    const {
                        lastJsonMessage: D
                    } = function(e, t) {
                        const a = (0, n.useMemo)((() => null != e ? e : t), [e, t]),
                            r = (0, n.useMemo)((() => a ? Nn.hF : null), [a]),
                            {
                                lastJsonMessage: l
                            } = (0, Tl.ZP)(r, {
                                protocols: a ? [a] : [],
                                shouldReconnect: () => Boolean(a),
                                reconnectAttempts: 10,
                                reconnectInterval: e => Math.min(2 ** e * 1e3, 1e4),
                                heartbeat: {
                                    message: JSON.stringify({
                                        type: "ping"
                                    }),
                                    returnMessage: JSON.stringify({
                                        type: "pong"
                                    }),
                                    interval: 1e4,
                                    timeout: 3e4
                                }
                            });
                        return {
                            lastJsonMessage: l
                        }
                    }(C, _), H = (0, n.useRef)(new Set), A = (0, n.useRef)(null), [Z, U] = (0, n.useState)(null);
                    (0, n.useEffect)((() => {
                        var e;
                        null == (e = A.current) || e.scrollIntoView({
                            behavior: "smooth"
                        })
                    }), []), (0, n.useEffect)((() => {
                        null != P && P.id && !P.readByCustomer && (E(P.id), l(M.g.activeTicket(S)))
                    }), [P, S, l, E]);
                    const {
                        showTypingIndicator: F
                    } = (({
                        lastJsonMessage: e,
                        ticketId: t,
                        ticketState: a
                    }) => {
                        const [r, l] = (0, n.useState)(!1), i = (0, n.useRef)();
                        return (0, n.useEffect)((() => () => clearTimeout(i.current)), []), (0, n.useEffect)((() => {
                            t && e && e.ticket_id === t && (e.type === Sl.MESSAGE || e.type === Sl.AI_MESSAGE || e.type === Sl.STATE_CHANGED ? (clearTimeout(i.current), l(!1)) : e.type === Sl.TYPING && (clearTimeout(i.current), l(!0), i.current = setTimeout((() => l(!1)), a === q.AI_CHAT ? 1e4 : 3e3)))
                        }), [e, t, a, l]), {
                            showTypingIndicator: r
                        }
                    })({
                        lastJsonMessage: D,
                        ticketId: null == P ? void 0 : P.id,
                        ticketState: null == P ? void 0 : P.state
                    });
                    (0, n.useEffect)((() => {
                        if (D && null != P && P.id && D.ticket_id === P.id)
                            if (D.type === Sl.MESSAGE) {
                                if (l(M.g.activeMessages), H.current.has(D.message_id)) return;
                                H.current.add(D.message_id), (0, m.ZD)(p.Xl.WEB_CHAT_MESSAGE_RECEIVED, {
                                    [p.Ox.WEB_CHAT_USER_TYPE]: R,
                                    [p.Ox.CLIENT_ID]: null == x ? void 0 : x.cid,
                                    [p.Ox.SENDER_TYPE]: B.AGENT,
                                    [p.Ox.MESSAGE_ID]: D.message_id,
                                    [p.Ox.CONVERSATION_ID]: P.id,
                                    [p.Ox.WEB_CHAT_SOURCE]: p.bY.CUSTOMER_HUB
                                }), (0, m.w8)(p.HW, p.ZS.WEB_CHAT_MESSAGE_SENT, {
                                    [p.Ny.CLIENT_ID]: null == x ? void 0 : x.cid,
                                    [p.Ny.WEB_CHAT_USER_TYPE]: R,
                                    [p.Ny.SENDER_TYPE]: B.AGENT,
                                    [p.Ny.MESSAGE_ID]: D.message_id,
                                    [p.Ny.CONVERSATION_ID]: P.id,
                                    [p.Ny.WEB_CHAT_SOURCE]: p.bY.CUSTOMER_HUB
                                })
                            } else D.type === Sl.AI_MESSAGE ? D.message_chunk && U(D.message_chunk) : D.type === Sl.CONVERSATION_CLOSED ? (O(Object.assign({}, P, {
                                status: z.CLOSED
                            })), l(M.g.activeMessages)) : D.type === Sl.STATE_CHANGED && (l(M.g.activeTicket(S)), l(M.g.activeMessages))
                    }), [D, P, S, l, O, x, R]);
                    const j = g || v,
                        V = (0, n.useMemo)((() => {
                            var e;
                            return (null == (e = o.webChat) ? void 0 : e.aiAgentEnabled) && v
                        }), [null == (t = o.webChat) ? void 0 : t.aiAgentEnabled, v]),
                        G = (0, n.useCallback)((async e => {
                            if (!j) {
                                const t = window.location.href;
                                P ? (d(Object.assign({}, e, {
                                    ticketId: P.id,
                                    context: {
                                        origin: {
                                            url: t
                                        }
                                    }
                                }), {
                                    onError: () => {
                                        y({
                                            label: i("customerHub.chat.errorMessage")
                                        })
                                    }
                                }), (0, m.ZD)(p.Xl.WEB_CHAT_MESSAGE_SENT, {
                                    [p.Ox.WEB_CHAT_USER_TYPE]: R,
                                    [p.Ox.CLIENT_ID]: null == x ? void 0 : x.cid,
                                    [p.Ox.MESSAGE_ID]: P.lastMessage.id,
                                    [p.Ox.CONVERSATION_ID]: P.id,
                                    [p.Ox.WEB_CHAT_SOURCE]: p.bY.CUSTOMER_HUB
                                }), (0, m.w8)(p.HW, p.ZS.WEB_CHAT_MESSAGE_SENT, {
                                    [p.Ny.CLIENT_ID]: null == x ? void 0 : x.cid,
                                    [p.Ny.WEB_CHAT_USER_TYPE]: R,
                                    [p.Ny.SENDER_TYPE]: B.CUSTOMER,
                                    [p.Ny.MESSAGE_ID]: P.lastMessage.id,
                                    [p.Ny.CONVERSATION_ID]: P.id,
                                    [p.Ny.WEB_CHAT_SOURCE]: p.bY.CUSTOMER_HUB
                                })) : h(Object.assign({}, e, {
                                    context: {
                                        origin: {
                                            url: t
                                        }
                                    }
                                }), {
                                    onSuccess: e => {
                                        (0, m.ZD)(p.Xl.WEB_CHAT_CONVERSATION_STARTED, {
                                            [p.Ox.WEB_CHAT_USER_TYPE]: R,
                                            [p.Ox.CLIENT_ID]: null == x ? void 0 : x.cid,
                                            [p.Ox.CONVERSATION_ID]: e.id,
                                            [p.Ox.WEB_CHAT_SOURCE]: p.bY.CUSTOMER_HUB
                                        }), (0, m.w8)(p.HW, p.ZS.WEB_CHAT_CONVERSATION_STARTED, {
                                            [p.Ny.CLIENT_ID]: null == x ? void 0 : x.cid,
                                            [p.Ny.WEB_CHAT_USER_TYPE]: R,
                                            [p.Ny.CONVERSATION_ID]: e.id,
                                            [p.Ny.WEB_CHAT_SOURCE]: p.bY.CUSTOMER_HUB
                                        }), (0, m.ZD)(p.Xl.WEB_CHAT_MESSAGE_SENT, {
                                            [p.Ox.WEB_CHAT_USER_TYPE]: R,
                                            [p.Ox.CLIENT_ID]: null == x ? void 0 : x.cid,
                                            [p.Ox.MESSAGE_ID]: e.lastMessage.id,
                                            [p.Ox.CONVERSATION_ID]: e.id,
                                            [p.Ox.WEB_CHAT_SOURCE]: p.bY.CUSTOMER_HUB
                                        }), (0, m.w8)(p.HW, p.ZS.WEB_CHAT_MESSAGE_SENT, {
                                            [p.Ny.CLIENT_ID]: null == x ? void 0 : x.cid,
                                            [p.Ny.WEB_CHAT_USER_TYPE]: R,
                                            [p.Ny.SENDER_TYPE]: B.CUSTOMER,
                                            [p.Ny.MESSAGE_ID]: e.lastMessage.id,
                                            [p.Ny.CONVERSATION_ID]: e.id,
                                            [p.Ny.WEB_CHAT_SOURCE]: p.bY.CUSTOMER_HUB
                                        })
                                    },
                                    onError: () => {
                                        y({
                                            label: i("customerHub.chat.errorMessage")
                                        })
                                    }
                                })
                            }
                        }), [j, P, d, y, i, h, x, R]),
                        Y = (0, n.useCallback)((() => {
                            (0, m.ZD)(p.Xl.WEB_CHAT_CONVERSATION_ESCALATED, {
                                [p.Ox.CLIENT_ID]: null == x ? void 0 : x.cid,
                                [p.Ox.WEB_CHAT_USER_TYPE]: R,
                                [p.Ox.MESSAGE_ID]: null == P ? void 0 : P.lastMessage.id,
                                [p.Ox.CONVERSATION_ID]: null == P ? void 0 : P.id,
                                [p.Ox.WEB_CHAT_SOURCE]: p.bY.CUSTOMER_HUB
                            }), (0, m.w8)(p.HW, p.ZS.WEB_CHAT_CONVERSATION_ESCALATED, {
                                [p.Ny.CLIENT_ID]: null == x ? void 0 : x.cid,
                                [p.Ny.WEB_CHAT_USER_TYPE]: R,
                                [p.Ny.CONVERSATION_ID]: null == P ? void 0 : P.id,
                                [p.Ny.WEB_CHAT_SOURCE]: p.bY.CUSTOMER_HUB
                            })
                        }), [P, R, x]);
                    return C || null != (a = o.webChat) && a.aiAgentEnabled ? r().createElement(Ol, null, (null == k ? void 0 : k.activeProduct) && !N && r().createElement(Zn.x, {
                        paddingX: 16,
                        paddingTop: 24,
                        paddingBottom: 16
                    }, r().createElement(Pl, {
                        product: k.activeProduct,
                        attributionSource: p.nm.CHAT,
                        viewEvent: p.Xl.CLICKED_PRODUCT
                    })), r().createElement(Dl, null, r().createElement(bl, {
                        ticket: P,
                        showTypingIndicator: F || V,
                        aiStreamingText: Z,
                        onStopAiStreaming: () => U(null),
                        onHandoff: Y
                    })), r().createElement(Rl, {
                        ref: A
                    }, r().createElement(kl, {
                        onSubmit: G,
                        busy: j,
                        activeTicket: P,
                        disabled: (null == P ? void 0 : P.status) === z.CLOSED || (null == P ? void 0 : P.state) === q.AI_CHAT && F || (null == P ? void 0 : P.state) === q.IDENTIFICATION || (null == P ? void 0 : P.state) === q.THIRD_PARTY_IDENTIFICATION_FOR_HANDOFF || (null == P ? void 0 : P.state) === q.PROMPT_TO_HANDOFF || (null == P ? void 0 : P.state) === q.PROMPT_TO_CONTINUE
                    }))) : r().createElement(ht, {
                        label: i("customerHub.chat.authCollectionMessage.helpText")
                    })
                };
            var Hl = a(81903);

            function Al(e, t) {
                const a = (0, k.m)();
                return (0, L.ZP)(M.g.getOrderKey(e), (() => a.getOrder(e)), {
                    fallbackData: t
                })
            }
            const Ml = K.ZP.div.withConfig({
                    displayName: "ShipmentProgressBar__BarContainer",
                    componentId: "sc-1c1pxvt-0"
                })(["display:flex;justify-content:space-between;width:100%;padding:var(--atlas-space-small) 0px;"]),
                Zl = K.ZP.div.withConfig({
                    displayName: "ShipmentProgressBar__BarStepContainer",
                    componentId: "sc-1c1pxvt-1"
                })(["display:flex;flex-direction:column;align-items:center;text-align:center;flex:1;&:first-child .atlas__shipment-progress--left{display:none !important;}&:last-child .atlas__shipment-progress--right{display:none !important;}"]),
                Bl = K.ZP.div.withConfig({
                    displayName: "ShipmentProgressBar__Circle",
                    componentId: "sc-1c1pxvt-2"
                })(["width:32px;height:32px;color:var(--atlas-text-primary-inverse);border:2px solid var(--atlas-text-primary);border-radius:50%;box-sizing:border-box;background:", ";display:flex;align-items:center;justify-content:center;margin-bottom:var(--atlas-space-tiny);", ""], (({
                    complete: e
                }) => e ? "var(--atlas-text-primary)" : "transparent"), (0, le.K)()),
                Ul = K.ZP.div.withConfig({
                    displayName: "ShipmentProgressBar__ConnectingBar",
                    componentId: "sc-1c1pxvt-3"
                })(["z-index:1;position:absolute;height:2px;top:50%;transform:translateY(-100%);background:var(--atlas-text-primary);", " ", ""], (0, le.K)(), (({
                    side: e
                }) => "right" === e ? (0, K.iv)(["right:0px;left:calc(50% + 16px);"]) : (0, K.iv)(["left:0px;right:calc(50% + 16px);"]))),
                Fl = K.ZP.div.withConfig({
                    displayName: "ShipmentProgressBar__StepInnerContainer",
                    componentId: "sc-1c1pxvt-4"
                })(["width:100%;position:relative;display:flex;justify-content:center;"]),
                zl = ({
                    status: e,
                    complete: t
                }) => {
                    const {
                        t: a
                    } = (0, b.ql)();
                    let n, l;
                    return n = "DELIVERED" === e && t ? "success" : "CANCELED" !== e && "REFUNDED" !== e || !t ? t ? "complete" : "pending" : "error", "error" === n ? l = r().createElement(Q.ZW, {
                        size: "small"
                    }) : ("success" === n || t) && (l = r().createElement(Q.hf, {
                        size: "small"
                    })), r().createElement(Zl, null, r().createElement(Fl, null, r().createElement(Ul, {
                        side: "left",
                        className: "atlas__shipment-progress--left"
                    }), r().createElement(Bl, {
                        complete: t
                    }, l), r().createElement(Ul, {
                        side: "right",
                        className: "atlas__shipment-progress--right"
                    })), r().createElement(re.l5, {
                        variant: "secondary"
                    }, a(Jt(e))))
                },
                ql = ({
                    status: e,
                    events: t
                }) => {
                    const a = {
                            CANCELED: ["PLACED", "CANCELED", "OUT_FOR_DELIVERY", "DELIVERED"],
                            REFUNDED: ["PLACED", "CONFIRMED_SHIPMENT", "DELIVERED", "REFUNDED"],
                            LABEL_PRINTED: ["PLACED", "LABEL_PRINTED", "IN_TRANSIT", "DELIVERED"],
                            LABEL_PURCHASED: ["PLACED", "LABEL_PURCHASED", "IN_TRANSIT", "DELIVERED"],
                            READY_FOR_PICKUP: ["PLACED", "CONFIRMED_SHIPMENT", "READY_FOR_PICKUP", "DELIVERED"],
                            ATTEMPTED_DELIVERY: ["PLACED", "CONFIRMED_SHIPMENT", "OUT_FOR_DELIVERY", "ATTEMPTED_DELIVERY"],
                            IN_TRANSIT: ["PLACED", "CONFIRMED_SHIPMENT", "IN_TRANSIT", "DELIVERED"],
                            FAILURE: ["PLACED", "CONFIRMED_SHIPMENT", "OUT_FOR_DELIVERY", "FAILURE"],
                            NOT_DELIVERED: ["PLACED", "CONFIRMED_SHIPMENT", "NOT_DELIVERED"],
                            MARKED_AS_FULFILLED: ["MARKED_AS_FULFILLED", "OUT_FOR_DELIVERY", "DELIVERED"],
                            FULFILLED: ["FULFILLED", "OUT_FOR_DELIVERY", "DELIVERED"],
                            DEFAULT: ["PLACED", "CONFIRMED_SHIPMENT", "OUT_FOR_DELIVERY", "DELIVERED"]
                        },
                        n = t && t.some((e => "READY_FOR_PICKUP" === e.status)),
                        l = a[e] || (n ? a.READY_FOR_PICKUP : a.DEFAULT),
                        i = l.findIndex((t => t === e));
                    return r().createElement(Ml, null, l.map(((e, t) => r().createElement(zl, {
                        status: e,
                        complete: i >= t,
                        key: e
                    }))))
                },
                jl = ({
                    item: e
                }) => {
                    const t = (0, b.nB)(),
                        {
                            data: a
                        } = ln(e.productId || "", e.productUrl || ""),
                        l = (0, n.useCallback)((() => {
                            if (a) {
                                const t = a.product.variants.find((t => t.id === e.variantId));
                                (0, m.ZD)(p.Xl.CLICKED_ORDER_LINE_ITEM, {
                                    [p.Ox.PRODUCT_ID]: a.product.id,
                                    [p.Ox.VARIANT_ID]: null == t ? void 0 : t.id,
                                    [p.Ox.IMAGE_URL]: a.product.imageUrl,
                                    [p.Ox.PRODUCT_NAME]: a.product.name,
                                    [p.Ox.VARIANT_NAME]: null == t ? void 0 : t.title,
                                    [p.Ox.PRODUCT_URL]: a.product.link,
                                    [p.Ox.VIEW_SOURCE]: p.nm.ORDER,
                                    $value: null == t ? void 0 : t.price,
                                    [p.Ox.PRODUCT]: a.product,
                                    [p.Ox.VARIANT]: t
                                })
                            }
                        }), [a, e]);
                    return r().createElement(Da, {
                        disablePadding: !0
                    }, r().createElement(Za, {
                        href: e.productUrl || "",
                        onClick: l
                    }, r().createElement(Ua, null, r().createElement(Kt, {
                        src: e.imageUrl,
                        size: 64
                    })), r().createElement(Ba, null, r().createElement(re.kd, {
                        noSpacing: !0
                    }, e.name), r().createElement(re.FJ, {
                        variant: "secondary",
                        noSpacing: !0
                    }, e.category), r().createElement(re.d9, {
                        noSpacing: !0
                    }, t(+e.price, e.currencyCode)))))
                },
                Vl = ({
                    items: e
                }) => {
                    const {
                        t: t
                    } = (0, b.ql)();
                    return 0 === e.length ? null : r().createElement(We, null, r().createElement(Ha, null, t("customerHub.order.title.inThisDelivery")), r().createElement(Oa, null, e.map((e => r().createElement(jl, {
                        key: e.id,
                        item: e
                    })))))
                },
                Wl = (0, K.ZP)(Ke).withConfig({
                    displayName: "shared__SummaryCardHeader",
                    componentId: "sc-7ax6c0-0"
                })(["padding:var(--atlas-space-jumbo) var(--atlas-space-medium);"]),
                Gl = (0, K.ZP)($e).withConfig({
                    displayName: "shared__SummaryCardContent",
                    componentId: "sc-7ax6c0-1"
                })(["padding:0px var(--atlas-space-medium) var(--atlas-space-jumbo);"]),
                $l = K.ZP.div.withConfig({
                    displayName: "OrderPriceBreakdown__PricingRow",
                    componentId: "sc-1jwgc0e-0"
                })(["display:flex;justify-content:space-between;&:not(:last-child){margin-bottom:var(--atlas-space-mini);}"]),
                Yl = ({
                    breakdown: e
                }) => {
                    const {
                        t: t
                    } = (0, b.ql)(), a = (0, b.nB)(), {
                        currency: n
                    } = e, l = parseFloat(e.discount);
                    return r().createElement(We, null, r().createElement(Wl, null, t("customerHub.order.title.orderSummary")), r().createElement(Gl, null, r().createElement($l, null, r().createElement(re.d9, {
                        noSpacing: !0
                    }, t("customerHub.order.pricing.subtotal")), r().createElement(re.d9, {
                        noSpacing: !0
                    }, a(parseFloat(e.subtotal), n))), r().createElement($l, null, r().createElement(re.d9, {
                        noSpacing: !0
                    }, t("customerHub.order.pricing.shipping")), r().createElement(re.d9, {
                        noSpacing: !0
                    }, a(parseFloat(e.shipping), n))), r().createElement($l, null, r().createElement(re.d9, {
                        noSpacing: !0
                    }, t("customerHub.order.pricing.totalPreTax")), r().createElement(re.d9, {
                        noSpacing: !0
                    }, a(parseFloat(e.totalsBeforeTax), n))), r().createElement($l, null, r().createElement(re.d9, {
                        noSpacing: !0
                    }, t("customerHub.order.pricing.taxes")), r().createElement(re.d9, {
                        noSpacing: !0
                    }, a(parseFloat(e.tax), n))), 0 !== l && r().createElement($l, null, r().createElement(re.d9, {
                        noSpacing: !0
                    }, t("customerHub.order.pricing.discount")), r().createElement(re.d9, {
                        noSpacing: !0
                    }, a(-l, n))), r().createElement($l, null, r().createElement(re.d9, {
                        noSpacing: !0
                    }, t("customerHub.order.pricing.total"), ":"), r().createElement(re.d9, {
                        noSpacing: !0
                    }, a(parseFloat(e.total), n)))))
                },
                Kl = ({
                    shippingAddress: e
                }) => {
                    const {
                        t: t
                    } = (0, b.ql)();
                    return r().createElement(We, null, r().createElement(Wl, null, t("customerHub.order.title.shippingInfo")), r().createElement(Gl, null, r().createElement(Xe, {
                        lines: e
                    })))
                },
                Jl = ({
                    paymentInfo: e
                }) => {
                    const {
                        t: t
                    } = (0, b.ql)();
                    return r().createElement(We, null, r().createElement(Wl, null, t("customerHub.order.title.payment")), r().createElement(Gl, null, e ? r().createElement(at, {
                        cardNumber: e.creditCardNumber,
                        company: e.creditCardCompany
                    }) : t("customerHub.order.title.noPayment")))
                },
                Xl = K.ZP.section.withConfig({
                    displayName: "OrderSummaryCards__CardList",
                    componentId: "sc-s8ppkt-0"
                })(["display:flex;flex-direction:column;gap:var(--atlas-space-medium);padding:var(--atlas-space-jumbo) var(--atlas-space-medium);"]),
                Ql = ({
                    order: e
                }) => r().createElement(Xl, {
                    className: "kl-hub-order-summary__cards"
                }, r().createElement(Vl, {
                    items: e.lineItems
                }), r().createElement(Yl, {
                    breakdown: e.priceBreakdown
                }), r().createElement(Kl, {
                    shippingAddress: e.shippingAddress
                }), r().createElement(Jl, {
                    paymentInfo: e.paymentInfo
                }));
            const ei = e => {
                    const {
                        t: t
                    } = (0, b.ql)(), {
                        navigate: a
                    } = (0, pe.HJ)();
                    return r().createElement(ne.zx, {
                        full: !0,
                        variant: "secondary",
                        onClick: () => {
                            e.trackGetHelpEvent(p.Xl.CLICKED_BEGIN_GET_HELP_FLOW), a("/orderHelp-issue", {
                                order: e.orderData
                            })
                        }
                    }, t("customerHub.order.button.getHelp"))
                },
                ti = e => {
                    var t;
                    const {
                        t: a
                    } = (0, b.ql)();
                    return null != (t = e.helpSettings) && null != (t = t.externalLink) && t.url ? r().createElement(ne.Qj, {
                        full: !0,
                        variant: "secondary",
                        href: e.helpSettings.externalLink.url,
                        target: "_blank",
                        onClick: () => {
                            e.trackGetHelpEvent(p.Xl.CLICKED_EXTERNAL_HELP_URL)
                        }
                    }, a("customerHub.order.button.getHelp")) : null
                },
                ai = e => {
                    const {
                        setIsOpen: t
                    } = h(), {
                        t: a
                    } = (0, b.ql)(), [l, i] = (0, n.useState)(!1), o = (0, n.useCallback)((() => {
                        var e, t;
                        return null == (e = null == (t = window.GorgiasChat) ? void 0 : t.isBusinessHours()) || e
                    }), []);
                    (0, n.useLayoutEffect)((() => {
                        window.GorgiasChat && window.GorgiasChat.init().then((() => {
                            i(!0)
                        }))
                    }), []);
                    if (!l) return r().createElement(ti, {
                        trackGetHelpEvent: e.trackGetHelpEvent,
                        helpSettings: e.helpSettings
                    });
                    const s = o() ? a("customerHub.order.button.gorgias.chatWithUs") : a("customerHub.order.button.gorgias.leaveAMessage");
                    return r().createElement(ne.zx, {
                        full: !0,
                        variant: "secondary",
                        onClick: () => {
                            e.trackGetHelpEvent(p.Xl.CLICKED_GORGIAS_CHAT_GET_HELP), window.GorgiasChat && (l ? Promise.resolve() : window.GorgiasChat.init()).then((() => {
                                o() && window.GorgiasChat.setPage("conversation"), window.GorgiasChat.open(), t(!1)
                            }))
                        }
                    }, s)
                },
                ni = () => {
                    const e = (0, pe.Qt)(),
                        t = (0, u.rV)(),
                        {
                            data: a
                        } = Al(e.orderId, e.order),
                        l = (0, n.useCallback)((e => {
                            a && (0, m.ZD)(e, {
                                [p.Ox.ORDER_ID]: a.id,
                                [p.Ox.LINE_ITEMS]: a.lineItems,
                                [p.Ox.ORDER_NAME]: a.orderName,
                                [p.Ox.ORDER]: a
                            })
                        }), [a]);
                    return t.helpSettings && a ? "hidden" === t.helpSettings.helpSettingsOption ? null : "inbox" === t.helpSettings.helpSettingsOption ? r().createElement(ei, {
                        trackGetHelpEvent: l,
                        orderData: a
                    }) : "externalUrl" === t.helpSettings.helpSettingsOption ? r().createElement(ti, {
                        trackGetHelpEvent: l,
                        helpSettings: t.helpSettings
                    }) : "gorgias" === t.helpSettings.helpSettingsOption ? r().createElement(ai, {
                        trackGetHelpEvent: l,
                        helpSettings: t.helpSettings
                    }) : null : null
                },
                ri = K.ZP.div.withConfig({
                    displayName: "OrderSummary__TextGroup",
                    componentId: "sc-45109e-0"
                })(["text-align:center;"]),
                li = () => {
                    var e, t, a;
                    const n = (0, pe.Qt)(),
                        {
                            t: l
                        } = (0, b.ql)(),
                        i = (0, b.OZ)(),
                        o = (0, P.A)(),
                        {
                            data: s
                        } = Al(n.orderId, n.order),
                        c = (0, u.rV)();
                    if (!s) return r().createElement(ve.$, {
                        size: "jumbo",
                        cover: !0
                    });
                    const d = Xt(s.status),
                        g = i(s.estimatedDeliveryAt, {
                            weekday: "long",
                            month: "short",
                            day: "numeric"
                        }),
                        h = "IN_PROGRESS" === d ? l("customerHub.order.expectedDate", {
                            date: g
                        }) : g,
                        v = l("customerHub.order.orderedDate", {
                            date: i(s.createdAt, {
                                month: "long",
                                day: "numeric",
                                year: "numeric"
                            })
                        });
                    let E = null == (e = s.latestFulfillment) ? void 0 : e.trackingUrl;
                    !E && c.storeId && (E = o.getOrderConfirmationLink(c.storeId, s.id));
                    let f = "";
                    if ("enabled" === (null == (t = c.returns) ? void 0 : t.returnsSettingsOption)) {
                        var y, C, _;
                        if (null === (null == (y = c.returns) ? void 0 : y.returnsPlatform)) throw new Error("Returns provider is not defined");
                        f = function(e, t, a, n) {
                            return t ? e === p.ww.aftership ? e.replace("[RETURN_URL]", t).replace("[ORDER_NUMBER]", a.replace("#", "")).replace("[EMAIL]", n) : e.replace("[RETURN_URL]", t).replace("[ORDER_NUMBER]", a).replace("[EMAIL]", n) : ""
                        }(p.ww[null == (C = c.returns) ? void 0 : C.returnsPlatform], null == (_ = c.returns) ? void 0 : _.returnsUrl, s.orderName, s.customerEmail)
                    }
                    return r().createElement("div", {
                        className: "kl-hub-order-summary"
                    }, r().createElement(Bn, {
                        display: "flex",
                        flexDirection: "column",
                        alignItems: "center",
                        gap: 12,
                        paddingX: 24,
                        paddingTop: 0,
                        paddingBottom: 24,
                        className: "kl-hub-order-summary__top"
                    }, r().createElement(ri, null, r().createElement(re.nL, {
                        noSpacing: !0,
                        variant: "secondary"
                    }, l(Jt(s.status))), h && g && r().createElement(re.d9, {
                        bold: !0,
                        noSpacing: !0
                    }, h)), r().createElement(ri, null, r().createElement(re.d9, {
                        variant: "secondary",
                        noSpacing: !0
                    }, v), r().createElement(re.d9, {
                        variant: "secondary",
                        noSpacing: !0
                    }, l("customerHub.order.name", {
                        orderName: s.orderName
                    }))), r().createElement(ql, {
                        status: s.status,
                        events: null == (a = s.fulfillments[0]) ? void 0 : a.events
                    }), r().createElement(ri, null, r().createElement(re.FJ, {
                        variant: "secondary",
                        noSpacing: !0
                    }, l("customerHub.order.title.mostRecentUpdate")), r().createElement(re.FJ, {
                        variant: "secondary",
                        noSpacing: !0
                    }, i(s.updatedAt, {
                        month: "long",
                        day: "numeric",
                        year: "numeric"
                    }))), r().createElement(ne.zx, {
                        full: !0,
                        onClick: () => {
                            o.clearCart().then((() => o.addToCart({
                                items: s.lineItems.map((e => ({
                                    id: e.variantId,
                                    quantity: e.quantity
                                }))),
                                properties: {
                                    _source_customer_hub_buy_it_again: "true"
                                }
                            }))).then((() => {
                                (0, m.ZD)(p.Xl.CLICKED_BUY_AGAIN, {
                                    [p.Ox.ORDER_ID]: s.id,
                                    [p.Ox.LINE_ITEMS]: s.lineItems,
                                    [p.Ox.ORDER_NAME]: s.orderName,
                                    [p.Ox.TOTAL_DISCOUNTS]: s.priceBreakdown.discount,
                                    $value: s.priceBreakdown.total,
                                    [p.Ox.ORDER]: s
                                }), o.getCart().then((e => {
                                    window.location.assign(`/checkouts/cn/${e.token}`)
                                })).catch((e => {
                                    (0, Hl.T)(e)
                                }))
                            }))
                        }
                    }, l("customerHub.order.button.buyAgain")), f && ["DELIVERED", "FULFILLED"].includes(s.status) && r().createElement(ne.Qj, {
                        full: !0,
                        variant: "secondary",
                        href: f,
                        target: "_blank",
                        onClick: () => {
                            (0, m.ZD)(p.Xl.CLICKED_START_RETURN, {
                                [p.Ox.ORDER_ID]: s.id,
                                [p.Ox.LINE_ITEMS]: s.lineItems,
                                [p.Ox.ORDER_NAME]: s.orderName,
                                [p.Ox.ORDER]: s
                            })
                        }
                    }, l("customerHub.order.button.startReturn")), E && r().createElement(ne.Qj, {
                        full: !0,
                        variant: "secondary",
                        href: E,
                        target: "_blank",
                        onClick: () => {
                            (0, m.ZD)(p.Xl.CLICKED_TRACK_SHIPMENT, {
                                [p.Ox.ORDER_ID]: s.id,
                                [p.Ox.LINE_ITEMS]: s.lineItems,
                                [p.Ox.ORDER_NAME]: s.orderName,
                                [p.Ox.ORDER]: s
                            })
                        }
                    }, l("customerHub.order.button.trackShipment")), r().createElement(ni, null)), r().createElement(Ql, {
                        order: s
                    }))
                },
                ii = K.ZP.div.withConfig({
                    displayName: "OrderHelpIssue__Page",
                    componentId: "sc-1bnoafd-0"
                })(["padding:0 var(--atlas-space-medium) var(--atlas-space-medium);"]),
                oi = K.ZP.header.withConfig({
                    displayName: "OrderHelpIssue__PageTop",
                    componentId: "sc-1bnoafd-1"
                })(["margin-bottom:var(--atlas-space-jumbo);"]),
                si = K.ZP.div.withConfig({
                    displayName: "OrderHelpIssue__IssueButtons",
                    componentId: "sc-1bnoafd-2"
                })(["display:flex;flex-direction:column;align-items:center;gap:var(--atlas-space-small);"]),
                ci = () => {
                    const e = (0, pe.Qt)(),
                        {
                            navigate: t
                        } = (0, pe.HJ)(),
                        {
                            t: a
                        } = (0, b.ql)(),
                        n = e.order;
                    if (!n) throw new Error("No order provided.");
                    const l = [{
                        label: a("customerHub.orderHelp.issueType.missingItem"),
                        issue: "missing_item"
                    }, {
                        label: a("customerHub.orderHelp.issueType.incorrectItem"),
                        issue: "incorrect_item"
                    }, {
                        label: a("customerHub.orderHelp.issueType.neverDelivered"),
                        issue: "never_delivered"
                    }, {
                        label: a("customerHub.orderHelp.issueType.other"),
                        issue: "other"
                    }];
                    return r().createElement(Zn.x, {
                        marginY: 16
                    }, r().createElement(ii, null, r().createElement(oi, null, r().createElement(re.XJ, null, a("customerHub.orderHelp.issueType.question", {
                        orderNumber: n.id
                    }))), r().createElement(si, null, l.map((e => r().createElement(ne.zx, {
                        key: e.issue,
                        full: !0,
                        variant: "secondary",
                        onClick: () => {
                            t("/orderHelp-items", {
                                order: n,
                                issue: e.issue
                            })
                        }
                    }, e.label))))))
                };

            function di() {
                const e = (0, k.m)();
                return (0, H.Z)(M.g.getHelp, ((t, {
                    arg: a
                }) => e.getHelp(a)))
            }
            const ui = K.ZP.div.withConfig({
                    displayName: "OrderHelpItems__Page",
                    componentId: "sc-xykcfs-0"
                })(["padding:0 var(--atlas-space-medium) var(--atlas-space-huge);height:100%;display:flex;flex-direction:column;gap:var(--atlas-space-jumbo);"]),
                mi = K.ZP.ul.withConfig({
                    displayName: "OrderHelpItems__LineItemList",
                    componentId: "sc-xykcfs-1"
                })(["display:flex;flex-direction:column;gap:var(--atlas-space-mini);padding:0;margin:0;"]),
                pi = K.ZP.li.withConfig({
                    displayName: "OrderHelpItems__ListItem",
                    componentId: "sc-xykcfs-2"
                })(["list-style-type:none;"]),
                gi = K.ZP.label.withConfig({
                    displayName: "OrderHelpItems__LineItemSelection",
                    componentId: "sc-xykcfs-3"
                })(["display:flex;align-items:center;gap:var(--atlas-space-medium);padding:var(--atlas-space-small) var(--atlas-space-medium);border-bottom:1px solid var(--atlas-border-light);"]),
                hi = K.ZP.input.withConfig({
                    displayName: "OrderHelpItems__LineItemCheckbox",
                    componentId: "sc-xykcfs-4"
                })(["width:20px;height:20px;"]),
                vi = (0, K.ZP)(ne.zx).withConfig({
                    displayName: "OrderHelpItems__ContinueButton",
                    componentId: "sc-xykcfs-5"
                })(["margin-top:auto;"]),
                Ei = () => {
                    const e = (0, pe.Qt)(),
                        {
                            navigate: t
                        } = (0, pe.HJ)(),
                        {
                            t: a
                        } = (0, b.ql)(),
                        l = e.order,
                        i = e.issue,
                        [o, s] = (0, n.useState)(new Set),
                        {
                            trigger: c
                        } = di(),
                        d = Array.from(o),
                        u = ((e, t) => {
                            const {
                                t: a
                            } = (0, b.ql)(), n = ((e, t) => ({
                                missingItem: e("customerHub.orderHelp.customerResponse.missingItem"),
                                missingItems: e("customerHub.orderHelp.customerResponse.missingItems", {
                                    count: t
                                }),
                                incorrectItem: e("customerHub.orderHelp.customerResponse.incorrectItem"),
                                incorrectItems: e("customerHub.orderHelp.customerResponse.incorrectItems", {
                                    count: t
                                }),
                                neverDelivered: e("customerHub.orderHelp.customerResponse.neverDelivered"),
                                neverDeliveredItems: e("customerHub.orderHelp.customerResponse.neverDeliveredItems", {
                                    count: t
                                })
                            }))(a, e.length), r = e.length > 1;
                            switch (t) {
                                case "missing_item":
                                    return r ? n.missingItems : n.missingItem;
                                case "incorrect_item":
                                    return r ? n.incorrectItems : n.incorrectItem;
                                case "never_delivered":
                                    return r ? n.neverDeliveredItems : n.neverDelivered;
                                default:
                                    return ""
                            }
                        })(d, i);
                    return r().createElement(Zn.x, {
                        marginY: 16
                    }, r().createElement(ui, null, r().createElement(re.XJ, null, a("customerHub.orderHelp.items.question")), r().createElement(mi, null, l.lineItems.map((e => r().createElement(pi, {
                        key: e.id
                    }, r().createElement(gi, null, r().createElement(hi, {
                        type: "checkbox",
                        checked: o.has(e),
                        onChange: () => {
                            var t;
                            t = e, o.has(t) ? o.delete(t) : o.add(t), s(new Set(o))
                        }
                    }), r().createElement(jl, {
                        item: e
                    })))))), r().createElement(vi, {
                        disabled: 0 === o.size,
                        full: !0,
                        variant: "primary",
                        onClick: () => {
                            "other" === i ? t("/orderHelp-form", {
                                order: l,
                                issue: i,
                                lineItems: d
                            }) : c({
                                orderId: l.id,
                                productIds: d.map((e => e.id)),
                                issueType: i,
                                issueDescription: u,
                                lineItems: d
                            }, {
                                onSuccess: () => {
                                    t("/chat")
                                }
                            })
                        }
                    }, a("customerHub.orderHelp.items.continue"))))
                },
                fi = K.ZP.div.withConfig({
                    displayName: "OrderHelpForm__Page",
                    componentId: "sc-tqkylm-0"
                })(["padding:0 var(--atlas-space-medium) var(--atlas-space-medium);display:flex;flex-direction:column;gap:var(--atlas-space-jumbo);"]),
                bi = K.ZP.ul.withConfig({
                    displayName: "OrderHelpForm__LineItemList",
                    componentId: "sc-tqkylm-1"
                })(["display:flex;flex-direction:column;gap:var(--atlas-space-mini);margin:0;padding:0;"]),
                yi = K.ZP.li.withConfig({
                    displayName: "OrderHelpForm__LineItem",
                    componentId: "sc-tqkylm-2"
                })(["width:100%;border:1px solid var(--atlas-border-light);border-radius:var(--atlas-thumbnail-border-radius);padding:var(--atlas-space-small) var(--atlas-space-medium);list-style-type:none;"]),
                Ci = K.ZP.textarea.withConfig({
                    displayName: "OrderHelpForm__TextArea",
                    componentId: "sc-tqkylm-3"
                })(["box-sizing:border-box;height:120px;width:100%;padding:6px var(--atlas-space-small);resize:both;overflow:auto;max-width:100%;max-height:500px;background-color:transparent;border:1px solid var(--atlas-border-dark);border-radius:var(--atlas-input-border-radius-normal);outline:none;box-shadow:none;::placeholder{color:#747576;}"]),
                _i = () => {
                    const e = (0, pe.Qt)(),
                        {
                            navigate: t
                        } = (0, pe.HJ)(),
                        {
                            t: a
                        } = (0, b.ql)(),
                        l = e.order,
                        i = e.issue,
                        o = e.lineItems || [],
                        [s, c] = (0, n.useState)(""),
                        {
                            trigger: d,
                            isMutating: u
                        } = di();
                    return r().createElement(Zn.x, {
                        marginY: 16
                    }, r().createElement(fi, null, r().createElement(re.XJ, null, a("customerHub.orderHelp.form.question")), r().createElement(bi, null, o.map((e => r().createElement(yi, {
                        key: e.id
                    }, r().createElement(jl, {
                        item: e
                    }))))), r().createElement(Ci, {
                        value: s,
                        placeholder: a("customerHub.orderHelp.form.descriptionPrompt"),
                        onChange: e => c(e.target.value),
                        maxLength: 1e3
                    }), r().createElement(ne.zx, {
                        full: !0,
                        variant: "secondary",
                        disabled: u,
                        onClick: () => {
                            d({
                                orderId: l.id,
                                productIds: o.map((e => e.id)),
                                issueType: i,
                                issueDescription: s,
                                lineItems: o
                            }, {
                                onSuccess: () => {
                                    t("/chat")
                                }
                            })
                        }
                    }, a("customerHub.orderHelp.form.send"))))
                },
                wi = () => {
                    var e;
                    const {
                        t: t
                    } = (0, b.ql)();
                    w((() => t("customerHub.forYou.recentlyViewed")));
                    const {
                        data: a,
                        isLoading: n
                    } = ka();
                    if (n) return r().createElement(Un, null, r().createElement(Bn, null, r().createElement(Oa, null, r().createElement(Va, null), r().createElement(Va, null))));
                    if (!a) return r().createElement(we, {
                        label: t("customerHub.products.recentlyViewed.empty")
                    });
                    const l = null != (e = null == a ? void 0 : a.flatMap((e => e.products))) ? e : [];
                    return r().createElement(Un, null, r().createElement(Bn, null, r().createElement(Oa, null, l.map((e => r().createElement(hn, {
                        product: e,
                        key: e.id,
                        attributionSource: p.nm.RECENTLY_VIEWED,
                        viewEvent: p.Xl.CLICKED_RECENTLY_VIEWED_PRODUCT,
                        shouldHydrateProduct: !0
                    }))))))
                },
                xi = () => {
                    const {
                        t: e
                    } = (0, b.ql)();
                    w((() => e("customerHub.forYou.recommendedProducts")));
                    const {
                        data: t,
                        isLoading: a
                    } = Ta();
                    if (a) return r().createElement(Un, null, r().createElement(Bn, null, r().createElement(Oa, null, r().createElement(Va, {
                        showActions: !0
                    }), r().createElement(Va, {
                        showActions: !0
                    }))));
                    if (null == t || !t.length) return r().createElement(we, {
                        label: e("customerHub.products.recommended.empty")
                    });
                    const n = null != t ? t : [];
                    return r().createElement(Un, null, r().createElement(Bn, null, r().createElement(Oa, null, n.map((e => r().createElement(hn, {
                        product: e,
                        key: e.id,
                        attributionSource: p.nm.RECOMMENDED,
                        viewEvent: p.Xl.CLICKED_RECOMMENDED_PRODUCT
                    }))))))
                },
                Ii = K.ZP.div.withConfig({
                    displayName: "WishlistItems__OnboardingSection",
                    componentId: "sc-1w5vngi-0"
                })(["padding:var(--atlas-space-huge) var(--atlas-space-medium);"]),
                ki = K.ZP.div.withConfig({
                    displayName: "WishlistItems__OnboardingCopy",
                    componentId: "sc-1w5vngi-1"
                })(["display:flex;flex-direction:column;align-items:center;padding:var(--atlas-space-large) var(--atlas-space-jumbo) var(--atlas-space-jumbo) var(--atlas-space-jumbo);text-align:center;"]),
                Ni = () => {
                    const {
                        t: e
                    } = (0, b.ql)();
                    w((() => e("customerHub.forYou.wishlistItems")));
                    const {
                        data: t,
                        isLoading: a,
                        error: n
                    } = (0, fe.Ei)(), {
                        token: l
                    } = (0, f.aC)();
                    if (a) return r().createElement(Un, null, r().createElement(Bn, null, r().createElement(Oa, null, r().createElement(Va, {
                        showActions: !0
                    }), r().createElement(Va, {
                        showActions: !0
                    }))));
                    if (null == t || !t.products.length || n) return r().createElement(we, {
                        label: e("customerHub.products.wishlist.empty")
                    });
                    const i = t.products;
                    return r().createElement(Un, null, !l && i.length > 0 && r().createElement(Ii, null, r().createElement(We, null, r().createElement(ki, null, r().createElement(on.X, {
                        active: !0
                    }), r().createElement(re.kd, {
                        noSpacing: !0
                    }, e("customerHub.products.wishlist.startedWishlist")), r().createElement(re.d9, {
                        noSpacing: !0
                    }, e("customerHub.products.wishlist.toSaveLogin")), r().createElement(ht, null)))), r().createElement(Bn, null, r().createElement(Oa, null, i.map((e => r().createElement(hn, {
                        product: e,
                        key: e.id,
                        shouldHydrateProduct: !l,
                        attributionSource: p.nm.FAVORITES,
                        viewEvent: p.Xl.CLICKED_WISHLIST_PRODUCT
                    }))))))
                },
                Ti = K.ZP.div.withConfig({
                    displayName: "SkeletonCoupons__SkeletonContainer",
                    componentId: "sc-ce1ifu-0"
                })(["padding:var(--atlas-space-jumbo) var(--atlas-space-medium);display:flex;flex-direction:column;"]),
                Si = K.ZP.div.withConfig({
                    displayName: "SkeletonCoupons__TitleSkeletonContainer",
                    componentId: "sc-ce1ifu-1"
                })(["margin-bottom:var(--atlas-space-medium);"]),
                Pi = K.ZP.div.withConfig({
                    displayName: "SkeletonCoupons__SkeletonCouponList",
                    componentId: "sc-ce1ifu-2"
                })(["display:flex;flex-direction:column;gap:var(--atlas-space-medium);"]),
                Oi = () => r().createElement("div", null, r().createElement(oa, {
                    size: "h1",
                    width: "50%"
                }), r().createElement(oa, {
                    size: "small",
                    width: "75%"
                }), r().createElement(oa, {
                    size: "small",
                    width: "75%"
                }), r().createElement(oa, {
                    size: "small",
                    width: "55%"
                })),
                Ri = () => r().createElement(Ti, null, r().createElement(Si, null, r().createElement(oa, {
                    size: "h1",
                    width: "75%"
                })), r().createElement(Pi, null, r().createElement(Oi, null), r().createElement(Oi, null)));
            var Di = qr({
                getSanitizer: () => zr.Z,
                sanitize: (e, t) => t.sanitize(e, {
                    ADD_ATTR: ["target", "rel"]
                })
            });
            const Li = K.ZP.div.withConfig({
                    displayName: "CouponListItem__StyledListItem",
                    componentId: "sc-1pst04a-0"
                })(["display:flex;flex-direction:column;padding:var(--atlas-space-medium);border-radius:var(--atlas-card-border-radius-small);gap:var(--atlas-space-medium);background-image:url(\"data:image/svg+xml,%3csvg width='100%25' height='100%25' xmlns='http://www.w3.org/2000/svg'%3e%3crect width='100%25' height='100%25' fill='none' rx='24' ry='24' stroke='rgba(0,0,0,0.15)' stroke-width='4' stroke-dasharray='9%2c 9' stroke-dashoffset='0' stroke-linecap='square'/%3e%3c/svg%3e\");background-color:", ";"], (({
                    unavailable: e
                }) => e ? "var(--atlas-overlay-light, rgba(0,0,0,0.15))" : "initial")),
                Hi = K.ZP.div.withConfig({
                    displayName: "CouponListItem__ButtonContainer",
                    componentId: "sc-1pst04a-1"
                })(["display:flex;flex-direction:row;gap:var(--atlas-space-small);"]),
                Ai = (0, K.ZP)(ne.zx).withConfig({
                    displayName: "CouponListItem__CopyButton",
                    componentId: "sc-1pst04a-2"
                })(["padding:0 var(--atlas-space-small);"]),
                Mi = ({
                    coupon: e,
                    unavailable: t = !1,
                    isCouponActive: a
                }) => {
                    var n;
                    const {
                        t: l
                    } = (0, b.ql)(), i = (0, P.A)(), o = (0, Ya.p)(), s = (0, b.OZ)(), c = Di(), d = a(e), u = !!e.expiresAt && new Date(e.expiresAt) < new Date;
                    return r().createElement(Li, {
                        unavailable: u || t,
                        "data-testid": "coupon-list-item"
                    }, r().createElement("div", null, r().createElement(re.kd, {
                        noSpacing: !0
                    }, e.name), r().createElement(re.TB, {
                        noSpacing: !0
                    }, l("customerHub.coupons.code", {
                        couponCode: e.code
                    }))), r().createElement(re.d9, {
                        "data-testid": "coupon-description",
                        noSpacing: !0,
                        dangerouslySetInnerHTML: {
                            __html: c(null != (n = e.description) ? n : "")
                        }
                    }), u && r().createElement(re.FJ, null, l("customerHub.coupons.expiredAt", {
                        expiredAt: s(e.expiresAt, {
                            month: "short",
                            day: "numeric",
                            year: "numeric"
                        })
                    })), !t && r().createElement(Hi, null, r().createElement(ne.zx, {
                        "data-testid": "apply-coupon-button",
                        full: !0,
                        onClick: () => {
                            d || ((0, m.ZD)(p.Xl.COUPON_APPLIED, {
                                [p.Ox.COUPON_CODE]: e.code,
                                [p.Ox.COUPON_NAME]: e.name,
                                [p.Ox.COUPON_ID]: e.couponId,
                                [p.Ox.COUPON_DESCRIPTION]: e.description,
                                [p.Ox.COUPON]: e
                            }), i.applyCouponCode(e.code))
                        }
                    }, l(d ? "customerHub.coupons.actions.applied" : "customerHub.coupons.actions.applyCoupon")), r().createElement(Ai, {
                        "data-testid": "copy-button",
                        variant: "icon",
                        "aria-label": l("customerHub.coupons.copyToClipboard"),
                        onClick: () => {
                            navigator.clipboard.writeText(e.code), o({
                                label: l("customerHub.coupons.toast.copiedToClipboard")
                            })
                        }
                    }, r().createElement(Q.TI, null))))
                },
                Zi = K.ZP.div.withConfig({
                    displayName: "Coupons__StyledCouponCategory",
                    componentId: "sc-vnr5c5-0"
                })(["padding:var(--atlas-space-jumbo) var(--atlas-space-medium);display:flex;flex-direction:column;"]),
                Bi = K.ZP.div.withConfig({
                    displayName: "Coupons__StyledCouponList",
                    componentId: "sc-vnr5c5-1"
                })(["display:flex;flex-direction:column;gap:var(--atlas-space-medium);"]),
                Ui = K.ZP.div.withConfig({
                    displayName: "Coupons__CouponsContainer",
                    componentId: "sc-vnr5c5-2"
                })(["background:var(--atlas-background-content);height:100%;"]),
                Fi = ({
                    title: e,
                    unavailable: t = !1,
                    coupons: a,
                    cart: l
                }) => {
                    const i = (0, n.useCallback)((e => {
                        if (!l) return !1;
                        const {
                            cartLevelDiscountApplications: t,
                            items: a
                        } = l;
                        return t.some((t => t.title === e.code)) || a.some((t => t.discounts.some((t => t.title === e.code))))
                    }), [l]);
                    return 0 === a.length ? null : r().createElement(Zi, null, r().createElement(re.XJ, null, e), r().createElement(Bi, null, a.map((e => r().createElement(Mi, {
                        key: e.couponId,
                        unavailable: t,
                        coupon: e,
                        isCouponActive: i
                    })))))
                },
                zi = () => {
                    var e, t, a;
                    const {
                        t: l
                    } = (0, b.ql)();
                    w((() => l("customerHub.coupons.couponsTitle")));
                    const {
                        data: i,
                        isLoading: o,
                        error: s
                    } = Sn(), c = (0, P.A)(), [d, u] = (0, n.useState)();
                    return (0, n.useEffect)((() => {
                        c.getCart().then((e => {
                            u(e)
                        }))
                    }), [c]), o ? r().createElement(Ri, null) : s ? r().createElement(we, {
                        label: l("customerHub.coupons.error")
                    }) : r().createElement(Ui, null, r().createElement(Fi, {
                        title: l("customerHub.coupons.activeCoupons"),
                        coupons: null != (e = null == i ? void 0 : i.active) ? e : [],
                        cart: d
                    }), r().createElement(Fi, {
                        title: l("customerHub.coupons.recentlyUsed"),
                        unavailable: !0,
                        coupons: null != (t = null == i ? void 0 : i.used) ? t : [],
                        cart: d
                    }), r().createElement(Fi, {
                        title: l("customerHub.coupons.expiredCoupons"),
                        unavailable: !0,
                        coupons: null != (a = null == i ? void 0 : i.expired) ? a : [],
                        cart: d
                    }))
                },
                qi = () => {
                    const {
                        t: e
                    } = (0, b.ql)();
                    return r().createElement(ht, {
                        label: e("customerHub.auth.cta.authPage")
                    })
                };
            var ji = a(13529),
                Vi = a(7739);
            const Wi = `${ji.bl.url}${ji.bl.submitToListPath}`;

            function Gi() {
                return (0, H.Z)(M.g.subscribeToList, ((e, {
                    arg: t
                }) => (async (e, t, a) => fetch(`${Wi}/?company_id=${e}`, {
                    method: "POST",
                    headers: Object.assign({
                        "Access-Control-Allow-Headers": "*",
                        "Content-Type": "application/json"
                    }, (0, Vi.h)(), {
                        Accept: "application/json",
                        revision: "2024-07-15"
                    }),
                    body: JSON.stringify({
                        data: {
                            type: "subscription",
                            attributes: {
                                profile: {
                                    data: {
                                        type: "profile",
                                        attributes: {
                                            email: t
                                        }
                                    }
                                }
                            },
                            relationships: {
                                list: {
                                    data: {
                                        type: "list",
                                        id: a
                                    }
                                }
                            }
                        }
                    })
                }))(t.companyId, t.email, t.listId)))
            }
            const $i = ["codePart1", "codePart2", "codePart3", "codePart4"],
                Yi = (0, K.ZP)(it.o).withConfig({
                    displayName: "CheckCodePage__OtpInput",
                    componentId: "sc-1odptk0-0"
                })(["width:71px;height:96px;gap:10px;border-radius:12px;text-align:center;font-size:var(--atlas-font-size-h2);line-height:var(--atlas-line-height-h2);&:focus{border:2px solid;border-color:var(--atlas-border-focus);outline:none;outline-offset:0px;}"]),
                Ki = K.ZP.div.withConfig({
                    displayName: "CheckCodePage__OTPFormContainer",
                    componentId: "sc-1odptk0-1"
                })(["display:flex;flex-direction:column;align-items:center;padding:var(--atlas-space-medium) var(--atlas-space-huge);"]),
                Ji = K.ZP.div.withConfig({
                    displayName: "CheckCodePage__OtpTopContainer",
                    componentId: "sc-1odptk0-2"
                })(["gap:var(--atlas-space-tiny);margin-bottom:var(--atlas-space-medium);text-align:center;"]),
                Xi = K.ZP.div.withConfig({
                    displayName: "CheckCodePage__OtpInputWrapper",
                    componentId: "sc-1odptk0-3"
                })(["display:flex;gap:10px;margin-bottom:var(--atlas-space-small);"]),
                Qi = () => {
                    const {
                        email: e,
                        previousData: t,
                        previousPath: a,
                        consentToMarketing: n
                    } = (0, pe.Qt)(), {
                        setValue: l,
                        handleSubmit: i,
                        setFocus: o,
                        control: s,
                        formState: {
                            errors: c
                        },
                        clearErrors: d,
                        setError: p,
                        reset: g
                    } = (0, lt.cI)(), {
                        t: h
                    } = (0, b.ql)(), {
                        trigger: v,
                        isMutating: E
                    } = function() {
                        const e = (0, k.m)();
                        return (0, H.Z)(M.g.verifyLogin, ((t, {
                            arg: a
                        }) => e.verifyLogin(a)))
                    }(), {
                        trigger: y,
                        isMutating: C
                    } = Gi(), {
                        companyId: _,
                        setToken: w
                    } = (0, f.aC)(), x = (0, u.rV)(), I = (0, fe.K_)(), {
                        replace: N
                    } = (0, pe.HJ)(), T = (0, k.m)(), S = async r => {
                        const l = r.codePart1 + r.codePart2 + r.codePart3 + r.codePart4;
                        try {
                            const t = await v({
                                    otp: l,
                                    email: e,
                                    company_id: _
                                }),
                                {
                                    authToken: a,
                                    isNewUser: n,
                                    multipassToken: r
                                } = t;
                            d($i), w(a, !0), T.setToken(a), r && await fetch(Nn.iu.shopifyMultipassLogin(r)), (0, m.oG)(e, n, I)
                        } catch (e) {
                            let t = {
                                message: h("customerHub.auth.verify.genericError")
                            };
                            return e instanceof Error && "RateLimited" === e.message && (t = {
                                message: h("customerHub.auth.verify.rateLimited")
                            }), p("root", t), o("codePart1"), g({
                                codePart1: void 0,
                                codePart2: void 0,
                                codePart3: void 0,
                                codePart4: void 0
                            }, {
                                keepErrors: !0
                            }), void setTimeout((() => {
                                d()
                            }), 3e3)
                        }
                        if (n && x.general.marketingListId) try {
                            await y({
                                companyId: _,
                                email: e,
                                listId: x.general.marketingListId
                            })
                        } catch (e) {}
                        N("/smsConsent", {
                            previousPath: a,
                            previousData: t
                        })
                    }, P = E || C;
                    return r().createElement(Ki, null, r().createElement(Ji, null, r().createElement(re.aC, {
                        noSpacing: !0
                    }, h("customerHub.auth.verify.heading")), r().createElement(re.TB, {
                        noSpacing: !0
                    }, r().createElement("span", null, h("customerHub.auth.verify.description1")), r().createElement("br", null), r().createElement("span", null, h("customerHub.auth.verify.description2")))), r().createElement("form", {
                        onSubmit: i(S)
                    }, r().createElement(Xi, {
                        onPaste: e => {
                            e.preventDefault();
                            const t = e.clipboardData.getData("text").slice(0, 4).split("");
                            $i.forEach(((e, a) => {
                                l(e, t[a])
                            })), o($i[t.length - 1]), 4 === t.length && i(S)()
                        }
                    }, $i.map(((e, t) => r().createElement(lt.Qr, {
                        key: e,
                        name: e,
                        control: s,
                        defaultValue: "",
                        render: ({
                            field: a
                        }) => r().createElement(Yi, X()({
                            onKeyDown: e => ((e, t) => {
                                "Backspace" === e.key && t > 0 && "" === e.currentTarget.value && o($i[t - 1])
                            })(e, t)
                        }, a, {
                            type: "text",
                            inputMode: "numeric",
                            maxLength: 1,
                            onInput: e => ((e, t) => {
                                const a = $i[e];
                                l(a, t.currentTarget.value), c.root && d("root"), t.currentTarget.value.length > 0 ? e >= 0 && e < 3 ? o($i[e + 1]) : i(S)() : e >= 1 && o($i[e - 1])
                            })(t, e),
                            invalid: !!c.root || !!c[e]
                        }))
                    }))))), P && r().createElement(ve.$, {
                        size: "jumbo"
                    }), c.root && r().createElement(re.TB, {
                        variant: "negative"
                    }, c.root.message))
                },
                eo = K.ZP.div.withConfig({
                    displayName: "Toast__StyledToast",
                    componentId: "sc-cwv4uq-0"
                })(["background:var(--atlas-background-content);display:flex;align-items:center;justify-content:space-between;gap:var(--atlas-space-mini);z-index:2147483647;position:fixed;bottom:var(--atlas-space-medium);right:var(--atlas-space-medium);border:1px solid var(--atlas-border-light);box-shadow:0px 16px 32px 0px rgba(55,63,71,0.12),0px 8px 20px 0px rgba(55,63,71,0.12),0px 0px 0px 2px rgba(55,63,71,0.08);padding:var(--atlas-space-small);border-radius:var(--atlas-toast-border-radius);transition-property:opacity,transform;min-width:350px;", ""], (({
                    variant: e
                }) => ("error" === e || "success" === e) && (0, K.iv)(["p{color:var(--atlas-text-primary-inverse);}background-color:", ";"], "error" === e ? "var(--atlas-background-error)" : "var(--atlas-background-success);"))),
                to = (0, K.ZP)(re.TB).withConfig({
                    displayName: "Toast__ToastLabel",
                    componentId: "sc-cwv4uq-1"
                })(["margin-right:var(--atlas-space-medium);"]),
                ao = K.ZP.div.withConfig({
                    displayName: "Toast__ButtonsContainer",
                    componentId: "sc-cwv4uq-2"
                })(["display:flex;align-items:center;"]),
                no = (0, K.ZP)(ne.zx).withConfig({
                    displayName: "Toast__ActionButton",
                    componentId: "sc-cwv4uq-3"
                })(["margin-right:var(--atlas-space-medium);"]),
                ro = ({
                    label: e,
                    open: t,
                    onClose: a,
                    action: i,
                    onUnmount: o,
                    autoCloseDuration: s,
                    variant: c = "notify"
                }) => {
                    const d = (0, l.jV)(),
                        u = (0, Pt.$)((() => null == o ? void 0 : o())),
                        m = (0, Pt.$)((() => a())),
                        p = (0, n.useRef)(!1),
                        {
                            context: g,
                            refs: h
                        } = (0, l.YF)({
                            nodeId: d,
                            open: t,
                            onOpenChange: e => {
                                e || a()
                            }
                        }),
                        {
                            isMounted: v,
                            styles: E
                        } = (0, l.Y_)(g, {
                            initial: {
                                opacity: 0,
                                transform: "scale(0.8)"
                            }
                        });
                    return (0, n.useEffect)((() => {
                        p.current && !v && u(), p.current = v
                    }), [v, u]), (0, n.useEffect)((() => {
                        if (!s || !t) return () => {};
                        const e = setTimeout((() => {
                            m()
                        }), s);
                        return () => {
                            clearTimeout(e)
                        }
                    }), [s, m, t]), v ? r().createElement(l.mN, {
                        id: d
                    }, r().createElement(l.ll, null, r().createElement(eo, {
                        variant: c,
                        style: E,
                        ref: h.setFloating,
                        className: "kl-hub-toast",
                        role: "alert",
                        "data-testid": "toast"
                    }, r().createElement(to, {
                        noSpacing: !0
                    }, e), r().createElement(ao, null, i && r().createElement(no, {
                        size: "small",
                        variant: "notify" === c ? "primary" : "secondary",
                        "data-testid": "toast-action",
                        onClick: () => {
                            var e;
                            i.onClick();
                            (null == (e = i.dismissOnClick) || e) && a()
                        },
                        className: "kl-toast__action"
                    }, i.label), r().createElement(ne.zx, {
                        size: "small",
                        variant: "icon",
                        onClick: a,
                        "data-testid": "toast-close"
                    }, r().createElement(Q.Tw, null)))))) : null
                },
                lo = () => {
                    var e;
                    const [t, a] = (0, n.useState)(void 0), [l, i] = (0, n.useState)([]), [o, s] = (0, n.useState)(!1);
                    return (0, n.useEffect)((() => {
                        const e = new AbortController;
                        return Ya.u.addEventListener("toast", (e => {
                            i((t => t.concat(e.detail)))
                        }), {
                            signal: e.signal
                        }), Ya.u.addEventListener("clear", (() => {
                            i([]), s(!1)
                        }), {
                            signal: e.signal
                        }), () => {
                            e.abort()
                        }
                    }), []), (0, n.useEffect)((() => {
                        l.length && !t ? (a(Object.assign({}, l[0])), i((e => e.slice(1)))) : l.length && t && s(!1)
                    }), [l, t]), (0, n.useEffect)((() => {
                        t && s(!0)
                    }), [t]), t ? r().createElement(ro, {
                        variant: null == t ? void 0 : t.variant,
                        label: null != (e = null == t ? void 0 : t.label) ? e : "",
                        open: o,
                        autoCloseDuration: 6e3,
                        onClose: () => {
                            s(!1)
                        },
                        onUnmount: () => {
                            a(void 0)
                        },
                        action: null == t ? void 0 : t.action
                    }) : null
                },
                io = K.ZP.div.withConfig({
                    displayName: "HubLauncherWidget__FloatingWidget",
                    componentId: "sc-1cgcsir-0"
                })(["display:flex;position:fixed;z-index:2147483646;align-items:center;justify-content:center;", ""], (({
                    placement: e = "bottom-end",
                    sideSpacing: t = 24,
                    bottomSpacing: a = 24
                }) => "left" === e ? (0, K.iv)(["bottom:50%;left:", "px;"], t) : "right" === e ? (0, K.iv)(["bottom:50%;right:", "px;"], t) : "bottom-start" === e ? (0, K.iv)(["left:", "px;bottom:", "px;"], t, a) : (0, K.iv)(["right:", "px;bottom:", "px;"], t, a))),
                oo = ({
                    children: e
                }) => {
                    const {
                        isOpen: t,
                        isLoading: a
                    } = h(), n = (0, u.rV)(), i = (0, l.jV)(), o = !a && !t, {
                        hubLauncher: s
                    } = n, {
                        context: c,
                        refs: d
                    } = (0, l.YF)({
                        nodeId: i,
                        open: o
                    }), {
                        isMounted: m,
                        styles: p
                    } = (0, l.Y_)(c, {
                        initial: {
                            opacity: 0,
                            transform: "scale(0.8)"
                        },
                        open: {
                            opacity: 1,
                            transform: "scale(1)"
                        }
                    });
                    return m ? r().createElement(l.mN, {
                        id: i
                    }, r().createElement(l.ll, null, r().createElement(io, {
                        style: p,
                        placement: null == s ? void 0 : s.positionOnDesktop,
                        sideSpacing: null == s ? void 0 : s.sideSpacing,
                        bottomSpacing: null == s ? void 0 : s.bottomSpacing,
                        ref: d.setFloating
                    }, e))) : null
                };
            var so = a(2816);
            const co = K.ZP.div.withConfig({
                    displayName: "FloatingMessages__FloatingMessageContainer",
                    componentId: "sc-a985x8-0"
                })(["display:flex;padding:var(--atlas-space-mini);border-radius:var(--atlas-message-border-radius);border:1px solid var(--atlas-overlay-medium);margin-bottom:var(--atlas-space-tiny);max-width:240px;height:36px;gap:10px;align-self:flex-start;align-items:center;justify-content:center;color:var(--atlas-chat-bubble-text-primary);background:var(--atlas-background-content);cursor:pointer;"]),
                uo = K.ZP.div.withConfig({
                    displayName: "FloatingMessages__FloatingMessage",
                    componentId: "sc-a985x8-1"
                })(["display:block;text-overflow:ellipsis;font-size:var(--atlas-font-size-small);font-family:var(--atlas-font-family);font-weight:var(--atlas-button-font-weight);line-height:var(--atlas-line-height-small);overflow:hidden;white-space:nowrap;"]),
                mo = K.ZP.div.withConfig({
                    displayName: "FloatingMessages__FloatingWidget",
                    componentId: "sc-a985x8-2"
                })(["display:flex;align-items:center;justify-content:center;color:var(--atlas-overlay-medium-heavy);width:16px;height:16px;"]),
                po = () => {
                    var e;
                    const {
                        setIsOpen: t
                    } = h(), {
                        navigate: a
                    } = (0, pe.HJ)(), {
                        trigger: l
                    } = W(), i = (0, u.rV)(), {
                        ticket: o,
                        updateTicketCache: c,
                        isLoading: d
                    } = $(), g = (0, n.useMemo)((() => o && !o.readByCustomer ? o.lastMessage : null), [o]), [v, E] = (0, n.useState)((() => !(0, s.Lt)())), f = () => {
                        (0, s.qO)(), E(!1)
                    }, b = (null == g ? void 0 : g.content) || !o && v && (null == (e = i.webChat) ? void 0 : e.welcomeMessage) || null;
                    return !b || d ? null : r().createElement(co, null, r().createElement(uo, {
                        key: g ? g.id : "welcome-message",
                        role: "button",
                        onClick: () => {
                            a("/chat"), t(!0), f(), (0, m.ZD)(p.yS.CLICKED_FLOATING_MESSAGE, {
                                [p.Ox.VIEW_SOURCE]: p.nm.HUB_LAUNCHER
                            })
                        }
                    }, b), r().createElement(mo, {
                        role: "button",
                        onClick: () => {
                            f(), o && !o.readByCustomer && (l(o.id), c(Object.assign({}, o, {
                                readByCustomer: !0
                            }))), (0, m.ZD)(p.yS.DISMISSED_FLOATING_MESSAGE, {
                                [p.Ox.VIEW_SOURCE]: p.nm.HUB_LAUNCHER
                            })
                        }
                    }, r().createElement(Q.Tw, null)))
                },
                go = K.ZP.button.withConfig({
                    displayName: "HubLauncherButton__StyledHubLauncherButton",
                    componentId: "sc-m8u3u8-0"
                })(["", ";position:relative;width:52px;height:52px;display:flex;justify-content:center;align-items:center;background:", ";border-radius:", "px;color:", ";border:none;&:after{border-radius:", "px;}&:hover,&:focus,&:focus-visible,&:active{background:", ";color:", ";}"], ne.uM, (({
                    backgroundVariant: e
                }) => e === so.JJ.BUTTON ? "var(--atlas-button-primary)" : e === so.JJ.WHITE ? "var(--atlas-white)" : "var(--atlas-background-main)"), (({
                    shape: e
                }) => Ue(e || so.oj.ROUNDED)), (({
                    backgroundVariant: e
                }) => e === so.JJ.BUTTON ? "var(--atlas-text-primary-inverse)" : "var(--atlas-button-primary)"), (({
                    shape: e
                }) => Ue(e || so.oj.ROUNDED)), (({
                    backgroundVariant: e
                }) => e === so.JJ.BUTTON ? "var(--atlas-button-primary)" : e === so.JJ.WHITE ? "var(--atlas-white)" : "var(--atlas-background-main)"), (({
                    backgroundVariant: e
                }) => e === so.JJ.BUTTON ? "var(--atlas-text-primary-inverse)" : "var(--atlas-button-primary)")),
                ho = ({
                    onClick: e,
                    children: t,
                    settings: a
                }) => {
                    var n, l;
                    return r().createElement(go, {
                        shape: null == (n = a.hubLauncher) ? void 0 : n.shape,
                        backgroundVariant: null == (l = a.hubLauncher) ? void 0 : l.backgroundColor,
                        onClick: e,
                        className: (0, ee.A)("kl-hub-launcher")
                    }, t)
                },
                vo = K.ZP.div.withConfig({
                    displayName: "ChatWidget__ChatWidgetContainer",
                    componentId: "sc-ixle6f-0"
                })(["display:flex;flex-direction:column;align-items:", ";"], (({
                    placement: e = so.gF.BOTTOM_END
                }) => e === so.gF.LEFT || e === so.gF.BOTTOM_START ? "flex-start" : "flex-end")),
                Eo = () => {
                    var e;
                    const {
                        t: t
                    } = (0, b.ql)(), {
                        setIsOpen: a
                    } = h(), {
                        navigate: n
                    } = (0, pe.HJ)(), l = (0, u.rV)();
                    return r().createElement(vo, {
                        placement: null == l || null == (e = l.hubLauncher) ? void 0 : e.positionOnDesktop
                    }, r().createElement(po, null), r().createElement(ho, {
                        settings: l,
                        onClick: () => {
                            n("/chat"), a(!0), (0, s.qO)(), (0, m.ZD)(p.yS.CLICKED_CHAT, {
                                [p.Ox.VIEW_SOURCE]: p.nm.HUB_LAUNCHER
                            })
                        },
                        "aria-label": t("customerHub.aria.label.openChat")
                    }, r().createElement(Q.P$, {
                        size: "large"
                    })))
                },
                fo = K.ZP.div.withConfig({
                    displayName: "WishlistWidget__NotificationCounter",
                    componentId: "sc-dxpr8c-0"
                })(["background-color:var(--atlas-white);color:var(--atlas-button-primary);width:24px;height:24px;top:", ";right:", ";border-radius:50%;position:absolute;z-index:1;border:1px solid var(--atlas-border-light);font-size:var(--atlas-font-size-small);line-height:var(--atlas-line-height-normal);"], (({
                    shape: e = so.oj.ROUNDED
                }) => e === so.oj.ROUNDED ? "-6px" : "-12px"), (({
                    shape: e = so.oj.ROUNDED
                }) => e === so.oj.ROUNDED ? "-6px" : "-12px")),
                bo = () => {
                    var e, t, a, n;
                    const {
                        setIsOpen: l
                    } = h(), {
                        navigate: i
                    } = (0, pe.HJ)(), {
                        t: o
                    } = (0, b.ql)(), {
                        data: s
                    } = (0, fe.Ei)(), c = (0, u.rV)(), d = null != (e = null == s || null == (t = s.products) ? void 0 : t.length) ? e : 0, g = (null == (a = c.wishlists) ? void 0 : a.iconStyle) === so.kJ.PLUS ? Q.KM : Q.qC;
                    return r().createElement(ho, {
                        settings: c,
                        onClick: () => {
                            i("/wishlist"), l(!0), (0, m.ZD)(p.yS.CLICKED_WISHLIST, {
                                [p.Ox.VIEW_SOURCE]: p.nm.HUB_LAUNCHER
                            })
                        },
                        "aria-label": o("customerHub.aria.label.openWishlist")
                    }, r().createElement(g, {
                        size: "large"
                    }), d > 0 && r().createElement(fo, {
                        shape: null == (n = c.hubLauncher) ? void 0 : n.shape,
                        role: "status",
                        "aria-label": o("customerHub.launcher.wishlistCount", {
                            number: d
                        })
                    }, d))
                },
                yo = () => {
                    const e = (0, u.rV)(),
                        {
                            isLoggedIn: t
                        } = (0, f.aC)(),
                        a = (0, s.FV)(),
                        {
                            data: l
                        } = (0, fe.Ei)(),
                        {
                            hubLauncher: i,
                            webChat: o
                        } = e,
                        c = "ALL" === (null == i ? void 0 : i.visibility) || t && "LOGGED_IN" === (null == i ? void 0 : i.visibility) || !t && "LOGGED_OUT" === (null == i ? void 0 : i.visibility),
                        d = (0, n.useMemo)((() => {
                            var a, n;
                            return "ALL" === (null == o ? void 0 : o.visibility) || t && "LOGGED_IN" === (null == o ? void 0 : o.visibility) || !t && "LOGGED_OUT" === (null == o ? void 0 : o.visibility) ? r().createElement(Eo, null) : null != (a = e.wishlists) && a.enabled && null != l && l.products && (null == l || null == (n = l.products) ? void 0 : n.length) > 0 ? r().createElement(bo, null) : null
                        }), [o, t, e, l]);
                    return i && a && c ? r().createElement(oo, null, d) : null
                };
            var Co = a(60116);

            function _o() {
                const {
                    resolvedToken: e
                } = T(), {
                    ticket: t,
                    setTicketId: a
                } = $(), {
                    mutate: n
                } = (0, L.kY)(), r = Nl(), l = nl();
                return null != t && t.id && t.status === z.OPEN ? Object.assign({}, l, {
                    trigger: (e, a) => {
                        l.trigger({
                            ticketId: t.id,
                            content: e.question,
                            context: {
                                faq: {
                                    id: e.id
                                },
                                origin: {
                                    url: window.location.href
                                }
                            }
                        }, a)
                    }
                }) : Object.assign({}, r, {
                    trigger: (l, i) => {
                        t && (a(void 0), n(M.g.activeTicket(e), void 0, {
                            revalidate: !1
                        }), n(M.g.activeMessages, void 0, {
                            revalidate: !1
                        })), r.trigger({
                            content: l.question,
                            context: {
                                faq: {
                                    id: l.id
                                },
                                origin: {
                                    url: window.location.href
                                }
                            }
                        }, i)
                    }
                })
            }
            const wo = () => {
                    const {
                        setIsOpen: e
                    } = h(), {
                        navigate: t
                    } = (0, pe.HJ)(), {
                        trigger: a
                    } = _o(), {
                        webChatEnabled: r,
                        userCanSendWebChatMessage: l
                    } = Ht(), i = (0, pe.rM)();
                    return (0, n.useEffect)((() => {
                        const n = new AbortController;
                        return Co.a.addEventListener("navigation", (a => {
                            e(!0), t(a.detail.data.path, a.detail.data.data)
                        }), {
                            signal: n.signal
                        }), Co.a.addEventListener("open", (t => {
                            e(t.detail.data.isOpen)
                        }), {
                            signal: n.signal
                        }), Co.a.addEventListener("faq", (n => {
                            e(!0), r && l ? (a(n.detail.data.faq), "/chat" !== i && t("/chat", {
                                hideTabs: !0
                            })) : t("/faq", {
                                faq: n.detail.data.faq
                            })
                        }), {
                            signal: n.signal
                        }), () => {
                            n.abort()
                        }
                    }), [e, t, l, r, a, i]), null
                },
                xo = K.ZP.div.withConfig({
                    displayName: "CustomerHubPreviewWindow__Container",
                    componentId: "sc-tsael1-0"
                })(["width:100%;height:100%;display:flex;flex-direction:column;background:var(--atlas-background-main);"]),
                Io = K.ZP.div.withConfig({
                    displayName: "CustomerHubPreviewWindow__OutletContainer",
                    componentId: "sc-tsael1-1"
                })(["flex:1;overflow-y:auto;"]),
                ko = K.ZP.div.withConfig({
                    displayName: "CustomerHubPreviewWindow__Header",
                    componentId: "sc-tsael1-2"
                })(["height:64px;width:100%;padding:var(--atlas-space-small);display:flex;justify-content:space-between;align-items:center;background-color:", ";"], (({
                    opaqueHeaderBackground: e
                }) => e ? "var(--atlas-background-content)" : "transparent")),
                No = K.ZP.div.withConfig({
                    displayName: "CustomerHubPreviewWindow__TitleContainer",
                    componentId: "sc-tsael1-3"
                })(["flex:1;display:flex;justify-content:center;"]),
                To = K.ZP.div.withConfig({
                    displayName: "CustomerHubPreviewWindow__BackButtonContainer",
                    componentId: "sc-tsael1-4"
                })(["width:var(--atlas-button-icon-size-normal);"]);

            function So() {
                if (document) return document.body
            }
            const Po = () => {
                const e = _(),
                    t = (0, pe.Qt)(),
                    a = (0, pe.rM)(),
                    {
                        back: n,
                        canGoBack: l,
                        navigate: i
                    } = (0, pe.HJ)();
                return r().createElement(K.LC, {
                    target: So()
                }, r().createElement(xo, {
                    className: "kl-hub-drawer"
                }, r().createElement(ko, {
                    opaqueHeaderBackground: "/" !== a
                }, r().createElement(To, null, !t.hideBackButton && r().createElement(ne.zx, {
                    variant: "icon",
                    onClick: () => {
                        l ? n() : i("/")
                    }
                }, r().createElement(Q.rV, null))), r().createElement(No, null, r().createElement(re.aC, {
                    noSpacing: !0
                }, e)), r().createElement(ne.zx, {
                    variant: "icon"
                }, r().createElement(Q.Tw, {
                    size: "medium"
                }))), r().createElement(Io, null, r().createElement(ge, null))))
            };
            var Oo = a(32118),
                Ro = a(66901);
            const Do = K.ZP.div.withConfig({
                    displayName: "Accordion__AccordionWrapper",
                    componentId: "sc-1gmp194-0"
                })(["width:100%;&.kl-hub-accordion--expanded{background-color:var(--atlas-overlay-light);}"]),
                Lo = (0, K.ZP)(Ma).withConfig({
                    displayName: "Accordion__AccordionButton",
                    componentId: "sc-1gmp194-1"
                })(["justify-content:space-between;&:hover:not(:disabled){background:none;}"]),
                Ho = (0, K.ZP)(Q.rs).withConfig({
                    displayName: "Accordion__AccordionIcon",
                    componentId: "sc-1gmp194-2"
                })(["transition:transform 150ms ease-in-out;"]),
                Ao = K.ZP.div.withConfig({
                    displayName: "Accordion__CollapsibleContainer",
                    componentId: "sc-1gmp194-3"
                })(["display:grid;grid-template-rows:", ";transition:grid-template-rows 150ms ease-in-out;"], (({
                    expanded: e
                }) => e ? "1fr" : "0fr")),
                Mo = K.ZP.div.withConfig({
                    displayName: "Accordion__CollapsibleContent",
                    componentId: "sc-1gmp194-4"
                })(["overflow:hidden;"]),
                Zo = K.ZP.div.withConfig({
                    displayName: "Accordion__CollapsibleContentInner",
                    componentId: "sc-1gmp194-5"
                })(["padding:var(--atlas-space-medium);padding-top:0;"]),
                Bo = {
                    up: 180,
                    down: 0,
                    left: 90,
                    right: -90
                },
                Uo = ({
                    expanded: e,
                    defaultExpanded: t,
                    onChange: a,
                    title: n,
                    children: l,
                    iconClosedDirection: i = "down",
                    iconExpandedDirection: o = "up",
                    className: s
                }) => {
                    const [c, d] = (0, Ro.u)({
                        controlledProp: e,
                        uncontrolledProp: t
                    });
                    return r().createElement(Do, {
                        className: (0, ee.A)("kl-hub-accordion", s, {
                            "kl-hub-accordion--expanded": !!c
                        })
                    }, r().createElement(Lo, {
                        onClick: () => {
                            d(!c), null == a || a(!c)
                        },
                        className: "kl-hub-accordion__button"
                    }, r().createElement(Zn.x, {
                        flex: 1
                    }, "string" == typeof n ? r().createElement(re.Rw, null, n) : n), r().createElement(Ho, {
                        size: "mini",
                        color: "heavy",
                        className: (0, ee.A)("kl-hub-accordion__icon", {
                            "kl-hub-accordion__icon--expanded": !!c
                        }),
                        style: {
                            transform: `rotate(${Bo[c?o:i]}deg)`
                        }
                    })), r().createElement(Ao, {
                        expanded: !!c,
                        "aria-hidden": !c,
                        inert: !c
                    }, r().createElement(Mo, {
                        className: "kl-hub-accordion__content"
                    }, r().createElement(Zo, null, l))))
                },
                Fo = (0, K.ZP)(re.d9).withConfig({
                    displayName: "FaqAccordionList__Answer",
                    componentId: "sc-zftcx3-0"
                })(["white-space:pre-wrap;"]),
                zo = ({
                    faqs: e
                }) => {
                    const {
                        t: t
                    } = (0, b.ql)(), a = (0, pe.Qt)().faq, [l, i] = (0, n.useState)(null == a ? void 0 : a.id), [o, s] = (0, n.useState)(!!a);
                    (0, n.useEffect)((() => {
                        if (o && l) {
                            const e = document.getElementById(`k-hub-faq-${l}`);
                            e && (e.scrollIntoView({
                                behavior: "smooth"
                            }), s(!1))
                        }
                    }), [o, l]);
                    return r().createElement(Oa, null, e.map((e => r().createElement(Da, {
                        key: e.id,
                        disablePadding: !0,
                        id: `k-hub-faq-${e.id}`
                    }, r().createElement(Uo, {
                        title: e.question,
                        expanded: e.id === l,
                        onChange: () => {
                            l === e.id ? i(void 0) : (i(e.id), (e => {
                                (0, m.ZD)(p.Xl.CLICKED_FAQ, {
                                    [p.Ox.FAQ_ID]: e.id,
                                    [p.Ox.FAQ_NAME]: e.name,
                                    [p.Ox.FAQ_SOURCE]: p.nm.FAQ
                                })
                            })(e))
                        }
                    }, r().createElement(Fo, null, e.answer), e.url && r().createElement(re.rU, {
                        href: e.url,
                        target: "_blank"
                    }, t("customerHub.faq.learnMore")))))))
                },
                qo = ({
                    faqs: e
                }) => {
                    const {
                        trigger: t
                    } = _o(), {
                        navigate: a
                    } = (0, pe.HJ)();
                    return r().createElement(Oa, null, e.map((e => r().createElement(Da, {
                        key: e.name,
                        disablePadding: !0
                    }, r().createElement(Ma, {
                        onClick: () => {
                            (e => {
                                (0, m.ZD)(p.Xl.CLICKED_FAQ, {
                                    [p.Ox.FAQ_ID]: e.id,
                                    [p.Ox.FAQ_NAME]: e.name,
                                    [p.Ox.FAQ_SOURCE]: p.nm.FAQ
                                })
                            })(e), (e => {
                                t(e), a("/chat", {
                                    hideTabs: !0
                                })
                            })(e)
                        }
                    }, r().createElement(Ba, null, r().createElement(re.Rw, null, e.question)), r().createElement(Fa, null, r().createElement(Q.di, {
                        size: "mini",
                        color: "heavy"
                    })))))))
                },
                jo = (0, K.ZP)(ne.zx).withConfig({
                    displayName: "FaqPage__FloatingChatButton",
                    componentId: "sc-ia36lz-0"
                })(["position:absolute;bottom:var(--atlas-space-huge);left:50%;transform:translateX(-50%);display:flex;align-items:center;gap:var(--atlas-space-mini);box-shadow:var(--atlas-shadow-medium);"]),
                Vo = () => {
                    var e;
                    const {
                        t: t
                    } = (0, b.ql)(), a = (0, u.rV)();
                    (0, pe.E0)(!(null != (e = a.faq) && e.enabled));
                    const {
                        faq: l
                    } = (0, pe.Qt)(), {
                        data: i,
                        isLoading: o
                    } = (0, Oo.D)(), {
                        webChatEnabled: c,
                        userCanSendWebChatMessage: d
                    } = Ht(), {
                        isLoading: m
                    } = V(), {
                        navigate: g,
                        replace: h
                    } = (0, pe.HJ)(), {
                        trigger: v
                    } = _o(), E = (0, s.FV)();
                    return w((() => t(c ? "customerHub.tabs.chat" : "customerHub.tabs.faq"))), (0, n.useEffect)((() => {
                        l && d && c && !m && (v(l), h("/chat"))
                    }), [l, d, c, v, h, m]), c && l && m ? r().createElement(ve.$, {
                        cover: !0,
                        size: "large"
                    }) : r().createElement(r().Fragment, null, r().createElement(Bn, {
                        height: "100%",
                        overflowY: "auto",
                        style: {
                            paddingBottom: c ? 96 : 0
                        }
                    }, r().createElement(Un, null, r().createElement(Zn.x, {
                        paddingX: 16,
                        paddingY: 24
                    }, r().createElement(re.nL, {
                        noSpacing: !0
                    }, t("customerHub.faq.header")), (null == E ? void 0 : E.activeProduct) && r().createElement(Zn.x, {
                        marginTop: 24
                    }, r().createElement(Pl, {
                        product: E.activeProduct,
                        attributionSource: p.nm.FAQ,
                        viewEvent: p.Xl.CLICKED_PRODUCT
                    }))), r().createElement(Zn.x, null, o ? r().createElement(Oa, null, r().createElement(Da, null, r().createElement(oa, {
                        size: "normal",
                        width: "90%"
                    })), r().createElement(Da, null, r().createElement(oa, {
                        size: "normal",
                        width: "90%"
                    })), r().createElement(Da, null, r().createElement(oa, {
                        size: "normal",
                        width: "90%"
                    }))) : i && (c && d ? r().createElement(qo, {
                        faqs: i.results
                    }) : r().createElement(zo, {
                        faqs: i.results
                    }))))), c && r().createElement(jo, {
                        onClick: () => {
                            g("/chat", {
                                hideTabs: !0
                            })
                        }
                    }, r().createElement(Le.Z, null, t("customerHub.chat.buttonPlaceholder")), r().createElement(Q.KK, null)))
                },
                Wo = K.ZP.img.withConfig({
                    displayName: "NextRewardCard__RewardImage",
                    componentId: "sc-waamqq-0"
                })(["width:28px;height:28px;"]),
                Go = K.ZP.div.withConfig({
                    displayName: "NextRewardCard__Row",
                    componentId: "sc-waamqq-1"
                })(["display:flex;justify-content:flex-start;align-items:center;gap:var(--atlas-space-mini);margin-bottom:var(--atlas-space-small);"]),
                $o = K.ZP.div.withConfig({
                    displayName: "NextRewardCard__Column",
                    componentId: "sc-waamqq-2"
                })(["display:flex;flex-direction:column;"]),
                Yo = () => {
                    var e, t, a, n, l;
                    const {
                        t: i
                    } = (0, b.ql)(), {
                        setIsOpen: o
                    } = h(), {
                        loyaltyClient: s
                    } = R(), {
                        data: c,
                        isLoading: d
                    } = zn(), {
                        data: m,
                        isLoading: p
                    } = qn(), g = (0, u.rV)(), v = null != (e = null == m ? void 0 : m.pointsBalance) ? e : 0, E = s.getNextTier(v, c);
                    return d || p ? r().createElement(oa, {
                        size: "normal",
                        width: "75%"
                    }) : c && m && E ? r().createElement(We, {
                        onClick: () => {
                            var e;
                            o(!1), s.openPanel({
                                productId: null == E || null == (e = E.pointsProduct) ? void 0 : e.id
                            })
                        }
                    }, r().createElement($e, null, r().createElement(Go, null, (null == (t = E.pointsProduct) || null == (t = t.reward) ? void 0 : t.imageSvg) && r().createElement(Wo, {
                        src: s.getRewardImage(null == (a = E.pointsProduct) || null == (a = a.reward) ? void 0 : a.imageSvg, null == g || null == (n = g.button) ? void 0 : n.color),
                        alt: null == (l = E.pointsProduct) || null == (l = l.reward) ? void 0 : l.name
                    }), r().createElement($o, null, r().createElement(re.FJ, {
                        noSpacing: !0,
                        "data-testid": "loyalty-next-reward"
                    }, i("customerHub.loyalty.nextRewardAt", {
                        points: s.formatPoints(E.pointsPrice - v)
                    })), r().createElement(re.kd, {
                        noSpacing: !0,
                        "data-testid": "loyalty-next-reward-name"
                    }, E.name))), r().createElement($n, {
                        showNextTier: !0
                    }))) : null
                },
                Ko = (0, K.ZP)(ne.zx).withConfig({
                    displayName: "ReferralCard__CopyButton",
                    componentId: "sc-wg2gsy-0"
                })(["padding:0 var(--atlas-space-small);position:absolute;right:var(--atlas-space-mini);top:var(--atlas-space-tiny);color:var(--atlas-primary-color);"]),
                Jo = K.ZP.div.withConfig({
                    displayName: "ReferralCard__ReferralLink",
                    componentId: "sc-wg2gsy-1"
                })(["width:100%;position:relative;margin-top:var(--atlas-space-small);"]),
                Xo = (0, K.ZP)(it.o).withConfig({
                    displayName: "ReferralCard__ReferralInput",
                    componentId: "sc-wg2gsy-2"
                })(["width:100%;padding-right:var(--atlas-space-medium);padding-top:var(--atlas-space-small);padding-bottom:var(--atlas-space-small);line-height:var(--atlas-font-size-normal);text-align:center;padding-right:36px;opacity:0.8;"]),
                Qo = () => {
                    var e;
                    const {
                        t: t
                    } = (0, b.ql)(), a = (0, Ya.p)(), {
                        data: l,
                        isLoading: i
                    } = qn(), o = (0, n.useRef)(null), s = null != (e = null == l ? void 0 : l.referralUrl) ? e : "";
                    return i ? r().createElement(We, null, r().createElement($e, null, r().createElement(oa, {
                        width: "50%"
                    }), r().createElement(oa, {
                        size: "small",
                        width: "40%"
                    }))) : l && l.referralUrl ? r().createElement(We, null, r().createElement($e, null, r().createElement(re.kd, {
                        noSpacing: !0,
                        bold: !0
                    }, t("customerHub.loyalty.referYourFriends")), r().createElement(re.TB, null, t("customerHub.loyalty.referralLink")), r().createElement(Jo, null, r().createElement(Xo, {
                        value: s,
                        readOnly: !0,
                        "data-testid": "loyalty-referral-link",
                        ref: o,
                        onClick: () => {
                            var e;
                            o.current && (null == (e = o.current) || e.select())
                        }
                    }), r().createElement(Ko, {
                        "data-testid": "loyalty-referral-copy-button",
                        variant: "icon",
                        "aria-label": t("customerHub.coupons.copyToClipboard"),
                        onClick: () => {
                            navigator.clipboard.writeText(s), a({
                                label: t("customerHub.loyalty.toast.copiedToClipboard")
                            })
                        }
                    }, r().createElement(Q.TI, null))))) : null
                },
                es = () => {
                    const {
                        t: e
                    } = (0, b.ql)(), {
                        loyaltyClient: t
                    } = R(), {
                        setIsOpen: a
                    } = h();
                    return r().createElement(kn, {
                        testId: "loyalty-ways-to-earn",
                        title: e("customerHub.loyalty.waysToEarn"),
                        onClick: () => {
                            a(!1), t.openPanel({
                                page: "points_activity_rules"
                            })
                        }
                    })
                },
                ts = K.ZP.img.withConfig({
                    displayName: "RewardListItem__RewardImage",
                    componentId: "sc-hdsh8u-0"
                })(["width:28px;height:28px;"]),
                as = ({
                    imageUrl: e,
                    title: t,
                    description: a,
                    action: n
                }) => r().createElement(Da, {
                    disableGutters: !0
                }, e && r().createElement(Ua, null, r().createElement(ts, {
                    src: e,
                    role: "presentation"
                })), r().createElement(Ba, null, r().createElement(re.kd, {
                    noSpacing: !0
                }, t), r().createElement(re.TB, {
                    noSpacing: !0
                }, a)), n && r().createElement(Fa, null, n)),
                ns = K.ZP.div.withConfig({
                    displayName: "EligibleRewardsList__Container",
                    componentId: "sc-10fe4n4-0"
                })(["display:flex;flex-direction:column;"]),
                rs = (0, K.ZP)(Ae).withConfig({
                    displayName: "EligibleRewardsList__Header",
                    componentId: "sc-10fe4n4-1"
                })(["padding:var(--atlas-space-small) 0;"]),
                ls = () => {
                    var e;
                    const {
                        t: t
                    } = (0, b.ql)(), {
                        loyaltyClient: a
                    } = R(), l = (0, u.rV)(), {
                        navigate: i
                    } = (0, o.et)(), {
                        data: s,
                        isLoading: c
                    } = zn(), {
                        data: d,
                        isLoading: m
                    } = qn(), p = null != (e = null == d ? void 0 : d.pointsBalance) ? e : 0, g = (0, n.useMemo)((() => s ? s.filter((e => e.pointsPrice <= p)) : []), [s, p]);
                    return c || m ? r().createElement(oa, {
                        size: "normal",
                        width: "75%"
                    }) : !s || !d || g.length < 1 ? null : r().createElement(ns, null, r().createElement(rs, null, t("customerHub.loyalty.redeemYouPoints")), r().createElement(Oa, null, g.map((e => {
                        var n, o, s, c;
                        return r().createElement(as, {
                            key: e.pointsProduct.id,
                            imageUrl: a.getRewardImage(null != (n = null == (o = e.pointsProduct) || null == (o = o.reward) ? void 0 : o.imageSvg) ? n : "", null == l || null == (s = l.button) ? void 0 : s.color),
                            title: null != (c = e.name) ? c : "",
                            description: a.formatPoints(e.pointsPrice),
                            action: r().createElement(ne.zx, {
                                variant: "primary",
                                onClick: () => {
                                    i(`/rewards/redeem/${e.pointsProduct.id}`)
                                }
                            }, t("customerHub.loyalty.viewReward"))
                        })
                    }))))
                },
                is = () => {
                    const {
                        t: e
                    } = (0, b.ql)(), {
                        loyaltyClient: t
                    } = R(), {
                        setIsOpen: a
                    } = h();
                    return r().createElement(kn, {
                        title: e("customerHub.loyalty.checkCurrentRewards"),
                        onClick: () => {
                            a(!1), t.openPanel()
                        }
                    })
                },
                os = K.ZP.div.withConfig({
                    displayName: "RewardsPage__Column",
                    componentId: "sc-1m967hk-0"
                })(["display:flex;flex-direction:column;gap:var(--atlas-space-tiny);"]),
                ss = K.ZP.div.withConfig({
                    displayName: "RewardsPage__TopSection",
                    componentId: "sc-1m967hk-1"
                })(["display:flex;padding:var(--atlas-space-medium) var(--atlas-space-medium) var(--atlas-space-huge) var(--atlas-space-medium);flex-direction:column;gap:var(--atlas-space-jumbo);"]),
                cs = K.ZP.div.withConfig({
                    displayName: "RewardsPage__PointsHeadline",
                    componentId: "sc-1m967hk-2"
                })(["display:flex;flex-direction:row;align-items:flex-end;gap:var(--atlas-space-tiny);"]),
                ds = (0, K.ZP)(re.Rk).withConfig({
                    displayName: "RewardsPage__InlineDisplayText",
                    componentId: "sc-1m967hk-3"
                })(["line-height:var(--atlas-font-size-display);"]),
                us = (0, K.ZP)(Bn).withConfig({
                    displayName: "RewardsPage__BottomSection",
                    componentId: "sc-1m967hk-4"
                })(["display:flex;flex:1;padding:var(--atlas-space-large) var(--atlas-space-medium) var(--atlas-space-jumbo) var(--atlas-space-medium);flex-direction:column;gap:var(--atlas-space-jumbo);"]),
                ms = () => {
                    var e;
                    const {
                        data: t,
                        isLoading: a
                    } = qn(), n = null != (e = null == t ? void 0 : t.pointsBalance) ? e : 0;
                    return a ? r().createElement(oa, {
                        size: "normal",
                        width: "75%"
                    }) : t ? r().createElement(Un, null, r().createElement(ss, null, r().createElement(os, null, r().createElement(Jn, null), r().createElement(cs, null, r().createElement(ds, {
                        noSpacing: !0
                    }, n), r().createElement(re.XJ, {
                        noSpacing: !0
                    }, 1 === n ? "point" : "points"))), r().createElement(Yo, null)), r().createElement(us, null, r().createElement(ls, null), r().createElement(is, null), r().createElement(es, null), r().createElement(Qo, null))) : null
                },
                ps = () => {
                    var e;
                    const {
                        t: t
                    } = (0, b.ql)();
                    w((() => t("customerHub.rewards.title")));
                    const a = (0, u.rV)();
                    (0, pe.E0)(!(null != a && null != (e = a.loyalty) && e.enabled));
                    const {
                        isInitialized: n
                    } = R();
                    return n ? r().createElement(ms, null) : r().createElement(oa, {
                        size: "normal",
                        width: "75%"
                    })
                };
            const gs = K.ZP.input.attrs((e => ({
                    className: (0, ee.A)("kl-hub-input-range", e.className)
                }))).withConfig({
                    displayName: "RangeInput",
                    componentId: "sc-rhcjmo-0"
                })(["width:100%;appearance:none;height:10px;border-radius:var(--atlas-loyalty-border-radius);background:var(--atlas-overlay-light);outline:none;transition:background 0.2s;cursor:pointer;&:hover{opacity:1;background:var(--atlas-overlay-medium);}&::-webkit-slider-thumb{-webkit-appearance:none;appearance:none;width:var(--atlas-range-input-thumb-size);height:var(--atlas-range-input-thumb-size);border-radius:50%;background:var(--atlas-range-input-thumb-background);border:var(--atlas-range-input-thumb-border);margin-top:-8px;}&::-moz-range-thumb{width:var(--atlas-range-input-thumb-size);height:var(--atlas-range-input-thumb-size);border-radius:50%;background:var(--atlas-range-input-thumb-background);border:var(--atlas-range-input-thumb-border);margin-top:-8px;}&::-moz-range-track{width:100%;height:10px;background:var(--atlas-range-input-background);border-radius:var(--atlas-loyalty-border-radius);}&::-webkit-slider-runnable-track{width:100%;height:10px;border-radius:var(--atlas-loyalty-border-radius);background:linear-gradient( to right,var(--atlas-button-primary) 0%,var(--atlas-button-primary) ", "%,var(--atlas-range-input-background) ", "%,var(--atlas-range-input-background) 100% );}&::-moz-range-progress{width:100%;height:10px;border-radius:var(--atlas-loyalty-border-radius);background:linear-gradient( to right,var(--atlas-button-primary) 0%,var(--atlas-button-primary) ", "%,var(--atlas-range-input-background) ", "%,var(--atlas-range-input-background) 100% );}"], (e => (e.value - e.min) / (e.max - e.min) * 100), (e => (e.value - e.min) / (e.max - e.min) * 100), (e => (e.value - e.min) / (e.max - e.min) * 100), (e => (e.value - e.min) / (e.max - e.min) * 100)),
                hs = (0, K.ZP)(re.FJ).withConfig({
                    displayName: "RedemptionCard__Label",
                    componentId: "sc-28xipl-0"
                })(["color:var(--atlas-button-primary);border-radius:var(--atlas-loyalty-border-radius);padding:var(--atlas-space-tiny);background-color:var(--atlas-empty-background);"]),
                vs = (0, K.ZP)($e).withConfig({
                    displayName: "RedemptionCard__CenteredCardContent",
                    componentId: "sc-28xipl-1"
                })(["display:flex;justify-content:center;align-items:center;flex-direction:column;gap:var(--atlas-space-medium);"]),
                Es = K.ZP.div.withConfig({
                    displayName: "RedemptionCard__Column",
                    componentId: "sc-28xipl-2"
                })(["display:flex;flex-direction:column;justify-content:center;align-items:center;"]),
                fs = K.ZP.img.withConfig({
                    displayName: "RedemptionCard__RewardImage",
                    componentId: "sc-28xipl-3"
                })(["width:30px;height:30px;"]),
                bs = (0, K.ZP)(re.TB).withConfig({
                    displayName: "RedemptionCard__RewardDescription",
                    componentId: "sc-28xipl-4"
                })(["text-align:center;"]),
                ys = () => {
                    const e = (0, u.rV)();
                    return r().createElement(Ge, {
                        shape: e.layout.shape
                    }, r().createElement(vs, null, r().createElement(oa, {
                        width: "50px"
                    }), r().createElement(Es, null, r().createElement(oa, {
                        size: "h2",
                        width: "200px"
                    })), r().createElement(oa, {
                        size: "small",
                        width: "175px"
                    }), r().createElement(oa, {
                        size: "small",
                        width: "150px"
                    }), r().createElement(ca, {
                        width: "100%"
                    })))
                },
                Cs = ({
                    onRedeem: e,
                    canRedeem: t,
                    reward: a
                }) => {
                    var l, i, o, s, c, d, m, p, g;
                    const {
                        t: h
                    } = (0, b.ql)(), {
                        loyaltyClient: v
                    } = R(), E = (0, u.rV)(), [f, y] = (0, n.useState)(a.pointsProduct.minimumPointsPrice), {
                        data: C
                    } = qn(), _ = null != (l = null == C ? void 0 : C.pointsBalance) ? l : 0;
                    return r().createElement(Ge, {
                        shape: E.layout.shape
                    }, r().createElement(vs, null, "variable" === a.pointsProduct.exchangeType ? r().createElement(hs, {
                        noSpacing: !0
                    }, null == (i = a.pointsProduct) ? void 0 : i.exchangeDescription) : r().createElement(hs, {
                        noSpacing: !0
                    }, v.formatPoints(a.pointsProduct.minimumPointsPrice)), r().createElement(Es, null, r().createElement(fs, {
                        src: v.getRewardImage(null != (o = null == (s = a.pointsProduct) || null == (s = s.reward) ? void 0 : s.imageSvg) ? o : "", null == E || null == (c = E.button) ? void 0 : c.color),
                        alt: null != (d = null == (m = a.pointsProduct) || null == (m = m.reward) ? void 0 : m.name) ? d : ""
                    }), r().createElement(re.kd, {
                        bold: !0,
                        noSpacing: !0
                    }, null == (p = a.pointsProduct) || null == (p = p.reward) ? void 0 : p.name)), r().createElement(bs, null, null == (g = a.pointsProduct) || null == (g = g.reward) ? void 0 : g.description), "variable" === a.pointsProduct.exchangeType && !!a.pointsProduct.variablePointsStepRewardValue && !!a.pointsProduct.variablePointsStep && r().createElement(r().Fragment, null, r().createElement(re.d9, null, h("customerHub.loyalty.rangeLabelPointsForReward", {
                        points: v.formatPoints(f),
                        reward: "$" + f * (a.pointsProduct.variablePointsStepRewardValue / a.pointsProduct.variablePointsStep)
                    })), r().createElement(gs, {
                        type: "range",
                        min: a.pointsProduct.minimumPointsPrice,
                        max: a.pointsProduct.variablePointsMax || Math.floor(_ / a.pointsProduct.variablePointsStep) * a.pointsProduct.variablePointsStep,
                        step: a.pointsProduct.variablePointsStep,
                        value: f,
                        onChange: e => y(Number(e.target.value))
                    })), t && r().createElement(ne.zx, {
                        full: !0,
                        variant: "primary",
                        onClick: () => "variable" === a.pointsProduct.exchangeType ? e({
                            points_to_spend: f
                        }) : e({})
                    }, h("customerHub.rewards.redeemButton"))))
                },
                _s = () => {
                    var e;
                    const {
                        t: t
                    } = (0, b.ql)(), {
                        rewardId: a
                    } = (0, pe.Qt)(), {
                        data: n,
                        isLoading: l
                    } = zn(), {
                        data: i,
                        isLoading: o
                    } = qn(), {
                        trigger: s
                    } = function() {
                        const {
                            loyaltyClient: e
                        } = R();
                        return (0, H.Z)(M.g.loyaltyPurchaseReward, ((t, {
                            arg: a
                        }) => e.purchaseReward(a.id, a.options)))
                    }(), c = (0, Ya.p)(), {
                        setIsOpen: d
                    } = h(), {
                        loyaltyClient: u
                    } = R(), m = null == n ? void 0 : n.find((e => e.pointsProduct.id.toString() === a));
                    if ((0, pe.E0)(!(l || o || m && i), {
                            path: "/rewards"
                        }), l || o) return r().createElement(Un, null, r().createElement(Bn, {
                        display: "flex",
                        flexDirection: "column",
                        gap: 20,
                        padding: 16
                    }, r().createElement(ys, null)));
                    if (!m || !i) return null;
                    const p = (null != (e = i.pointsBalance) ? e : 0) >= m.pointsPrice;
                    return r().createElement(Un, null, r().createElement(Bn, {
                        display: "flex",
                        flexDirection: "column",
                        gap: 20,
                        padding: 16
                    }, r().createElement(Cs, {
                        onRedeem: e => {
                            s({
                                id: m.pointsProduct.id,
                                options: e
                            }).then((() => {
                                d(!1), u.openPanel(), c({
                                    label: t("customerHub.loyalty.toast.purchasedReward"),
                                    variant: "success"
                                })
                            })).catch((() => {
                                c({
                                    label: t("customerHub.loyalty.toast.errorPurchasingReward"),
                                    variant: "error"
                                })
                            }))
                        },
                        canRedeem: p,
                        reward: m
                    })))
                },
                ws = () => {
                    var e;
                    const {
                        t: t
                    } = (0, b.ql)();
                    w((() => t("customerHub.redeem.title")));
                    const a = (0, u.rV)();
                    (0, pe.E0)(!(null != a && null != (e = a.loyalty) && e.enabled));
                    const {
                        isInitialized: n
                    } = R();
                    return n ? r().createElement(_s, null) : r().createElement(oa, {
                        size: "normal",
                        width: "75%"
                    })
                };

            function xs() {
                return (0, s.Dn)() ? null : (0, i.u)("/")
            }

            function Is() {
                return null
            }
            const ks = /^#kl?-hub(\/[\w/-]*)?/;
            const Ns = new c.K,
                Ts = new class {
                    async getCustomer() {
                        var e;
                        const t = await (null == (e = window.Smile) ? void 0 : e.fetchCustomer({
                            include: "vip_tier"
                        }));
                        return (0, d.k5)(t)
                    }
                    async getLoyaltyTiers() {
                        var e;
                        const t = await (null == (e = window.Smile) ? void 0 : e.fetchAllCustomerPointsProducts({
                            include: "reward,customer_points_products.points_product.reward.image_svg"
                        }));
                        return (0, d.k5)(t || [])
                    }
                    getNextTier(e, t = []) {
                        return t && t.filter((t => t.pointsPrice > e)).sort(((e, t) => (e.pointsPrice || e.pointsPrice) - (t.pointsPrice || t.pointsPrice)))[0] || null
                    }
                    getBestTier(e, t = []) {
                        return t && t.filter((t => t.pointsPrice <= e)).sort(((e, t) => (t.pointsPrice || t.pointsPrice) - (e.pointsPrice || e.pointsPrice)))[0] || null
                    }
                    openPanel(e) {
                        var t, a, n;
                        null != e && e.page ? null == (t = window.SmileUI) || t.openPanel({
                            deep_link: e.page
                        }) : null != e && e.productId ? null == (n = window.SmileUI) || n.openPanel({
                            deep_link: `points_product:${null==e?void 0:e.productId}`
                        }) : null == (a = window.SmileUI) || a.openPanel()
                    }
                    formatPoints(e, t = {}) {
                        return window.Smile.formatPoints(e, t)
                    }
                    getRewardImage(e, t = "#000000") {
                        return `${e}?color=${encodeURIComponent(t)}`
                    }
                    async purchaseReward(e, t) {
                        var a;
                        const n = await (null == (a = window.Smile) ? void 0 : a.purchasePointsProduct(e, t || {}));
                        return (0, d.k5)(n)
                    }
                },
                Ss = ({
                    settings: e
                }) => {
                    const t = function() {
                            const e = document.location.hash.match(ks);
                            var t;
                            return e && null != (t = e[1]) ? t : "/"
                        }(),
                        a = (0, n.useMemo)((() => function(e, t = !1) {
                            var a, n;
                            const l = t ? Is : xs;
                            return [{
                                component: t ? r().createElement(Po, null) : r().createElement(Pe, null),
                                children: [{
                                    component: r().createElement(zt, null),
                                    defaultData: {
                                        hideBackButton: !0
                                    },
                                    children: [{
                                        path: "/",
                                        component: r().createElement(or, null),
                                        defaultData: {
                                            transparentHeader: !0
                                        }
                                    }, {
                                        path: "/orders",
                                        component: r().createElement(gr, null)
                                    }, {
                                        path: "/chat",
                                        defaultData: {
                                            headerActions: [_r],
                                            hideBackButton: !(null != (a = e.faq) && a.enabled),
                                            defaultBackDestination: null != (n = e.faq) && n.enabled ? "/faq" : "/"
                                        },
                                        component: r().createElement(Ll, null)
                                    }, {
                                        path: "/faq",
                                        component: r().createElement(Vo, null)
                                    }, {
                                        path: "/profile",
                                        component: r().createElement(xt, null)
                                    }]
                                }, {
                                    path: "/orders/:orderId",
                                    loader: l,
                                    component: r().createElement(li, null)
                                }, {
                                    path: "/orderHelp-issue",
                                    component: r().createElement(ci, null)
                                }, {
                                    path: "/orderHelp-items",
                                    component: r().createElement(Ei, null)
                                }, {
                                    path: "/orderHelp-form",
                                    component: r().createElement(_i, null)
                                }, {
                                    path: "/recently-viewed",
                                    component: r().createElement(wi, null)
                                }, {
                                    path: "/wishlist",
                                    component: r().createElement(Ni, null)
                                }, {
                                    path: "/coupons",
                                    component: r().createElement(zi, null)
                                }, {
                                    path: "/rewards",
                                    component: r().createElement(ps, null),
                                    defaultData: {
                                        transparentHeader: !0
                                    }
                                }, {
                                    path: "/rewards/redeem/:rewardId",
                                    component: r().createElement(ws, null)
                                }, {
                                    path: "/auth",
                                    component: r().createElement(qi, null)
                                }, {
                                    path: "/checkOTP",
                                    component: r().createElement(Qi, null)
                                }, {
                                    path: "/smsConsent",
                                    defaultData: {
                                        hideBackButton: !0
                                    },
                                    loader: l,
                                    component: r().createElement(Ne, null)
                                }, {
                                    path: "/recommended-products",
                                    component: r().createElement(xi, null)
                                }, {
                                    path: "/profile/edit",
                                    loader: l,
                                    component: r().createElement(kt, null)
                                }]
                            }]
                        }(e)), [e]);
                    return r().createElement(u.mu, {
                        settings: e
                    }, r().createElement(E, null, r().createElement(f.Ho, null, r().createElement(o.IG, {
                        routes: a,
                        defaultPath: t
                    }, r().createElement(b._C, {
                        dictionary: y.e,
                        locale: "en-US"
                    }, r().createElement(x, null, r().createElement(I.k, null, r().createElement(S, null, r().createElement(Y, null, r().createElement(P.B, {
                        client: Ns
                    }, r().createElement(D, {
                        client: Ts
                    }, r().createElement(l.RB, null, r().createElement(lo, null), r().createElement(yo, null), r().createElement(wo, null), r().createElement(qe, null), r().createElement(o.lE, null)))))))))))))
                };

            function Ps(e) {
                return fetch(`${Nn.EA}/settings/${e}`, {
                    headers: {
                        "Content-Type": "application/json"
                    }
                }).then((e => e.json())).then(d.k5)
            }
        },
        66901: function(e, t, a) {
            a.d(t, {
                u: function() {
                    return r
                }
            });
            var n = a(76223);

            function r({
                controlledProp: e,
                uncontrolledProp: t
            }) {
                const a = (0, n.useRef)(void 0 !== e),
                    [r, l] = (0, n.useState)(t),
                    i = a.current ? e : r,
                    o = (0, n.useCallback)((e => {
                        a.current || l(e)
                    }), []);
                return (0, n.useMemo)((() => [i, o]), [o, i])
            }
        },
        99112: function(e, t, a) {
            a.d(t, {
                h: function() {
                    return r
                }
            });
            var n = a(76223);

            function r() {
                const [e, t] = (0, n.useState)({
                    width: 0,
                    height: 0
                }), a = (0, n.useRef)(null);
                return (0, n.useEffect)((() => {
                    if (!a.current) return () => {};
                    const e = new ResizeObserver((e => {
                        const {
                            width: a,
                            height: n
                        } = e[0].target.getBoundingClientRect();
                        t({
                            width: a,
                            height: n
                        })
                    }));
                    return e.observe(a.current), () => {
                        e.disconnect()
                    }
                }), []), {
                    measurementRef: a,
                    dimensions: e
                }
            }
        },
        16269: function(e, t, a) {
            a.d(t, {
                Q: function() {
                    return r
                },
                u: function() {
                    return l
                }
            });
            a(92461), a(70818);

            function n(e, t) {
                const a = ["/"].concat(e.split("/").filter((e => "" !== e))),
                    n = ["/"].concat(t.split("/").filter((e => "" !== e)));
                if (a.length !== n.length) return;
                const r = {};
                for (let e = 0; e < a.length; e += 1)
                    if (a[e].startsWith(":")) {
                        r[a[e].split(":")[1]] = n[e]
                    } else if (!a[e].startsWith(":") && a[e] !== n[e]) return;
                return r
            }

            function r(e, t, a = "") {
                let l = a;
                for (const i of e) {
                    if (i.path && (l = a + i.path), i.children) {
                        const e = r(i.children, t, l);
                        if (e) return {
                            routes: [i, ...e.routes],
                            pathData: e.pathData
                        }
                    }
                    const e = n(l, t);
                    if (e) return {
                        routes: [i],
                        pathData: e
                    }
                }
            }

            function l(e) {
                return {
                    path: e
                }
            }
        },
        65595: function(e, t, a) {
            a.d(t, {
                IG: function() {
                    return g
                },
                et: function() {
                    return c
                },
                k: function() {
                    return m
                },
                lE: function() {
                    return p
                }
            });
            a(26650);
            var n = a(76223),
                r = a.n(n),
                l = a(16269),
                i = a(72737),
                o = a(51573);
            const s = (0, n.createContext)(void 0);

            function c() {
                const e = (0, n.useContext)(s);
                if (!e) throw new Error("useSimpleRouter: No SimpleRouterProvider found.");
                return e
            }
            const d = (0, n.createContext)(0);

            function u() {
                return (0, n.useContext)(d)
            }
            const m = ({
                    children: e
                }) => {
                    const t = u();
                    return r().createElement(d.Provider, {
                        value: t + 1
                    }, e)
                },
                p = () => {
                    var e;
                    const t = u(),
                        {
                            routes: a,
                            activePath: r,
                            activeData: o,
                            redirect: s
                        } = c(),
                        d = (0, n.useMemo)((() => (0, l.Q)(a, r)), [a, r]),
                        m = null == d ? void 0 : d.routes[t],
                        p = null == m ? void 0 : m.loader,
                        [g, h] = (0, n.useState)(!p),
                        v = (0, i.$)((() => {
                            if (p) {
                                const e = p({
                                    path: r,
                                    data: o
                                });
                                e && s(e.path), h(!0)
                            }
                        }));
                    return (0, n.useEffect)((() => {
                        v()
                    }), [v]), g && null != (e = null == m ? void 0 : m.component) ? e : null
                };
            const g = ({
                routes: e,
                defaultPath: t,
                children: a,
                defaultData: l
            }) => {
                const [i, c] = (0, n.useState)((() => t)), [d, u] = (0, n.useState)(l), [m, g] = (0, n.useState)([{
                    activePath: i
                }]), [h, v] = (0, n.useState)(0), E = (0, n.useRef)(!1), f = (0, o.U_)(), b = (0, n.useMemo)((() => {
                    const t = e => {
                        c(e), f || function(e) {
                            window.history.replaceState(void 0, "", `${window.location.pathname}${window.location.search}#k-hub${e}`)
                        }(e)
                    };
                    return {
                        routes: e,
                        activePath: i,
                        activeData: d,
                        navigate: (e, a) => {
                            t(e), u(a), g((t => [...t.slice(0, h + 1), {
                                activePath: e,
                                activeData: a
                            }])), E.current = !1, v(h + 1)
                        },
                        back: () => {
                            if (0 !== h) {
                                const {
                                    activePath: e,
                                    activeData: a
                                } = m[h - 1];
                                t(e), u(a), E.current = !1, v(h - 1)
                            }
                        },
                        canGoBack: 0 !== h,
                        replace: (e, a) => {
                            t(e), u(a), E.current = !1, g((t => [...t.slice(0, h), {
                                activePath: e,
                                activeData: a
                            }]))
                        },
                        redirect: (e, a = {}, n) => {
                            if (!E.current || n) {
                                let n, r;
                                null != d && d.previousPath ? (n = d.previousPath, r = d.previousData) : (n = i, r = d), E.current = !0, t(e), u(Object.assign({}, a, {
                                    previousPath: n,
                                    previousData: r
                                })), g((t => [...t.slice(0, h), {
                                    activePath: e,
                                    activeData: a
                                }]))
                            }
                        }
                    }
                }), [e, d, i, h, m, f]);
                return r().createElement(s.Provider, {
                    value: b
                }, a || r().createElement(p, null))
            }
        },
        22950: function(e, t, a) {
            a.d(t, {
                E0: function() {
                    return s
                },
                HJ: function() {
                    return o
                },
                Qt: function() {
                    return c
                },
                rM: function() {
                    return i
                }
            });
            a(26650), a(92461), a(44159), a(83362);
            var n = a(76223),
                r = a(16269),
                l = a(65595);

            function i() {
                const {
                    activePath: e
                } = (0, l.et)();
                return e
            }

            function o() {
                const {
                    navigate: e,
                    back: t,
                    replace: a,
                    redirect: n,
                    canGoBack: r
                } = (0, l.et)();
                return {
                    navigate: e,
                    back: t,
                    replace: a,
                    redirect: n,
                    canGoBack: r
                }
            }

            function s(e, {
                path: t = "/",
                method: a = "replace"
            } = {}) {
                const {
                    redirect: r,
                    replace: l
                } = o();
                (0, n.useEffect)((() => {
                    e && ("redirect" === a ? r(t) : l(t))
                }), [e, t, r, l, a])
            }

            function c() {
                const {
                    activeData: e
                } = (0, l.et)(), t = function() {
                    const {
                        routes: e,
                        activePath: t
                    } = (0, l.et)();
                    return (0, n.useMemo)((() => (0, r.Q)(e, t)), [e, t])
                }();
                return (0, n.useMemo)((() => {
                    const a = null == t ? void 0 : t.routes.reduce(((e, t) => (t.defaultData && Object.entries(t.defaultData).forEach((([t, a]) => {
                        e[t] = a
                    })), e)), {});
                    return Object.assign({}, a, null == t ? void 0 : t.pathData, e)
                }), [null == t ? void 0 : t.routes, null == t ? void 0 : t.pathData, e])
            }
        },
        50664: function(e, t, a) {
            function n(e) {
                return e instanceof HTMLElement
            }

            function r(e, t) {
                return t === e && n(e.firstElementChild) ? e.firstElementChild : t && n(t.nextElementSibling) ? t.nextElementSibling : n(e.firstElementChild) ? e.firstElementChild : null
            }

            function l(e, t) {
                return t === e && n(e.lastElementChild) ? e.lastElementChild : t && n(t.previousElementSibling) ? t.previousElementSibling : n(e.lastElementChild) ? e.lastElementChild : null
            }

            function i(e, t, a) {
                let n = a(e, t),
                    r = !1;
                for (; n;) {
                    if (n === e.firstElementChild) {
                        if (r) return !1;
                        r = !0
                    }
                    if (!("true" === n.getAttribute("aria-disabled"))) return n.focus(), !0;
                    n = a(e, n)
                }
                return !1
            }
            a.d(t, {
                Ds: function() {
                    return o
                },
                UU: function() {
                    return l
                },
                pr: function() {
                    return i
                },
                vi: function() {
                    return r
                }
            });
            const o = (e, t, a, n) => {
                const {
                    key: r
                } = e;
                t || " " !== r && "ArrowUp" !== r && "ArrowDown" !== r || (a(!0), n(!0))
            }
        },
        93579: function(e, t, a) {
            a.d(t, {
                IS: function() {
                    return r
                },
                cm: function() {
                    return l
                },
                hn: function() {
                    return n
                }
            });
            let n = function(e) {
                return e[e.createdAtDesc = 0] = "createdAtDesc", e[e.ratingDesc = 1] = "ratingDesc", e[e.ratingAsc = 2] = "ratingAsc", e[e.mostRelevant = 3] = "mostRelevant", e
            }({});
            const r = ["widgetMargin", "primaryBackgroundColor", "secondaryBackgroundColor", "accentColor", "cornerRadius", "divisionLines", "primaryFont", "primaryFontColor", "secondaryFont", "secondaryFontColor", "buttonColor", "buttonCornerRadius", "buttonBorder", "buttonHoverColor", "buttonInnerPadding", "buttonFont", "buttonFontColor", "starColor", "emptyStarColor", "starBorder", "starShape", "starSize", "starSpacing", "summaryStarSize", "reviewStarSize", "filterCornerRadius", "filterBackgroundColor", "filterShowSearchIcon", "filterPlaceholderTextColor", "summaryImagesCornerRadius", "reviewImagesCornerRadius", "reviewImagesSize", "featuredReviewsPerPage", "featuredTextLimit", "featuredImageSize", "filterButtonBackgroundColor", "filterButtonBorderWidth", "filterButtonBorderColor", "filterButtonCornerRadius", "filterButtonFont", "filterButtonFontColor", "filterButtonLetterSpacing", "featuredCarouselHeadlineGap", "featuredCarouselHeadlineAlignment", "textAlignment", "contentAlignment", "showFeaturedCarouselDate", "showFeaturedCarouselUsername", "showFeaturedCarouselVerifiedBadge", "headlinePrimaryFont", "headlineFontColor", "cardColor", "cardShadow", "cardBorderColor", "cardBorderWidth", "carouselBackgroundColor", "featuredImageFit", "reviewTitleFont", "reviewTitleFontColor"],
                l = e => r.includes(e)
        },
        58352: function(e, t, a) {
            a.d(t, {
                Z: function() {
                    return g
                }
            });
            var n = a(87789),
                r = a.n(n),
                l = (a(19986), a(92461), a(70818), a(44159), a(60873), a(60624), a(75479), a(93579)),
                i = a(13529);
            var o = {
                getCustomerSettingsUrl: `${i.bl.reviewsUrl}/api/client_onsite_widgets/`,
                getReviewsUrl: `${i.bl.reviewsUrl}/api/client_reviews/`,
                getFeaturedReviewsUrl: `${i.bl.reviewsUrl}/api/featured_reviews/`,
                getReviewRequestUrl: `${i.bl.reviewSubmissionUrl}/api/review_request`
            };
            const s = ["product", "products", "reviews", "summary", "variant_counts"],
                {
                    getCustomerSettingsUrl: c,
                    getReviewsUrl: d,
                    getFeaturedReviewsUrl: u,
                    getReviewRequestUrl: m
                } = o;

            function p(e, t, a) {
                const n = new Map;
                null == t || t.forEach((e => {
                    n.set(e.external_id, e)
                })), a && n.set(a.external_id, a);
                return e.map((e => {
                    let t = "product" in e ? e.product : void 0;
                    var a;
                    t || (t = n.get(null != (a = e.product_external_id) ? a : "invalid_id"));
                    return Object.assign({}, e, {
                        product: t
                    })
                }))
            }
            var g = {
                getCustomerSettings: (e, t) => {
                    const a = t ? `&lang=${t}` : "";
                    return fetch(`${c}?company_id=${encodeURI(e)}${a}`).then((e => e.json()))
                },
                getReviewsForProduct: async ({
                    productId: e,
                    reviewUuid: t = "",
                    limit: a = 30,
                    offset: n = 0,
                    sort: i = l.hn.mostRelevant,
                    filter: o = "",
                    type: c = "reviews",
                    subtype: u = null,
                    media: m = !1,
                    rating: g,
                    customQuestions: h,
                    companyId: v,
                    variantId: E,
                    preferredCountry: f
                }) => {
                    var b, y;
                    let C;
                    try {
                        const t = await fetch(`${d}${encodeURI(e)}/grouped_id/?company_id=${v}`),
                            {
                                grouped_id: a
                            } = await t.json();
                        if ("string" != typeof a) throw new Error("Invalid grouped_id");
                        C = a
                    } catch (t) {
                        C = e
                    }
                    const _ = new URLSearchParams({
                        product_id: C,
                        company_id: v,
                        limit: String(a),
                        offset: String(n),
                        sort: String(i),
                        filter: o,
                        type: c,
                        media: String(m),
                        kl_review_uuid: t
                    });
                    g && _.append("rating", String(g)), h && _.append("custom_questions", JSON.stringify(h)), u && _.append("subtype", u), E && _.append("variant_id", E);
                    const w = null == (b = document.querySelector('meta[property="og:country"]')) ? void 0 : b.getAttribute("content");
                    (f || w) && _.append("preferred_country", f || w || "");
                    const x = null == (y = window) || null == (y = y.Intl) || null == (y = y.DateTimeFormat()) || null == (y = y.resolvedOptions()) ? void 0 : y.timeZone;
                    x && _.append("tz", x);
                    const I = await fetch(`${d}${encodeURI(C)}/?${_.toString()}`),
                        k = await I.json(),
                        {
                            product: N,
                            products: T,
                            reviews: S,
                            summary: P,
                            variant_counts: O
                        } = k,
                        R = r()(k, s),
                        D = p(S, T, N);
                    return Object.assign({}, R, {
                        product: N,
                        summary: Object.assign({}, P, {
                            product_id: e
                        }),
                        reviews: D,
                        variant_counts: O
                    })
                },
                getReviews: ({
                    companyId: e,
                    productIds: t = []
                }) => fetch(`${d}?company_id=${encodeURI(e)}&products=${encodeURI(JSON.stringify(t))}`).then((e => e.json())),
                getFeaturedReviews: async ({
                    companyId: e
                }) => {
                    const t = await fetch(`${u}?company_id=${encodeURI(e)}`),
                        {
                            reviews: a,
                            products: n
                        } = await t.json();
                    return {
                        reviews: p(a, n)
                    }
                },
                getReviewRequest: ({
                    id: e,
                    rating: t
                }) => fetch(`${m}/${e}/?rating=${t}`).then((e => e.json())).then((e => Object.assign({}, {
                    is_email_known: !1
                }, e))),
                submitReview: ({
                    id: e,
                    body: t
                }) => fetch(`${m}/${e}/`, {
                    method: "PUT",
                    headers: {
                        "Content-Type": "application/json"
                    },
                    body: t
                }).then((e => e.json())),
                deleteReview: ({
                    id: e
                }) => fetch(`${m}/${e}/`, {
                    method: "DELETE",
                    headers: {
                        "Content-Type": "application/json"
                    }
                }).then((e => e.json())),
                getReviewRequestInformation: ({
                    originalReviewRequestKey: e,
                    productExternalId: t,
                    rating: a,
                    productVariantExternalId: n
                }) => fetch(`${m}/multiple_product_review_request/`, {
                    method: "POST",
                    headers: {
                        "Content-Type": "application/json"
                    },
                    body: JSON.stringify({
                        original_review_request_key: e,
                        product_external_id: t,
                        product_variant_external_id: n,
                        rating: a
                    })
                }).then((e => e.json())).then((e => Object.assign({}, {
                    is_email_known: !1
                }, e))),
                createStoreReviewRequest: ({
                    originalReviewRequestKey: e
                }) => fetch(`${m}/store_review_request/`, {
                    method: "POST",
                    headers: {
                        "Content-Type": "application/json"
                    },
                    body: JSON.stringify({
                        original_review_request_key: e
                    })
                }).then((e => e.json())).then((e => Object.assign({}, {
                    is_email_known: !1,
                    customer_reviewed_store: !1
                }, e)))
            }
        }
    }
]);