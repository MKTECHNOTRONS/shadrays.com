(function() {
    function bxBootstrap() {
        var re = /bot|crawl|slurp|spider|mediapartners|headlesschrome|snap-prefetch|remotasks|woorank|uptime\.com|facebookexternalhit|facebookcatalog/i;
        if (re.test(navigator.userAgent) || navigator.userAgent == '') {
            return;
        }

        if (!(window.bouncex && bouncex.website)) {
            var pushedData = [];
            if (window.bouncex && bouncex.push && bouncex.length) {
                pushedData = bouncex;
            }
            window.bouncex = {};
            bouncex.pushedData = pushedData;
            bouncex.website = {
                "id": 4853,
                "name": "Shady Rays",
                "cookie_name": "bounceClientVisit4853",
                "domain": "shadyrays.com",
                "ct": "fp_local_storage",
                "ally": 0,
                "ei": 0,
                "tcjs": "",
                "cjs": "",
                "force_https": false,
                "waypoints": false,
                "content_width": 900,
                "gai": "UA-44163708-1",
                "swids": "",
                "sd": 0,
                "ljq": "auto",
                "campaign_id": 0,
                "is_preview": false,
                "aco": {
                    "first_party_limit": "3500",
                    "local_storage": "1"
                },
                "cmp": {
                    "gdpr": 0,
                    "gmp": 0,
                    "whitelist_check": 0
                },
                "burls": [],
                "ple": false,
                "fbe": true,
                "ffs": "",
                "mas": 2,
                "map": 1,
                "gar": true,
                "ete": 1,
                "ettm": false,
                "etjs": "\r\n/* ---------------------------- SHARED VARIABLES ---------------------------- */\r\n\r\nvar CART_COOKIE_KEY = 'cart';\r\n\r\n/* --------------------------------- HELPERS -------------------------------- */\r\n\r\nfunction getUrl() {\r\n    return bouncex.utils.url.allowParams();\r\n}\r\n\r\nfunction setVarAndCookie(varName, value) {\r\n    bouncex.setVar(varName, value);\r\n    bouncex.setBounceCookie();\r\n}\r\n\r\nfunction getItemId(url) {\r\n    return url ? url.split('/').pop() : '';\r\n}\r\n\r\nfunction getItemImage() {\r\n    if (jQuery('.product-media img, .color-dots-container, .color-dot-container').length > 0) {\r\n        var hrefMinusScheme = jQuery('.product-media img').eq(0).attr('src').split('?')[0] || jQuery('[data-image-order=1]:visible').attr('src');\r\n        if (hrefMinusScheme) {\r\n            if(hrefMinusScheme.indexOf('http') > -1){\r\n                return hrefMinusScheme;\r\n            }\r\n\r\n            return 'https:' + hrefMinusScheme;\r\n        }\r\n\r\n    }\r\n    if(jQuery('.custom-checkbox[data-url]:checked').length > 0){\r\n        return 'https:' + jQuery('.custom-checkbox[data-url]:checked').attr('data-images')\r\n    }\r\n    return jQuery('meta[property=\"og:image\"]').attr('content').split('?')[0] || '';\r\n}\r\n\r\nfunction getCopy(){\r\n\r\n    var headline = jQuery('.headline-text').first().text().replace(/\\s+/g, ' ').replace(/™/, '').trim();\r\n    var name = jQuery('[itemprop=\"name\"]').first().text().replace(/\\s+/g, ' ').trim();\r\n\r\n    if(headline !== '' && name !== ''){\r\n        return headline + ' ' + name;\r\n    }\r\n    \r\n    if (jQuery('.custom-checkbox[data-url]:checked').length > 0){\r\n        return jQuery('.custom-checkbox[data-url]:checked').attr('data-title').trim()\r\n    }\r\n    return  bouncex.vars.prod_name || jQuery('.cs-sign').text();\r\n}\r\n\r\nfunction isExludedProduct() {\r\n   return getUrl().includes('apex-polarized')\r\n}\r\n\r\n\r\n\r\n/* ------------------------------ ITEM TRACKING ----------------------------- */\r\n\r\nfunction getItem() {\r\n    var itemUrl = getUrl();\r\n\r\n    return {\r\n        id: getItemId(itemUrl),\r\n        copy: getCopy(),\r\n        category: bouncex.utils.getNestedProp('ShopifyAnalytics.meta.product.type').length ? bouncex.utils.getNestedProp('ShopifyAnalytics.meta.product.type') : 'global',\r\n        url: itemUrl,\r\n        imageurl: getItemImage(),\r\n        price: bouncex.vars.prod_price,\r\n        instock: bouncex.vars.in_stock\r\n        \r\n    };\r\n}\r\n\r\nfunction isExcluded(item) {\r\n    return item.url.indexOf('gift-card') > -1;\r\n}\r\n\r\nfunction initializeItemEvents() {\r\n    var item;\r\n\r\n    bouncex.et.onTrue(function() {\r\n        item = getItem();\r\n\r\n        return  !!item.id &&\r\n                !!item.copy &&\r\n                !!item.category &&\r\n                !!item.url &&\r\n                !!item.imageurl;\r\n        },function() {\r\n\r\n            if (isExcluded(item)) {\r\n                return;\r\n            }\r\n\r\n            bouncex.push(['item', item]);\r\n            bouncex.push(['view item', {'item:id':item.id}]);\r\n            initializeATCClickTracking(item.id);\r\n            initializePrescriptionATCClickTracking(item.id)\r\n\r\n        },10);\r\n}\r\n\r\n/* ---------------------------- CATEGORY TRACKING --------------------------- */\r\n\r\nfunction getItemIdsCat() {\r\n    var ids = [],\r\n        $tiles = jQuery('.product-block a, .type-explore a.btn, .flip-card a, .sg-frame-type a, .exp-frontier-col a, .section-sr-product-card a, .gw-tile-image a, .products-container .product-img-block a, .inner-collection .product-title a:visible, #product-loop .product-name a:visible, .product-details a:visible, .product-title a:visible, .sr-product-grid-col a'),\r\n        i = 0,\r\n        id = '';\r\n\r\n    for (i; i < $tiles.length; i++ ) {\r\n        id = (function() {\r\n            return getItemId(bouncex.utils.url.allowParams('', jQuery($tiles[i]).attr('href')));\r\n        })();\r\n\r\n        if (!id || ids.indexOf(id) > -1 || id.indexOf('automated-replacement') > -1) {\r\n            continue;\r\n        }\r\n\r\n        ids[ids.length] = id;\r\n    }\r\n\r\n    return ids.join(',');\r\n}\r\n\r\nfunction getCategoryObject() {\r\n    return {\r\n        'page:url': getUrl(),\r\n        'items:ids': getItemIdsCat()\r\n    };\r\n}\r\n\r\nfunction initializeCategoryEvents() {\r\n    var categoryObj;\r\n\r\n    if (bouncex.website.pts === 'category'){\r\n        bouncex.et.onTrue(\r\n            function() {\r\n                categoryObj = getCategoryObject();\r\n                return !!categoryObj['items:ids'].length &&\r\n                        !!categoryObj['page:url'];\r\n            },\r\n            function() {\r\n                bouncex.push(['view category', categoryObj]);\r\n            },\r\n            10\r\n        );\r\n    }\r\n}\r\n\r\n/* ------------------------------- CART EVENTS ------------------------------ */\r\n\r\nfunction fireAddToCart(itemId) {\r\n    var token;\r\n\r\n    bouncex.et.onTrue(\r\n        function() {\r\n            token = bouncex.getBounceCookie(CART_COOKIE_KEY);\r\n            return token;\r\n        },\r\n        function() {\r\n            bouncex.push([\r\n                'add to cart',\r\n                {\r\n                    'item:id': itemId,\r\n                    'cart:token': token\r\n                }\r\n            ]);\r\n\r\n            if (bouncex.vars.cart) {\r\n                return;\r\n            }\r\n\r\n            setVarAndCookie('cart', true);\r\n        },\r\n        10\r\n    );\r\n}\r\n\r\nfunction initializeCategoryATCTracking(){\r\n\r\n    bouncex.et.on(jQuery(\".btns-blocks .btn-snow-pack\"), 'click.bxatc', function(){\r\n        var itemId = jQuery(this).siblings(\".btn-view-pack\").eq(0).attr(\"data-handle\")\r\n        fireAddToCart(itemId);\r\n    });\r\n}\r\n\r\n/* function initializeATCClickTracking(itemId) {\r\n    bouncex.et.on(jQuery('#AddToCart, .add.common-btn_green'), 'click.bxatc', function(){\r\n        fireAddToCart(itemId);\r\n    });\r\n\r\n    return;\r\n} */\r\n\r\n/* function initializeATCClickTracking(itemId) {\r\n    bouncex.et.onVisible('#AddToCart, [type=\"submit\"].add.common-btn_green', function(){\r\n\tbouncex.et.on(jQuery('#AddToCart, [type=\"submit\"].add.common-btn_green'), 'click.bxatc', function () {\r\n        fireAddToCart(itemId);\r\n    });\r\n    });\r\n} */\r\n\r\n/* function initializeATCClickTracking(itemId){\r\n    bouncex.et.onVarChange('cart_qty', function(oldVal, newVal){\r\n        if (newVal > oldVal) {\r\n                fireAddToCart(itemId);\r\n\r\n        }\r\n    });\r\n} */\r\n\r\nfunction AtcButtonClick() {\r\n    bouncex.et.onVisible('#AddToCart, [type=\"submit\"].add.common-btn_green,.add-to-cart[name=\"add\"]', function(){\r\n\tbouncex.et.on(jQuery('#AddToCart, [type=\"submit\"].add.common-btn_green,.add-to-cart[name=\"add\"]'), 'click.bxatc', function () {\r\n        return true;\r\n    });\r\n    });\r\n}\r\nfunction CartQtyChange(itemId){\r\n    bouncex.et.onVarChange('cart_qty', function(oldVal, newVal){\r\n        if (newVal > oldVal) {\r\n            return fireAddToCart(itemId);\r\n        }\r\n    });\r\n}\r\n\r\nfunction initializeATCClickTracking(itemId){\r\n    AtcButtonClick() ? fireAddToCart(itemId) : CartQtyChange(itemId);\r\n}\r\n\r\nfunction initializePrescriptionATCClickTracking(itemId){\r\n    \r\n    bouncex.et.on(jQuery(\"#AddToCart\"), 'click.bxatc', function () {\r\n        if(jQuery(\".eye-upload.selected\").length){\r\n            fireAddToCart(itemId);\r\n        }\r\n    });\r\n}\r\n\r\nfunction emptyCart() {\r\n    if (jQuery(\".cart-drawer__empty-content:not('.cart-drawer__empty-content--hidden')\").length\r\n&& bouncex.vars.cart_qty === 0){\r\n        bouncex.push(['empty_cart']);\r\n        setVarAndCookie('cart', false);\r\n    }\r\n}\r\n\r\nfunction initializeCartEvents() {\r\n    bouncex.et.cart.init({\r\n        replenishmentType: 'cookie',\r\n        replenish: function(cart) {\r\n            bouncex.utils.cookies.create({\r\n                name: CART_COOKIE_KEY,\r\n                value: cart.token\r\n            });\r\n            replenComplete();\r\n\r\n        }\r\n    });\r\n\r\n    function replenComplete() {\r\n        window.location.href = window.location.origin +\r\n                               window.location.pathname +\r\n                               '?bx_replen=true';\r\n    }\r\n    \r\n    bouncex.et.onVarChange('cart_qty',  emptyCart);\r\n}\r\n\r\n/* ------------------------------ USER TRACKING ----------------------------- */\r\n\r\nfunction getUserEmail() {\r\n    var websiteData = bouncex.utils.getNestedProp('dataLayer'),\r\n        i = 0;\r\n\r\n    for (i; i < websiteData.length; i++){\r\n        if (websiteData[i].emailAddress){\r\n            return websiteData[i].emailAddress;\r\n        }\r\n    }\r\n\r\n    return '';\r\n}\r\n\r\nfunction initializeUserTracking() {\r\n    var userEmail;\r\n\r\n    if (!bouncex.vars.logged_in || !!bouncex.vars.logged_in_identified) {\r\n        return;\r\n    }\r\n\r\n    userEmail = getUserEmail();\r\n\r\n    if (!bouncex.utils.validate.email(userEmail)) {\r\n        return;\r\n    }\r\n\r\n    bouncex.push([\r\n        'user',\r\n        {\r\n            'email': userEmail,\r\n            'source': 'LoggedIn'\r\n        }\r\n    ]);\r\n    setVarAndCookie('logged_in_identified', true);\r\n}\r\n\r\n/* --------------------------- INITIALIZE TRACKING -------------------------- */\r\n\r\nfunction isValidDomain() {\r\n    return getUrl().indexOf('shadyrays.com') > -1;\r\n}\r\n\r\nfunction isEn() {\r\n    return jQuery('html').attr('lang') === 'en';\r\n}\r\n\r\nfunction isValidForTracking() {\r\n    return isValidDomain() && isEn() && !isExludedProduct();\r\n}\r\n\r\nfunction init() {\r\n    if (!isValidForTracking()) {\r\n        return;\r\n    }\r\n    \r\n    initializeUserTracking();\r\n    initializeCartEvents();\r\n\r\n    switch(bouncex.website.pts) {\r\n        case 'category':\r\n            initializeCategoryEvents();\r\n            initializeCategoryATCTracking();\r\n            break;\r\n        case 'product':\r\n            initializeItemEvents();\r\n            break;\r\n        default:\r\n            break;\r\n    }\r\n\r\n\r\n}\r\n\r\nbouncex.setTimeout2(init, 1000);",
                "dge": true,
                "bxidLoadFirst": false,
                "pie": true,
                "cme": true,
                "gbi_enabled": 0,
                "bpush": false,
                "pt": {
                    "cart": {
                        "testmode": true,
                        "val": [
                            [{
                                "activation": "current_page_url",
                                "prop": "contains",
                                "prop2": "",
                                "prop3": "",
                                "val": "/cart"
                            }]
                        ]
                    },
                    "category": {
                        "testmode": false,
                        "val": [
                            [{
                                "activation": "js",
                                "prop": "",
                                "prop2": "",
                                "prop3": "",
                                "val": "bouncex.utils.getNestedProp('ShopifyAnalytics.meta.page.pageType', '') === 'collection';"
                            }],
                            [{
                                "activation": "current_page_url",
                                "prop": "not_contains",
                                "prop2": "",
                                "prop3": "",
                                "val": "/gift-cards"
                            }]
                        ]
                    },
                    "checkout": {
                        "testmode": true,
                        "val": [
                            [{
                                "activation": "current_page_url",
                                "prop": "contains",
                                "prop2": "",
                                "prop3": "",
                                "val": "/checkouts/"
                            }]
                        ]
                    },
                    "home": {
                        "testmode": false,
                        "val": [
                            [{
                                "activation": "js",
                                "prop": "",
                                "prop2": "",
                                "prop3": "",
                                "val": "bouncex.utils.getNestedProp('ShopifyAnalytics.meta.page.pageType', '') === 'home';"
                            }],
                            [{
                                "activation": "current_page_url",
                                "prop": "not_contains",
                                "prop2": "",
                                "prop3": "",
                                "val": "shopifypreview.com"
                            }]
                        ]
                    },
                    "product": {
                        "testmode": false,
                        "val": [
                            [{
                                "activation": "js",
                                "prop": "",
                                "prop2": "",
                                "prop3": "",
                                "val": "bouncex.utils.getNestedProp('ShopifyAnalytics.meta.page.pageType', '') === 'product';"
                            }],
                            [{
                                "activation": "current_page_url",
                                "prop": "not_contains",
                                "prop2": "",
                                "prop3": "",
                                "val": "gift-card"
                            }]
                        ]
                    },
                    "search": {
                        "testmode": false,
                        "val": [
                            [{
                                "activation": "current_page_url",
                                "prop": "contains",
                                "prop2": "",
                                "prop3": "",
                                "val": "search?q="
                            }]
                        ]
                    }
                },
                "els": {
                    "blank_site_element": "",
                    "skip_link": "[data-acsb]:has(+ #badge-modal-outer)",
                    "top_bar_signup": ".summer-bogo-topbar a"
                },
                "vars": [{
                    "name": "logged_in",
                    "polling": "none",
                    "persist": "no",
                    "page_types": [],
                    "testmode": false,
                    "default": "false",
                    "code": "!!bouncex.utils.getNestedProp('__st.cid', false);",
                    "trigger": ""
                }, {
                    "name": "ever_logged_in",
                    "polling": "none",
                    "persist": "permanent",
                    "page_types": [],
                    "testmode": false,
                    "default": "false",
                    "code": "bouncex.vars.logged_in || null;",
                    "trigger": ""
                }, {
                    "name": "cart_qty",
                    "polling": "all",
                    "persist": "visit",
                    "page_types": [],
                    "testmode": false,
                    "default": "0",
                    "code": "window.location.pathname.indexOf('/checkout') >- 1 ? null : Number(jQuery('.cart-link__count').text().replace(/[^0-9.]/g, ''));",
                    "trigger": ""
                }, {
                    "name": "cart_value",
                    "polling": "all",
                    "persist": "visit",
                    "page_types": [],
                    "testmode": false,
                    "default": "0",
                    "code": "bouncex.website.pts === 'cart' && jQuery('#shopping-cart').text().indexOf('empty') > -1 ? 0 : Number(jQuery('.subtotal').first().text().replace(/[^0-9.]/g, '')) || null;",
                    "trigger": ""
                }, {
                    "name": "prod_price",
                    "polling": "all",
                    "persist": "no",
                    "page_types": ["product"],
                    "testmode": false,
                    "default": "false",
                    "code": "jQuery('[property=\"og:price:amount\"]').attr('content') || jQuery('.money').first().text().replace(/[^0-9.]/g, '') || '0';",
                    "trigger": ""
                }, {
                    "name": "prod_name",
                    "polling": "all",
                    "persist": "no",
                    "page_types": ["product"],
                    "testmode": false,
                    "default": "false",
                    "code": "(function(){\n    if (jQuery('#product-description .review-section').length > 0){\n        return jQuery('#product-description .review-section').text().split('$')[0].trim();\n    } else if (window.location.href.indexOf('/custom-snow-goggles') > -1){\n        return 'custom snow goggles'  \n    }else if ( jQuery('meta[property=\"og:title\"]').length > 0 ){\n        return jQuery('meta[property=\"og:title\"]').attr('content');\n    } else if (jQuery('#AddToCart[value=\"Add To Cart\"]').length > 0 || jQuery('.common-btn_green').length > 0) {\n        return jQuery('#product-main-container #product-name-mob .section-title span').text().split('Sold Out')[0].trim() + ' ' + jQuery('#product-main-container #product-name-mob .section-title .top-sign').text().trim();\n    }\n    else {\n        return jQuery('#product-name-mob .section-title .top-sign').text().trim() || '';\n    }\n})();",
                    "trigger": ""
                }, {
                    "name": "in_stock",
                    "polling": "all",
                    "persist": "no",
                    "page_types": ["product"],
                    "testmode": false,
                    "default": "false",
                    "code": "jQuery('[data-add-to-cart-text=\"Add to cart\"]:visible').length > 0;",
                    "trigger": ""
                }, {
                    "name": "submitted_onsite",
                    "polling": "all",
                    "persist": "permanent",
                    "page_types": [],
                    "testmode": false,
                    "default": "false",
                    "code": "jQuery('.connect-section .klaviyo-form:contains(\"start sending news and offers to your inbox\")').length > 0 || null;",
                    "trigger": ""
                }, {
                    "name": "page_url",
                    "polling": "none",
                    "persist": "no",
                    "page_types": ["category", "search"],
                    "testmode": true,
                    "default": "false",
                    "code": "",
                    "trigger": ""
                }, {
                    "name": "cart_token",
                    "polling": "none",
                    "persist": "no",
                    "page_types": [],
                    "testmode": true,
                    "default": "false",
                    "code": "null;",
                    "trigger": "pageload"
                }, {
                    "name": "cart_items",
                    "polling": "none",
                    "persist": "no",
                    "page_types": [],
                    "testmode": true,
                    "default": "false",
                    "code": "null;",
                    "trigger": "pageload"
                }, {
                    "name": "cart",
                    "polling": "none",
                    "persist": "permanent",
                    "page_types": [],
                    "testmode": false,
                    "default": "false",
                    "code": "null;",
                    "trigger": "pageload"
                }, {
                    "name": "cookie_modal_present",
                    "polling": "all",
                    "persist": "no",
                    "page_types": [],
                    "testmode": true,
                    "default": "false",
                    "code": "null;",
                    "trigger": "pageload"
                }, {
                    "name": "logged_in_identified",
                    "polling": "none",
                    "persist": "visit",
                    "page_types": [],
                    "testmode": false,
                    "default": "false",
                    "code": "null;",
                    "trigger": "pageload"
                }, {
                    "name": "current_url",
                    "polling": "all",
                    "persist": "no",
                    "page_types": ["category", "product"],
                    "testmode": false,
                    "default": "false",
                    "code": "bouncex.utils.url.allowParams();",
                    "trigger": "pageload"
                }, {
                    "name": "ktest",
                    "polling": "none",
                    "persist": "no",
                    "page_types": [],
                    "testmode": false,
                    "default": "false",
                    "code": "_learnq.isIdentified();",
                    "trigger": "pageload"
                }],
                "dgu": "pixel.cdnwidget.com",
                "dgp": false,
                "ba": {
                    "enabled": 0,
                    "fbte": 0
                },
                "biu": "assets.bounceexchange.com",
                "bau": "api.bounceexchange.com",
                "beu": "events.bouncex.net",
                "ibx": {
                    "tjs": "",
                    "cjs": "",
                    "miw": 0,
                    "mibcx": 1,
                    "te": 1,
                    "cart_rep": {
                        "get": "",
                        "set": ""
                    },
                    "ulpj": {
                        "bxid": "espemailid"
                    },
                    "cus": "",
                    "miw_exclude": "",
                    "enabled": 1
                },
                "etjson": null,
                "osre": true,
                "osru": "osr.bounceexchange.com/v1/osr/items",
                "checkDfp": false,
                "gamNetwork": "",
                "spa": 1,
                "spatm": 0,
                "preinit_cjs": "",
                "crs": {
                    "integrations": null,
                    "pageCount": null
                },
                "mat": 0,
                "math": 0,
                "cpnu": "coupons.bounceexchange.com",
                "dfpcms": 0,
                "sms": {
                    "optm": "",
                    "eventSharing": false,
                    "shqId": "",
                    "enabled": 0
                },
                "pde": true,
                "fmc": ["US"],
                "fme": true,
                "fmx": "",
                "uid2": false,
                "sdk": {
                    "android": {
                        "enabled": false,
                        "enabledVersions": [],
                        "eventModifications": null
                    },
                    "ios": {
                        "enabled": false,
                        "enabledVersions": [],
                        "eventModifications": null
                    }
                },
                "onsite": {
                    "enabled": 1
                },
                "ads": {
                    "enabled": 0
                },
                "pubs": {
                    "enabled": 0
                },
                "websdk": {
                    "enabled": 0,
                    "devMode": 0
                },
                "ga4_property_id": "308043128",
                "ga4_measurement_id": "G-HYCEJP1Y7M",
                "tag_state_domain": "api.bounceexchange.com",
                "tag_state_domain_enabled": false
            };

            bouncex.tag = 'tag3';
            bouncex.$ = window.jQuery;
            bouncex.env = 'production';
            bouncex.restrictedTlds = {
                "casl": {
                    "ca": 1
                },
                "gdpr": {
                    "ad": 1,
                    "al": 1,
                    "at": 1,
                    "ax": 1,
                    "ba": 1,
                    "be": 1,
                    "bg": 1,
                    "by": 1,
                    "xn--90ais": 1,
                    "ch": 1,
                    "cy": 1,
                    "cz": 1,
                    "de": 1,
                    "dk": 1,
                    "ee": 1,
                    "es": 1,
                    "eu": 1,
                    "fi": 1,
                    "fo": 1,
                    "fr": 1,
                    "uk": 1,
                    "gb": 1,
                    "gg": 1,
                    "gi": 1,
                    "gr": 1,
                    "hr": 1,
                    "hu": 1,
                    "ie": 1,
                    "im": 1,
                    "is": 1,
                    "it": 1,
                    "je": 1,
                    "li": 1,
                    "lt": 1,
                    "lu": 1,
                    "lv": 1,
                    "mc": 1,
                    "md": 1,
                    "me": 1,
                    "mk": 1,
                    "xn--d1al": 1,
                    "mt": 1,
                    "nl": 1,
                    "no": 1,
                    "pl": 1,
                    "pt": 1,
                    "ro": 1,
                    "rs": 1,
                    "xn--90a3ac": 1,
                    "ru": 1,
                    "su": 1,
                    "xn--p1ai": 1,
                    "se": 1,
                    "si": 1,
                    "sj": 1,
                    "sk": 1,
                    "sm": 1,
                    "ua": 1,
                    "xn--j1amh": 1,
                    "va": 1,
                    "tr": 1
                }
            };
            bouncex.client = {
                supportsBrotli: 1
            };
            bouncex.assets = {
                "ads": "646cf096aae730e1484b6de87539a9af",
                "creativesBaseStyles": "a53944a2",
                "gpsAuction": "bbb80866120d17013073bb6d284cbd6b",
                "inbox": "a17aab65d5ec0e7dbba07712663f933e",
                "onsite": "c05f8c5551fa6b964660ad61916291c1",
                "sms": "e39203556bab2366e56296ce42e974a7",
                "websdk": "9c2817e65e803cb8c86d0410c88f20c1",
                "website_campaigns_4853": "380b2da3c487cfc9442d7eb1e021cf85"
            };
            bouncex.push = function(pushData) {
                bouncex.pushedData.push(pushData);
            }

            var runtime = document.createElement('script');
            runtime.setAttribute('src', '//assets.bounceexchange.com/assets/smart-tag/versioned/runtime_c81e76ee00d795b1eebf8d27949f8dc5.br.js');
            runtime.setAttribute('async', 'async');

            bouncex.initializeTag = function() {
                var script = document.createElement('script');
                script.setAttribute('src', '//assets.bounceexchange.com/assets/smart-tag/versioned/main-v2_0cd81115cd0e8b6360bb6ba2359ae191.br.js');
                script.setAttribute('async', 'async');
                document.body.appendChild(script);


                var deviceGraphScript = document.createElement('script');
                deviceGraphScript.setAttribute('src', '//assets.bounceexchange.com/assets/smart-tag/versioned/cjs_min_23e9fb6eac44d2bdee89ffde48eb6611.js');
                deviceGraphScript.setAttribute('async', 'async');
                var dgAttrs = [{
                    "Key": "id",
                    "Value": "c.js"
                }, {
                    "Key": "async",
                    "Value": "true"
                }, {
                    "Key": "data-apikey",
                    "Value": "2^HIykD"
                }, {
                    "Key": "data-cb",
                    "Value": "bouncex.dg.initPostDeviceGraph"
                }, {
                    "Key": "data-bx",
                    "Value": "1"
                }, {
                    "Key": "data-gm",
                    "Value": "1"
                }, {
                    "Key": "data-fire",
                    "Value": "1"
                }];
                if (dgAttrs) {
                    for (var i = 0; i < dgAttrs.length; i++) {
                        deviceGraphScript.setAttribute(dgAttrs[i].Key, dgAttrs[i].Value);
                    }
                }
                document.body.appendChild(deviceGraphScript);

                bouncex.initializeTag = function() {};
            };

            runtime.onload = bouncex.initializeTag;
            document.body.appendChild(runtime);

        }


    }

    if (document.readyState === "loading") {
        document.addEventListener("DOMContentLoaded", bxBootstrap);
    } else {
        bxBootstrap();
    }
})();