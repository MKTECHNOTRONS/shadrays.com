! function(t) {
    var e = {};

    function n(o) {
        if (e[o]) return e[o].exports;
        var r = e[o] = {
            i: o,
            l: !1,
            exports: {}
        };
        return t[o].call(r.exports, r, r.exports, n), r.l = !0, r.exports
    }
    n.m = t, n.c = e, n.d = function(t, e, o) {
        n.o(t, e) || Object.defineProperty(t, e, {
            enumerable: !0,
            get: o
        })
    }, n.r = function(t) {
        "undefined" != typeof Symbol && Symbol.toStringTag && Object.defineProperty(t, Symbol.toStringTag, {
            value: "Module"
        }), Object.defineProperty(t, "__esModule", {
            value: !0
        })
    }, n.t = function(t, e) {
        if (1 & e && (t = n(t)), 8 & e) return t;
        if (4 & e && "object" == typeof t && t && t.__esModule) return t;
        var o = Object.create(null);
        if (n.r(o), Object.defineProperty(o, "default", {
                enumerable: !0,
                value: t
            }), 2 & e && "string" != typeof t)
            for (var r in t) n.d(o, r, function(e) {
                return t[e]
            }.bind(null, r));
        return o
    }, n.n = function(t) {
        var e = t && t.__esModule ? function() {
            return t.default
        } : function() {
            return t
        };
        return n.d(e, "a", e), e
    }, n.o = function(t, e) {
        return Object.prototype.hasOwnProperty.call(t, e)
    }, n.p = "", n(n.s = 7)
}([function(t, e, n) {
    "use strict";
    n.r(e),
        function(t) {
            n.d(e, "__extends", function() {
                return r
            }), n.d(e, "__assign", function() {
                return i
            }), n.d(e, "__rest", function() {
                return s
            }), n.d(e, "__decorate", function() {
                return a
            }), n.d(e, "__param", function() {
                return u
            }), n.d(e, "__metadata", function() {
                return c
            }), n.d(e, "__awaiter", function() {
                return l
            }), n.d(e, "__generator", function() {
                return d
            }), n.d(e, "__exportStar", function() {
                return f
            }), n.d(e, "__values", function() {
                return p
            }), n.d(e, "__read", function() {
                return h
            }), n.d(e, "__spread", function() {
                return y
            }), n.d(e, "__spreadArrays", function() {
                return v
            }), n.d(e, "__await", function() {
                return g
            }), n.d(e, "__asyncGenerator", function() {
                return m
            }), n.d(e, "__asyncDelegator", function() {
                return _
            }), n.d(e, "__asyncValues", function() {
                return w
            }), n.d(e, "__makeTemplateObject", function() {
                return b
            }), n.d(e, "__importStar", function() {
                return S
            }), n.d(e, "__importDefault", function() {
                return E
            });
            /*! *****************************************************************************
            Copyright (c) Microsoft Corporation. All rights reserved.
            Licensed under the Apache License, Version 2.0 (the "License"); you may not use
            this file except in compliance with the License. You may obtain a copy of the
            License at http://www.apache.org/licenses/LICENSE-2.0

            THIS CODE IS PROVIDED ON AN *AS IS* BASIS, WITHOUT WARRANTIES OR CONDITIONS OF ANY
            KIND, EITHER EXPRESS OR IMPLIED, INCLUDING WITHOUT LIMITATION ANY IMPLIED
            WARRANTIES OR CONDITIONS OF TITLE, FITNESS FOR A PARTICULAR PURPOSE,
            MERCHANTABLITY OR NON-INFRINGEMENT.

            See the Apache Version 2.0 License for specific language governing permissions
            and limitations under the License.
            ***************************************************************************** */
            var o = function(t, e) {
                return (o = Object.setPrototypeOf || {
                        __proto__: []
                    }
                    instanceof Array && function(t, e) {
                        t.__proto__ = e
                    } || function(t, e) {
                        for (var n in e) e.hasOwnProperty(n) && (t[n] = e[n])
                    })(t, e)
            };

            function r(t, e) {
                function n() {
                    this.constructor = t
                }
                o(t, e), t.prototype = null === e ? Object.create(e) : (n.prototype = e.prototype, new n)
            }
            var i = function() {
                return (i = Object.assign || function(t) {
                    for (var e, n = 1, o = arguments.length; n < o; n++)
                        for (var r in e = arguments[n]) Object.prototype.hasOwnProperty.call(e, r) && (t[r] = e[r]);
                    return t
                }).apply(this, arguments)
            };

            function s(t, e) {
                var n = {};
                for (var o in t) Object.prototype.hasOwnProperty.call(t, o) && e.indexOf(o) < 0 && (n[o] = t[o]);
                if (null != t && "function" == typeof Object.getOwnPropertySymbols) {
                    var r = 0;
                    for (o = Object.getOwnPropertySymbols(t); r < o.length; r++) e.indexOf(o[r]) < 0 && Object.prototype.propertyIsEnumerable.call(t, o[r]) && (n[o[r]] = t[o[r]])
                }
                return n
            }

            function a(t, e, n, o) {
                var r, i = arguments.length,
                    s = i < 3 ? e : null === o ? o = Object.getOwnPropertyDescriptor(e, n) : o;
                if ("object" == typeof Reflect && "function" == typeof Reflect.decorate) s = Reflect.decorate(t, e, n, o);
                else
                    for (var a = t.length - 1; a >= 0; a--)(r = t[a]) && (s = (i < 3 ? r(s) : i > 3 ? r(e, n, s) : r(e, n)) || s);
                return i > 3 && s && Object.defineProperty(e, n, s), s
            }

            function u(t, e) {
                return function(n, o) {
                    e(n, o, t)
                }
            }

            function c(t, e) {
                if ("object" == typeof Reflect && "function" == typeof Reflect.metadata) return Reflect.metadata(t, e)
            }

            function l(e, n, o, r) {
                return new(o || (o = t))(function(t, i) {
                    function s(t) {
                        try {
                            u(r.next(t))
                        } catch (t) {
                            i(t)
                        }
                    }

                    function a(t) {
                        try {
                            u(r.throw(t))
                        } catch (t) {
                            i(t)
                        }
                    }

                    function u(e) {
                        e.done ? t(e.value) : new o(function(t) {
                            t(e.value)
                        }).then(s, a)
                    }
                    u((r = r.apply(e, n || [])).next())
                })
            }

            function d(t, e) {
                var n, o, r, i, s = {
                    label: 0,
                    sent: function() {
                        if (1 & r[0]) throw r[1];
                        return r[1]
                    },
                    trys: [],
                    ops: []
                };
                return i = {
                    next: a(0),
                    throw: a(1),
                    return: a(2)
                }, "function" == typeof Symbol && (i[Symbol.iterator] = function() {
                    return this
                }), i;

                function a(i) {
                    return function(a) {
                        return function(i) {
                            if (n) throw new TypeError("Generator is already executing.");
                            for (; s;) try {
                                if (n = 1, o && (r = 2 & i[0] ? o.return : i[0] ? o.throw || ((r = o.return) && r.call(o), 0) : o.next) && !(r = r.call(o, i[1])).done) return r;
                                switch (o = 0, r && (i = [2 & i[0], r.value]), i[0]) {
                                    case 0:
                                    case 1:
                                        r = i;
                                        break;
                                    case 4:
                                        return s.label++, {
                                            value: i[1],
                                            done: !1
                                        };
                                    case 5:
                                        s.label++, o = i[1], i = [0];
                                        continue;
                                    case 7:
                                        i = s.ops.pop(), s.trys.pop();
                                        continue;
                                    default:
                                        if (!(r = (r = s.trys).length > 0 && r[r.length - 1]) && (6 === i[0] || 2 === i[0])) {
                                            s = 0;
                                            continue
                                        }
                                        if (3 === i[0] && (!r || i[1] > r[0] && i[1] < r[3])) {
                                            s.label = i[1];
                                            break
                                        }
                                        if (6 === i[0] && s.label < r[1]) {
                                            s.label = r[1], r = i;
                                            break
                                        }
                                        if (r && s.label < r[2]) {
                                            s.label = r[2], s.ops.push(i);
                                            break
                                        }
                                        r[2] && s.ops.pop(), s.trys.pop();
                                        continue
                                }
                                i = e.call(t, s)
                            } catch (t) {
                                i = [6, t], o = 0
                            } finally {
                                n = r = 0
                            }
                            if (5 & i[0]) throw i[1];
                            return {
                                value: i[0] ? i[1] : void 0,
                                done: !0
                            }
                        }([i, a])
                    }
                }
            }

            function f(t, e) {
                for (var n in t) e.hasOwnProperty(n) || (e[n] = t[n])
            }

            function p(t) {
                var e = "function" == typeof Symbol && t[Symbol.iterator],
                    n = 0;
                return e ? e.call(t) : {
                    next: function() {
                        return t && n >= t.length && (t = void 0), {
                            value: t && t[n++],
                            done: !t
                        }
                    }
                }
            }

            function h(t, e) {
                var n = "function" == typeof Symbol && t[Symbol.iterator];
                if (!n) return t;
                var o, r, i = n.call(t),
                    s = [];
                try {
                    for (;
                        (void 0 === e || e-- > 0) && !(o = i.next()).done;) s.push(o.value)
                } catch (t) {
                    r = {
                        error: t
                    }
                } finally {
                    try {
                        o && !o.done && (n = i.return) && n.call(i)
                    } finally {
                        if (r) throw r.error
                    }
                }
                return s
            }

            function y() {
                for (var t = [], e = 0; e < arguments.length; e++) t = t.concat(h(arguments[e]));
                return t
            }

            function v() {
                for (var t = 0, e = 0, n = arguments.length; e < n; e++) t += arguments[e].length;
                var o = Array(t),
                    r = 0;
                for (e = 0; e < n; e++)
                    for (var i = arguments[e], s = 0, a = i.length; s < a; s++, r++) o[r] = i[s];
                return o
            }

            function g(t) {
                return this instanceof g ? (this.v = t, this) : new g(t)
            }

            function m(e, n, o) {
                if (!Symbol.asyncIterator) throw new TypeError("Symbol.asyncIterator is not defined.");
                var r, i = o.apply(e, n || []),
                    s = [];
                return r = {}, a("next"), a("throw"), a("return"), r[Symbol.asyncIterator] = function() {
                    return this
                }, r;

                function a(e) {
                    i[e] && (r[e] = function(n) {
                        return new t(function(t, o) {
                            s.push([e, n, t, o]) > 1 || u(e, n)
                        })
                    })
                }

                function u(e, n) {
                    try {
                        (o = i[e](n)).value instanceof g ? t.resolve(o.value.v).then(c, l) : d(s[0][2], o)
                    } catch (t) {
                        d(s[0][3], t)
                    }
                    var o
                }

                function c(t) {
                    u("next", t)
                }

                function l(t) {
                    u("throw", t)
                }

                function d(t, e) {
                    t(e), s.shift(), s.length && u(s[0][0], s[0][1])
                }
            }

            function _(t) {
                var e, n;
                return e = {}, o("next"), o("throw", function(t) {
                    throw t
                }), o("return"), e[Symbol.iterator] = function() {
                    return this
                }, e;

                function o(o, r) {
                    e[o] = t[o] ? function(e) {
                        return (n = !n) ? {
                            value: g(t[o](e)),
                            done: "return" === o
                        } : r ? r(e) : e
                    } : r
                }
            }

            function w(e) {
                if (!Symbol.asyncIterator) throw new TypeError("Symbol.asyncIterator is not defined.");
                var n, o = e[Symbol.asyncIterator];
                return o ? o.call(e) : (e = p(e), n = {}, r("next"), r("throw"), r("return"), n[Symbol.asyncIterator] = function() {
                    return this
                }, n);

                function r(o) {
                    n[o] = e[o] && function(n) {
                        return new t(function(r, i) {
                            (function(e, n, o, r) {
                                t.resolve(r).then(function(t) {
                                    e({
                                        value: t,
                                        done: o
                                    })
                                }, n)
                            })(r, i, (n = e[o](n)).done, n.value)
                        })
                    }
                }
            }

            function b(t, e) {
                return Object.defineProperty ? Object.defineProperty(t, "raw", {
                    value: e
                }) : t.raw = e, t
            }

            function S(t) {
                if (t && t.__esModule) return t;
                var e = {};
                if (null != t)
                    for (var n in t) Object.hasOwnProperty.call(t, n) && (e[n] = t[n]);
                return e.default = t, e
            }

            function E(t) {
                return t && t.__esModule ? t : {
                    default: t
                }
            }
        }.call(this, n(2).Promise)
}, function(t, e, n) {
    "use strict";
    Object.defineProperty(e, "__esModule", {
        value: !0
    });
    var o = function() {
        function t() {}
        return t.prototype.getQueryParams = function(t) {
            var e = t.location.search.substring(1),
                n = {};
            return e.split("&").forEach(function(t) {
                var e = t.split("="),
                    o = decodeURIComponent(e[0]).toLowerCase(),
                    r = decodeURIComponent(e.length > 1 ? e[1] : "");
                n[o] = r
            }), n
        }, t.prototype.isUrlMatchedByRegex = function(t, e) {
            var n = t.location.href;
            return new RegExp(e).test(n)
        }, t.prototype.isUrlDomainMatchedByRegex = function(t, e) {
            var n = t.location.hostname;
            return new RegExp(e).test(n)
        }, t.prototype.isQueryParamExists = function(t, e) {
            var n = this.getQueryParams(t);
            return e.some(function(t) {
                return n[t]
            })
        }, t
    }();
    e.default = new o
}, function(t, e, n) {
    (function(e, n) {
        /*!
         * @overview es6-promise - a tiny implementation of Promises/A+.
         * @copyright Copyright (c) 2014 Yehuda Katz, Tom Dale, Stefan Penner and contributors (Conversion to ES6 API by Jake Archibald)
         * @license   Licensed under MIT license
         *            See https://raw.githubusercontent.com/stefanpenner/es6-promise/master/LICENSE
         * @version   v4.2.8+1e68dce6
         */
        var o;
        o = function() {
            "use strict";

            function t(t) {
                return "function" == typeof t
            }
            var o = Array.isArray ? Array.isArray : function(t) {
                    return "[object Array]" === Object.prototype.toString.call(t)
                },
                r = 0,
                i = void 0,
                s = void 0,
                a = function(t, e) {
                    h[r] = t, h[r + 1] = e, 2 === (r += 2) && (s ? s(y) : w())
                },
                u = "undefined" != typeof window ? window : void 0,
                c = u || {},
                l = c.MutationObserver || c.WebKitMutationObserver,
                d = "undefined" == typeof self && void 0 !== e && "[object process]" === {}.toString.call(e),
                f = "undefined" != typeof Uint8ClampedArray && "undefined" != typeof importScripts && "undefined" != typeof MessageChannel;

            function p() {
                var t = setTimeout;
                return function() {
                    return t(y, 1)
                }
            }
            var h = new Array(1e3);

            function y() {
                for (var t = 0; t < r; t += 2) {
                    (0, h[t])(h[t + 1]), h[t] = void 0, h[t + 1] = void 0
                }
                r = 0
            }
            var v, g, m, _, w = void 0;

            function b(t, e) {
                var n = this,
                    o = new this.constructor(I);
                void 0 === o[E] && F(o);
                var r = n._state;
                if (r) {
                    var i = arguments[r - 1];
                    a(function() {
                        return D(r, o, i, n._result)
                    })
                } else T(n, o, t, e);
                return o
            }

            function S(t) {
                if (t && "object" == typeof t && t.constructor === this) return t;
                var e = new this(I);
                return W(e, t), e
            }
            d ? w = function() {
                return e.nextTick(y)
            } : l ? (g = 0, m = new l(y), _ = document.createTextNode(""), m.observe(_, {
                characterData: !0
            }), w = function() {
                _.data = g = ++g % 2
            }) : f ? ((v = new MessageChannel).port1.onmessage = y, w = function() {
                return v.port2.postMessage(0)
            }) : w = void 0 === u ? function() {
                try {
                    var t = Function("return this")().require("vertx");
                    return void 0 !== (i = t.runOnLoop || t.runOnContext) ? function() {
                        i(y)
                    } : p()
                } catch (t) {
                    return p()
                }
            }() : p();
            var E = Math.random().toString(36).substring(2);

            function I() {}
            var A = void 0,
                O = 1,
                C = 2;

            function j(e, n, o) {
                n.constructor === e.constructor && o === b && n.constructor.resolve === S ? function(t, e) {
                    e._state === O ? P(t, e._result) : e._state === C ? M(t, e._result) : T(e, void 0, function(e) {
                        return W(t, e)
                    }, function(e) {
                        return M(t, e)
                    })
                }(e, n) : void 0 === o ? P(e, n) : t(o) ? function(t, e, n) {
                    a(function(t) {
                        var o = !1,
                            r = function(t, e, n, o) {
                                try {
                                    t.call(e, n, o)
                                } catch (t) {
                                    return t
                                }
                            }(n, e, function(n) {
                                o || (o = !0, e !== n ? W(t, n) : P(t, n))
                            }, function(e) {
                                o || (o = !0, M(t, e))
                            }, t._label);
                        !o && r && (o = !0, M(t, r))
                    }, t)
                }(e, n, o) : P(e, n)
            }

            function W(t, e) {
                if (t === e) M(t, new TypeError("You cannot resolve a promise with itself"));
                else if (r = typeof(o = e), null === o || "object" !== r && "function" !== r) P(t, e);
                else {
                    var n = void 0;
                    try {
                        n = e.then
                    } catch (e) {
                        return void M(t, e)
                    }
                    j(t, e, n)
                }
                var o, r
            }

            function L(t) {
                t._onerror && t._onerror(t._result), R(t)
            }

            function P(t, e) {
                t._state === A && (t._result = e, t._state = O, 0 !== t._subscribers.length && a(R, t))
            }

            function M(t, e) {
                t._state === A && (t._state = C, t._result = e, a(L, t))
            }

            function T(t, e, n, o) {
                var r = t._subscribers,
                    i = r.length;
                t._onerror = null, r[i] = e, r[i + O] = n, r[i + C] = o, 0 === i && t._state && a(R, t)
            }

            function R(t) {
                var e = t._subscribers,
                    n = t._state;
                if (0 !== e.length) {
                    for (var o = void 0, r = void 0, i = t._result, s = 0; s < e.length; s += 3) o = e[s], r = e[s + n], o ? D(n, o, r, i) : r(i);
                    t._subscribers.length = 0
                }
            }

            function D(e, n, o, r) {
                var i = t(o),
                    s = void 0,
                    a = void 0,
                    u = !0;
                if (i) {
                    try {
                        s = o(r)
                    } catch (t) {
                        u = !1, a = t
                    }
                    if (n === s) return void M(n, new TypeError("A promises callback cannot return that same promise."))
                } else s = r;
                n._state !== A || (i && u ? W(n, s) : !1 === u ? M(n, a) : e === O ? P(n, s) : e === C && M(n, s))
            }
            var x = 0;

            function F(t) {
                t[E] = x++, t._state = void 0, t._result = void 0, t._subscribers = []
            }
            var k = function() {
                    function t(t, e) {
                        this._instanceConstructor = t, this.promise = new t(I), this.promise[E] || F(this.promise), o(e) ? (this.length = e.length, this._remaining = e.length, this._result = new Array(this.length), 0 === this.length ? P(this.promise, this._result) : (this.length = this.length || 0, this._enumerate(e), 0 === this._remaining && P(this.promise, this._result))) : M(this.promise, new Error("Array Methods must be provided an Array"))
                    }
                    return t.prototype._enumerate = function(t) {
                        for (var e = 0; this._state === A && e < t.length; e++) this._eachEntry(t[e], e)
                    }, t.prototype._eachEntry = function(t, e) {
                        var n = this._instanceConstructor,
                            o = n.resolve;
                        if (o === S) {
                            var r = void 0,
                                i = void 0,
                                s = !1;
                            try {
                                r = t.then
                            } catch (t) {
                                s = !0, i = t
                            }
                            if (r === b && t._state !== A) this._settledAt(t._state, e, t._result);
                            else if ("function" != typeof r) this._remaining--, this._result[e] = t;
                            else if (n === N) {
                                var a = new n(I);
                                s ? M(a, i) : j(a, t, r), this._willSettleAt(a, e)
                            } else this._willSettleAt(new n(function(e) {
                                return e(t)
                            }), e)
                        } else this._willSettleAt(o(t), e)
                    }, t.prototype._settledAt = function(t, e, n) {
                        var o = this.promise;
                        o._state === A && (this._remaining--, t === C ? M(o, n) : this._result[e] = n), 0 === this._remaining && P(o, this._result)
                    }, t.prototype._willSettleAt = function(t, e) {
                        var n = this;
                        T(t, void 0, function(t) {
                            return n._settledAt(O, e, t)
                        }, function(t) {
                            return n._settledAt(C, e, t)
                        })
                    }, t
                }(),
                N = function() {
                    function e(t) {
                        this[E] = x++, this._result = this._state = void 0, this._subscribers = [], I !== t && ("function" != typeof t && function() {
                            throw new TypeError("You must pass a resolver function as the first argument to the promise constructor")
                        }(), this instanceof e ? function(t, e) {
                            try {
                                e(function(e) {
                                    W(t, e)
                                }, function(e) {
                                    M(t, e)
                                })
                            } catch (e) {
                                M(t, e)
                            }
                        }(this, t) : function() {
                            throw new TypeError("Failed to construct 'Promise': Please use the 'new' operator, this object constructor cannot be called as a function.")
                        }())
                    }
                    return e.prototype.catch = function(t) {
                        return this.then(null, t)
                    }, e.prototype.finally = function(e) {
                        var n = this.constructor;
                        return t(e) ? this.then(function(t) {
                            return n.resolve(e()).then(function() {
                                return t
                            })
                        }, function(t) {
                            return n.resolve(e()).then(function() {
                                throw t
                            })
                        }) : this.then(e, e)
                    }, e
                }();
            return N.prototype.then = b, N.all = function(t) {
                return new k(this, t).promise
            }, N.race = function(t) {
                var e = this;
                return o(t) ? new e(function(n, o) {
                    for (var r = t.length, i = 0; i < r; i++) e.resolve(t[i]).then(n, o)
                }) : new e(function(t, e) {
                    return e(new TypeError("You must pass an array to race."))
                })
            }, N.resolve = S, N.reject = function(t) {
                var e = new this(I);
                return M(e, t), e
            }, N._setScheduler = function(t) {
                s = t
            }, N._setAsap = function(t) {
                a = t
            }, N._asap = a, N.polyfill = function() {
                var t = void 0;
                if (void 0 !== n) t = n;
                else if ("undefined" != typeof self) t = self;
                else try {
                    t = Function("return this")()
                } catch (t) {
                    throw new Error("polyfill failed because global object is unavailable in this environment")
                }
                var e = t.Promise;
                if (e) {
                    var o = null;
                    try {
                        o = Object.prototype.toString.call(e.resolve())
                    } catch (t) {}
                    if ("[object Promise]" === o && !e.cast) return
                }
                t.Promise = N
            }, N.Promise = N, N
        }, t.exports = o()
    }).call(this, n(8), n(9))
}, function(t, e, n) {
    "use strict";
    Object.defineProperty(e, "__esModule", {
        value: !0
    }), e.injectIntersectionObserverCSS = e.EMPTY_PLACEHOLDER_STYLE_RESET_CLASS = void 0, e.EMPTY_PLACEHOLDER_STYLE_RESET_CLASS = "yotpo-widget-empty-placeholder", e.injectIntersectionObserverCSS = function(t) {
        var n = t.createElement("style");
        n.innerHTML = "." + e.EMPTY_PLACEHOLDER_STYLE_RESET_CLASS + " { display: block!important; }", t.head.appendChild(n)
    }
}, function(t, e, n) {
    "use strict";
    Object.defineProperty(e, "__esModule", {
        value: !0
    });
    var o = n(0).__importDefault(n(1)),
        r = function() {
            function t() {}
            return t.prototype.get = function(t) {
                return localStorage.getItem(t)
            }, t.prototype.set = function(t, e) {
                localStorage.setItem(t, e)
            }, t.prototype.setOptionalQueryParamToLocalStorage = function(t, e) {
                var n = o.default.getQueryParams(t)[e];
                n && localStorage.setItem(e, n)
            }, t
        }();
    e.default = new r
}, function(t, e, n) {
    "use strict";
    Object.defineProperty(e, "__esModule", {
            value: !0
        }), e.LOADER_SCRIPT_FLAGS = e.PREVIEW_MODE_KEY = void 0, e.PREVIEW_MODE_KEY = "force-show-yotpo-widget",
        function(t) {
            t.IS_SCRIPTS_LOADED = "yotpo_widget_scripts_loaded", t.IS_SCRIPT_WITH_ALL_WIDGETS_LOADED = "yotpo_widget_scripts_with_all_widgets_loaded"
        }(e.LOADER_SCRIPT_FLAGS || (e.LOADER_SCRIPT_FLAGS = {}))
}, function(t, e, n) {
    "use strict";
    (function(t) {
        Object.defineProperty(e, "__esModule", {
            value: !0
        });
        var o = n(0),
            r = function() {
                function e() {
                    this.loadedResources = new Map, this.loadedResourcesCallbacks = new Map
                }
                return e.prototype.safeScriptInjection = function(e, n, r, i) {
                    var s = this,
                        a = this;
                    return new t(function(t) {
                        if (s.loadedResources.get(n)) {
                            var u = s.loadedResourcesCallbacks.get(n);
                            u ? s.loadedResourcesCallbacks.set(n, o.__spreadArrays(u, [t])) : t()
                        } else s.loadedResources.set(n, !0), s.loadedResourcesCallbacks.set(n, [t]), s.injectScript(e, n, function() {
                            var t = a.loadedResourcesCallbacks.get(n);
                            t && t.forEach(function(t) {
                                t()
                            }), a.loadedResourcesCallbacks.delete(n)
                        }, r, i || !1)
                    })
                }, e.prototype.injectScript = function(t, e, n, o, r) {
                    var i = t,
                        s = i.createElement("script");
                    if (s.onload = n, s.src = e, r && (s.type = "module"), o) {
                        var a = i.getElementsByTagName("script")[0];
                        a && a.parentNode ? a.parentNode.insertBefore(s, a) : i.head.appendChild(s)
                    } else s.async = !0, i.head.appendChild(s)
                }, e
            }();
        e.default = r
    }).call(this, n(2).Promise)
}, function(t, e, n) {
    "use strict";
    Object.defineProperty(e, "__esModule", {
        value: !0
    });
    var o = n(0),
        r = n(3),
        i = n(10),
        s = o.__importDefault(n(6)),
        a = o.__importDefault(n(13)),
        u = o.__importDefault(n(14)),
        c = o.__importDefault(n(15)),
        l = o.__importDefault(n(16)),
        d = n(17),
        f = o.__importDefault(n(19)),
        p = o.__importDefault(n(20)),
        h = o.__importDefault(n(22)),
        y = o.__importDefault(n(24)),
        v = o.__importDefault(n(25));
    "undefined" == typeof yotpoWidgetsContainer ? console.log("yotpoWidgetsContainer is not defined") : ("undefined" != typeof window && window.performance && window.performance.mark && window.performance.mark("yotpo:initializer:loaded"), r.injectIntersectionObserverCSS(document), yotpoWidgetsContainer.yotpo_widget_initializer = function(t) {
        var e = new a.default,
            n = new c.default(e, window),
            o = new s.default,
            r = new h.default,
            l = new u.default(o, r),
            d = new f.default,
            g = new p.default,
            m = new y.default(window),
            _ = new v.default(window, t.data.guid, yotpoWidgetsContainer);
        return new i.MerchantWidgetsInitializer(t, l, n, window, localStorage, yotpoWidgetsContainer, d, g, m, _)
    }, yotpoWidgetsContainer.yotpo_request_cache = yotpoWidgetsContainer.yotpo_request_cache || new l.default, yotpoWidgetsContainer.yotpo_script_injector = yotpoWidgetsContainer.yotpo_script_injector || new s.default, yotpoWidgetsContainer.safeScriptInjection = function(t, e, n) {
        yotpoWidgetsContainer.yotpo_script_injector.safeScriptInjection(t, e, n)
    }, d.getOrCreateEventBus())
}, function(t, e) {
    var n, o, r = t.exports = {};

    function i() {
        throw new Error("setTimeout has not been defined")
    }

    function s() {
        throw new Error("clearTimeout has not been defined")
    }

    function a(t) {
        if (n === setTimeout) return setTimeout(t, 0);
        if ((n === i || !n) && setTimeout) return n = setTimeout, setTimeout(t, 0);
        try {
            return n(t, 0)
        } catch (e) {
            try {
                return n.call(null, t, 0)
            } catch (e) {
                return n.call(this, t, 0)
            }
        }
    }! function() {
        try {
            n = "function" == typeof setTimeout ? setTimeout : i
        } catch (t) {
            n = i
        }
        try {
            o = "function" == typeof clearTimeout ? clearTimeout : s
        } catch (t) {
            o = s
        }
    }();
    var u, c = [],
        l = !1,
        d = -1;

    function f() {
        l && u && (l = !1, u.length ? c = u.concat(c) : d = -1, c.length && p())
    }

    function p() {
        if (!l) {
            var t = a(f);
            l = !0;
            for (var e = c.length; e;) {
                for (u = c, c = []; ++d < e;) u && u[d].run();
                d = -1, e = c.length
            }
            u = null, l = !1,
                function(t) {
                    if (o === clearTimeout) return clearTimeout(t);
                    if ((o === s || !o) && clearTimeout) return o = clearTimeout, clearTimeout(t);
                    try {
                        o(t)
                    } catch (e) {
                        try {
                            return o.call(null, t)
                        } catch (e) {
                            return o.call(this, t)
                        }
                    }
                }(t)
        }
    }

    function h(t, e) {
        this.fun = t, this.array = e
    }

    function y() {}
    r.nextTick = function(t) {
        var e = new Array(arguments.length - 1);
        if (arguments.length > 1)
            for (var n = 1; n < arguments.length; n++) e[n - 1] = arguments[n];
        c.push(new h(t, e)), 1 !== c.length || l || a(p)
    }, h.prototype.run = function() {
        this.fun.apply(null, this.array)
    }, r.title = "browser", r.browser = !0, r.env = {}, r.argv = [], r.version = "", r.versions = {}, r.on = y, r.addListener = y, r.once = y, r.off = y, r.removeListener = y, r.removeAllListeners = y, r.emit = y, r.prependListener = y, r.prependOnceListener = y, r.listeners = function(t) {
        return []
    }, r.binding = function(t) {
        throw new Error("process.binding is not supported")
    }, r.cwd = function() {
        return "/"
    }, r.chdir = function(t) {
        throw new Error("process.chdir is not supported")
    }, r.umask = function() {
        return 0
    }
}, function(t, e) {
    var n;
    n = function() {
        return this
    }();
    try {
        n = n || new Function("return this")()
    } catch (t) {
        "object" == typeof window && (n = window)
    }
    t.exports = n
}, function(t, e, n) {
    "use strict";
    (function(t) {
        Object.defineProperty(e, "__esModule", {
            value: !0
        }), e.MerchantWidgetsInitializer = void 0;
        var o = n(0),
            r = n(11),
            i = n(3),
            s = o.__importDefault(n(1)),
            a = (n(12), o.__importDefault(n(4))),
            u = n(5),
            c = function() {
                function e(t, e, n, o, r, i, s, a, u, c) {
                    this.widgetInstanceAttribute = "data-yotpo-instance-id", this.widgetInstanceClass = "yotpo-widget-instance", this.widgetInstanceCssSelector = "." + this.widgetInstanceClass, this.widgetElementStatusAttribute = "data-yotpo-element-loaded", this.uninitializedWidgetInstanceCssSelector = "." + this.widgetInstanceClass + ":not([" + this.widgetElementStatusAttribute + "])", this.lazyLoadCustomizationName = "should-lazy-load", this.shouldWatchMutationsAttribute = "should-watch-mutations", this.mutationSectionAttribute = "mutation-section-attribute", this.config = t, this.templateLoader = e, this.cssLoader = n, this.windowElement = o, this.documentElement = o.document, this.yotpoWidgetsContainer = i, this.storage = r, this.widgetV2ScriptInjector = s, this.widgetV2Converter = a, this.widgetConditionalLoading = u, this.previewModeHandler = c, this.initIntersectionObserver(), this.initMutationObserver()
                }
                return e.prototype.initWidgets = function(e) {
                    var n = this;
                    return void 0 === e && (e = !0), new t(function(t) {
                        n.runOnDomReady(function() {
                            var o = n.windowElement.location.hostname.includes(".yotpo.com");
                            if (o || n.upgradeStaticW2Widgets(n.documentElement), a.default.setOptionalQueryParamToLocalStorage(n.windowElement, u.PREVIEW_MODE_KEY), n.previewModeHandler.shouldInjectNewLoaderWithAllWidgets()) return n.previewModeHandler.injectLoaderWithAllWidgets(), t();
                            n.injectSelfExecutableWidgets(n.windowElement, n.documentElement, n.config.widgets);
                            var r = Array.from(n.locateAllWidgets(n.documentElement)),
                                i = n.config.data.guid;
                            r.forEach(function(t) {
                                n.initWidgetPlaceholder(t, e)
                            }), o || n.widgetV2ScriptInjector.injectOldWidgetScript(n.windowElement, i, n.yotpoWidgetsContainer), t()
                        })
                    })
                }, e.prototype.initWidgetPlaceholder = function(t, e) {
                    if (void 0 === e && (e = !0), this.shouldLazyLoadWidget(t)) this.addIntersectionObserver(t);
                    else if (this.shouldInitializeWidget(t, e)) {
                        var n = this.getWidgetId(t);
                        this.initWidget(n, t)
                    }
                }, e.prototype.initAddedWidgets = function() {
                    var t = this;
                    this.locateAllUnitializedWidgets(this.mutationContainer).forEach(function(e) {
                        t.shouldInjectWhenMutated(e) && t.initWidgetPlaceholder(e)
                    })
                }, e.prototype.initIntersectionObserver = function() {
                    if (this.windowElement.IntersectionObserver && !this.intersectionObserver) {
                        this.intersectionObserver = new IntersectionObserver(this.onIntersection.bind(this), {
                            rootMargin: "50px",
                            threshold: 0
                        })
                    }
                }, e.prototype.initMutationObserver = function() {
                    var t = this,
                        e = function() {
                            var n = t.config.widgets;
                            Object.values(n).some(function(e) {
                                return !!e.customizations[t.shouldWatchMutationsAttribute]
                            }) && (t.mutationContainer = t.documentElement.body, t.mutationObserver = new r.PageMutationObserver(t.windowElement, t.initAddedWidgets.bind(t)), t.mutationObserver.observe(t.mutationContainer)), t.windowElement.removeEventListener("load", e)
                        };
                    "complete" === this.windowElement.document.readyState ? e() : this.windowElement.addEventListener("load", e)
                }, e.prototype.onIntersection = function(t) {
                    var e = this;
                    t.forEach(function(t) {
                        var n = t.target,
                            o = t.isIntersecting,
                            r = t.boundingClientRect;
                        if (e.shouldInitializeWidget(n, !1)) {
                            var i = Object.values(r.toJSON()).every(function(t) {
                                return 0 == t
                            });
                            if (o || i) {
                                var s = e.getWidgetId(n);
                                e.initWidget(s, n), e.removeIntersectionObserver(n)
                            }
                        } else e.removeIntersectionObserver(n)
                    })
                }, e.prototype.initWidget = function(t, e) {
                    if (e) {
                        var n = this.config.data,
                            o = this.config.widgets,
                            r = this.config.guidStaticContent,
                            i = this.yotpoWidgetsContainer,
                            s = o[t];
                        if (s) {
                            s.instanceId = s.instanceId || t;
                            var a = [];
                            if (s.dependencyGroupId && !(a = this.config.dependencyGroups[s.dependencyGroupId])) return void console.log("cannot load widget " + s.instanceId + " because its dependency group is missing");
                            this.widgetConditionalLoading.shouldLoadWidget(s, this.previewModeHandler.isPreviewMode()) && this.loadWidget(this.windowElement, this.documentElement, e, s, n, this.storage, i, a, r)
                        }
                    }
                }, e.prototype.runOnDomReady = function(t) {
                    "loading" == this.documentElement.readyState ? this.documentElement.addEventListener("DOMContentLoaded", function() {
                        t()
                    }) : t()
                }, e.prototype.loadWidget = function(t, e, n, o, r, i, s, a, u) {
                    this.cssLoader.load(e, o.customizationCssUrl, o.instanceId), this.cssLoader.load(e, o.cssOverrideAssetUrl, o.instanceId), this.templateLoader.load(t, e, n, o, r, i, s, a, u), n.setAttribute(this.widgetElementStatusAttribute, "true")
                }, e.prototype.locateAllWidgets = function(t) {
                    return t.querySelectorAll(this.widgetInstanceCssSelector)
                }, e.prototype.locateAllUnitializedWidgets = function(t) {
                    return Array.from(t.querySelectorAll(this.uninitializedWidgetInstanceCssSelector))
                }, e.prototype.injectSelfExecutableWidgets = function(t, e, n) {
                    for (var o in n) {
                        var r = n[o];
                        r.staticContent && r.staticContent.selfExecutable && !this.isWidgetAlreadyInjected(t, o) && r.staticContent.urlMatch && s.default.isUrlMatchedByRegex(t, r.staticContent.urlMatch) && this.injectWidgetPlaceholder(e, o)
                    }
                }, e.prototype.getWidgetId = function(t) {
                    return t.getAttribute(this.widgetInstanceAttribute) || ""
                }, e.prototype.isWidgetAlreadyInjected = function(t, e) {
                    return t.loadedSelfExecutableWidgets || (t.loadedSelfExecutableWidgets = []), !!t.loadedSelfExecutableWidgets.includes(e) || (t.loadedSelfExecutableWidgets.push(e), !1)
                }, e.prototype.injectWidgetPlaceholder = function(t, e) {
                    var n = t.createElement("div");
                    n.setAttribute(this.widgetInstanceAttribute, e), n.className = this.widgetInstanceClass, t.body.insertBefore(n, t.body.firstChild)
                }, e.prototype.upgradeStaticW2Widgets = function(t) {
                    var e = this,
                        n = this.config.widgets;
                    Object.keys(n).forEach(function(o) {
                        var r = n[o].customizations["old-widget-class-name"],
                            i = n[o].customizations["v2-id-key"],
                            s = n[o].customizations["v2-id-value"],
                            a = n[o].className;
                        e.widgetV2Converter.convert(t, o, r, a, i, s)
                    })
                }, e.prototype.shouldInitializeWidget = function(t, e) {
                    return e || "true" !== t.getAttribute(this.widgetElementStatusAttribute)
                }, e.prototype.shouldLazyLoadWidget = function(t) {
                    var e;
                    if (!this.intersectionObserver) return !1;
                    var n = this.getWidgetId(t);
                    return !!(null === (e = this.config.widgets[n]) || void 0 === e ? void 0 : e.customizations[this.lazyLoadCustomizationName])
                }, e.prototype.shouldInjectWhenMutated = function(t) {
                    var e = this.getWidgetId(t),
                        n = t.getAttribute("data-yotpo-section-id"),
                        o = (this.config.widgets[e] || {}).customizations,
                        r = o && o[this.shouldWatchMutationsAttribute],
                        i = o && o[this.mutationSectionAttribute] || "";
                    return r && i.split(",").indexOf(n) > -1
                }, e.prototype.addIntersectionObserver = function(t) {
                    "" === (null == t ? void 0 : t.innerHTML) && t.classList.add(i.EMPTY_PLACEHOLDER_STYLE_RESET_CLASS), this.intersectionObserver.observe(t)
                }, e.prototype.removeIntersectionObserver = function(t) {
                    t.classList.remove(i.EMPTY_PLACEHOLDER_STYLE_RESET_CLASS), this.intersectionObserver.unobserve(t)
                }, e
            }();
        e.MerchantWidgetsInitializer = c
    }).call(this, n(2).Promise)
}, function(t, e, n) {
    "use strict";
    Object.defineProperty(e, "__esModule", {
        value: !0
    }), e.PageMutationObserver = void 0;
    var o = 500;
    var r = function() {
        function t(t, e) {
            void 0 === t && (t = window), this.windowElement = t, this.config = {
                attributes: !1,
                childList: !0,
                subtree: !0
            }, this.callback = e
        }
        return t.prototype.onMutation = function(t) {
            for (var e = !1, n = 0; n < t.length; n++) t.forEach(function(t) {
                for (var n = 0; n < t.addedNodes.length; n++) {
                    var o = t.addedNodes[n];
                    if (1 === o.nodeType && !["SCRIPT", "LINK", "STYLE"].includes(o.nodeName)) {
                        e = !0;
                        break
                    }
                }
            });
            e && this.callback()
        }, t.prototype.observe = function(t) {
            this.observer && this.observer.observe(t, this.config)
        }, Object.defineProperty(t.prototype, "observer", {
            get: function() {
                return this._observer ? this._observer : this.windowElement.MutationObserver ? (this._observer = new MutationObserver(function(t, e) {
                    void 0 === e && (e = o);
                    var n = 0;
                    return function() {
                        for (var o = [], r = 0; r < arguments.length; r++) o[r] = arguments[r];
                        var i = Date.now();
                        i - n >= e && (t.apply(void 0, o), n = i)
                    }
                }(this.onMutation.bind(this))), this._observer) : null
            },
            enumerable: !1,
            configurable: !0
        }), t
    }();
    e.PageMutationObserver = r
}, function(t, e, n) {
    "use strict";
    Object.defineProperty(e, "__esModule", {
        value: !0
    })
}, function(t, e, n) {
    "use strict";
    Object.defineProperty(e, "__esModule", {
        value: !0
    });
    var o = function() {
        function t() {
            this.loadedResources = new Map
        }
        return t.prototype.safeLinkInjection = function(t, e, n) {
            this.loadedResources.get(e) || (this.loadedResources.set(e, !0), this.injectLink(t, e, n))
        }, t.prototype.injectLink = function(t, e, n) {
            var o = t,
                r = o.createElement("link");
            r.rel = "stylesheet", r.href = e, this.setAttributes(r, n), o.head.appendChild(r)
        }, t.prototype.setAttributes = function(t, e) {
            Object.keys(e).forEach(function(n) {
                t.setAttribute(n, e[n])
            })
        }, t
    }();
    e.default = o
}, function(t, e, n) {
    "use strict";
    (function(t) {
        Object.defineProperty(e, "__esModule", {
            value: !0
        });
        var o = n(0),
            r = o.__importDefault(n(1)),
            i = function() {
                function e(t, e) {
                    this.scriptInjector = t, this.fontInjector = e
                }
                return e.prototype.load = function(e, n, r, i, s, a, u, c, l) {
                    return o.__awaiter(this, void 0, void 0, function() {
                        var d, f, p, h, y, v, g, m, _, w;
                        return o.__generator(this, function(o) {
                            switch (o.label) {
                                case 0:
                                    if (!i.templateAssetUrl) return console.error("missing templateAssetUrl"), [2];
                                    for (this.fontInjector.safeFontInjection(n, i), d = this.getTemplateToOverride(e, r, i.className), f = d || i.templateAssetUrl, p = this.isImportantLoad(i.staticContent), h = this.isModule(i.customizations), y = [], v = 0; v < c.length; v++) y.push(this.scriptInjector.safeScriptInjection(n, c[v], !1));
                                    return y.push(this.scriptInjector.safeScriptInjection(n, f, p, h)), [4, t.all(y)];
                                case 1:
                                    return o.sent(), (g = u[i.className]) ? (m = g()) ? (_ = this.fontInjector.areFontsLoaded(i.instanceId), w = {
                                        element: r,
                                        metadata: i,
                                        merchantData: s,
                                        storage: a,
                                        windowElement: e,
                                        guidStaticContent: l,
                                        areFontsLoaded: _
                                    }, m.init(w), m.run(), [2]) : (console.error("widget constructor returns null"), [2]) : (console.error("missing class on window: " + i.className), [2])
                            }
                        })
                    })
                }, e.prototype.getTemplateToOverride = function(t, e, n) {
                    return this.getTemplateFromUrlParam(t, n) || this.getTemplateFromAttribute(e)
                }, e.prototype.getTemplateFromUrlParam = function(t, e) {
                    var n = r.default.getQueryParams(t);
                    if (!n.override_templates || n.override_templates.length <= 0) return null;
                    for (var o = n.override_templates.split(","), i = 0; i < o.length; i++) {
                        var s = o[i].split(":::");
                        if (2 == s.length && s[0] == e) {
                            var a = s[1];
                            if (0 == a.lastIndexOf("https://cdn-widget-assets.yotpo.com", 0) || 0 == a.lastIndexOf("https://cdn-widgetsrepository.yotpo.com/widget-assets", 0)) return a
                        }
                    }
                    return null
                }, e.prototype.getTemplateFromAttribute = function(t) {
                    return t.getAttribute("override-template")
                }, e.prototype.isImportantLoad = function(t) {
                    return !(!t || !t.importantScriptLoad || "true" !== t.importantScriptLoad.toString())
                }, e.prototype.isModule = function(t) {
                    return !(!t || !t["use-es6-module"] || "true" !== t["use-es6-module"].toString())
                }, e
            }();
        e.default = i
    }).call(this, n(2).Promise)
}, function(t, e, n) {
    "use strict";
    Object.defineProperty(e, "__esModule", {
        value: !0
    });
    var o = n(0).__importDefault(n(1)),
        r = function() {
            function t(t, e) {
                this.linkInjector = t, this.windowElement = e
            }
            return t.prototype.load = function(t, e, n) {
                if (e) {
                    var r = o.default.getQueryParams(this.windowElement);
                    if (r.yotpo_skip_custom_css && "true" == r.yotpo_skip_custom_css.toString()) return void console.warn("skipping custom css loading");
                    var i = {
                        "data-yotpo-widget-css": "true",
                        "data-css-instance-id": n
                    };
                    this.linkInjector.safeLinkInjection(t, e, i)
                }
            }, t
        }();
    e.default = r
}, function(t, e, n) {
    "use strict";
    Object.defineProperty(e, "__esModule", {
        value: !0
    });
    var o = n(0),
        r = function() {
            function t() {
                this.pool = new Map
            }
            return t.prototype.call = function(t, e) {
                return o.__awaiter(this, void 0, void 0, function() {
                    var n, r;
                    return o.__generator(this, function(o) {
                        return n = t.getCacheKey(), (r = this.pool.get(n)) || (r = e.call(t), this.pool.set(n, r)), [2, r]
                    })
                })
            }, t
        }();
    e.default = r
}, function(t, e, n) {
    "use strict";
    Object.defineProperty(e, "__esModule", {
        value: !0
    }), e.getOrCreateEventBus = void 0;
    var o = n(0).__importDefault(n(18));
    e.getOrCreateEventBus = function() {
        var t = window,
            e = t.yotpoWidgetsContainer.yotpo_event_bus;
        if (e) return e;
        var n = new o.default(!0);
        return t.yotpoWidgetsContainer.yotpo_event_bus = n, n
    }
}, function(t, e, n) {
    "use strict";
    Object.defineProperty(e, "__esModule", {
        value: !0
    });
    var o = n(0),
        r = function() {
            function t(t) {
                this.subscriptions = new Map, this.logErrors = t
            }
            return t.prototype.subscribe = function(t, e) {
                var n = this.getRandomId(),
                    o = this.subscriptions.get(t);
                return o || (o = new Map, this.subscriptions.set(t, o)), o.set(n, e), {
                    eventName: t,
                    callback: e,
                    unsubscribe: function() {
                        o && o.delete(n)
                    }
                }
            }, t.prototype.publish = function(t, e) {
                for (var n = this, r = [], i = 2; i < arguments.length; i++) r[i - 2] = arguments[i];
                var s = this.subscriptions.get(t);
                s && s.forEach(function(t) {
                    try {
                        t.apply(void 0, o.__spreadArrays([e], r))
                    } catch (t) {
                        n.logErrors && console.error(t)
                    }
                })
            }, t.prototype.getRandomId = function() {
                return Math.random().toString(36).substr(2, 9)
            }, t
        }();
    e.default = r
}, function(t, e, n) {
    "use strict";
    Object.defineProperty(e, "__esModule", {
        value: !0
    });
    var o = n(0),
        r = function(t) {
            function e() {
                return null !== t && t.apply(this, arguments) || this
            }
            return o.__extends(e, t), e.prototype.injectOldWidgetScript = function(t, e, n) {
                var o = this,
                    r = t.document;
                if (this.isInjectionRequired(t, r, e, n)) {
                    var i = this.getOldScriptSrc(r, e),
                        s = i.split("widget.js?")[1];
                    i += s ? "&" : "?", i += "v2enforce=true", this.safeScriptInjection(r, i, !0).then(function() {
                        n.isV2ScriptInjected = !0, o.executeV2Callbacks(n)
                    })
                }
            }, e.prototype.isInjectionRequired = function(t, e, n, o) {
                return !(o && o.isV2ScriptInjected) && this.isStoreIdValid(n) && (this.locateAllV2Widgets(e).length > 0 || "yotpoTrackConversionData" in t)
            }, e.prototype.locateAllV2Widgets = function(t) {
                return t.querySelectorAll(".yotpo-main-widget, .bottomLine, .yotpo-pictures-widget, .embedded-widget, .yotpo-pictures-gallery, .yotpo-badge, .QABottomLine, .yotpo-reviews-carousel, .yotpo-slider, .yotpo-visual-carousel, .yotpo-shoppable-gallery, #yotpo-testimonials-custom-tab, .yotpo.testimonials, .yotpo-single-video, .yotpo-shoppers-say, .y-badge")
            }, e.prototype.isStoreIdValid = function(t) {
                return new RegExp("[A-Za-z0-9]{40}").test(t)
            }, e.prototype.getOldScriptSrc = function(t, e) {
                for (var n = t.getElementsByTagName("script"), o = new RegExp("//(staticw2|w2)\\.yotpo\\.com/[A-Za-z0-9]{40}/widget\\.js.*"), r = 0; r < n.length; r++)
                    if (o.test(n[r].src)) return n[r].src;
                return "//staticw2.yotpo.com/" + e + "/widget.js"
            }, e.prototype.executeV2Callbacks = function(t) {
                t.yotpoV3 && t.yotpoV3.v2Callbacks && t.yotpoV3.v2Callbacks.forEach(function(t) {
                    t()
                })
            }, e
        }(o.__importDefault(n(6)).default);
    e.default = r
}, function(t, e, n) {
    "use strict";
    Object.defineProperty(e, "__esModule", {
        value: !0
    });
    var o = n(0),
        r = function(t) {
            function e() {
                var e = null !== t && t.apply(this, arguments) || this;
                return e.widgetsTypesWithDivToReplace = ["ReviewsMainWidget", "ReviewsStarRatingsWidget", "QuestionsAndAnswers", "ReviewsCarousel", "ReviewsSeoPage", "VugcMediaGallery"], e.widgetsTypesWithoutDivToReplace = ["ReviewsTab"], e.widgetsTypes = o.__spreadArrays(e.widgetsTypesWithDivToReplace, e.widgetsTypesWithoutDivToReplace), e.selectorsById = ["ReviewsSeoPage"], e.oldWidgetCheckers = new Map([
                    ["ReviewsMainWidget", function(t) {
                        return !t.hasAttribute("data-mode") || "reviews" == t.getAttribute("data-mode")
                    }],
                    ["QuestionsAndAnswers", function(t) {
                        return t.hasAttribute("data-mode") || "questions" == t.getAttribute("data-mode")
                    }]
                ]), e
            }
            return o.__extends(e, t), e.prototype.convert = function(t, e, n, o, r, i) {
                var s, a = this;
                if (n && this.widgetsTypes.includes(o)) {
                    var u = [];
                    if (this.selectorsById.includes(o)) {
                        (c = t.getElementById(n)) && u.push(c)
                    } else {
                        var c;
                        if (u = Array.from(t.getElementsByClassName(n)), this.widgetsTypesWithoutDivToReplace.includes(o))(s = (c = t.createElement("div")).classList).add.apply(s, n.split(" ")), t.body.appendChild(c), u.push(c);
                        u = this.filterMultiInstances(u, r, i)
                    }
                    u.forEach(function(t) {
                        a.shouldConvert(t, o) && (a.replaceAttributesName(t, "data", "data-yotpo"), a.replaceClassName(t, n, "yotpo-widget-instance"), a.setAttribute(t, "data-yotpo-instance-id", e), a.selectorsById.includes(o) && (t.removeAttribute("id"), a.setAttribute(t, "class", "yotpo-widget-instance")))
                    })
                }
            }, e.prototype.filterMultiInstances = function(t, e, n) {
                var o = this.buildMultiInstancesSelector(e, n);
                return o ? t.filter(function(t) {
                    return t.matches(o)
                }) : t
            }, e.prototype.buildMultiInstancesSelector = function(t, e) {
                return t && e ? "[" + t + '="' + e + '"]' : null
            }, e.prototype.shouldConvert = function(t, e) {
                var n = this.oldWidgetCheckers.get(e);
                return !n || n(t)
            }, e
        }(o.__importDefault(n(21)).default);
    e.default = r
}, function(t, e, n) {
    "use strict";
    Object.defineProperty(e, "__esModule", {
        value: !0
    });
    var o = function() {
        function t() {}
        return t.prototype.replaceAttributesName = function(t, e, n) {
            var o = this;
            Array.from(t.attributes).forEach(function(r) {
                var i = r.name,
                    s = r.value;
                o.replaceAttributeName(t, i, s, e, n)
            })
        }, t.prototype.replaceAttributeName = function(t, e, n, o, r) {
            if (new RegExp(o).test(e) && !e.includes(r)) {
                var i = e.replace(o, r);
                t.removeAttribute(e), this.setAttribute(t, i, n)
            }
        }, t.prototype.setAttribute = function(t, e, n) {
            t.setAttribute(e, n)
        }, t.prototype.replaceClassName = function(t, e, n) {
            t.className = t.className.replace(e, n)
        }, t
    }();
    e.default = o
}, function(t, e, n) {
    "use strict";
    Object.defineProperty(e, "__esModule", {
        value: !0
    });
    var o = n(23),
        r = function() {
            function t() {
                this.fonts = [], this.injectedFonts = []
            }
            return t.prototype.areFontsLoaded = function(t) {
                return !!this.fonts.length && this.fonts.some(function(e) {
                    return e.widgetInstanceId === t
                })
            }, t.prototype.safeFontInjection = function(t, e) {
                var n = this,
                    r = this.getFontCustomizations(e);
                if (r.length && !this.isInPreviewMode(t)) {
                    this.insertFontsFromWidget(r, e);
                    var i = t.getElementsByClassName(o.yotpoFontClassName),
                        s = this.fonts.length ? this.fonts.filter(function(t) {
                            return !n.injectedFonts.some(function(e) {
                                return e.family === t.family && e.url === t.url
                            })
                        }).filter(function(t, e, n) {
                            return n.findIndex(function(e) {
                                return e.family == t.family
                            }) === e && !!t.family
                        }).filter(function(e) {
                            return !o.isFontInjected(t, e, i)
                        }).map(function(t) {
                            return {
                                url: t.url,
                                family: t.family
                            }
                        }) : [];
                    s.length > 0 && (this.injectFonts(t, s), this.injectedFonts = this.injectedFonts.concat(s))
                }
            }, t.prototype.insertFontsFromWidget = function(t, e) {
                var n = this;
                t.forEach(function(t) {
                    if (e.customizations[t]) {
                        var o = e.customizations[t].split("|")[0],
                            r = e.customizations[t].split("|")[1],
                            i = e.instanceId;
                        o && r && n.fonts.push({
                            family: o,
                            url: r,
                            widgetInstanceId: i
                        })
                    }
                })
            }, t.prototype.getFontCustomizations = function(e) {
                var n = e.customizations[t.loadFontsCustomizationKey];
                return "string" != typeof n ? [] : n.split(",").map(function(t) {
                    return t.trim()
                }) || []
            }, t.prototype.isInPreviewMode = function(t) {
                if (t && t.body && [t.body.querySelector(".widget-preview"), t.body.querySelector(".widget-wrapper")].some(function(t) {
                        return null !== t
                    })) return !0;
                return !1
            }, t.prototype.injectFonts = function(t, e) {
                o.loadFonts(t, null, e)
            }, t.loadFontsCustomizationKey = "load-font-customizations", t
        }();
    e.default = r
}, function(t, e, n) {
    "use strict";
    Object.defineProperty(e, "__esModule", {
        value: !0
    }), e.loadFonts = e.loadFont = e.loadFontStyle = e.isFontInjected = e.yotpoFontClassName = void 0;
    var o = ["fonts.googleapis.com/css", "cdn-widgetsrepository.yotpo.com/web-fonts/css", "staticw2.yotpo.com/web-fonts/css"];
    e.yotpoFontClassName = "yotpo-font", e.isFontInjected = function(t, n, o) {
        var r;
        for (var i in void 0 === o && (o = t.getElementsByClassName(e.yotpoFontClassName)), o) {
            var s = null == o ? void 0 : o[i];
            if ("STYLE" === s.tagName && (null === (r = s.textContent) || void 0 === r ? void 0 : r.includes(n.url))) return !0;
            if ("LINK" === s.tagName && s.getAttribute("href") === n.url) return !0
        }
        return !1
    }, e.loadFontStyle = function(t, n, o) {
        var r = t.createElement("style");
        r.innerHTML = '\n  @font-face {\n    font-family: "' + n.family + "\";\n    src: url('" + n.url + "');\n    font-display: swap;\n  }", r.classList.add(e.yotpoFontClassName), o ? o.appendChild(r) : t.head.appendChild(r)
    }, e.loadFont = function(t, n, r) {
        if (n.url && (n.url.endsWith(".css") || o.some(function(t) {
                return n.url.includes(t)
            }))) {
            var i = t.createElement("style");
            i.classList.add(e.yotpoFontClassName);
            var s;
            s = "@import url('" + n.url + "');", i.innerHTML = s, t.head.appendChild(i)
        } else {
            if (!n.url) return;
            e.loadFontStyle(t, n, r)
        }
    }, e.loadFonts = function(t, n, o) {
        o && o.forEach(function(o) {
            return e.loadFont(t, o, n)
        })
    }
}, function(t, e, n) {
    "use strict";
    Object.defineProperty(e, "__esModule", {
        value: !0
    });
    var o = n(0).__importDefault(n(1)),
        r = function() {
            function t(t) {
                this.YOTPO_DOMAIN = "yotpo.com", this.windowElement = t
            }
            return t.prototype.shouldLoadWidget = function(t, e) {
                return !this.shouldHideIfUrlMatchQueryParam(t) && (o.default.isUrlDomainMatchedByRegex(this.windowElement, this.YOTPO_DOMAIN) || this.shouldShowByStaticContent(t) || this.shouldShowIfUrlMatchQueryParam() || e)
            }, t.prototype.shouldShowByStaticContent = function(t) {
                var e;
                return !(null === (e = null == t ? void 0 : t.staticContent) || void 0 === e ? void 0 : e.isHidden)
            }, t.prototype.shouldShowIfUrlMatchQueryParam = function() {
                return o.default.isQueryParamExists(this.windowElement, ["oseid"])
            }, t.prototype.shouldHideIfUrlMatchQueryParam = function(t) {
                var e, n;
                return !(null === (e = null == t ? void 0 : t.staticContent) || void 0 === e || !e.hideIfMatchingQueryParam) && o.default.isQueryParamExists(this.windowElement, null === (n = null == t ? void 0 : t.staticContent) || void 0 === n ? void 0 : n.hideIfMatchingQueryParam)
            }, t
        }();
    e.default = r
}, function(t, e, n) {
    "use strict";
    Object.defineProperty(e, "__esModule", {
        value: !0
    });
    var o = n(0),
        r = n(5),
        i = o.__importDefault(n(4)),
        s = function() {
            function t(t, e, n) {
                this.LOADER_URL = "https://widgetsrepository.yotpo.com/v1/loader", this.guid = e, this.yotpoWidgetsContainer = n, this.window = t
            }
            return t.prototype.isPreviewMode = function() {
                return "true" === i.default.get(r.PREVIEW_MODE_KEY)
            }, t.prototype.shouldInjectNewLoaderWithAllWidgets = function() {
                return this.isPreviewMode() && this.isFirstLoadWithAllWidgets()
            }, t.prototype.injectLoaderWithAllWidgets = function() {
                this.allowLoaderToBeLoaded(), this.injectScriptElement(), this.setScriptWithAllWidgetsLoadedFlag()
            }, t.prototype.isFirstLoadWithAllWidgets = function() {
                return !Boolean(this.getScriptWithAllWidgetsLoadedFlag())
            }, t.prototype.allowLoaderToBeLoaded = function() {
                this.yotpoWidgetsContainer.guids[this.guid][r.LOADER_SCRIPT_FLAGS.IS_SCRIPTS_LOADED] = !1
            }, t.prototype.injectScriptElement = function() {
                var t = this.window.document.createElement("script");
                t.src = this.getLoaderURLWithAllWidgets(), t.async = !0, this.window.document.head.appendChild(t)
            }, t.prototype.getLoaderURLWithAllWidgets = function() {
                return this.LOADER_URL + "/" + this.guid + "?all=true"
            }, t.prototype.getScriptWithAllWidgetsLoadedFlag = function() {
                return this.yotpoWidgetsContainer.guids[this.guid][r.LOADER_SCRIPT_FLAGS.IS_SCRIPT_WITH_ALL_WIDGETS_LOADED]
            }, t.prototype.setScriptWithAllWidgetsLoadedFlag = function() {
                this.yotpoWidgetsContainer.guids[this.guid][r.LOADER_SCRIPT_FLAGS.IS_SCRIPT_WITH_ALL_WIDGETS_LOADED] = !0
            }, t
        }();
    e.default = s
}]);