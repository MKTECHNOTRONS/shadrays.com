// Last edit: Fri, 02 Nov 18 15:44:28 -0400
var rfsn_ajax = {
    x: function() {
        if ("undefined" !== typeof XMLHttpRequest) return new XMLHttpRequest;
        for (var f = "MSXML2.XmlHttp.6.0 MSXML2.XmlHttp.5.0 MSXML2.XmlHttp.4.0 MSXML2.XmlHttp.3.0 MSXML2.XmlHttp.2.0 Microsoft.XmlHttp".split(" "), a, d = 0; d < f.length; d++) try {
            a = new ActiveXObject(f[d]);
            break
        } catch (h) {}
        return a
    },
    send: function(f, a, d, h, g) {
        void 0 === g && (g = !0);
        var e = rfsn_ajax.x();
        e.open(d, f, g);
        e.onreadystatechange = function() {
            4 == e.readyState && a(e.responseText)
        };
        "POST" == d && e.setRequestHeader("Content-type", "application/x-www-form-urlencoded");
        e.send(h)
    },
    get: function(f, a, d, h) {
        var g = [],
            e;
        for (e in a) g.push(encodeURIComponent(e) + "=" + encodeURIComponent(a[e]));
        rfsn_ajax.send(f + (g.length ? "?" + g.join("&") : ""), d, "GET", null, h)
    },
    post: function(f, a, d, h) {
        var g = [],
            e;
        for (e in a) g.push(encodeURIComponent(e) + "=" + encodeURIComponent(a[e]));
        rfsn_ajax.send(f, d, "POST", g.join("&"), h)
    }
};

function rfsnLoadScript(f, a) {
    var d = document.createElement("script");
    d.type = "text/javascript";
    d.readyState ? d.onreadystatechange = function() {
        if ("loaded" == d.readyState || "complete" == d.readyState) d.onreadystatechange = null, a()
    } : d.onload = function() {
        a()
    };
    d.src = f;
    document.getElementsByTagName("head")[0].appendChild(d)
}

function RFSNTracker() {
    this.is_ready = !1;
    this.log_count = 1;
    var f = {},
        a = {
            is_loaded: !1,
            ls_enabled: !1,
            verbose: !1
        },
        d = function() {
            var a = window.location.href;
            a = -1 != a.search(/^https?:\/\//) ? a.match(/^https?:\/\/([^\/?#]+)(?:[\/?#]|$)/i, "") : a.match(/^([^\/?#]+)(?:[\/?#]|$)/i, "");
            return a[1]
        };
    this.init = function() {
        a.shop = this.get_qs("shop", !0);
        a.public_key = this.get_qs("pk", !0);
        a.client_id = this.get_qs("client_id", !0);
        var b = this.get_qs("custom_key", !0);
        a.custom_key = b ? b : "rfsn";
        if (a.is_loaded)
            if (a.xdomain_enabled =
                0 <= a.xdomains.indexOf(d()), a.xdomain_enabled && 2 === a.version && "undefined" === typeof xdLocalStorage) rfsnLoadScript(a.base_url + "js/xdLocalStorage.min.js?v=" + Math.floor(100 * Math.random()), function() {
                xdLocalStorage.init({
                    iframeUrl: a.base_url + "tracker/v3/xdomain/" + a.public_key + ".html",
                    initCallback: function() {
                        _rfsn_tracker.init()
                    }
                });
                _rfsn_tracker.log("XDomain support enabled.")
            });
            else {
                this.log("Tracker has been initiated.");
                this.is_ready = !0;
                "undefined" === typeof jQuery && rfsnLoadScript("//ajax.googleapis.com/ajax/libs/jquery/1.12.0/jquery.min.js",
                    function() {
                        $ = jQuery.noConflict(!0)
                    });
                try {
                    localStorage.setItem("test", "test"), localStorage.removeItem("test"), a.ls_enabled = !0
                } catch (c) {
                    a.ls_enabled = !1, e(1)
                }
                "" !== this.get_qs("rf_test") && alert("Success! Your Refersion click was tracked, please continue with your test order.");
                this.fingerprint_click();
                this.fingerprint_cart();
                1 < a.version && this.cookie_change_listener()
            }
        else this.log("Setting for tracker did not load properly.", "error")
    };
    this.cookie_change_listener = function() {
        var a = this,
            c = setInterval(function() {
                "" !=
                a.get_cookie("cart") && "undefined" != typeof a.get_cookie("cart") && a.get_cookie("cart") != localStorage.getItem("current_cart") && (a.fingerprint_cart(), clearInterval(c))
            }, 1E3)
    };
    this.log = function(b, c) {
        if (a.verbose) {
            switch (c) {
                case "error":
                    console.error("Refersion [" + this.log_count + "]: " + b);
                    break;
                case "warn":
                    console.warn("Refersion [" + this.log_count + "]: " + b);
                    break;
                default:
                    console.log("Refersion [" + this.log_count + "]: " + b)
            }
            this.log_count++
        }
    };
    this.load_settings = function(b) {
        for (var c in b) a[c] = b[c];
        "undefined" !==
        typeof localStorage.tracking_version && (a.version = localStorage.tracking_version)
    };
    this.get_qs = function(a, c) {
        a = a.replace(/[\[]/, "\\[").replace(/[\]]/, "\\]");
        var b = new RegExp("[\\?&]" + a + "=([^&#]*)"),
            d = "";
        if (c) {
            for (var e = document.getElementsByTagName("script"), f = 0; f <= e.length; f++)
                if (e[f].src.match(/(refersion\.com.|s3\.amazonaws\.com.refersion)[^\/]*(\/\d*\/tracking|pixel)/ig)) {
                    d = e[f].src;
                    break
                }
            b = b.exec(d)
        } else b = b.exec(location.search);
        return null === b ? "" : decodeURIComponent(b[1].replace(/\+/g, " "))
    };
    var h = function() {
        var a = document.cookie,
            c = 0,
            d = {};
        "function" !== typeof String.prototype.trimLeft && (String.prototype.trimLeft = function() {
            return this.replace(/^\s+/, "")
        });
        "function" !== typeof String.prototype.trimRight && (String.prototype.trimRight = function() {
            return this.replace(/\s+$/, "")
        });
        "function" !== typeof Array.prototype.map && (Array.prototype.map = function(a, c) {
            for (var b = 0, d = this.length, e = []; b < d; b++) b in this && (e[b] = a.call(c, this[b]));
            return e
        });
        document.cookie.match(/^\s*\$Version=(?:"1"|1);\s*(.*)/) &&
            (a = RegExp.$1, c = 1);
        0 === c ? a.split(/[,;]/).map(function(a) {
            var c = a.split(/=/, 2);
            a = decodeURIComponent(c[0].trimLeft());
            c = 1 < c.length ? decodeURIComponent(c[1].trimRight()) : null;
            d[a] = c
        }) : a.match(/(?:^|\s+)([!#$%&'*+\-.0-9A-Z^`a-z|~]+)=([!#$%&'*+\-.0-9A-Z^`a-z|~]*|"(?:[\x20-\x7E\x80\xFF]|\\[\x00-\x7F])*")(?=\s*[,;]|$)/g).map(function(a, c) {
            var b = '"' === c.charAt(0) ? c.substr(1, -1).replace(/\\(.)/g, "$1") : c;
            d[a] = b
        });
        return d
    };
    this.get_cookie = function(a) {
        return h()[a]
    };
    var g = function(a, c) {
            var b = new Image;
            b.onload =
                function() {};
            b.setAttribute("style", "float: right;");
            b.setAttribute("class", c);
            b.setAttribute("alt", "");
            b.src = a;
            document.body.appendChild(b)
        },
        e = function(b) {
            a.version = b;
            a.ls_enabled && localStorage.setItem("tracking_version", b)
        };
    this.get_setting = function(b) {
        return a[b] || void 0
    };
    this.get_version = function() {
        return parseFloat(a.version)
    };
    this.is_settings_loaded = function() {
        return a.is_loaded || !1
    };
    var k = function() {
            a.xdomain_enabled && "undefined" != typeof xdLocalStorage && (0 < parseInt(localStorage.rfsn_ci || 0) &&
                ("undefined" !== typeof localStorage.rfsn_aid && xdLocalStorage.setItem("rfsn_aid_" + a.public_key, localStorage.rfsn_aid), "undefined" !== typeof localStorage.rfsn_ci && xdLocalStorage.setItem("rfsn_ci_" + a.public_key, localStorage.rfsn_ci), "undefined" !== typeof localStorage.rfsn_cs && xdLocalStorage.setItem("rfsn_cs_" + a.public_key, localStorage.rfsn_cs), "undefined" !== typeof localStorage.tracking_version && xdLocalStorage.setItem("tracking_version_" + a.public_key, localStorage.tracking_version), "undefined" !== typeof localStorage.current_cart &&
                    xdLocalStorage.setItem("current_cart_" + a.public_key, localStorage.current_cart)), _rfsn_tracker.log("localStorage Pushed"))
        },
        l = function() {
            a.xdomain_enabled && "undefined" != typeof xdLocalStorage && (xdLocalStorage.getItem("rfsn_ci" + a.public_key, function(b) {
                parseInt(localStorage.rfsn_ci || 0) <= parseInt(b.value || 0) && (xdLocalStorage.getItem("rfsn_aid_" + a.public_key, function(a) {
                    a.value && "undefined" !== typeof a.value && (localStorage.rfsn_aid = a.value)
                }), xdLocalStorage.getItem("rfsn_ci_" + a.public_key, function(a) {
                    a.value &&
                        "undefined" !== typeof a.value && (localStorage.rfsn_ci = a.value)
                }), xdLocalStorage.getItem("rfsn_cs_" + a.public_key, function(a) {
                    a.value && "undefined" !== typeof a.value && (localStorage.rfsn_cs = a.value)
                }), xdLocalStorage.getItem("tracking_version_" + a.public_key, function(a) {
                    a.value && "undefined" !== typeof a.value && (localStorage.tracking_version = a.value)
                }), xdLocalStorage.getItem("current_cart_" + a.public_key, function(a) {
                    a.value && "undefined" !== typeof a.value && (localStorage.current_cart = a.value)
                }))
            }), _rfsn_tracker.log("localStorage Pulled"))
        };
    this.check_action_timeout = function(a) {
        var b = (new Date).getTime();
        a = localStorage.getItem("current_rfsn_" + a);
        return 60 < (b - a) / 1E3 || !a
    };
    this.set_action_mark = function(a) {
        var b = (new Date).getTime();
        localStorage.getItem("current_rfsn_" + a) && !this.check_action_timeout(a) || localStorage.setItem("current_rfsn_" + a, b)
    };
    this.fingerprint_click = function() {
        _rfsn_tracker.click("")
    };
    this.click = function(b) {
        if ("" == this.get_qs("rfsn") && "" == this.get_qs(a.custom_key) || !this.check_action_timeout("click")) "undefined" !== typeof f.click &&
            60 >= f.click && this.log("Click tracking on timeout. (" + f.click + ")");
        else switch (this.log("Click track attempt:"), a.version) {
            case 1:
                var c = a.base_url + "p" + location.search + "&krfsn_k=" + a.custom_key + "&rfsn_fp=" + b + "&d=" + (new Date).getTime();
                g(c, "rfsn_pixel_click_legacy");
                this.log("Tracker [v1] [Custom] click tracked @ " + c);
                this.set_action_mark("click");
                break;
            case 2:
                l(), c = a.base_url + "t/v2" + location.search + "&rfsn_k=" + a.custom_key + "&rfsn_fp=" + b + "&rfsn_lp=" + escape(document.URL) + "&rfsn_r=" + escape(document.referrer) +
                    "&d=" + (new Date).getTime(), rfsn_ajax.get(c, {}, function(a) {
                        a = JSON.parse(a);
                        !isNaN(a.cid) && 0 < a.cid ? (a.aid && localStorage.setItem("rfsn_aid", a.aid), a.cs && localStorage.setItem("rfsn_cs", a.cs), a.cid && localStorage.setItem("rfsn_ci", a.cid), k(), _rfsn_tracker.log("Tracker [v2] [Custom] click tracked @ " + c), _rfsn_tracker.set_action_mark("click")) : (e("1.0"), k(), _rfsn_tracker.log("Tracker [v2] click tracked blocked. Trying legacy approach.", "warn"), _rfsn_tracker.fingerprint_click())
                    })
        }
    };
    this.fingerprint_cart =
        function() {
            _rfsn_tracker.cart("")
        };
    this.cart = function(b) {
        if (this.check_action_timeout("cart")) switch (this.log("Cart map attempt:"), l(), a.version) {
            case 1:
                if ("" != this.get_cookie("cart") && "undefined" !== typeof this.get_cookie("cart")) {
                    var c = a.base_url + "tracker/shopify?shop=" + a.shop + "&i=NULL&sci=" + this.get_cookie("cart") + "&rfsn_fp=" + b + "&d=" + (new Date).getTime();
                    g(c, "rfsn_pixel_cookie_legacy");
                    this.log("Tracker [v1] [Standard] cart tracked @ " + c);
                    this.set_action_mark("cart")
                }
                break;
            case 2:
                null !== localStorage.getItem("rfsn_ci") &&
                    "" != this.get_cookie("cart") && "undefined" !== typeof this.get_cookie("cart") && this.get_cookie("cart") != localStorage.getItem("current_cart") && (c = a.base_url + "tracker/shopify/v2?shop=" + a.shop + "&rci=" + localStorage.getItem("rfsn_ci") + "&raid=" + localStorage.getItem("rfsn_aid") + "&sci=" + this.get_cookie("cart") + "&rfsn_fp=" + b + "&d=" + (new Date).getTime(), rfsn_ajax.get(c, {}, function(a) {
                        "TRUE" == a && (_rfsn_tracker.log("Tracker [v2] [Custom] cart tracked @ " + c), k(), _rfsn_tracker.set_action_mark("cart"))
                    }), this.log("AJAX item tracked."))
        }
    };
    this.get_qs("pk", !0) ? rfsnLoadScript("https://s3.amazonaws.com/refersion_client/" + this.get_qs("client_id", !0) + "/tracking/" + this.get_qs("pk", !0) + ".js?shop=" + this.get_qs("shop", !0), function() {
        _rfsn_tracker.init()
    }) : this.log("Error: Missing public key.", "error")
}
var _rfsn_tracker = _rfsn_tracker || new RFSNTracker;