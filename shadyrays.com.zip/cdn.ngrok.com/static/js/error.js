window.addEventListener("load", (() => {
    const t = function() {
        const t = document.getElementById("root") || {},
            e = (t.dataset || {}).payload || "",
            n = function(t) {
                try {
                    return JSON.parse(t || "{}")
                } catch (t) {
                    return {}
                }
            }(function(t) {
                if (/^([0-9a-zA-Z+/]{4})*(([0-9a-zA-Z+/]{2}==)|([0-9a-zA-Z+/]{3}=))?$/.test(t)) try {
                    return window.atob(t) || "{}"
                } catch (e) {
                    return window.decodeURIComponent(t)
                }
                return window.decodeURIComponent(t)
            }(e));
        return o = n.cdnBase || "https://cdn.ngrok.com", (o || "").trim().replace(/\/+$/, "");
        var o
    }();
    ! function(t) {
        const e = document.createElement("script");
        e.setAttribute("src", t), document.head.appendChild(e)
    }(t + "/static/compiled/js/allerrors.js"),
    function(t) {
        const e = document.createElement("link");
        e.setAttribute("rel", "stylesheet"), e.setAttribute("type", "text/css"), e.setAttribute("href", t), document.head.appendChild(e)
    }(t + "/static/compiled/css/allerrors.css");
    const e = document.getElementById("style");
    e && e.remove()
}));