! function() {
    if (!window.__SnapPixel) {
        window.__SnapPixel = {};
        var t = {
            initialize: function() {
                if (!window.snaptr) {
                    var t = window.snaptr = function() {
                        t.handleRequest ? t.handleRequest.apply(t, arguments) : t.queue.push(arguments)
                    };
                    t.queue = [];
                    var e = "script",
                        r = document.createElement(e);
                    r.async = !0, r.src = "https://sc-static.net/scevent.min.js";
                    var n = document.getElementsByTagName(e)[0];
                    n.parentNode.insertBefore(r, n)
                }
            },
            getCurrentScript: function() {
                var t = document.currentScript;
                if (!t)
                    for (var e = document.getElementsByTagName("script"), r = 0; r < e.length; r++)
                        if (e[r].src && 0 === e[r].src.indexOf("https://intg.snapchat.com/shopify/shopify_scevent.js?id=")) return e[r];
                return t
            },
            getUrlParameters: function(t) {
                var e = {};
                return t.replace(/[?&]+([^=&]+)=([^&]*)/gi, function(t, r, n) {
                    e[r] = n
                }), e
            },
            scrapeProductMetadata: function() {
                var e = null,
                    r = t.scrapeSearchTerm();
                if (r && (e = {
                        search_string: r,
                        integration: "shopify"
                    }), window.ShopifyAnalytics && window.ShopifyAnalytics.meta.product) {
                    var n = window.ShopifyAnalytics.meta;
                    if (n) {
                        (e = e || {}).integration = "shopify", e.currency = n.currency, e.item_category = n.product.id;
                        var i = n.selectedVariantId ? n.product.variants.find(function(t) {
                            return String(t.id) === String(n.selectedVariantId)
                        }) : n.product.variants[0];
                        i && (i.id && (e.item_ids = [String(i.id)]), i.name && (e.description = i.name.trim()), e.price = i.price ? Number((i.price / 100).toFixed(2)) : 0)
                    }
                }
                return e || {
                    integration: "shopify"
                }
            },
            scrapePurchaseMetadata: function() {
                var t = null,
                    e = window.Shopify.checkout;
                if (e) try {
                    t = {
                        integration: "shopify",
                        currency: e.currency,
                        description: JSON.stringify(e.line_items.map(function(t) {
                            return {
                                product_id: t.product_id,
                                variant_id: t.variant_id,
                                sku: t.sku,
                                title: t.title,
                                variant_title: t.variant_title,
                                price: t.price,
                                line_price: t.line_price,
                                quantity: t.quantity
                            }
                        })),
                        item_ids: e.line_items.map(function(t) {
                            return t.variant_id ? String(t.variant_id) : null
                        }).filter(Boolean),
                        price: e.subtotal_price,
                        transaction_id: e.order_id
                    }
                } catch (t) {}
                return t
            },
            scrapeStartCheckoutMetadata: function() {
                var t = {
                        integration: "shopify"
                    },
                    e = Array.from(document.querySelectorAll("*[data-cart-item]")).map(function(t) {
                        var e = {},
                            r = t.querySelector("*[data-cart-item-title]"),
                            n = t.querySelector("*[data-cart-item-price]"),
                            i = t.querySelector("*[data-cart-item-label-quantity]"),
                            a = t.getAttribute("data-cart-item-id"),
                            c = !!r && r.textContent,
                            o = !!n && r.price,
                            u = !!i && r.quantity;
                        return a && (a.indexOf(":") > -1 && (a = a.split(":")[0]), e.variantId = a), c && (e.variantTitle = c), o && (e.price = o.replace(/[^0-9.]/g, "")), u && (e.quantity = u), e
                    }),
                    r = !!window.ShopifyAnalytics.meta && window.ShopifyAnalytics.meta.currency;
                r && (t.currency = r);
                var n = document.querySelector("*[data-cart-subtotal]");
                return n && (t.price = (n.textContent || "").replace(/[^0-9.]/g, "")), e.length > 0 && (t.item_ids = e.map(function(t) {
                    return t.variantId ? String(t.variantId) : null
                }).filter(Boolean), t.description = JSON.stringify(e.map(function(t) {
                    return {
                        variant_id: t.variantId,
                        title: t.variantTitle,
                        price: t.price,
                        quantity: t.quantity
                    }
                }))), t
            },
            scrapeSearchTerm: function() {
                var e = null;
                try {
                    var r = window.location.pathname.split("/");
                    if ("search" === r[r.length - 1]) e = t.getUrlParameters(window.location.href).q;
                    else if (document.referrer) {
                        var n = new URL(document.referrer);
                        if (n.hostname === window.location.hostname) {
                            var i = n.pathname.split("/");
                            "search" === i[i.length - 1] && (e = t.getUrlParameters(n.href).q)
                        }
                    }
                } catch (t) {}
                return e
            },
            scrapeUserId: function() {
                if (window.ShopifyAnalytics) {
                    var t = window.ShopifyAnalytics.lib.user();
                    if (t) {
                        try {
                            return t.id()
                        } catch (t) {}
                        try {
                            return t.traits().uniqToken
                        } catch (t) {}
                        try {
                            return t.properties().uniqToken
                        } catch (t) {}
                        try {
                            return t.anonymousId()
                        } catch (t) {}
                    }
                    return __st_uniqToken || __st.u
                }
            },
            scrapeInitMeta: function() {
                var t = {};
                try {
                    var e = window.Shopify.checkout,
                        r = e.phone || e.shipping_address && e.shipping_address.phone || e.billing_address && e.billing_address.phone,
                        n = !!r && r.replace(/[^0-9]/g, ""),
                        i = e.email;
                    i && (t.user_email = i), n && (t.user_phone_number = n)
                } catch (t) {}
                return t
            },
            logAddToCartEvent: function(e) {
                var r = t.scrapeProductMetadata();
                return r && (t.logEvent("ADD_CART", r), e && e.target && e.target.removeEventListener("submit", t.logAddToCartEvent)), !0
            },
            logCheckoutEvent: function(e) {
                var r = t.scrapeStartCheckoutMetadata();
                return r && t.logEvent("START_CHECKOUT", r), !0
            },
            logEvent: function(t, e) {
                var r = {};
                if (e)
                    for (var n in e) e.hasOwnProperty(n) && (r[n] = e[n]);
                window.snaptr("track", t, r)
            },
            logPageViewEvent: function() {
                var e = t.scrapeProductMetadata();
                t.logEvent("PAGE_VIEW", e)
            },
            logPurchaseEvent: function() {
                var e = t.scrapePurchaseMetadata();
                e && t.logEvent("PURCHASE", e)
            },
            logSearchEvent: function(e) {
                if (!e || !e.target) return !0;
                var r = e.target.querySelector("*[name=q]");
                return r && r.value && t.logEvent("SEARCH", {
                    search_string: r.value
                }), !0
            },
            logSignUpEvent: function(e) {
                if (!e || !e.target) return !0;
                var r = e.target.querySelector("input[type=email]");
                return r && r.value && t.logEvent("SIGN_UP", {
                    sign_up_method: "Mailing List Subscription"
                }), !0
            },
            logViewContentEvent: function() {
                var e = t.scrapeProductMetadata();
                t.logEvent("VIEW_CONTENT", e)
            },
            trackAddToCart: function() {
                for (var e = document.querySelectorAll("form[action^='/cart/add']"), r = 0; r < e.length; r++) e[r].addEventListener("submit", t.logAddToCartEvent, !0)
            },
            trackCheckout: function() {
                for (var e = document.querySelectorAll("form[action='/cart'], form[action='/cart/']"), r = 0; r < e.length; r++) e[r].addEventListener("submit", t.logCheckoutEvent, !0)
            },
            trackSearch: function() {
                for (var e = document.querySelectorAll("form[action^='/search']"), r = 0; r < e.length; r++) e[r].addEventListener("submit", t.logSearchEvent, !0)
            },
            trackSignUp: function() {
                for (var e = document.querySelectorAll("form[action^='/contact']"), r = 0; r < e.length; r++) e[r].addEventListener("submit", t.logSignUpEvent, !0)
            },
            trackViewContent: function() {
                window.ShopifyAnalytics && window.ShopifyAnalytics.meta && window.ShopifyAnalytics.meta.page && "product" === window.ShopifyAnalytics.meta.page.pageType && t.logViewContentEvent()
            },
            trackStoreSession: function() {
                var e = t.scrapeInitMeta();
                try {
                    var r = t.getCurrentScript(),
                        n = t.getUrlParameters(r.src).id;
                    window.snaptr("init", n, e), t.logPageViewEvent(), window.Shopify.checkout ? t.logPurchaseEvent() : (t.trackAddToCart(), t.trackSearch(), t.trackCheckout(), t.trackSignUp(), t.trackViewContent())
                } catch (t) {}
            }
        };
        t.initialize(), t.trackStoreSession()
    }
}();