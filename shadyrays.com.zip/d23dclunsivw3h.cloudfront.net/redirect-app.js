(() => {
    var e = {
            8015: e => {
                var t = "https://easy-redirects.shopcircle.co";
                t = "https://easy-redirects.shopcircle.co", e.exports = {
                    api_base_url: t
                }
            }
        },
        t = {};

    function r(o) {
        var i = t[o];
        if (void 0 !== i) return i.exports;
        var a = t[o] = {
            exports: {}
        };
        return e[o](a, a.exports, r), a.exports
    }
    r.n = e => {
        var t = e && e.__esModule ? () => e.default : () => e;
        return r.d(t, {
            a: t
        }), t
    }, r.d = (e, t) => {
        for (var o in t) r.o(t, o) && !r.o(e, o) && Object.defineProperty(e, o, {
            enumerable: !0,
            get: t[o]
        })
    }, r.o = (e, t) => Object.prototype.hasOwnProperty.call(e, t), (() => {
        "use strict";
        var e = r(8015),
            t = window.location.hash;
        if (console.log(t), -1 !== t.indexOf("#erid")) {
            "pushState" in history ? history.pushState("", document.title, window.location.pathname + window.location.search) : window.location.hash = "";
            var o = new XMLHttpRequest;
            o.open("GET", e.api_base_url + "/api/redirect-hit?shop=" + Shopify.shop + "&id=" + t.replace("#erid", "")), o.send()
        }
    })()
})();