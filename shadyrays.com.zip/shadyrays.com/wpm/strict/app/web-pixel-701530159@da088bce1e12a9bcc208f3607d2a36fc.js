(() => {
    var C = Object.create;
    var I = Object.defineProperty;
    var P = Object.getOwnPropertyDescriptor;
    var $ = Object.getOwnPropertyNames;
    var S = Object.getPrototypeOf,
        R = Object.prototype.hasOwnProperty;
    var u = (e, t) => () => (e && (t = e(e = 0)), t);
    var T = (e, t) => () => (t || e((t = {
        exports: {}
    }).exports, t), t.exports);
    var E = (e, t, i, c) => {
        if (t && typeof t == "object" || typeof t == "function")
            for (let o of $(t)) !R.call(e, o) && o !== i && I(e, o, {
                get: () => t[o],
                enumerable: !(c = P(t, o)) || c.enumerable
            });
        return e
    };
    var N = (e, t, i) => (i = e != null ? C(S(e)) : {}, E(t || !e || !e.__esModule ? I(i, "default", {
        value: e,
        enumerable: !0
    }) : i, e));
    var d = (e, t, i) => new Promise((c, o) => {
        var l = n => {
                try {
                    a(i.next(n))
                } catch (s) {
                    o(s)
                }
            },
            r = n => {
                try {
                    a(i.throw(n))
                } catch (s) {
                    o(s)
                }
            },
            a = n => n.done ? c(n.value) : Promise.resolve(n.value).then(l, r);
        a((i = i.apply(e, t)).next())
    });
    var k, m = u(() => {
        k = "WebPixel::Render"
    });
    var g, h = u(() => {
        m();
        g = e => shopify.extend(k, e)
    });
    var y = u(() => {
        h()
    });
    var x = u(() => {
        y()
    });
    var w = T(f => {
        x();

        function _(e, t) {
            e = e.replace(/[\[\]]/g, "\\$&");
            let i = new RegExp("[?&]" + e + "(=([^&#]*)|&|#|$)", "i"),
                c = i.exec(t);
            return c ? c[2] ? decodeURIComponent(c[2].replace(/\+/g, " ")) : "" : null
        }

        function D(e) {
            return d(this, null, function*() {
                yield fetch("https://trkapi.impact.com/PageLoad", {
                    keepalive: !0,
                    method: "post",
                    headers: {
                        "Content-Type": "application/json"
                    },
                    body: JSON.stringify(e)
                }).then(t => console.log(t.status)).catch(t => console.error(t))
            })
        }

        function O(e, t) {
            return d(this, null, function*() {
                yield fetch(e, {
                    keepalive: !0,
                    mode: "no-cors",
                    method: "post",
                    headers: {
                        "Content-Type": "application/json"
                    },
                    body: JSON.stringify(t)
                }).then(i => console.log(i.status)).catch(i => console.error(i))
            })
        }

        function U(e, t, i, c) {
            return d(this, null, function*() {
                let o = new Date;
                o.setTime(o.getTime() + c * 24 * 60 * 60 * 1e3);
                let l = "expires=" + o.toUTCString();
                yield e.cookie.set(`${t}=${i}; expires=${l}; path=/; SameSite=Lax; Secure=true;`)
            })
        }

        function p(e, t) {
            return d(this, null, function*() {
                let i = yield e.cookie.get(t);
                if (t === "IR_PI") return i;
                if (t !== "irclickid" && i !== "") {
                    let c = i.match(/\|([^|]+)\|$/);
                    return c ? c[1] : null
                }
                return i
            })
        }
        g(c => d(f, [c], function*({
            analytics: e,
            browser: t,
            settings: i
        }) {
            let {
                externalExecutionURL: o,
                campaignID: l
            } = i;
            e.subscribe("page_viewed", r => d(f, null, function*() {
                let a = _("irclickid", r.context.window.location.href) || _("im_ref", r.context.window.location.href);
                a && U(t, "irclickid", a, 30);
                let n = (yield p(t, "irclickid")) || (yield p(t, `IR_${l}`)),
                    s = yield p(t, "IR_PI");
                yield D({
                    CampaignId: parseInt(l),
                    PageUrl: r.context.window.location.href,
                    EventDate: r.timestamp,
                    ReferringUrl: r.context.document.referrer,
                    CustomProfileId: r.clientId,
                    UserAgent: r.context.navigator.userAgent,
                    ClickId: n,
                    IntegrationSource: "Shopify",
                    FirstPartyCookie: s
                })
            })), e.subscribe("checkout_completed", r => d(f, null, function*() {
                let a = (yield p(t, "irclickid")) || (yield p(t, `IR_${l}`)),
                    n = r.data.checkout.order.id.toString().match(/\d+/g).join(""),
                    s = yield p(t, "IR_PI");
                yield O(`${o}?irclickid=${a}&client_id=${r.clientId}&order_id=${n}&first_party_cookie=${s}`, {
                    client_id: r.clientId,
                    order_id: n,
                    irclickid: a,
                    first_party_cookie: s
                })
            }))
        }))
    });
    var z = N(w());
})();