var customer_vip = "";
var customer_loggedin = false;

var promotion_name = "";
var currentPromotion = false;
var activePromotion = {};
var utm_sr_campaign = "";

function getUrlVars() {
    var vars = {};
    window.location.href.replace(
        /[?&]+([^=&]+)=([^&]*)/gi,
        function(m, key, value) {
            vars[key] = value;
        }
    );
    return vars;
}

function isCartPage() {
    return window.location.pathname.indexOf("cart") > -1;
}

window.specialVariants = {
    "pro-polarized": [
        "pro-polarized",
        "pro-polarized-small",
        "pro-polarized-standard",
    ],
    colorush: ["colorush", "colorush-standard", "colorush-small"],
};

function isHomePage() {
    return window.location.pathname === "/";
}

function setCookieWithExpiry(name, value, expires = 1.5) {
    return Cookies.set(name, value, {
        expires
    });
}

function getUrlParam(parameter, defaultValue = false) {
    var urlParameter = defaultValue;
    if (window.location.href.indexOf(parameter) > -1) {
        urlParameter = getUrlVars()[parameter];
    }
    return urlParameter;
}

function inIframe() {
    try {
        return window.self !== window.top;
    } catch (e) {
        return true;
    }
}

window.BLACKLISTED_COUPON_CODES = ["LD23", "JULY4-2024", "JULY4-2024-30"];

window.autoApplyCouponCode = function(discount_code = "", expires = 7) {
    const anchor = document.getElementById("markdown-anchor");
    if (inIframe()) {
        return;
    }
    const current_discount = Cookies.get("markdown_discount_code") || "";
    const markdowns = Cookies.getJSON("markdown_object") || [];
    const mardownsWithCode = markdowns.filter((x) => x.markdown_discount_code);
    const mardownCode = mardownsWithCode.length ?
        mardownsWithCode[0].markdown_discount_code :
        "";
    let code = discount_code || mardownCode || current_discount;
    let d_code = markdowns.filter(x => x.markdown_discount_code && x.markdown_auto_apply_coupon === true).map(x => x.markdown_discount_code);

    if (d_code) {
        let arr_code = '';
        code = '';

        arr_code = decodeURIComponent(d_code);
        if (arr_code.includes(",")) {
            code = arr_code.split(",");
            code = code[0];
        } else {
            code = arr_code;
        }
        console.log('apply code ', code);
    }

    const applied_discount = Cookies.get("discount_code") || "";
    const code_applied = Cookies.get("discount_code_applied") === code;

    //console.log('is apply', d_code);
    //console.log({discount_code, mardownCode, current_discount});

    if (!code || BLACKLISTED_COUPON_CODES.includes(code)) return;
    setCookieWithExpiry("markdown_discount_code", code, expires);

    if (!applied_discount || !code_applied || applied_discount !== code) {
        //console.log('Code applied', code);
        if (anchor) {
            const frame = document.createElement("iframe");
            frame.src = `https://shadyrays.com/discount/${code}`;
            frame.style = "width:0;height:0;border:0;border:none;position:absolute;";
            anchor.innerHTML = "";
            anchor.appendChild(frame);
            setCookieWithExpiry("discount_code_applied", code, expires);
        }
    }
};

// VanityURL Class

const dis_codes = [{
        dis: 40,
        code: "TAKE40OFF",
    },
    {
        dis: 45,
        code: "TAKE45OFF",
    },
];

let static_map = {
    "shade-shop": {
        url: "/collections/shade-shop",
        title: "Sunglasses",
    },
    "blue-light": {
        url: "/collections/blue-light",
        title: "Blue Light",
    },
    kids: {
        url: "/collections/kids",
        title: "Kids",
    },
    "snow-goggles": {
        url: "/collections/snow-goggles",
        title: "Snow",
    },
};


let col_map = {
    ...theme.globals.allCollections,
    ...static_map,
};

const selectors = {
    cart_promotion: 'div[data-promotion-id="promotion-cart-code-instruction"]',
    cart_upsell: 'div[data-promotion-id="promotion-cart-upsell"]',
    collection_prop: 'input[name="properties[_theme.globals.productCollections]"]',
    special_msg: ".special-message",
    checkout_msg: "#Checkout-Message",
    mystery_pair_btn: 'button[data-promotion-id="promotion-cart-mystery-pair"]',
    hardcase_section: ".add-hard-cover-section",
    hardcase_checkbox: "#hard-case-checkbox",
    basket_right: "#basket-right",
    markdown_reminder: "#markdown-reminder",
    vu_countdown_expiry: "vu_countdown_expiry",
    timer: "#shipTodayMsg",
    aws_url: "https://warranty-production-files.s3.amazonaws.com",
};

class VanityURL {
    /**
       * @module VanityURL
       * Modifying the content on the website with help
    	  of special parameter in the URL
      */

    arrayParams = ["vu_col"];

    intParams = [
        "vu_init",
        "vu_dt",
        "vu_tl",
        "vu_mxp",
        "vu_cexp",
        "vu_ul",
        "vu_gif",
        "vu_st",
        "vu_ac",
        "vu_nx",
        "vu_atemp",
        "vu_temp",
        "vu_ab_cntrl",
        "vu_pdp",
        "vu_up2",
        "vu_hc",
        "vu_mp",
        "vu_disabled",
    ];

    terminationCodes = [false, "clear"];

    disabledPromoCodes = ["SPRING2023", "JULYBOGO"];

    AB_Distribution = {
        0: 0.0,
        1: 0.05,
        2: 0.1,
        3: 0.2,
        4: 0.3,
        5: 0.4,
        6: 0.5,
    };

    /** @constructor */
    constructor() {}

    /**
     * @desc Variable mapping is used for assigning the initial values for parameters
     * Syntax:-
     * {
     * 		key:{
     * 			val: "initial value",
     * 			action: function(){
     * 				**Do something
     * 			}
     * 		}
     * }
     * key: The key which is present in URL or Cookies
     * initial value: Any value assigned to the key depending on the key
     */

    vo = {
        vu_disabled: {
            val: 0
        },

        vu_id: {
            val: 0
        },

        vu_countdown_expiry: {
            val: 0
        },

        vu_init: {
            val: 0
        },

        vu_cc: {
            val: false
        },

        vu_dis: {
            val: 0
        },

        vu_col: {
            val: ["all"]
        },

        vu_dt: {
            val: 0
        },

        vu_tl: {
            val: 1
        },

        vu_mxm: {
            val: "You can buy NUM more product(s) with this offer."
        },

        vu_mxp: {
            val: 0
        },

        vu_cexp: {
            val: 0
        },

        vu_ul: {
            val: 1
        },

        vu_gif: {
            val: 0
        },

        vu_exp: {
            val: 0
        },

        vu_cet: {
            val: 0
        },

        vu_ced: {
            val: 0
        },

        vu_created_at: {
            val: new Date()
        },

        vu_gt: {
            val: ""
        },

        vu_uc: {
            val: "all"
        },

        vu_ctm: {
            val: "Your offer is going to expire in"
        },

        vu_st: {
            val: 0
        },

        vu_ac: {
            val: 0
        },

        vu_acm: {
            val: ""
        },

        vu_nx: {
            val: 0
        },

        vu_atemp: {
            val: 1
        },

        vu_temp: {
            val: 1
        },

        vu_ab_cntrl: {
            val: 1
        },

        vu_pdp: {
            val: 0
        },

        vu_tb: {
            val: ""
        },

        vu_ab_al: {
            val: 0
        },

        vu_dist_per: {
            val: 0
        },

        vu_splm: {
            val: "",
            action: function() {
                if (!this.val) {
                    return;
                }

                const text = this.val.split("|");
                const cart_promotion = document.querySelector(selectors.cart_promotion);
                if (!cart_promotion.length) {
                    return;
                }

                document.querySelector(selectors.special_msg).remove();

                cart_promotion.before(`
				<div data-promotion-id="promotion-cart-code-instruction" class="special-offer__tags special-message">
					<div>
						<h3><strong>${text[0].replaceAll("percent", "%")}</strong></h3>
						<p>${text[1].replaceAll("percent", "%")}</p>
					</div>
				</div>`);
            },
        },

        vu_up2: {
            val: 1,
            action: function() {
                if (!this.val) document.querySelector(selectors.checkout_msg).remove();
            },
        },

        vu_hc: {
            val: 1,
            action: function() {
                if (this.val) {
                    const hardcaseSection = document.querySelector(
                        selectors.hardcase_section
                    );
                    const hardcaseCheckbox = document.querySelector(
                        selectors.hardcase_checkbox
                    );

                    if (hardcaseSection) hardcaseSection.style.display = "block";
                    if (hardcaseCheckbox) hardcaseCheckbox.checked = true;
                } else {
                    const hardcaseSection = document.querySelector(
                        selectors.hardcase_section
                    );
                    const hardcaseCheckbox = document.querySelector(
                        selectors.hardcase_checkbox
                    );
                    const cartAccordion = document.querySelector(".cart-accordian");

                    if (hardcaseSection) hardcaseSection.style.display = "none";
                    if (hardcaseCheckbox) hardcaseCheckbox.checked = false;
                    if (cartAccordion) cartAccordion.classList.add("hidden");
                }
            },
        },

        vu_mp: {
            val: 1,
            action: function() {
                const mystery_pair = document.querySelector(selectors.mystery_pair_btn);
                if (!mystery_pair) return;
                if (this.val && this.val > 0) {
                    mystery_pair.classList.remove("hidden");
                } else {
                    mystery_pair.classList.add("hidden");
                }
            },
        },

        vu_cr: {
            val: "",
            action: function() {
                if (this.val && this.val !== "") {
                    var text = this.val.split("|");
                    var basketRight = document.querySelector(selectors.basket_right);

                    if (!basketRight) {
                        return;
                    }

                    var couponReminder = document.querySelector(".coupon-reminder");
                    if (couponReminder) {
                        couponReminder.remove();
                    }

                    var div = document.createElement("div");
                    div.classList.add("special-offer__tags", "coupon-reminder");

                    var innerHTML = `
					<div>
						<h3><strong>${text[0].replaceAll("percent", "%")}</strong></h3>
						<p>${text[1].replaceAll("percent", "%")}</p>
					</div>`;
                    div.innerHTML = innerHTML;
                    basketRight.insertAdjacentHTML('afterbegin', div);
                }
            },
        },
    };

    getData(key) {
        return this.intParams.indexOf(key) > -1 ?
            parseInt(this.vo[key].val) :
            this.vo[key].val;
    }

    setData(key, value) {
        if (!(key in this.vo)) return;
        this.vo[key].val =
            this.arrayParams.indexOf(key) > -1 ? value.split(",") : value;
        setCookieWithExpiry(key, value);
    }

    eligibleCollections() {
        return this.getData("vu_col")
            .map((h) => (col_map[h] ? col_map[h].title : ""))
            .join(", ");
    }

    showGstMessage() {
        let m = "";
        const vu_atemp = parseInt(this.getData("vu_atemp"));
        const vu_tl = this.getData("vu_tl");
        const vu_cc = this.getData("vu_cc");

        switch (vu_atemp) {
            case 1:
                m =
                    (vu_tl > 1 ? `MINIMUM ${vu_tl} ITEMS IN CART: ` : "") +
                    `ALL PRICING DISPLAYED ARE DISCOUNTED PRICE WITH ${vu_cc} COUPON CODE`;
                break;
            case 2:
                m = `ALL PRICING DISPLAYED ARE DISCOUNTED PRICE WITH ${vu_cc} COUPON CODE`;
                break;
            case 3:
                m = `ALL PRICING DISPLAYED ARE DISCOUNTED PRICE WITH ${vu_cc} COUPON CODE Excludes RX`;
                break;
            case 4:
                m =
                    (vu_tl > 1 ? `MINIMUM ${vu_tl} ITEMS IN CART: ` : "") +
                    `ALL PRICING DISPLAYED ARE DISCOUNTED PRICE WITH ${vu_cc} COUPON CODE Excludes RX`;
                break;
            default:
                m =
                    (vu_tl > 1 ? `MINIMUM ${vu_tl} ITEMS IN CART: ` : "") +
                    `ALL PRICING DISPLAYED ARE DISCOUNTED PRICE WITH ${vu_cc} COUPON CODE`;
                break;
        }

        if (vu_cc == "222BOGO") {
            // 222BOGO
            m = `MINIMUM 2 ITEMS IN CART: ALL PRICING DISPLAYED ARE DISCOUNTED PRICE WITH 222BOGO COUPON CODE`;
        } else if (vu_cc == "FORTY2022") {
            //FORTY2022
            m = `MINIMUM 2 ITEMS IN CART: ALL PRICING DISPLAYED ARE DISCOUNTED PRICE WITH FORTY2022 COUPON CODE`;
        } else if (vu_cc == "LASTSHOT2022") {
            //LASTSHOT2022
            m = `ALL PRICING DISPLAYED ARE DISCOUNTED PRICE WITH LASTSHOT2022 COUPON CODE`;
        } else if (vu_cc == "SPD20") {
            //SPD20
            m = `ALL PRICING DISPLAYED ARE DISCOUNTED PRICE WITH SPD20 COUPON CODE`;
        } else if (vu_cc == "SPRING35") {
            //SPRING35
            m = `ALL PRICING DISPLAYED ARE DISCOUNTED PRICE WITH SPRING35 COUPON CODE`;
        } else if (vu_cc == "SHADES30OFF") {
            //SHADES30OFF
            m = `ALL PRICING DISPLAYED ARE DISCOUNTED PRICE WITH SHADES30OFF COUPON CODE Excludes RX`;
        } else if (vu_cc == "PMT2022") {
            //PMT2022
            m = `MINIMUM 2 ITEMS IN CART: ALL PRICING DISPLAYED ARE DISCOUNTED PRICE WITH PMT2022 COUPON CODE Excludes RX`;
        } else if (vu_cc == "FORE2022") {
            //FORE2022
            m = `MINIMUM 2 ITEMS IN CART: ALL PRICING DISPLAYED ARE DISCOUNTED PRICE WITH FORE2022 COUPON CODE Excludes RX`;
        } else if (vu_cc == "KFC2022") {
            //KFC2022
            m = `MINIMUM 2 ITEMS IN CART: ALL PRICING DISPLAYED ARE DISCOUNTED PRICE WITH KFC2022 COUPON CODE Excludes RX`;
        } else if (vu_cc == "CHICLETS2022") {
            //CHICLETS2022
            m = `MINIMUM 2 ITEMS IN CART: ALL PRICING DISPLAYED ARE DISCOUNTED PRICE WITH CHICLETS2022 COUPON CODE Excludes RX`;
        } else if (vu_cc == "2022FANTASY") {
            //2022FANTASY
            m = `MINIMUM 2 ITEMS IN CART: ALL PRICING DISPLAYED ARE DISCOUNTED PRICE WITH 2022FANTASY COUPON CODE Excludes RX`;
        } else if (vu_cc == "2022NASCAR") {
            //2022NASCAR
            m = `MINIMUM 2 ITEMS IN CART: ALL PRICING DISPLAYED ARE DISCOUNTED PRICE WITH 2022NASCAR COUPON CODE Excludes RX`;
        } else if (vu_cc == "2022MLB") {
            //2022MLB
            m = `MINIMUM 2 ITEMS IN CART: ALL PRICING DISPLAYED ARE DISCOUNTED PRICE WITH 2022MLB COUPON CODE Excludes RX`;
        } else if (vu_cc == "2022PGA") {
            //2022PGA
            m = `MINIMUM 2 ITEMS IN CART: ALL PRICING DISPLAYED ARE DISCOUNTED PRICE WITH 2022PGA COUPON CODE Excludes RX`;
        } else if (vu_cc == "2022XM") {
            //2022PGA
            m = `MINIMUM 2 ITEMS IN CART: ALL PRICING DISPLAYED ARE DISCOUNTED PRICE WITH 2022XM COUPON CODE Excludes RX`;
        } else if (vu_cc == "2022BOSTONRADIO") {
            //2022BOSTONRADIO
            m = `MINIMUM 2 ITEMS IN CART: ALL PRICING DISPLAYED ARE DISCOUNTED PRICE WITH 2022BOSTONRADIO COUPON CODE Excludes RX`;
        } else if (vu_cc == "FIFTY2022") {
            //FIFTY2022
            m = `MINIMUM 2 ITEMS IN CART: ALL PRICING DISPLAYED ARE DISCOUNTED PRICE WITH FIFTY2022 COUPON CODE Excludes RX`;
        } else if (this.getData("vu_cc") == "AT20") {
            m = `20% OFF ON SUNGLASSES | Use code: AT20`;
        } else if (this.getData("vu_cc") == "ANNIVERSARY") {
            m = `ANNIVERSARY SALE •  30% OFF ALL SHADES • USE CODE: ANNIVERSARY`;
        }

        this.setData("vu_acm", m);

        const topDiscountNoteHTML = `
		<div id="top-discount-note" class="top-discount-note text-center title">
			<span id="vanity-url-message" class="vanity-url-message">${m}</span>
		</div>`;

        var template = theme.globals.template;
        const topDiscountNote = document.querySelector("#top-discount-note");
        if (topDiscountNote) {
            topDiscountNote.remove();
        }

        if (template.includes("cart")) {
            var cartForm = document.querySelector("#cartform");
            if (cartForm) {
                cartForm.insertAdjacentHTML('beforebegin', topDiscountNoteHTML);
            }
        } else if (template.includes("index")) {
            const rtbsSection = document.querySelector(".section-sr-slideshow");
            if (rtbsSection) {
                rtbsSection.insertAdjacentHTML('afterend', topDiscountNoteHTML);
            }
        } else {
            var shadeShopCollectionTitle = document.querySelector(".collection-title");
            if (shadeShopCollectionTitle) {
                shadeShopCollectionTitle.insertAdjacentHTML('beforebegin', topDiscountNoteHTML);
            }
        }
        this.showMaxLimitMessage();
    }

    showTopbarMessage() {
        let m = "";
        let vu_temp = parseInt(this.getData("vu_temp"));
        let vu_cc = this.getData("vu_cc");
        let vu_tl = this.getData("vu_tl");
        let collections = this.eligibleCollections();
        if (!collections && vu_cc == 'UV60T') {
            collections = "uv protection shirts";
        }
        let discount =
            this.getData("vu_dt") == 1 ?
            `$${this.getData("vu_dis")}` :
            `${this.getData("vu_dis")}%`;

        switch (vu_temp) {
            case 1:
                m =
                    `${discount} OFF ` +
                    (vu_tl > 1 ? `${vu_tl}+ PAIRS` : "") +
                    ` On ${collections} | CODE: ${vu_cc}`;
                break;
            case 2:
                m =
                    `SPECIAL OFFER : ${discount} OFF ` +
                    (vu_tl > 1 ? `${vu_tl}+ PAIRS` : "") +
                    ` On ${collections}`;
                break;
            case 3:
                m = `LIMITED TIME OFFER: ${discount} OFF ALL SHADES`;
                break;
            case 4:
                m = `Summer Exclusive: ${discount} OFF ALL SHADES`;
                break;
            default:
                m =
                    `${discount} OFF ` +
                    (vu_tl > 1 ? `${vu_tl}+ PAIRS` : "") +
                    ` On ${collections} | CODE: ${vu_cc}`;
                break;
        }

        if (this.getData("vu_cc") == "222BOGO") {
            // 222BOGO
            m = `50% OFF 2+ PAIRS On SUNGLASSES | CODE: 222BOGO`;
        } else if (this.getData("vu_cc") == "FORTY2022") {
            //FORTY2022
            m = `SPECIAL OFFER : 40% OFF 2+ PAIRS On SUNGLASSES & BLUE LIGHT`;
        } else if (this.getData("vu_cc") == "FIFTY2022") {
            //FIFTY2022
            m = `SPECIAL OFFER : 50% OFF 2+ PAIRS On SUNGLASSES`;
        } else if (this.getData("vu_cc") == "LASTSHOT2022") {
            //LASTSHOT2022
            m = `SPECIAL OFFER : $24 OFF On SUNGLASSES`;
        } else if (this.getData("vu_cc") == "SPD20") {
            //SPD20
            m = `SPECIAL OFFER : $20 OFF On ST. PATRICK'S DAY COLLECTION`;
        } else if (this.getData("vu_cc") == "SPRING35") {
            //SPRING35
            m = `SPECIAL OFFER : 35% OFF On BEST SELLERS`;
        } else if (this.getData("vu_cc") == "SHADES30OFF") {
            //SHADES30OFF
            m = `LIMITED TIME OFFER: 30% OFF ALL SHADES`;
        } else if (this.getData("vu_cc") == "PMT2022") {
            //PMT2022
            m = `50% OFF 2+ PAIRS - SUNGLASSES`;
        } else if (this.getData("vu_cc") == "FORE2022") {
            //FORE2022
            m = `50% OFF 2+ PAIRS - SUNGLASSES`;
        } else if (this.getData("vu_cc") == "KFC2022") {
            //KFC2022
            m = `50% OFF 2+ PAIRS - SUNGLASSES`;
        } else if (this.getData("vu_cc") == "CHICLETS2022") {
            //CHICLETS2022
            m = `50% OFF 2+ PAIRS - SUNGLASSES`;
        } else if (this.getData("vu_cc") == "2022FANTASY") {
            //2022FANTASY
            m = `50% OFF 2+ PAIRS - SUNGLASSES`;
        } else if (this.getData("vu_cc") == "2022NASCAR") {
            //2022NASCAR
            m = `50% OFF 2+ PAIRS - SUNGLASSES`;
        } else if (this.getData("vu_cc") == "2022MLB") {
            //2022MLB
            m = `50% OFF 2+ PAIRS - SUNGLASSES`;
        } else if (this.getData("vu_cc") == "2022PGA") {
            //2022PGA
            m = `50% OFF 2+ PAIRS - SUNGLASSES`;
        } else if (this.getData("vu_cc") == "2022XM") {
            //2022PGA
            m = `50% OFF 2+ PAIRS FROM SUNGLASSES & BLUE LIGHT`;
        } else if (this.getData("vu_cc") == "2022BOSTONRADIO") {
            //2022BOSTONRADIO
            m = `50% OFF 2+ PAIRS - SUNGLASSES`;
        } else if (this.getData("vu_cc") == "FLASH35") {
            //FLASH35
            m = `SPECIAL OFFER : 35% OFF ON Women's Collection`;
        } else if (this.getData("vu_cc") == "WOMEN50") {
            //WOMEN50
            m = `50% OFF 2+ PAIRS ON Women's Collection | CODE: WOMEN50`;
        } else if (this.getData("vu_cc") == "JULYBOGO") {
            m = `Buy One Get One Free | Use code: JULYBOGO`;
        } else if (this.getData("vu_cc") == "AT20") {
            m = `20% OFF ON SUNGLASSES | Use code: AT20`;
        } else if (this.getData("vu_cc") == "ANNIVERSARY") {
            m = `ANNIVERSARY SALE •  30% OFF ALL SHADES • USE CODE: ANNIVERSARY`;
        }

        const vu_tb = this.getData("vu_tb");
        if (!vu_tb) {
            this.setData("vu_tb", m);
        } else {
            m = vu_tb;
        }
        const code = this.getData("vu_cc");
        var topBanner = document.querySelector(".announcement__text");
        if (topBanner) {
            topBanner.classList.add("vanity--announcement__text");
            if (code === "ANNIV24" || code === "ANNIV24CR" || code === "ANNIVERSARY") {
                topBanner.innerHTML = `
				<div class="usa-store-only summer-promotion-default" id="topBannerUSA">
					<span >Anniversary sale •</span> 
					<span>30% off</span> all shades • 
					<a href="/collections/men-all-styles">Shop men</a> • 
					<a href="/collections/women-all-styles">Shop women</a>
				</div>`;

                var bannerTop = document.querySelector(".bannertop");
                if (bannerTop) {
                    bannerTop.classList.add("bannertop-anniversary");
                }
            } else {
                topBanner.innerHTML = m;
            }
        }

        var vipItemOnly = document.querySelector("#banner-message .vip-item-only");
        if (vipItemOnly) {
            vipItemOnly.remove();
        }
    }

    stop() {
        this.vo.vu_init.val = 0;
        for (var key in this.vo) {
            Cookies.remove(key);
        }
        Cookies.remove("currentPromotion");
        Cookies.remove("vanity_in_cookie");
        Cookies.remove("vanity_expiry");
        MarkdownPricePro.clear("vanity-markdown");
    }

    applyOnlyCode(discount_code) {
        autoApplyCouponCode(discount_code);
    }

    initMarkdown() {

        const discount =
            this.getData("vu_dt") == 1 ?
            parseInt(this.getData("vu_dis")) :
            1 - parseInt(this.getData("vu_dis")) / 100;
        const code = this.getData("vu_cc");
        const markdown = {
            discount_code: code,
            multiplier: discount,
            collections: this.getData("vu_col"),
            subtract: this.getData("vu_dt") == 1 ? true : false,
            id: "vanity-markdown",
        };

        console.log('Vanity collection object', markdown);

        if (code !== "MDW" && code !== "OPENING") {
            if (code === "ANNIV24" || code === "ANNIV24CR") {
                markdown.specialVariants = specialVariants.colorush;
                markdown.specialMultiplier = 1;
            }
            MarkdownPricePro.init(markdown);
        } else {
            this.stop();
        }
    }

    callActions() {
        const vo = this.vo;

        Object.values(vo)
            .filter((item) => "action" in item)
            .forEach((item) => item.action());

        const {
            vu_cc,
            vu_ac,
            vu_gif,
            vu_ul,
            vu_uc
        } = this.vo;

        this.showMessage();

        if (vu_cc.val) {
            if (vu_ac.val == 1) {
                this.showGstMessage();
            }

            this.showTopbarMessage();

            // Initialise Markdown
            this.initMarkdown();
        }
        if (vu_gif.val && vu_gif.val != 0) {
            this.updateGiftBox();

            updatePromotionalGiftItem(vu_gif.val, vu_ul.val, vu_uc.val, "");
        }
    }

    getUpsell2Message(cartdata = null) {
        const markdownReminder = document.querySelector(selectors.markdown_reminder);
        if (markdownReminder) {
            markdownReminder.remove();
        }

        if (this.terminationCodes.includes(this.getData("vu_cc"))) {
            return "";
        }

        var collectionData = this.getData("vu_col");
        const actual_cart_items = getActualCartItems(collectionData);

        let collection_links = collectionData
            .map((h) => col_map[h] ?
                `<a style="text-decoration: underline;display:inline-block !important;margin: 0;" href="/collections/${h}">${col_map[h].title}</a>` :
                ""
            ).join(", ");
        const current_discount = this.getData("vu_dis");
        const threshold = parseInt(this.getData("vu_tl"));
        const discount = this.getData("vu_dt") == 1 ?
            `$${current_discount}` :
            `${current_discount}%`;

        if (this.getData("vu_nx") == 0) {
            if (actual_cart_items >= threshold) {
                const code = this.getData("vu_cc");
                if (code === "AT20") {
                    return `
					<div class="special-offer__tags sr-promo-box-wrapper" id="markdown-reminder">
						<div class="discount-content">
							<h3><strong>Exclusive Offer!</strong></h3>
							<p>Use Code: <strong>${code}</strong>
							at checkout for 20% OFF.</p>
							<div class="shop-men-women flex justify-center">
								<a href="/collections/men-all-styles">Shop Mens</a>
								<span>|</span>
								<a href="/collections/women-all-styles">Shop Womens</a>
							</div>
						</div>
					</div>`;
                } else if (code === "ANNIV24" || code === "ANNIV24CR") {
                    return `
					<div class="special-offer__tags" id="markdown-reminder">
						<div>
							<h3><strong>Exclusive Offer!</strong></h3>
							<p>Use Code: <strong>${code}</strong>
							at checkout for 30% off each pair from Sunglasses. <br>
							<a href="/collections/men-all-styles"><u>Shop Mens</u></a> |
								<a href="/collections/women-all-styles"><u>Shop Womens</u></a>
							<br><small>
								<em>*Excludes Green Wolf and Colorush</em>
							</small>
							</p>
						</div>
					</div>`;
                } else {
                    return `
					<div class="special-offer__tags" id="markdown-reminder">
						<div>
							<h3><strong>DEAL MET!</strong></h3>
							<p>Use Code: <strong>${code}</strong>
							at checkout for ${discount} off each pair from ${collection_links}.
							<br><small>
								<em>Offer cannot be combined with other coupons</em>
							</small>
							</p>
						</div>
					</div>`;
                }
            }

            if (actual_cart_items > 0) {
                return `
				<div class="special-offer__tags" id="markdown-reminder">
					<div>
						<h3 style="text-transform: uppercase;">
						<strong>Only ${actual_cart_items} Pair?</strong>
						</h3>
						<p>Grab one more pair from ${collection_links}
						for <strong>${discount} OFF</strong> both pairs!
						<br>
						<small>
							<em>Offer cannot be combined with other coupons</em>
						</small>
						</p>
					</div>
				</div>`;
            }
        } else {
            const dis_codes = this.nextCodeSetting();
            const up_2 = dis_codes.filter((x) => x.dis > current_discount);
            if (up_2.length) {
                if (actual_cart_items >= threshold + 1) {
                    return `
					<div class="special-offer__tags" id="markdown-reminder">
						<h3 id="memQualified">
							<strong>DEAL MET!</strong>
						</h3>
						<p>Use Code:
							<strong>${up_2[0].code}</strong>
							at checkout for ${up_2[0].dis}% off each pair from ${collection_links}.
							<br><small>
							<em>Offer cannot be combined with other coupons</em>
							</small>
						</p>
					</div>`;
                }

                if (actual_cart_items > 0) {
                    return `
					<div class="special-offer__tags" id="markdown-reminder">
						<h3><strong>ONLY ONE PAIR?</strong></h3>
						<p>Grab one more pair from
							${collection_links} for <strong>${up_2[0].dis}% OFF</strong>
							both pairs! <br><small>
							<em>Offer cannot be combined with other coupons</em>
							</small>
						</p>
					</div>`;
                }
            }
        }
    }

    nextCodeSetting() {
        const customSetting = {
            SPRING2023: {
                dis: 35,
                code: "2SPRING35",
            },
        };

        for (const code in customSetting) {
            const codeObj = customSetting[code];
            const found = dis_codes.find((x) => x.code === codeObj.code);
            if (this.getData("vu_cc") == code && !found) {
                dis_codes.push(codeObj);
            }
        }

        return dis_codes.sort((a, b) => a.dis - b.dis);
    }

    showMessage() {
        var basketRight = document.querySelector(selectors.basket_right);
        if (basketRight) {
            const cartMarkdownReminder = this.getUpsell2Message();
            if (cartMarkdownReminder) {
                basketRight.insertAdjacentHTML('afterbegin', cartMarkdownReminder);
            }
        }

        var checkoutMsg = document.querySelector(selectors.checkout_msg);
        if (checkoutMsg) {
            checkoutMsg.remove();
        }
    }

    showPdpBox(pid, cartdata) {
        if (!pid) return;

        var pdpBox = document.querySelector(".pdp-box");
        if (pdpBox) {
            pdpBox.innerHTML = "";
        }

        if (this.getData("vu_pdp") == 1) {
            var upsellFormHandler = document.querySelector(".upsell-form-handler");
            var kidsUpsellWrapper = document.querySelector(".kids-upsell-wrapper");
            if (upsellFormHandler) {
                upsellFormHandler.style.display = "none";
            }
            if (kidsUpsellWrapper) {
                kidsUpsellWrapper.style.display = "none";
            }

            if (pdpBox) {
                pdpBox.innerHTML = this.getUpsell2Message(cartdata);
            }
        }
    }

    showMaxLimitMessage() {
        const vu_mxp = this.getData("vu_mxp");
        var maxLimitReminder = document.querySelector("#max-limit-reminder");
        if (maxLimitReminder) {
            maxLimitReminder.remove();
        }

        if (!vu_mxp) {
            return;
        }

        if (
            theme.globals.cartItems &&
            this.terminationCodes.indexOf(this.getData("vu_cc")) === -1
        ) {
            const collectionData = this.getData("vu_col");
            const actualCartItems = getActualCartItems(collectionData);
            if (actualCartItems < vu_mxp) {
                let mxm = this.getData("vu_mxm").replace("NUM", vu_mxp - actualCartItems);
                if (this.getData("vu_cc") == "JULYBOGO") {
                    mxm = `YOU CAN BUY UPTO 4 SHADES WITH THIS OFFER.`;
                }

                var messageSpan = document.createElement("span");
                messageSpan.classList.add("vanity-url-message", "maximum-limit");
                messageSpan.textContent = mxm;

                var topDiscountNoteEl = document.getElementById("top-discount-note");
                if (topDiscountNoteEl) {
                    topDiscountNoteEl.classList.add("flex-column");
                    topDiscountNoteEl.appendChild(messageSpan);
                }
            }
        }
    }

    updateGiftBox() {
        var freeItem = theme.globals.cartItems.filter(
            (x) => x.id == this.getData("vu_gif") && x.line_price == 0
        );

        if (!this.getData("vu_splm") && freeItem.length === 0) {
            const collections = this.eligibleCollections();

            var specialMsg = document.querySelector(selectors.special_msg);
            if (specialMsg) {
                specialMsg.remove();
            }

            var cartBlock = document.querySelector(".cart-block");
            if (cartBlock) {
                var div = document.createElement("div");
                div.setAttribute(
                    "data-promotion-id",
                    "promotion-cart-code-instruction"
                );
                div.classList.add("special-offer__tags", "special-message");

                var innerHTML = `
                <div>
                    <h3><strong>Free Gift!</strong></h3>
                    <p>Get free
                    <strong>${this.getData("vu_gt")}</strong>
                    on purchase of any ${this.getData("vu_ul")} items from
                    <span style="text-decoration:underline;">${collections}</span>
                    </p>
                </div>
            `;
                div.innerHTML = innerHTML;
                cartBlock.parentElement.insertBefore(div, cartBlock);
            }
        }
    }

    getTimeRemaining(endtime) {
        const total = Date.parse(endtime) - Date.parse(new Date());
        const seconds = Math.floor((total / 1000) % 60);
        const minutes = Math.floor((total / 1000 / 60) % 60);
        const hours = Math.floor((total / (1000 * 60 * 60)) % 24);
        const days = Math.floor(total / (1000 * 60 * 60 * 24));

        return {
            total,
            days,
            hours,
            minutes,
            seconds,
        };
    }

    initializeClock() {
        const self = this;
        const vu_countdown_expiry = Cookies.get(selectors.vu_countdown_expiry);
        const endtime = new Date(
            Date.parse(vu_countdown_expiry) + 0 * 24 * 60 * 60 * 1000
        );

        function _slice(val) {
            return ("0" + val).slice(-2);
        }

        function updateClock() {
            const t = self.getTimeRemaining(endtime);

            var timeleft = `${t.days}D ${_slice(t.hours)}H ${_slice(
				t.minutes
			)}M ${_slice(t.seconds)}S`;

            if (t.days == 0) {
                if (t.hours >= 1) {
                    timeleft = `${_slice(t.hours)}:${_slice(t.minutes)}:${_slice(
						t.seconds
					)}`;
                } else {
                    timeleft = `${_slice(t.minutes)}:${_slice(t.seconds)}`;
                }
            }

            const timerElement = document.querySelector(selectors.timer);
            if (timerElement) {
                const span = timerElement.querySelector("span");
                if (span) {
                    span.innerHTML = `${self.getData(
						"vu_ctm"
					)}<span class="timeleft">${timeleft}</span>`;
                }
                timerElement.style.display = "block";
            }

            if (t.total <= 0) {
                clearInterval(timeinterval);
            }
        }

        updateClock();
        const timeinterval = setInterval(updateClock, 1000);
    }

    gaTrack(str, code) {
        var retryCounter = 0;

        function checkIfAnalyticsLoaded() {
            if (typeof gtag === "function" || retryCounter++ > 20) {
                gtag("event", "page_view", {
                    [str]: code
                });

                if (str === "Control") {
                    gtag("event", "pageview", {
                        dimension8: code
                    });
                }

                if (str === "Experiment") {
                    gtag("event", "pageview", {
                        dimension9: code
                    });
                }
            } else {
                setTimeout(checkIfAnalyticsLoaded, 2000);
            }
        }
        checkIfAnalyticsLoaded();
    }

    run() {
        Cookies.set("currentPromotion", "clear");

        if (!this.getData("vu_id")) {
            return this.stop();
        }

        setCookieWithExpiry("vanity_in_cookie", true);

        const vu_cc = this.getData("vu_cc");
        const vu_ab_al = this.getData("vu_ab_al");
        const vu_dist_per = this.getData("vu_dist_per");
        const percentage = this.AB_Distribution[this.getData("vu_ab_cntrl")];
        const vu_countdown_expiry = Cookies.get(selectors.vu_countdown_expiry);
        let user_type = Cookies.get("user_type") || false;

        if (vu_ab_al == 1) {
            const distribution = vu_dist_per / 100;
            if (!user_type) {
                if (Math.random() < distribution) {
                    user_type = "control";
                } else {
                    user_type = "test";
                }
            }

            if (user_type && user_type == "control") {
                Cookies.set("user_type", "control");
                this.vo.vu_mxp.val = 0;
                Cookies.remove("vu_mxp");
                this.gaTrack(`vanity_control`, vu_cc);
            } else {
                Cookies.set("user_type", "test");
                this.gaTrack(`vanity_test`, vu_cc);
            }
        }

        // Checking expiry date
        const vu_ced = parseInt(this.getData("vu_ced"));
        const vu_cet = this.getData("vu_cet");

        if (vu_ced && vu_cet) {
            if (!vu_countdown_expiry) {
                const vu_cet_array = vu_cet.split(":");
                let dt = new Date();
                dt.setDate(dt.getDate() + vu_ced);
                dt.setHours(dt.getHours() + parseInt(vu_cet_array[0]));
                dt.setMinutes(dt.getMinutes() + parseInt(vu_cet_array[1]));
                this.setData(selectors.vu_countdown_expiry, dt);
            }

            const now = new Date();
            const expiry_date = new Date(Cookies.get(selectors.vu_countdown_expiry));

            if (now > expiry_date) {
                return this.stop();
            }
        }

        if (this.getData("vu_st") == 1 && !theme.globals.template.contains("cart")) {
            this.initializeClock();
        }

        this.callActions();
    }

    /**
     * @param {INTEGER} type
     * 1 - Vanity enabled from URL
     * 0 - Vanity initialised from cookies
     */
    updateCookies(type, data = null) {
        let expired = false;
        const vanity_expiry_datetime = Cookies.get("vanity_expiry");

        if (vanity_expiry_datetime) {
            expired = new Date().getTime() > new Date(vanity_expiry_datetime).getTime();
        }

        if (expired) {
            return this.stop();
        }

        let vo = this.vo;

        for (let key in vo) {
            if (Object.hasOwnProperty.call(vo, key)) {
                if (key == selectors.vu_countdown_expiry) continue;

                let value =
                    type == 1 ?
                    key == "vu_created_at" ?
                    data.created_at :
                    data[key] :
                    Cookies.get(key);
                if (value) {
                    this.setData(key, value);
                } else {
                    Cookies.remove(key);
                }
            }
        }

        const expiry = new Date(Date.now() + 1.5 * 24 * 60 * 60 * 1000);
        setCookieWithExpiry(
            "vanity_expiry",
            expiry.toISOString(),
            parseInt(vo.vu_cexp)
        );
        this.run();
    }

    init(vanity_id = null) {
        console.info("Vanity URL initiated");

        const self = this;
        const vanity_in_cookie = Cookies.get("vanity_in_cookie") || false;
        const vu_id = getUrlParam("vu_id") || vanity_id || false;

        if (vu_id === "clear") {
            return self.stop();
        }

        if (vu_id) {
            self.getDataFromAWS(vu_id, vanity_id !== null);
        } else if (vanity_in_cookie === "true") {
            // If the URL does not contains vu_init or it's false then check in cookies
            const vu_cc = Cookies.get("vu_cc");

            // Flush the old cookies for AT20 if its not already flushed
            // Cookies.remove("vanity_cookie_flushed");
            // Cookies.remove("vanity_cookie_flushed1");
            // Cookies.remove("vanity_cookie_flushed2");

            // const forced_delete_vanity = Cookies.get("forced_delete_vanity");

            // if (!forced_delete_vanity && vu_cc == "AT20") {
            // 	self.stop();
            // 	Cookies.set("forced_delete_vanity", true);
            // 	return;
            // }

            if (!vu_cc || self.disabledPromoCodes.includes(vu_cc)) {
                return self.stop();
            }
            self.updateCookies(0);
        } else {
            return self.stop();
        }

        setInterval(() => self.refreshData(), 900000);
    }

    getDataFromAWS(vu_id, defaultPromo = false) {
        const self = this;
        const url = `${selectors.aws_url}/${vu_id}.json?t=${new Date().valueOf()}`;

        fetch(url)
            .then((response) => response.json())
            .then((data) => {
                if (!data.status) {
                    self.stop();
                    return;
                }
                data.defaultPromo = defaultPromo;
                self.updateCookies(1, data);
            })
            .catch((error) => {
                console.error("Error fetching data:", error);
            });
    }

    refreshData() {
        const vanity_in_cookie = Cookies.get("vanity_in_cookie") || false;
        let vu_id = getUrlParam("vu_id") || false;

        vu_id = vu_id || this.getData("vu_id");
        this.getDataFromAWS(vu_id);
    }

    vanityCode() {
        return {
            active: this.getData("vu_init"),
            discount: this.getData("vu_dis"),
            collection: this.getData("vu_col"),
            upgrade: this.getData("vu_nx"),
        };
    }
}
// End VanityURL Class

// AD40 Promotion
function applyAustraliaPromotion() {
    Cookies.set("currentPromotion", "clear");
    MarkdownPricePro.init({
        discount_code: "AD40",
        multiplier: 0.6,
        collections: ["shade-shop"],
        id: "AD40-markdown",
    });
}

document.addEventListener("DOMContentLoaded", function() {
    currentPromotion = Cookies.get("currentPromotion") || false;

    var cc = getUrlParam("cc", false);
    var cm = getUrlParam("utm_campaign", false);
    var isHPVersionB = false;

    if (cm == "BFCM%3A%20Cyber%20Monday%202%2F3%20%28HkjKVe%29") {
        cc = "cyberexclusive";
    }

    if (cc != false) {
        if (cc == "clear") {
            currentPromotion = false;
            Cookies.set("currentPromotion", "clear");
        } else {
            currentPromotion = cc;
            Cookies.set("currentPromotion", currentPromotion);
        }
        if (cc === "free-hard-case") {
            Cookies.set("add_free_hardcase", currentPromotion);
        }
        if (cc === "shop-pay") {
            Cookies.set("SR_use_sp", "shop-pay");
        }

        /* Check AB Testing */
        if (cc === "abtesting" || cc === "version-b") {
            document.body.classList.add("ab-test-activate");
        }
        if (cc === "abtestingmenu" || cc === "menu-version-b") {
            document.body.classList.add("ab-test-menu-activate");
        }
        if (cc === "abtestingmenu" || cc === "menu-version-b") {
            document.body.classList.add("ab-test-menu-activate");
        }

        if (cc === "homepage-b") {
            document.body.classList.add("hero-banner-homepage");
            isHPVersionB = true;
        }
    }

    if (document.body.classList.contains("hero-banner-homepage")) {
        isHPVersionB = true;
    }

    /* Homepage Version */
    setTimeout(function() {
        if (document.body.classList.contains("hero-banner-homepage")) {
            loadHomepageContent(true);
        } else {
            loadHomepageContent(false);
        }
    }, 100);

    const use_shop_pay = Cookies.get("SR_use_sp");
    if (use_shop_pay === "shop-pay" || cc === "shop-pay") {
        document.body.classList.add("use-shop-pay");
    }

    // ApplyCustomPromotion();

    var demo = getUrlParam("demo", false);
    if (demo == "blackout") {
        document.body.classList.add("blackoutActive");
    }


    document.addEventListener("campaign_impression", function() {

        const currentMarkdownDiscountCode = Cookies.get("markdown_discount_code") || "";
        if (currentMarkdownDiscountCode === "IGOT2") {
            return MarkdownPricePro.clear("campaign_impression");
        }

        window.onload = function() {
            const event = dataLayer.find(
                (layer) => (layer.event === "campaign_impression")
            );

            const coupon = event.coupon;
            const discount = 1 - parseInt(event.discount) / 100;
            if (coupon && Number(discount) && !Cookies.get("vanity_in_cookie")) {
                MarkdownPricePro.init({
                    discount_code: coupon,
                    multiplier: discount,
                    collections: ["men-all-styles", "shade-shop", "green-wolf", "accessories", "blue-light", "readers", "shady-rays-rx", "snow-goggles-collection", "snow-goggle-collection", "snow-goggle-frames", "kids-snow-goggles", "kids", "react", "snow-goggles"],
                    id: "campaign_impression",
                });
                setTimeout(() => {
                    MarkdownPricePro.clear("campaign_impression");
                }, 900000);
            }
        }
    });

    /**
     * Insert code of promotion here...
     */

    /**
     * Creating object for Vanity URL Class and initiating it
     */

    if (getUrlParam("vu_id") != "" || Cookies.get("vanity_in_cookie") == "true") {
        var vanity = new VanityURL();
        var vu_id = getUrlParam("vu_id");
        vanity.init();
        window.Shopify.vanity = vanity;

    }

    autoApplyCouponCode();
});

function checkMensHomepage() {
    var cc = getUrlParam("cc", false);

    const inCookie = Cookies.get("promo_mens_homepage") || "";
    if (inCookie) {
        if (cc && cc === "clear") {
            Cookies.remove("promo_mens_homepage");
            return false;
        }
        return true;
    }

    if (cc === "mens") {
        setCookieWithExpiry("promo_mens_homepage", cc, 7);
        return true;
    }
    return false;
}

function loadHomepageContent(isVersionB = false) {
    if (!isHomePage()) return;
    const isMensHomePage = checkMensHomepage();
    const homepageRtb = isVersionB ?
        "homepage-hero-rtb-b" :
        "homepage-hero-rtb-a";
    const homepageVersion = isVersionB ?
        "homepage-version-b" :
        "homepage-version-a";

    const fxShopifyUrlRt =
        window.Shopify.routes.root + "?section_id=" + homepageRtb;
    const fxShopifyUrlHPversion =
        window.Shopify.routes.root + "?section_id=" + homepageVersion;

    /*
    let customerIsVIP = Cookies.get('customer_vip');
    if(!document.querySelector(".home-vip-section").classList.contains('hidden')) {
    	document.querySelector(".home-vip-section").classList.add('hidden');
    }
    if(customerIsVIP=='vip') {
      document.querySelector('.home-vip-section.welcome-vip').classList.remove('hidden');
    } else if(customerIsVIP=='almostvip') {
      document.querySelector('.home-vip-section.welcome-almostvip').classList.remove('hidden');
    }
    */
    if (isVersionB) {
        document.querySelector(".homepage-hero-rtb-container").innerHTML =
            fxShopifyUrlRt;
    }

    const homepageVersionContainer = document.querySelector(".homepage-version-container");
    if (homepageVersionContainer) {
        homepageVersionContainer.innerHTML = fxShopifyUrlHPversion;
    }

    let customerIsVIP = Cookies.get("customer_vip");
    const homepageVipSection = document.querySelector(".home-vip-section");
    if (homepageVipSection && !homepageVipSection.classList.contains("hidden")) {
        homepageVipSection.classList.add("hidden");
    }
    if (customerIsVIP == "vip") {
        document
            .querySelector(".home-vip-section.welcome-vip")
            .classList.remove("hidden");
    } else if (customerIsVIP == "almostvip") {
        document
            .querySelector(".home-vip-section.welcome-almostvip")
            .classList.remove("hidden");
    }
    initClickTracker();

    setTimeout(function() {
        if (
            isMensHomePage &&
            document.body.classList.contains("mens-homepage-discount")
        ) {
            MarkdownPricePro.init({
                discount_code: "AT20",
                multiplier: 0.8,
                collections: [
                    "promo-rx", "prescription-items", "men-all-styles", "shade-shop", "green-wolf", "accessories", "blue-light", "readers", "shady-rays-rx", "snow-goggles-collection", "snow-goggle-collection", "snow-goggle-frames", "kids-snow-goggles", "kids", "react", "snow-goggles"
                ],
                id: "mens-homepage-discount",
            });
        }
    }, 500);
}


function ApplyCustomPromotion() {
    const activePromotions =
        (promotionsList &&
            Object.values(promotionsList).filter(
                (promotion) => promotion.promotion_is_active
            )) || [];
    activePromotions.forEach((promo) => {
        if (currentPromotion && promo.promotion_primary_id === currentPromotion) {
            activatePromotion(promo);
        }
    });
}

function activatePromotion(promotion) {
    document.body.classList.add(promotion.promotion_body_class);
    if (!promotion.promotion_is_country_specific) {
        return updateForUSStore(promotion, false);
    }
    if (theme.globals.userCurrency !== "USD") {
        return updateForOtherStores(promotion);
    }
    return updateForUSStore(promotion, true);
}

function updateForUSStore(promotion, isCountrySpecific) {
    updateStore(promotion);
    if (isCountrySpecific && promotion.promotion_is_different_for_INT) {
        updateForInternational(promotion);
    }
}

function updateForOtherStores(promotion) {
    const storePromotion = { ...promotion
    };
    Object.keys(promotion).forEach((key) => {
        if (`${key}_${theme.globals.userCurrency}` in promotion) {
            storePromotion[key] = promotion[`${key}_${theme.globals.userCurrency}`];
        }
    });
    updateStore(storePromotion);
}

function updateForInternational(promotion) {
    if (typeof GEF !== "undefined") {
        if (GEF.countryCode !== "US") {
            const storePromotion = { ...promotion
            };
            Object.keys(promotion).forEach((key) => {
                if (`${key}_INT` in promotion) {
                    storePromotion[key] = promotion[`${key}_INT`];
                }
            });
            updateStore(storePromotion);
        }
    } else {
        setTimeout(() => {
            updateForInternational(promotion);
        }, 500);
    }
}

function updateStore(promotion) {
    activePromotion = promotion;
    if (promotion.promotion_has_top_banner) {
        updateTopBanner(promotion);
    }
    if (promotion.promotion_has_homepage_banner) {
        updateHomepage(promotion);
    }
    updateMarkdown();
}

function updateTopBanner(promotion) {
    const topBannerEl = document.querySelector(
        'div[data-promotion-id="promotion-top-banner"]'
    );
    document.querySelector(".bannertop").classList.add("promotion-top-banner");
    topBannerEl.innerHTML = promotion.promotion_top_banner;
}

function updateHomepage(promotion) {
    const defaultBanner = document.querySelector('div[data-id="default-banner"]');
    defaultBanner.style.display = "none";

    const homepageBannerContainer = document.querySelector(
        'div[data-promotion-id="promotion-hompepage-banner"]'
    );
    homepageBannerContainer.innerHTML = promotion.promotion_homepage_banner;
}

function updateProductPage() {
    if (!activePromotion || !activePromotion.promotion_is_active) return;
    updateDiscountCode();
    const promo_eligible_product_count = getEligibleProductCount();
    let upsell_to_show = 0;
    for (let number = 1; number < 5; number++) {
        if (
            activePromotion[`promotion_has_product_upsell_${number}`] &&
            promo_eligible_product_count ===
            Number(
                activePromotion[`promotion_quantity_for_product_upsell_${number}`]
            )
        ) {
            upsell_to_show = number;
            break;
        }
    }
    const productUpsellContainer = document.querySelector(
        'div[data-promotion-id="promotion-product-upsell"]'
    );
    if (upsell_to_show) {
        productUpsellContainer.innerHTML = `
      <div class="summer-bogo-product">
        <a href="${activePromotion.promotion_product_upsell_banner_CTA_link}">
          <img class="sr-desktop" src="${activePromotion[`promotion_product_upsell_banner_${upsell_to_show}`]
			}" alt="Promotion Product Upsell Banner">
          <img class="sr-mobile" src="${activePromotion[
			`promotion_product_upsell_banner_mobile_${upsell_to_show}`
			]
			}" alt="Promotion Product Upsell Banner Mobile">
        </a>
      </div>`;
    } else {
        productUpsellContainer.innerHTML = "";
    }
}

function updatePromotionalCartPage() {
    if (!activePromotion || !activePromotion.promotion_is_active) return;
    updateDiscountCode();
    const promo_eligible_product_count = getEligibleProductCount();
    let upsell_to_show = 0;
    for (let number = 1; number < 5; number++) {
        if (
            activePromotion[`promotion_has_cart_upsell_${number}`] &&
            promo_eligible_product_count ===
            Number(activePromotion[`promotion_quantity_for_cart_upsell_${number}`])
        ) {
            upsell_to_show = number;
            break;
        }
    }
    const cartUpsellContainer = document.querySelector(
        'div[data-promotion-id="promotion-cart-upsell"]'
    );
    const cartCodeInstructionEl = document.querySelector(
        'div[data-promotion-id="promotion-cart-code-instruction"]'
    );
    if (upsell_to_show) {
        cartUpsellContainer.innerHTML = `
      <div class="summer-bogo-product">
        <a href="${activePromotion.promotion_cart_upsell_banner_CTA_link}">
          <img class="sr-desktop" src="${activePromotion[`promotion_cart_upsell_banner_${upsell_to_show}`]
			}" alt="Promotion Cart Upsell Banner">
          <img class="sr-mobile" src="${activePromotion[
			`promotion_cart_upsell_banner_mobile_${upsell_to_show}`
			]
			}" alt="Promotion Cart Upsell Banner Mobile">
        </a>
      </div>`;
    } else {
        cartUpsellContainer.innerHTML = "";
    }
    if (
        activePromotion.promotion_has_cart_code_instruction &&
        promo_eligible_product_count >=
        Number(activePromotion.promotion_quantity_for_cart_instruction)
    ) {
        cartCodeInstructionEl.innerHTML =
            activePromotion.promotion_cart_code_instruction_html;
        cartCodeInstructionEl.classList.remove("hidden");
        cartCodeInstructionEl.style.display = "block";
        if (
            promo_eligible_product_count >= 2 &&
            activePromotion.promotion_primary_id === "mdw"
        ) {
            cartCodeInstructionEl.querySelector(
                '*[data-promotion-id="promotion_discount_code"]'
            ).innerHTML = "MDW25";
            cartCodeInstructionEl.querySelector(
                '*[data-promotion-id="promotion_discount_offer"]'
            ).innerHTML = "$25 OFF each pair";
        }
    } else if (activePromotion.promotion_keep_upsell_to_two) {
        cartCodeInstructionEl.classList.remove("hidden");
        cartCodeInstructionEl.style.display = "block";
    } else {
        cartCodeInstructionEl.innerHTML = "";
        cartCodeInstructionEl.classList.add("hidden");
    }
}

function getEligibleProductCount() {
    let promo_eligible_collections = activePromotion.promotion_collection_handles ?
        activePromotion.promotion_collection_handles.split(",") :
        [];
    const promo_exclude_collections =
        activePromotion.promotion_collection_handles_to_exclude ?
        activePromotion.promotion_collection_handles_to_exclude.split(",") :
        [];
    if (!promo_eligible_collections.length) {
        if (!promo_exclude_collections.length) {
            promo_eligible_collections = theme.globals.allCollectionHandles;
        } else {
            promo_eligible_collections = [];
            for (let index = 0; index < theme.globals.allCollectionHandles.length; index++) {
                if (!promo_exclude_collections.includes(theme.globals.allCollectionHandles[index])) {
                    promo_eligible_collections.push(theme.globals.allCollectionHandles[index]);
                }
            }
        }
    }
    const actual_cart_items = theme.globals.cartItems.filter((item) => {
        let mainProductId;
        if (item.properties._hardcase_bundle && item.properties._hardcase_bundle.includes(':')) {
            mainProductId = item.properties["_hardcase_bundle"].split(":")[1]
        }
        if (!item.properties["_hardcase_bundle"] || `${item.id}` === mainProductId) {
            return i;
        }
    });

    return actual_cart_items.reduce((prev, curr) => {
        let quantity = 0;
        const productCollections = curr._collections;
        for (let index = 0; index < productCollections.length; index++) {
            if (promo_eligible_collections.includes(productCollections[index])) {
                quantity = curr.quantity;
                break;
            }
        }
        return prev + quantity;
    }, 0);
}

function updatePromotionalGiftItem() {
    if (!activePromotion || !activePromotion.promotion_is_active) return;
    const promo_eligible_product_count = getEligibleProductCount();
    const required_count = Number(
        activePromotion.promotion_min_quantity_for_gift_item
    );
    if (
        activePromotion.promotion_has_gift_item &&
        promo_eligible_product_count >= required_count
    ) {
        if (!theme.globals.cartItems.some(
                (item) => `${item.id}` === activePromotion.promotion_gift_item_id
            )) {
            fetch("/cart/add.js", {
                method: "POST",
                headers: {
                    "Content-Type": "application/json",
                },
                body: JSON.stringify({
                    quantity: 1,
                    id: activePromotion.promotion_gift_item_id,
                }),
            }).then(() => {
                setTimeout(function() {
                    location.reload();
                }, 1500);
            });
        }
    } else {
        if (
            theme.globals.cartItems.some(
                (item) => `${item.id}` === activePromotion.promotion_gift_item_id
            )
        ) {
            fetch("/cart/change.js", {
                method: "POST",
                headers: {
                    "Content-Type": "application/json",
                },
                body: JSON.stringify({
                    quantity: 0,
                    id: activePromotion.promotion_gift_item_id,
                }),
            }).then(() => {
                setTimeout(function() {
                    location.reload();
                }, 1500);
            });
        }
    }
}

function updateMarkdown() {
    if (!activePromotion || !activePromotion.promotion_is_active) return;
    let subtract = false;
    const discount = activePromotion.promotion_discount;
    let value = discount.replace(/[^0-9.]/, "");
    if (discount.includes("%")) {
        value = 1 - Number(value) / 100;
    } else {
        discount_value = Number(value);
        subtract = true;
    }
    let collections = activePromotion.promotion_collection_handles ?
        activePromotion.promotion_collection_handles.split(",") :
        [];
    const excluded = activePromotion.promotion_collection_handles_to_exclude ?
        activePromotion.promotion_collection_handles_to_exclude.split(",") :
        [];

    if (!collections.length) {
        if (!excluded.length) {
            collections = theme.globals.allCollectionHandles;
        } else {
            collections = [];
            for (let index = 0; index < theme.globals.allCollectionHandles.length; index++) {
                if (!excluded.includes(theme.globals.allCollectionHandles[index])) {
                    collections.push(theme.globals.allCollectionHandles[index]);
                }
            }
        }
    }
    if (activePromotion.promotion_enable_markdown) {
        MarkdownPricePro.init({
            discount_code: activePromotion.promotion_discount_code,
            multiplier: value,
            collections,
            subtract,
            id: activePromotion.promotion_primary_id,
        });
    } else {
        MarkdownPricePro.clear(activePromotion.promotion_primary_id);
    }
}

function addCollectionItemProperty() {
    if (
        theme.globals.productCollections &&
        !document.querySelector('input[name="properties[_theme.globals.productCollections]"]')
    ) {
        const form = document.querySelector(
            'form[action="/cart/add"][data-product-form]'
        );
        const input = document.createElement("input");
        input.type = "hidden";
        input.name = "properties[_theme.globals.productCollections]";
        input.value = theme.globals.productCollections;
        form.appendChild(input);
    }
}

function updateDiscountCode() {
    if (!activePromotion || !activePromotion.promotion_is_active) return;
    const promo_eligible_product_count = getEligibleProductCount();
    if (
        activePromotion.promotion_has_secondary_discount_code &&
        promo_eligible_product_count >=
        Number(activePromotion.promotion_quantity_for_secondary_discount_code)
    ) {
        changeCouponCode(
            activePromotion.promotion_primary_id,
            activePromotion.promotion_secondary_discount_code
        );
    } else {
        changeCouponCode(
            activePromotion.promotion_primary_id,
            activePromotion.promotion_discount_code
        );
    }
}

function changeCouponCode(id, code) {
    let markdownObject = Cookies.getJSON("markdown_object") || [];

    if (!markdownObject.length) return;

    const existing = markdownObject.find((obj) => obj.markdown_id === `${id}`);

    if (!existing) return;

    const current_discount = existing.markdown_discount_code;
    if (current_discount !== code) {
        MarkdownPricePro.update(id, {
            markdown_discount_code
        });
        autoApplyCouponCode(code);
    }
}

function getActualCartItems(collectionData, cart_items = theme.globals.cartItems) {
    return cart_items
        .filter(function(i) {
            if (i._collections.length) {
                const found = collectionData.find(
                    (element) => i._collections.includes(element) && !i.title.includes("Colorush")
                );

                let mainProductId;
                if (i.properties._hardcase_bundle && i.properties._hardcase_bundle.includes(':')) {
                    mainProductId = i.properties["_hardcase_bundle"].split(":")[1]
                }
                if ((!i.properties["_hardcase_bundle"] || `${i.id}` === mainProductId) && found) {
                    return i;
                }
            }
        })
        .map((item) => item.quantity)
        .reduce((prev, curr) => prev + curr, 0);
}

autoApplyTalkableCode();

function autoApplyTalkableCode() {
    const params = getUrlVars();
    if (!("tkbl_coupon" in params)) return;

    autoApplyCouponCode(params.tkbl_coupon);
}

function gaCall(action = "event", value = "") {
    var retryCounter = 0;

    function checkIfAnalyticsLoaded() {
        if (typeof gtag === "function" || retryCounter++ > 20) {
            gtag("event", action, value);
        } else {
            setTimeout(checkIfAnalyticsLoaded, 2000);
        }
    }
    checkIfAnalyticsLoaded();
}