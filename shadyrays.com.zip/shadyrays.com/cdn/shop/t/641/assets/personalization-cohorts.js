function moveBefore({
    section,
    itemSelector,
    refSelector
}) {
    const sectionElem = document.querySelector(section);
    const target = sectionElem.querySelector(itemSelector);
    const ref = sectionElem.querySelector(refSelector);

    if (!target) {
        return console.error(`moveBefore: The target item with selector ${itemSelector} not found`);
    }
    if (!ref) {
        return console.error(`moveBefore: The reference item with selector ${refSelector} not found`);
    }

    sectionElem.insertBefore(target, ref);
}

function moveAfter({
    section,
    itemSelector,
    refSelector
}) {
    const sectionElem = document.querySelector(section);
    const target = sectionElem.querySelector(itemSelector);
    const ref = sectionElem.querySelector(refSelector);

    if (!target) {
        return console.error(`moveAfter: The target item with selector ${itemSelector} not found`);
    }
    if (!ref) {
        return console.error(`moveAfter: The reference item with selector ${refSelector} not found`);
    }

    sectionElem.insertBefore(target, ref.nextSibling);
}

function replace({
    section,
    itemSelector,
    content
}) {
    const sectionElem = document.querySelector(section);
    const target = sectionElem.querySelector(itemSelector);

    if (!target) {
        return console.error(`replace: The target item with selector ${itemSelector} not found`);
    }

    if (typeof content === 'object') {
        Object.entries(content).forEach(([key, value]) => {
            const targetElement = target.querySelector(`[data-${section}-content-${key}]`);
            if (targetElement) {
                targetElement.innerHTML = value;
            }
        });
        return;
    }

    target.outerHTML = content;
}

function hide({
    section,
    itemSelector
}) {
    const sectionElem = document.querySelector(section);
    const target = sectionElem.querySelector(itemSelector);

    if (!target) {
        return console.error(`hide: The target item with selector ${itemSelector} not found`);
    }

    target.style.display = 'none';
}

function show({
    section,
    itemSelector
}) {
    const sectionElem = document.querySelector(section);
    const target = sectionElem.querySelector(itemSelector);

    if (!target) {
        return console.error(`show: The target item with selector ${itemSelector} not found`);
    }

    target.style.display = '';
}

function remove({
    section,
    itemSelector
}) {
    const sectionElem = document.querySelector(section);
    const target = sectionElem.querySelector(itemSelector);

    if (!target) {
        return console.error(`remove: The target item with selector ${itemSelector} not found`);
    }

    target.remove();
}

function moveToStart({
    section,
    itemSelector
}) {
    const sectionElem = document.querySelector(section);
    const target = sectionElem.querySelector(itemSelector);

    if (!target) {
        return console.error(`moveToStart: The target item with selector ${itemSelector} not found`);
    }

    sectionElem.prepend(target);
}

function moveToEnd({
    section,
    itemSelector
}) {
    const sectionElem = document.querySelector(section);
    const target = sectionElem.querySelector(itemSelector);

    if (!target) {
        return console.error(`moveToEnd: The target item with selector ${itemSelector} not found`);
    }

    sectionElem.append(target);
}

function append({
    section,
    content
}) {
    const sectionElem = document.querySelector(section);

    if (!sectionElem) {
        return console.error(`append: Please provide a valid section selector. Selector ${section} not found.`);
    }

    if (typeof content !== 'string') {
        return console.error(`append: The content must be a HTML string`);
    }

    sectionElem.insertAdjacentHTML('beforeend', content);
}

function prepend({
    section,
    content
}) {
    const sectionElem = document.querySelector(section);

    if (!sectionElem) {
        return console.error(`prepend: Please provide a valid section selector. Selector ${section} not found.`);
    }

    if (typeof content !== 'string') {
        return console.error(`prepend: The content must be a HTML string`);
    }

    sectionElem.insertAdjacentHTML('afterbegin', content);
}

const actionFns = {
    moveBefore,
    moveAfter,
    replace,
    hide,
    show,
    remove,
    moveToStart,
    moveToEnd,
    append,
    prepend,
};

function applyCohortPersonalizations(customerCohort) {
    const config = window.personalizationConfig || {};
    if (!config.enabled || !config.personalizations || !Array.isArray(config.sections)) {
        return;
    }

    const personalizations = config.personalizations;
    const cohort = customerCohort.toLowerCase();

    if (!personalizations[cohort]) {
        return;
    }

    const cohortPersonalizations = personalizations[cohort];
    for (const [section, actions] of Object.entries(cohortPersonalizations)) {
        if (!config.sections.includes(section)) {
            return console.error(`The section ${section} is not supported. Please use one of ${config.sections.join(', ')}`);
        }

        for (const {
                item,
                ref,
                action,
                ...rest
            } of actions) {
            if (!actionFns[action]) {
                return console.error(`The action ${action} is not supported`);
            }
            actionFns[action]({
                itemSelector: `[data-px-${section}-item="${item}"]`,
                refSelector: `[data-px-${section}-item="${ref}"]`,
                section: `[data-px-section-${section}]`,
                ...rest,
            });
        }
    }
}

function runCohortPersonalizations() {
    let tags = Cookies.getJSON('SR_PR_tags') || [];
    if (!Array.isArray(tags) && typeof tags === 'string') {
        tags = tags.split(',');
    }

    if (!tags.length) {
        const kId = Cookies.get('SR_PR_kId') || Cookies.get('SR_PR_klaviyo_id') || '';
        if (!kId) {
            const kEmail = Cookies.get('SR_PR_kEm') || Cookies.get('SR_PR_klaviyo_em') || '';
            if (!kEmail) {
                return;
            }
        }
        return;
    }
    tags.forEach(applyCohortPersonalizations);
}