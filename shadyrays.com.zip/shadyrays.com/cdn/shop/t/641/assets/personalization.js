document.addEventListener('DOMContentLoaded', function() {
    checkPersonalizationObject();
    getKlaviyoIdFromUrl();
    trackPersonalization();
    vipFeatures();
    checkAttentiveSignup();
    initClickTracker();
});

const KlaviyoEndpoint = 'https://twilight-flowers-hlgyuddy7tc5.vapor-farm-g1.com/api/klaviyo';

function getUrlVars() {
    const vars = {};
    const parts = window.location.href.replace(/[?&]+([^=&]+)=([^&]*)/gi, function(m, key, value) {
        vars[key] = value;
    });
    return vars;
}

function getUrlParam(parameter, defaultvalue = false) {
    let urlparameter = defaultvalue;
    if (window.location.href.indexOf(parameter) > -1) {
        urlparameter = getUrlVars()[parameter];
    }
    return urlparameter;
}

function getKlaviyoUserInfo(id) {
    return new Promise((resolve, reject) => {
        if (!id) return reject("No ID supplied");
        fetch(`${KlaviyoEndpoint}/person/${id}`)
            .then(response => response.json())
            .then(data => {
                const response = setPersonalisationCookies(data);
                if (!response.success) {
                    return reject(response.message);
                }
                resolve(data);
            });
    });
}

function setPersonalisationCookies(data) {
    if (!data || !data.id) return {
        success: false,
        message: "No data"
    };
    const {
        email
    } = data.attributes;
    const {
        organic_order_spent,
        'Shopify Tags': tags
    } = data.attributes.properties;
    const status = tags && tags.includes('VIP') ? 'VIP' : organic_order_spent ? 'Purchaser' : 'Non-Purchaser';
    const id = data.id;
    const customer_email = btoa(email);
    Cookies.set('SR_PR_kStatus', status);
    Cookies.set('SR_PR_kId', id);
    Cookies.set('SR_PR_kEm', customer_email);
    Cookies.set('SR_PR_tags', tags);
    if (!status || !id) return {
        success: false,
        message: "No ID or Status"
    };
    track({
        id,
        status
    });
    checkPersonalizationObject();
    return {
        success: true
    };
}

function gaTrack(label, id, data) {
    try {
        gtag('event', label, {
            [id]: data
        });
    } catch (error) {
        setTimeout(() => {
            gaTrack(label, id, data);
        }, 500);
    }
}

function track(data) {
    gaTrack('Personalization', data.id, data.status);
}

function sendTracking(id, status) {
    try {
        gtag('event', 'Personalization-tracked', {
            [id]: status
        });
    } catch (error) {
        setTimeout(() => {
            sendTracking(id, status);
        }, 500);
    }
}

function getKlaviyoInfoFromEmail(email) {
    if (!email) return;

    const isBase64 = email => /^(?:[A-Za-z0-9+/]{4})*(?:[A-Za-z0-9+/]{2}==|[A-Za-z0-9+/]{3}=|[A-Za-z0-9+/]{4})$/.test(email);
    if (isBase64(email)) {
        email = atob(email);
    }

    const url = `${KlaviyoEndpoint}/person-email?email=${email}`;
    fetch(url)
        .then(response => {
            if (!response.ok) {
                throw new Error(`Network response was not ok: ${response.statusText}`);
            }
            return response.json();
        })
        .then(data => {
            setPersonalisationCookies(data);
        })
        .catch(error => {
            console.error('There was a problem with the fetch operation:', error);
        });
}

function getKlaviyoIdFromUrl() {
    let bxid = getUrlParam('bxid');
    if (!bxid) return;
    Cookies.set('SR_PR_klaviyo_id', bxid);
    checkPersonalizationObject();
}

function trackPersonalization() {
    const status = Cookies.get('SR_PR_kStatus');
    const personalization_tracked = Number(Cookies.get('SR_PR_pTracked')) || 0;
    const klaviyo_id = Cookies.get('SR_PR_kId');
    const now = Date.now();
    const sixHours = 21600000;
    if (status && now - personalization_tracked >= sixHours) {
        sendTracking(klaviyo_id, status);
    }
}

function checkPersonalizationObject() {
    const status = Cookies.get('SR_PR_kStatus');
    const klaviyo_id = Cookies.get('SR_PR_kId');

    if (!status || !klaviyo_id) {
        const id = Cookies.get('SR_PR_klaviyo_id');
        if (!id) {
            const email = Cookies.get('SR_PR_klaviyo_em');
            if (!email) {
                return;
            }
            return getKlaviyoInfoFromEmail(email);
        }
        return getKlaviyoUserInfo(id);
    }
    const url_id = Cookies.get('SR_PR_klaviyo_id');
    if (url_id && url_id !== klaviyo_id) {
        // If the klaviyo ID changes, we should refresh the data
        getKlaviyoUserInfo(url_id);
    }
    const tags = Cookies.get('SR_PR_tags');
    if (!tags || tags === 'undefined') {
        return getKlaviyoUserInfo(klaviyo_id);
    }
    const email = Cookies.get('SR_PR_kEm');
    return personalizeExperience({
        email,
        klaviyo_id,
        status
    });
}

function personalizeExperience(object) {
    if (!object) return;
    const {
        email,
        klaviyo_id,
        status
    } = object;
    runCohortPersonalizations();
    const customer_vip = status === 'VIP' ? 'vip' : status === 'Purchaser' ? 'almostvip' : '';
    if (customer_vip) {
        activateVIP(customer_vip);
        checkVIPStatus(customer_vip);
        vipFeatures();
    }
}

/**
 * VIP Status Banner and Message
 */

function checkVIPStatus(status) {
    if (!status) return;
    //document.querySelector(".home-vip-section").style.display = 'none';
    const homeVipSection = document.querySelector(".home-vip-section");
    if (homeVipSection && !homeVipSection.classList.contains('hidden')) {
        //homeVipSection.classList.add('hidden');
    }
    const srVipReferralBanner = document.querySelector(".sr-vip-refrerral-banner");
    if (status == 'vip' && srVipReferralBanner) {
        srVipReferralBanner.innerHTML = `<div class="sr-col-6 relative vip-wrap">
        <div class="welcome-vip non-vip-block vip-member-block">
          <div class="sr-full-img">
            <picture>
              <source media="(min-width:740px)" srcset="//shadyrays.com/cdn/shop/files/vip-col-bg-desk.png?v=16630887873020537432">
              <source media="(min-width:200px)" srcset="//shadyrays.com/cdn/shop/files/vip-col-bg-mob.png?v=7889269232260326446">
              <img class="d-block"  src="//shadyrays.com/cdn/shop/files/vip-col-bg-desk.png?v=16630887873020537432" alt="VIP"/>
            </picture>
          </div>
          <div class="overly overly-home-vip flex">
            <div class="sr-container">
              <div class="content-block">
                <div class="img-block">
                  <img class="d-block" src="//shadyrays.com/cdn/shop/files/vip-welcome-logo.svg?v=14907199534891222032" alt="Welcome VIP"/>
                </div>
                <div class="copies text-center">
                  <p class="fs-30 fw-500 color-white">Thanks for being a<br class="show-small"> loyal member<br class="hide-small"> of the<br class="show-small"> Shady Rays Community.</p>
                </div>
                <div class="vip-benefits-list flex">
                  <div class="vip-benefit-col text-center">
                    <div class="benefit-img">
                      <img class="d-block" src="//shadyrays.com/cdn/shop/files/vip-icon-1.svg?v=11559102910437522000" alt="VIP Benefits"/>
                    </div>
                    <span class="color-white fs-14 fw-600 uppercase">5% Extra<br class="hide-small"> Discount</span>
                  </div>
                  <div class="vip-benefit-col text-center">
                    <div class="benefit-img">
                      <img src="//shadyrays.com/cdn/shop/files/vip-icon-2.svg?v=8285441201582451252" alt="VIP Benefits"/>
                    </div>
                    <span class="color-white fs-14 fw-600 uppercase">Priority order<br class="hide-small"> processing</span>
                  </div>
                  <div class="vip-benefit-col text-center">
                    <div class="benefit-img">
                      <img src="//shadyrays.com/cdn/shop/files/vip-icon-3.svg?v=6268219248784758986" alt="VIP Benefits"/>
                    </div>
                    <span class="color-white fs-14 fw-600 uppercase">Early access<br class="hide-small"> to sales</span>
                  </div>
                  <div class="vip-benefit-col text-center">
                    <div class="benefit-img">
                      <img src="//shadyrays.com/cdn/shop/files/vip-icon-4.svg?v=3717052154855290286" alt="VIP Benefits"/>
                    </div>
                    <span class="color-white fs-14 fw-600 uppercase">Dedicated<br class="hide-small"> customer support</span>
                  </div>
                </div>
                <div class="note">
                  <p class="color-white fs-18"><i>Explore #ShadyRaysVIP</i></p>
                </div>
                <div class="note-float">
                  <a class="color-white fs-12 fw-600 ls-2px text-underline" href="/pages/vip-landing">LEARN MORE</a>
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>
      <div class="sr-col-6 relative refer-wrap">
        <div class="welcome-vip refer-offer referred-offer">
          <div class="sr-full-img">
            <picture>
              <source media="(min-width:740px)" srcset="//shadyrays.com/cdn/shop/files/ref-friend-desk.png?v=11625471557569764314">
              <source media="(min-width:200px)" srcset="//shadyrays.com/cdn/shop/files/ref-friend-mob.png?v=4647822266734139151">
              <img class="d-block" src="//shadyrays.com/cdn/shop/files/ref-friend-desk.png?v=11625471557569764314" alt="VIP"/>
            </picture>
          </div>
          <div class="overly overly-home-vip flex">
            <div class="sr-container">
              <div class="content-block">
                <div class="copies text-center">
                  <h2 class="color-white fs-60 fw-700 lh-1 ls-2em">Refer a Friend</h2>
                  <p class="fs-30 fw-500 color-white lh-160">Invite your friends to shop at Shady Rays and get them one step closer to joining you on the VIP team.</p>
                </div>
                <div class="btn-block">
                  <a class="ibtn round fw-600 color-black bg-white border-white" href="/pages/referral-dashboard"><span>Invite Your Friends</span></a>
                </div>
                <div class="note-float hasImg flex justify-content-center">
                  <img class="d-block" src="//shadyrays.com/cdn/shop/files/refa-sr-vip-logo.svg?v=11733547757219664780" alt="VIP"/>
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>`;
    } else if (status == 'almostvip') {
        srVipReferralBanner.innerHTML = `<div class="sr-col-6 relative vip-wrap ">
        <div class="welcome-vip non-vip-block">
          <div class="sr-full-img">
            <picture>
              <source media="(min-width:740px)" srcset="//shadyrays.com/cdn/shop/files/non-vip-col-bg-desk.png?v=15202094532742853999">
              <source media="(min-width:200px)" srcset="//shadyrays.com/cdn/shop/files/non-vip-col-bg-mob.png?v=7692427467498371455">
              <img class="d-block" src="//shadyrays.com/cdn/shop/files/non-vip-col-bg-desk.png?v=15202094532742853999" alt="VIP"/>
            </picture>
          </div>
          <div class="overly overly-home-vip flex">
            <div class="sr-container">
              <div class="content-block">
                <h3 class="color-white fs-30 fw-500 lh-13">You are one order away from becoming a</h3>
                <div class="img-block">
                  <img class="d-block" src="//shadyrays.com/cdn/shop/files/vip-logo-u22.svg?v=1916147997293428176" alt="VIP Logo"/>
                </div>
                <div class="vip-benefits-list non-vip-list flex">
                  <div class="vip-benefit-col text-center">
                    <div class="benefit-img">
                      <img class="d-block" src="//shadyrays.com/cdn/shop/files/vip-icon-1.svg?v=11559102910437522000" alt="VIP Benefits"/>
                    </div>
                    <span class="color-white fs-14 fw-600 uppercase">5% Extra<br class="hide-small"> Discount</span>
                  </div>
                  <div class="vip-benefit-col text-center">
                    <div class="benefit-img">
                      <img src="//shadyrays.com/cdn/shop/files/vip-icon-2.svg?v=8285441201582451252" alt="VIP Benefits"/>
                    </div>
                    <span class="color-white fs-14 fw-600 uppercase">Priority order<br class="hide-small"> processing</span>
                  </div>
                  <div class="vip-benefit-col text-center">
                    <div class="benefit-img">
                      <img src="//shadyrays.com/cdn/shop/files/vip-icon-3.svg?v=6268219248784758986" alt="VIP Benefits"/>
                    </div>
                    <span class="color-white fs-14 fw-600 uppercase">Early access<br class="hide-small"> to sales</span>
                  </div>
                  <div class="vip-benefit-col text-center">
                    <div class="benefit-img">
                      <img src="//shadyrays.com/cdn/shop/files/vip-icon-5.svg?v=342752941951221539" alt="VIP Benefits"/>
                    </div>
                    <span class="color-white fs-14 fw-600 uppercase">UNLOCK EXCLUSIVE<br class="hide-small"> VIP SHADES</span>
                  </div>
                  <div class="vip-benefit-col text-center">
                    <div class="benefit-img">
                      <img src="//shadyrays.com/cdn/shop/files/vip-icon-4.svg?v=3717052154855290286" alt="VIP Benefits"/>
                    </div>
                    <span class="color-white fs-14 fw-600 uppercase">Dedicated<br class="hide-small"> customer support</span>
                  </div>
                </div>
                <div class="btn-block">
                  <a class="ibtn round fw-600 color-black bg-gold border-gold" href="/collections/men-all-styles"><span>Shop Now</span></a>
                </div>
                <div class="note-float">
                  <a class="color-white fs-12 fw-600 ls-2px text-underline statusCheck" href="#">CHECK MY VIP STATUS</a>
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>
      <div class="sr-col-6 relative refer-wrap">
        <div class="welcome-vip refer-offer">
          <div class="sr-full-img">
            <picture>
              <source media="(min-width:740px)" srcset="//shadyrays.com/cdn/shop/files/get-20-bg-desk.png?v=8100759813367501643">
              <source media="(min-width:200px)" srcset="//shadyrays.com/cdn/shop/files/get-20-bg-mob.png?v=9479273866824337212">
              <img class="d-block" src="//shadyrays.com/cdn/shop/files/get-20-bg-desk.png?v=8100759813367501643" alt="VIP"/>
            </picture>
          </div>
          <div class="overly overly-home-vip flex">
            <div class="sr-container">
              <div class="content-block">
                <div class="copies text-center">
                  <h3 class="color-white fs-24 fw-700 lh-13 ls-2em uppercase">Refer a friend and</h3>
                  <h2 class="color-white fs-80 fw-700 lh-13 ls-2em">Get $20</h2>
                  <p class="fs-30 fw-500 color-white lh-160">Invite your friends and get <span class="fw-700">$20 OFF</span> your next order. Plus, your friend also receives <span class="fw-700">$20 OFF</span> their first order. It's a win, win.</p>
                </div>
                <div class="btn-block">
                  <a class="ibtn round fw-600 color-black bg-white border-white" href="pages/share"><span>Invite Your Friends</span></a>
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>`;
    } else {
        //homeVipSection.classList.remove('hidden');
    }
}

function messageVIPStatus(status) {
    if (!status) return;
    document.querySelector('.checking-form').style.display = 'none';
    document.querySelector('.checking-status').style.display = 'block';
    const messageElement = document.querySelector('.sr-cs-vip-program-message').querySelector('h3');
    if (status == 'vip') {
        messageElement.innerHTML = `Congratulations, you’re a VIP! <br>Thanks for being part of the Shady Rays community.`;
    } else if (status == 'almostvip') {
        messageElement.innerHTML = `You have not made a purchase yet. <br class="hide-small">After you’ve made 2 orders, you’ll qualify for exclusive VIP benefits!`;
    }
}

function checkVIPStatusByEmail(email) {
    if (email) {
        const isBase64 = email => /^(?:[A-Za-z0-9+/]{4})*(?:[A-Za-z0-9+/]{2}==|[A-Za-z0-9+/]{3}=|[A-Za-z0-9+/]{4})$/.test(email);
        if (isBase64(email)) {
            email = atob(email);
        }
        fetch(`${KlaviyoEndpoint}/person-email?email=${email}`)
            .then(response => response.json())
            .then(data => {
                if (data.id) {
                    const status = getCustomerStatus(data);
                    checkVIPStatus(status);
                } else {
                    checkVIPStatus('non-vip');
                }
            })
            .catch(() => {
                messageVIPStatus("non-vip");
                checkVIPStatus('none-vip');
            });
    } else {
        const klaviyo_id = Cookies.get('SR_PR_kId');
        if (klaviyo_id) {
            checkVIPStatusByID(klaviyo_id);
        } else {
            checkVIPStatus('none-vip');
        }
    }
}

function getCustomerStatus(data) {
    const {
        organic_order_spent,
        'Shopify Tags': tags
    } = data.attributes.properties;
    return tags && tags.includes('VIP') ? 'vip' : organic_order_spent ? 'almostvip' : 'Non-Purchaser';
}

function checkVIPStatusByID(id) {
    if (!id) return;
    fetch(`${KlaviyoEndpoint}/person/${id}`)
        .then(response => response.json())
        .then(data => {
            if (!data || !data.id) return;
            const status = getCustomerStatus(data);
            checkVIPStatus(status);
        });
}

function checkVIPStatusByEmailForPopUp(email, callback) {
    if (email) {

        const isBase64 = email => /^(?:[A-Za-z0-9+/]{4})*(?:[A-Za-z0-9+/]{2}==|[A-Za-z0-9+/]{3}=|[A-Za-z0-9+/]{4})$/.test(email);
        if (isBase64(email)) {
            email = atob(email);
        }

        fetch(`${KlaviyoEndpoint}/person-email?email=${email}`)
            .then(response => response.json())
            .then(data => {
                if (data.id) {
                    const status = getCustomerStatus(data);
                    messageVIPStatus(status);
                } else {
                    messageVIPStatus("non-vip");
                }
                callback(data);
            })
            .catch(() => {
                messageVIPStatus("non-vip");
                callback({
                    id: null,
                    status: "non-vip"
                });
            });
    } else {
        callback({
            id: null,
            status: "non-vip"
        });
        messageVIPStatus("non-vip");
    }
}

function checkVIPStatusByIDForPopUp(id) {
    if (!id) return;
    fetch(`${KlaviyoEndpoint}/person/${id}`)
        .then(response => response.json())
        .then(data => {
            if (!data || !data.id) return;
            const status = getCustomerStatus(data);
            messageVIPStatus(status);
        });
}

function vipFeatures() {
    const sr_pr_status = Cookies.get('SR_PR_kStatus');
    const vipTagElements = document.querySelectorAll('.sr-product-tag.product-tag-vip-tag');
    vipTagElements.forEach(element => {
        element.querySelector('img').setAttribute("src", '//shadyrays.com/cdn/shop/files/vip-lock.svg?v=6811815750803423095');
        element.querySelector('img').setAttribute("data-src", '//shadyrays.com/cdn/shop/files/vip-lock.svg?v=6811815750803423095');
    });

    if (sr_pr_status == "VIP") {
        vipTagElements.forEach(element => {
            element.querySelector('img').setAttribute("src", '//shadyrays.com/cdn/shop/files/vip-open.svg?277625');
            element.querySelector('img').setAttribute("data-src", '//shadyrays.com/cdn/shop/files/vip-open.svg?277625');
        });

        const nonVipAnnouncement = document.querySelectorAll('.announcement');
        nonVipAnnouncement.forEach(element => {
            if (!element.classList.contains('vip-announcement')) {
                element.remove();
            }
        });
    }
}

function checkAttentiveSignup() {
    if (window.innerWidth > 480) return;
    const id = Cookies.get('SR_PR_kId');
    const attentiveShown = Cookies.get('SR_PR_asShown');
    if (!id || attentiveShown) return;
    getKlaviyoUserInfo(id).then((data) => {
        if (!data) return;
        if (data.sms_attentive_signup) {
            Cookies.remove('SR_PR_asTrigger');
            Cookies.set('SR_PR_asSms', data.sms_attentive_signup);
        } else {
            Cookies.set('SR_PR_asTrigger', true);
        }
        triggerAttentiveSignup();
    });
}

function triggerAttentiveSignup() {
    const id = Cookies.get('SR_PR_kId');
    const email = Cookies.get('SR_PR_kEm');
    const trigger = Cookies.get('SR_PR_asTrigger');
    const attentiveShown = Cookies.get('SR_PR_asShown');
    if (attentiveShown || !trigger) return;
    triggerAttentive(id, email);
}

function triggerAttentive(id, email) {
    try {
        if (!window.__attentive ? .trigger) {
            return setTimeout(() => {
                triggerAttentive(id, email);
            }, 500);
        }
        window.__attentive.trigger(null, id, email, 269269);
        Cookies.set('SR_PR_asShown', true, {
            expires: 7
        });
        gaTrack("Attentive-Signup", id, 'Attentive signup triggered');
    } catch (error) {
        console.log(error);
        setTimeout(() => {
            triggerAttentive(id, email);
        }, 1000);
    }
}

const personalizationFns = {
    addClass: (selector, className) => {
        document.querySelector(selector).classList.add(className);
    },
    removeClass: (selector, className) => {
        document.querySelector(selector).classList.remove(className);
    },
    load: (selector, url) => {
        fetch(url)
            .then(response => response.text())
            .then(html => {
                document.querySelector(selector).innerHTML = html;
            });
    },
    imgSrc: (selector, url) => {
        document.querySelector(selector).setAttribute('src', url);
    },
    hide: (selector) => {
        document.querySelector(selector).style.display = 'none';
    },
    show: (selector) => {
        document.querySelector(selector).style.display = 'block';
    },
    remove: (selector) => {
        document.querySelector(selector).remove();
    },
};

/*
 * This requires an element has already been defined with the right syntax e.g to load a section in the url: /sections/mens-banner
 * into an element with id: #men-promotion we need to have an element defined like this
 * <div data-px-bhv-men="load::#men-promotion=/sections/mens-banner">
 * addClass, removeClass, load, imgSrc have the syntax shown above (selector=value)
 * hide, show, remove needs only a selector e.g <div data-px-bhv-men="hide::#men-promotion">
 * To define multiple command, separate with a pipe (|) e.g
 * <div data-px-bhv-men="load::#men-promotion=/sections/mens-banner|hide::#men-promotion">
 */
function runPersonalizationActions(type, cohort) {
    const selectors = `px-${type}-${cohort}`;
    const actions = ['addClass', 'removeClass', 'load', 'imgSrc', 'hide', 'show', 'remove'];

    const elements = document.querySelectorAll(`[data-${selectors}]`);
    if (elements.length) {
        elements.forEach(element => {
            const pairs = element.getAttribute(`data-${selectors}`).split('|');
            pairs.forEach(pair => {
                const [command, values] = pair.split('::');

                if (!actions.includes(command)) {
                    return console.warn(`Action ${command} is not currently supported. Please use one of the supported actions: "${actions.join(', ')}"`);
                }
                if (values.includes('=')) {
                    const [selector, value] = values.split('=');
                    return personalizationFns[command](selector, value);
                }
                return personalizationFns[command](values);
            });
        });
    }
}

function getCurrentPersonalizion() {
    let pxTypeFromCookie = Cookies.get('SR_PR_px-type');
    let pxCohortFromCookie = Cookies.get('SR_PR_px-cohort');
    let pxType = pxTypeFromCookie || getUrlParam('px-type');
    let pxCohort = pxCohortFromCookie || getUrlParam('px-cohort');

    if (!pxType || !pxCohort) return;

    runPersonalizationActions(pxType, pxCohort);
}

function trackPageClicks(page, section, element) {
    try {
        gtag('event', 'User Click', {
            'event_category': page,
            'event_label': `${section} - ${element}`,
            'value': {
                [`${section}`]: `${element}`
            }
        });
    } catch (error) {
        setTimeout(() => {
            trackPageClicks(page, section, element);
        }, 500);
    }
}

function initClickTracker() {
    const selector = "[data-ga-track]";

    document.addEventListener('click', function(event) {
        if (event.target.matches(selector)) {
            const [page, section, element] = event.target.getAttribute('data-ga-track').split('|');
            trackPageClicks(page, section, element);
        }
    });
}