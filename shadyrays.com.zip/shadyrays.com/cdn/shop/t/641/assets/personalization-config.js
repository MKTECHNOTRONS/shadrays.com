window.personalizationConfig = {
    enabled: false,
    sections: [
        'navigation',
        'best-sellers',
        'new-arrivals',
        'mens-collection',
        'mens-collection-menu',
        'womens-collection',
        'womens-collection-menu',
        'product-upsell',
    ],

    cohortTags: [
        'Male',
        'Women',
        'male-casual',
        'colorush',
        'greenwolf',
        'male-sports',
        'male-premium',
        'VIP',
        'female-casual',
        'female-active',
        'Deal hunter',
        'Basic deal',
        'High spender',
        'Low Spender',
        'Non dweller',
        'Dweller',
        'High value',
        'Deep deal',
        'FX-NC-CHURN-RISK',
        'FX-NC-LAPSED',
        'FX-REPLACER',
        'FX-ORG-AGING',
        'FX-ORG-PLUS-REPLACER',
    ],

    personalizations: {
        male: {
            navigation: [{
                    action: 'moveBefore', // moveBefore, moveAfter
                    item: 'Prescription',
                    ref: 'Snow Goggles',
                },
                {
                    action: 'hide', // hide, show, remove
                    item: 'UV Shirts',
                },
            ],
        },
        women: {
            'best-sellers': [{
                    action: 'replace', // replace
                    item: 'Tangle Free',
                    content: {
                        // accepts html string or object with keys matching the data-attributes data-section-content-key e.g. data-best-sellers-content-title
                        title: 'Cayman',
                        desc: 'Snap pin hinges & no slip rubber temple tips for a versatile fit.',
                        image: 'https://shadyrays.com/cdn/shop/files/CL-31Angle1NEW_1.jpg?v=1689875500',
                        link: '/collections/cayman',
                        cta: 'Shop Cayman',
                    },
                },
                {
                    action: 'moveToStart', // moveToStart, moveToEnd
                    item: 'Navigator',
                },
            ],
        },
        colorush: {
            navigation: [{
                action: 'moveAfter', // moveBefore, moveAfter
                item: 'Golf',
                ref: 'Kids',
            }, ],
            'new-arrivals': [{
                    action: 'replace', // replace
                    item: 'Golf',
                    content: {
                        // accepts html string or object with keys matching the data-attributes data-section-content-key e.g. data-new-arrivals-content-title
                        title: 'Golf',
                        desc: 'The Golf is a classic style that is perfect for any occasion.',
                        image: 'https://shadyrays.com/cdn/shop/files/CL-31Angle1NEW_1.jpg?v=1689875500',
                        link: '/collections/golf',
                        cta: 'Shop Golf',
                    },
                },
                {
                    action: 'remove', // remove
                    item: 'Cayman',
                },
                {
                    action: 'append', // append, prepend
                    content: `<div data-new-arrivals-item="Capitan" class="sr-col-3 home-product-card col-capitan">
              <div class="col-wrapper position-relative">
                <div class="col-img">
                  <a data-ga-track="Homepage|Tile|Capitan" href="/collections/capitan">
                    <picture>
                        <source media="(min-width:740px)" srcset="https://cdn.shopify.com/s/files/1/0350/5401/files/capitan-hp-tile-desk.png">
                        <source media="(min-width:200px)" srcset="//cdn.shopify.com/s/files/1/0350/5401/files/capitanv2-hp-tile-mob.png?v=16608281265083538666">
                        <img src="https://cdn.shopify.com/s/files/1/0350/5401/files/capitan-hp-tile-desk.png" alt="Capitan">
                    </picture>
                  </a>
                </div>
  
                <div class="overly flex align-items-end justify-content-center home-product-card">
                    <div class="col-copy text-center">
                        <a data-ga-track="Homepage|Tile|Capitan" href="/collections/capitan">
                            <!--div class="image-tile-tag text-center mgb-5">
                                <img src="https://cdn.shopify.com/s/files/1/0350/5401/files/new-launch-tile-tag-icon.svg">
                            </div-->
                            <h3 class="hp-tile-title color-white font-size-48 fw-600 mgb-10 lh-11 mgb-10">Capitan</h3>
                            <p class="hp-tile-copy color-white font-size-18 fw-500 lh-160 mgb-20">Wrap around frame built for performance &amp; all day comfort.</p>
                        </a>
  
                        <div class="btn-block flex justify-content-center mgb-35">
                            <a class="ibtn md round fw-600 color-white border-white home-product-card" href="/collections/capitan" data-ga-track="Homepage|Tile|Capitan"><span>Shop Capitan</span></a>
                        </div>
                    </div>
                </div>
              </div>
            </div>`,
                },
            ],
            'product-upsell': [{
                action: 'replace', // replace
                item: 'Product',
                // accepts html string or object with keys matching the data-attributes data-section-content-key e.g. data-new-arrivals-content-title
                content: `<div class="summer-bogo-product">
              <a href="/collections/col"><img class="sr-desktop" src="https://shadyrays.com/cdn/shop/files/CL-31Angle1NEW_1.jpg?v=1689875500" alt="Promotion Product Upsell Banner">
                <img class="sr-mobile" src="https://shadyrays.com/cdn/shop/files/CL-31Angle1NEW_1.jpg?v=1689875500" alt="Promotion Product Upsell Banner Mobile">
              </a>
              </div>`,
            }, ],
        },
        greenwolf: {
            navigation: [{
                action: 'moveBefore', // moveBefore, moveAfter
                item: 'Golf',
                ref: 'Kids',
            }, ],
            'new-arrivals': [{
                    action: 'replace',
                    item: 'Golf',
                    content: {
                        // accepts html string or object with keys matching the data-attributes data-section-content-key e.g. data-new-arrivals-content-title
                        title: 'Golf',
                        desc: 'The Golf is a classic style that is perfect for any occasion.',
                        image: 'https://shadyrays.com/cdn/shop/files/CL-31Angle1NEW_1.jpg?v=1689875500',
                        link: '/collections/golf',
                        cta: 'Shop Golf',
                    },
                },
                {
                    action: 'remove', // remove
                    item: 'Capitan',
                },
                {
                    action: 'prepend', // append, prepend
                    content: `<div data-new-arrivals-item="Capitan" class="sr-col-3 home-product-card col-capitan">
              <div class="col-wrapper position-relative">
                <div class="col-img">
                  <a data-ga-track="Homepage|Tile|Capitan" href="/collections/capitan">
                    <picture>
                        <source media="(min-width:740px)" srcset="https://cdn.shopify.com/s/files/1/0350/5401/files/capitan-hp-tile-desk.png">
                        <source media="(min-width:200px)" srcset="//cdn.shopify.com/s/files/1/0350/5401/files/capitanv2-hp-tile-mob.png?v=16608281265083538666">
                        <img src="https://cdn.shopify.com/s/files/1/0350/5401/files/capitan-hp-tile-desk.png" alt="Capitan">
                    </picture>
                  </a>
                </div>
  
                <div class="overly flex align-items-end justify-content-center home-product-card">
                    <div class="col-copy text-center">
                        <a data-ga-track="Homepage|Tile|Capitan" href="/collections/capitan">
                            <!--div class="image-tile-tag text-center mgb-5">
                                <img src="https://cdn.shopify.com/s/files/1/0350/5401/files/new-launch-tile-tag-icon.svg">
                            </div-->
                            <h3 class="hp-tile-title color-white font-size-48 fw-600 mgb-10 lh-11 mgb-10">Capitan</h3>
                            <p class="hp-tile-copy color-white font-size-18 fw-500 lh-160 mgb-20">Wrap around frame built for performance &amp; all day comfort.</p>
                        </a>
  
                        <div class="btn-block flex justify-content-center mgb-35">
                            <a class="ibtn md round fw-600 color-white border-white home-product-card" href="/collections/capitan" data-ga-track="Homepage|Tile|Capitan"><span>Shop Capitan</span></a>
                        </div>
                    </div>
                </div>
              </div>
            </div>`,
                },
            ],
        },
        'male-casual': {
            'mens-collection': [{
                action: 'moveAfter', // moveBefore, moveAfter
                item: 'Titan',
                ref: 'Classics',
            }, ],
            'mens-collection-menu': [{
                action: 'moveBefore', // moveBefore, moveAfter
                item: 'Cayman',
                ref: 'Navigator',
            }, ],
            'new-arrivals': [{
                    action: 'replace',
                    item: 'Golf',
                    content: {
                        // accepts html string or object with keys matching the data-attributes data-section-content-key e.g. data-new-arrivals-content-title
                        title: 'Golf',
                        desc: 'The Golf is a classic style that is perfect for any occasion.',
                        image: 'https://shadyrays.com/cdn/shop/files/CL-31Angle1NEW_1.jpg?v=1689875500',
                        link: '/collections/golf',
                        cta: 'Shop Golf',
                    },
                },
                {
                    action: 'remove', // remove
                    item: 'Capitan',
                },
            ],
        },
    },
};