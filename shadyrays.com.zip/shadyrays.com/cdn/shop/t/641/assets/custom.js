/**
 * JAVASCRIPT DEVELOPER DOCUMENTATION
 *
 * Symmetry is a powerful and customizable theme designed for large-scale e-commerce stores. Built
 * using Web Components, it offers a highly modular architecture that makes customization and
 * maintenance easier than ever. In addition, Symmetry is optimized for speed, ensuring that your
 * store runs as fast as possible to provide your customers with a seamless shopping experience.
 *
 * If you would like to add your own JS to Symmetry, we recommend using this file and referencing
 * it using Theme Settings > Advanced > Custom HTML.
 *
 * As a brief overview, Symmetry:
 *  - Broadcasts many JS events.
 *  - Is built using Web Components.
 *  - Leverages 'code splitting' for some features.
 *  - Is completely custom built (no JS libraries)
 *  - Has a number of JS utilities.
 *
 *
 *
 * =================================================================================================
 * Custom JavaScript Events
 * =================================================================================================
 *
 * Symmetry broadcasts many custom events for ease of extensibility, detailed in this section.
 *
 * When in the Theme Editor, the details of each custom event will be logged out in the Dev Tools
 * console everytime it is triggered.
 *
 * Events are named in the following convention: ["on/dispatch"]:[subject]:[action] (where
 * 'dispatch' will trigger an event to occur, and 'on' indicates an event has occurred).
 *
 * All 'Return data' detailed in this section is returned within the 'event.detail' object.
 *
 * The available events are:
 *  1.  on:variant:change
 *  2.  on:cart:add
 *  3.  on:cart:error
*   4.  on:cart:after-merge
 *  5.  on:cart-drawer:before-open
 *  6.  on:cart-drawer:after-open
 *  7.  on:cart-drawer:after-close
 *  8.  on:quickbuy:before-open
 *  9.  on:quickbuy:after-open
 *  10. on:quickbuy:after-close
 *  11. dispatch:cart-drawer:open
 *  12. dispatch:cart-drawer:refresh
 *  13. dispatch:cart-drawer:close
 *  14. on:debounced-resize
 *  15. on:breakpoint-change
 *
 * -------------------------------------------------------------------------------------------------
 * 1) on:variant:change
 * -------------------------------------------------------------------------------------------------
 * Fires whenever a variant is selected (e.g. Product page, Quickbuy, Featured Product etc).
 *
 * How to listen:
 * document.addEventListener('on:variant:change', (event) => {
 *  // your code here
 * });
 *
 * Returned data:
 *  - form: the product form content
 *  - variant: the selected variant object
 *  - allVariants: an array of all variants
 *  - selectedOptions: an array of currently selected options (e.g. ['Blue', 'Large'])
 *
 *
 * -------------------------------------------------------------------------------------------------
 * 2) on:cart:add
 * -------------------------------------------------------------------------------------------------
 * Fires when a variant has been added to the cart, where it didn't exist in the cart before. This
 * event does not fire when the added variant was already in the cart.
 *
 * How to listen:
 * document.addEventListener('on:cart:add', (event) => {
 *   // your code here
 * });
 *
 * Returned data:
 *   - variantId: id of the variant that was just added to the cart
 *
 *
 * -------------------------------------------------------------------------------------------------
 * 3) on:cart:error
 * -------------------------------------------------------------------------------------------------
 * Fires when an action related to the cart has failed, for example adding too much quantity of an
 * item to the cart.
 *
 * How to listen:
 * document.addEventListener('on:cart:error', (event) => {
 *   // your code here
 * });
 *
 * Returned data:
 *   - error: the error message
 *
 *
 * -------------------------------------------------------------------------------------------------
 * 4) on:cart:after-merge
 * -------------------------------------------------------------------------------------------------
 * Fires after a list of cart items has finished being dynamically updated after a cart change.
 *
 * How to listen:
 * document.addEventListener('on:cart:after-merge', (event) => {
 *   // your code here
 * });
 *
 *
 * -------------------------------------------------------------------------------------------------
 * 5) on:cart-drawer:before-open
 * -------------------------------------------------------------------------------------------------
 * Fires before the cart drawer opens.
 *
 * How to listen:
 * document.addEventListener('on:cart-drawer:before-open', (event) => {
 *   // your code here
 * });
 *
 *
 * -------------------------------------------------------------------------------------------------
 * 6) on:cart-drawer:after-open
 * -------------------------------------------------------------------------------------------------
 * Fires after the cart drawer has finished opening.
 *
 * How to listen:
 * document.addEventListener('on:cart-drawer:after-open', (event) => {
 *   // your code here
 * });
 *
 *
 * -------------------------------------------------------------------------------------------------
 * 7) on:cart-drawer:after-close
 * -------------------------------------------------------------------------------------------------
 * Fires after the cart drawer has finished closing.
 *
 * How to listen:
 * document.addEventListener('on:cart-drawer:after-close', (event) => {
 *   // your code here
 * });
 *
 *
 * -------------------------------------------------------------------------------------------------
 * 8) on:quickbuy:before-open
 * -------------------------------------------------------------------------------------------------
 * Fires before the quick buy drawer opens.
 *
 * How to listen:
 * document.addEventListener('on:quickbuy:before-open', (event) => {
 *   // your code here
 * });
 *
 *
 * -------------------------------------------------------------------------------------------------
 * 9) on:quickbuy:after-open
 * -------------------------------------------------------------------------------------------------
 * Fires after the quick buy drawer has finished opening.
 *
 * How to listen:
 * document.addEventListener('on:quickbuy:after-open', (event) => {
 *   // your code here
 * });
 *
 *
 * -------------------------------------------------------------------------------------------------
 * 10) on:quickbuy:after-close
 * -------------------------------------------------------------------------------------------------
 * Fires after the quick buy drawer has finished closing.
 *
 * How to listen:
 * document.addEventListener('on:quickbuy:after-close', (event) => {
 *   // your code here
 * });
 *
 *
 * -------------------------------------------------------------------------------------------------
 * 11) dispatch:cart-drawer:open
 * -------------------------------------------------------------------------------------------------
 * Opens the cart drawer (if enabled in the Theme Settings).
 *
 * How to trigger:
 * document.dispatchEvent(new CustomEvent('dispatch:cart-drawer:open'));
 *
 * You can optionally pass in a 'detail' object with a property of 'opener', which specifies the DOM
 * element that should be focussed on when the drawer is closed.
 *
 * Example:
 * document.getElementById('header-search').addEventListener('keydown', (evt) => {
 *   if (evt.keyCode === 67) {
 *     evt.preventDefault();
 *     document.dispatchEvent(new CustomEvent('dispatch:cart-drawer:open', {
 *       detail: {
 *         opener: evt.target
 *       }
 *     }));
 *   }
 * });
 *
 * In this example, we attach a keydown listener to the search input in the header. If the user
 * presses the 'c' key, it prevents the default behavior (which would be to type the letter 'c' in
 * the input) and dispatches the 'dispatch:cart-drawer:open' event with a 'detail' object that
 * specifies the search input as the opener. When the cart drawer is closed, focus is returned to
 * the search input.
 *
 *
 * -------------------------------------------------------------------------------------------------
 * 12) dispatch:cart-drawer:refresh
 * -------------------------------------------------------------------------------------------------
 * Refreshes the contents of the cart drawer.
 *
 * This event is useful when you are adding variants to the cart and would like to instruct the
 * theme to re-render the cart drawer.
 *
 * How to trigger:
 * document.dispatchEvent(new CustomEvent('dispatch:cart-drawer:refresh', {
 *   bubbles: true
 * }));
 *
 *
 * -------------------------------------------------------------------------------------------------
 * 13) dispatch:cart-drawer:close
 * -------------------------------------------------------------------------------------------------
 * Closes the cart drawer.
 *
 * How to trigger:
 * document.dispatchEvent(new CustomEvent('dispatch:cart-drawer:close'));
 *
 *
 * -------------------------------------------------------------------------------------------------
 * 14) on:debounced-resize
 * -------------------------------------------------------------------------------------------------
 * Fires when the viewport finishes resizing (debounced to 300ms by default).
 *
 * How to listen:
 * window.addEventListener('on:debounced-resize', (event) => {
 *   // your code here
 * });
 *
 *
 * -------------------------------------------------------------------------------------------------
 * 15) on:breakpoint-change
 * -------------------------------------------------------------------------------------------------
 * Fires when the breakpoint of the viewport changes.
 *
 * Example:
 * window.addEventListener('on:breakpoint-change', (event) => {
 *  if (theme.mediaMatches.md) {
 *   console.log('we are not on mobile');
 *  }
 * });
 *
 *
 *
 * =================================================================================================
 * Web Components
 * =================================================================================================
 *
 * Symmetry utilizes Web Components to the fullest.
 *
 * Web Components are a set of standardized APIs that allow developers to create custom, reusable
 * HTML elements that can be used across different web pages and applications.
 * Web Components consist of three main technologies: Custom Elements, Shadow DOM and HTML
 * Templates.
 *
 * See Mozilla for more: https://developer.mozilla.org/en-US/docs/Web/Web_Components
 *
 *
 *
 =================================================================================================
 * Third-Party JavaScript Dependencies
 * =================================================================================================
 *
 * Symmetry has no third-party JavaScript dependencies.
 *
 *
 * =================================================================================================
 *
 * Have fun! - The Clean Canvas Development Team.
 */
// Select the sticky filter element


/**
 * SR Custom Components
 */

/* SR Tab Content */
class SRTabContents extends HTMLElement {
    constructor() {
        super();
    }

    connectedCallback() {
        const tab_items = Array.from(this.querySelectorAll('sr-tab'));

        tab_items.forEach((tab, index) => {
            tab.addEventListener('click', (event) => {
                this.handleTabClick(event, index);
            });
        });
    }

    handleTabClick(event, index) {
        const target_tab = event.target;
        const tab_items = this.querySelectorAll('sr-tab');
        const tab_content_items = this.querySelectorAll('sr-tab-content');

        Array.from(tab_items).forEach(tab_item => {
            tab_item.classList.remove('active');
        });

        Array.from(tab_content_items).forEach(tab_content_item => {
            if (tab_content_item.tagName === 'SR-TAB-CONTENT') {
                tab_content_item.classList.remove('active');
            }
        });

        tab_content_items[index].classList.add('active');
        target_tab.classList.add('active');
    }
}
customElements.define('sr-tab-contents', SRTabContents);
/* SR Tab Content end */

/* SR Green Wolf Product Card */
class SRGWProductCard extends HTMLElement {
    constructor() {
        super();
    }

    connectedCallback() {
        const color_dot = Array.from(this.querySelectorAll('input[type="radio"]'));
        const button = this.querySelectorAll('a.btn-gw-product-card')[0];
        let ctr = 0;

        color_dot.forEach(cd => {
            if (ctr == 0) {
                button.setAttribute('href', cd.dataset.prodUrl);
            }
            cd.addEventListener('change', (event) => {
                this.handleColorDotChange(event);
            });
            ctr++;
        });
    }

    handleColorDotChange(event) {
        const target_color_dot = event.target;
        //const source = this.querySelectorAll('.product-image picture source')[0];
        //const image = this.querySelectorAll('.product-image picture img')[0];
        const img_mobile = this.querySelectorAll('.product-image picture img.mobile-only')[0];
        const img_desktop = this.querySelectorAll('.product-image picture img.desktop-only')[0];
        const button = this.querySelectorAll('a.btn-gw-product-card')[0];
        const button_call_class = target_color_dot.dataset.callbackClass;

        const button_tile = document.querySelectorAll(`a.${button_call_class}`)[0];

        //source.setAttribute('og-src', target_color_dot.dataset.imgMob);
        //source.setAttribute('srcset', target_color_dot.dataset.imgSrcsetMob);

        img_mobile.src = target_color_dot.dataset.imgMob;
        img_mobile.setAttribute('srcset', target_color_dot.dataset.imgSrcsetMob);

        img_desktop.src = target_color_dot.dataset.imgDesk;
        img_desktop.setAttribute('srcset', target_color_dot.dataset.imgSrcsetDesk);

        button.setAttribute('href', target_color_dot.dataset.prodUrl);
        button_tile.setAttribute('href', target_color_dot.dataset.prodUrl);
    }
}
customElements.define('sr-gw-product-card', SRGWProductCard);
/* SR Green Wolf Product Card end */

/* SR Image Comparison */
class SRImageComparison extends HTMLElement {
    constructor(parameters) {
        super();
    }

    connectedCallback() {
        const slider = this.querySelector('.comparison-slider');
        const handle = this.querySelector('.slider-handle');
        const imageAfter = this.querySelector('.image-after');

        const color_dot = Array.from(this.querySelectorAll('input[type="radio"]'));
        color_dot.forEach(cd => {
            cd.addEventListener('change', (event) => {
                this.handleColorDotChange(event);
            });
        });

        let isDragging = false;

        handle.addEventListener('mousedown', () => isDragging = true);
        this.addEventListener('mouseup', () => isDragging = false);

        this.addEventListener('mousemove', (e) => {
            if (!isDragging) return;

            const rect = slider.getBoundingClientRect();
            let x = e.clientX - rect.left; // Get mouse position relative to the slider
            if (x < 0) x = 0;
            if (x > rect.width) x = rect.width;

            const percentage = (x / rect.width) * 100;
            handle.style.left = `${percentage}%`;
            imageAfter.style.clipPath = `inset(0 ${100 - percentage}% 0 0)`;
        });

        handle.addEventListener('touchstart', () => isDragging = true);
        this.addEventListener('touchend', () => isDragging = false);

        this.addEventListener('touchmove', (e) => {
            if (!isDragging) return;

            const touch = e.touches[0];
            const rect = slider.getBoundingClientRect();
            let x = touch.clientX - rect.left; // Get touch position relative to the slider
            if (x < 0) x = 0;
            if (x > rect.width) x = rect.width;

            const percentage = (x / rect.width) * 100;
            handle.style.left = `${percentage}%`;
            imageAfter.style.clipPath = `inset(0 ${100 - percentage}% 0 0)`;
        });
    }

    handleColorDotChange(event) {
        const target_color_dot = event.target;
        const label = document.querySelectorAll('.img-comp-after')[0];
        const img2 = document.querySelectorAll('.image-after')[0];
        const slider = document.querySelectorAll('.slider-handle')[0];

        const comparison_slider = document.querySelectorAll('.comparison-slider')[0];
        label.innerHTML = target_color_dot.dataset.title;
        comparison_slider.querySelectorAll('.image-before')[0].src = target_color_dot.dataset.imgAfter;
        comparison_slider.querySelectorAll('.image-before')[0].setAttribute('srcset', target_color_dot.dataset.imgAfter);
    }
}
customElements.define('sr-image-comparison', SRImageComparison);
/* SR Image Comparison end */

/* SR Product Card with Color dots */
SRProductCardWithCD = class extends HTMLElement {
    constructor() {
        super();
    }

    connectedCallback() {
        this.addEventListener('change', this.handleColorDotChange.bind(this));
        window.addEventListener('DOMContentLoaded', () => {
            const selectedRadio = this.querySelector('input[type="radio"]:checked');
            if (selectedRadio) {
                this.handleColorDotChange({
                    target: selectedRadio
                });
            }
        });
    }

    handleColorDotChange(event) {
        if (event.target.type === "radio") {
            const sel_cd = event.target;
            const prod_info = this.querySelector('.sr-product-info');
            const image1 = prod_info.querySelector('img.default-image');
            const image2 = prod_info.querySelector('img.hover-image');
            const price = prod_info.querySelector('.product-price');
            const title = prod_info.querySelector('.product-name a');
            const a_link = prod_info.querySelectorAll('a');

            image1.src = sel_cd.dataset.img1;
            image1.setAttribute('srcset', sel_cd.dataset.img1Srcset);

            image2.src = sel_cd.dataset.img2;
            image2.setAttribute('srcset', sel_cd.dataset.img2Srcset);
            title.innerHTML = sel_cd.dataset.title;
            price.innerHTML = sel_cd.dataset.price;
            a_link.forEach((link) => {
                link.setAttribute('href', sel_cd.dataset.prodUrl);
            });
            if (sel_cd.dataset.showAllTags) {
                // code here!
            }
        }
    }
}
customElements.define('sr-product-card-cd', SRProductCardWithCD);
/* SR Product Card with Color dots end */


class IGOT2MarkdownHandler {
    constructor() {

        this.config = {
            discountCode: 'IGOT2',
            discountMultiplier: 0.75,
            discountCollections: ["shade-shop", "green-wolf", "kids-snow-goggles", "kids-snow-goggle"],
            igot2MarkdownId: "discount-igot2",
            igot2CouponCode: "IGOT2",
            igot2CouponMultiplier: 0.75,
        };

        this.cookies = {
            markdownObject: Cookies.getJSON('markdown_object') || [],
            vanityId: Cookies.get("vu_id") || "",
            tempVanityId: Cookies.get("tmp_vanity_id") || "",
            customerType: Cookies.get("SR_PR_kStatus") || "",
        };

        this.markdownObject = this.cookies.markdownObject;
        this.hasMarkdown = false;
        this.discountMultiMap = {
            0.8: {
                msg: '20%',
                upmsg: '25%'
            },
            0.75: {
                msg: '25%',
                upmsg: '30%'
            },
            0.7: {
                msg: '30%',
                upmsg: '35%'
            },
            0.65: {
                msg: '35%',
                upmsg: '40%'
            },
            0.6: {
                msg: '40%',
                upmsg: '45%'
            }
        }
    }

    init() {
        this.refreshSelectors();
        setTimeout(() => {
            this.initialSetup();
            this.checkEligibleCriteria();
        }, 1000);
    }

    refreshSelectors() {
        this.container = document.querySelector('cart-form');
        this.elements = {
            discAT20: this.container.querySelector('[data-discount-code="AT20"]'),
            upsellTo2Pdp: document.querySelector('.sr-upsell-to-2-wrapper'),
            upsellTo2Cart: this.container.querySelector('.sr-upsell-to-2-cart-wrapper[data-promo="IGOT2"]'),
            itemDiscountEligible: this.container.querySelectorAll('.cart-item[data-item-discount-eligible="true"]'),
        };
        this.itemDiscountEligibleCount = this.elements.itemDiscountEligible.length;
    }

    initialSetup() {
        const {
            vanityId,
            tempVanityId,
            customerType
        } = this.cookies;
        const {
            discAT20,
            upsellTo2Pdp
        } = this.elements;

        if (!tempVanityId) {
            Cookies.set("tmp_vanity_id", vanityId);
            console.log('set tmp_vanity_id');
        }

        if (discAT20) {
            discAT20.classList.add('hidden');
        }

        if (upsellTo2Pdp) {
            upsellTo2Pdp.classList.add('hidden');
        }

        if (upsellTo2Pdp && customerType && (customerType === 'VIP' || customerType === 'Purchaser' || customerType === 'Non-Purchaser')) {
            upsellTo2Pdp.classList.remove('hidden');
        }
    }

    calculateTotalQty() {
        const {
            itemDiscountEligible
        } = this.elements;
        console.log('calculateTotalQty', itemDiscountEligible);

        let totalQty = 0;
        if (itemDiscountEligible) {
            itemDiscountEligible.forEach(item => {
                totalQty += Number(item.dataset.qty);
            });
        }

        return totalQty;
    }

    checkEligibleCriteria() {
        const {
            vanityId,
            tempVanityId,
            customerType
        } = this.cookies;
        console.log('checkEligibleCriteria', {
            vanityId,
            tempVanityId,
            customerType
        });

        if (vanityId || tempVanityId) {
            this.checkVanityMarkdown();
        } else if (customerType && (customerType === 'VIP' || customerType === 'Purchaser' || customerType === 'Non-Purchaser')) {
            this.checkVIPMarkdown();
        } else {
            this.checkMarkdownDiscount();
        }

        this.updateBanner();
    }

    checkVanityMarkdown() {
        const {
            discountCollections,
            igot2MarkdownId,
            igot2CouponCode
        } = this.config;
        const {
            vanityId,
            tempVanityId
        } = this.cookies;

        const totalQty = this.calculateTotalQty();
        console.log('checkVanityMarkdown', {
            vanityId,
            tempVanityId,
            totalQty
        });

        if (totalQty <= 1) {
            MarkdownPricePro.clear(igot2MarkdownId);
            setTimeout(() => {
                if (!Cookies.get("vu_id") && tempVanityId) {
                    console.log('checkVanityMarkdown -> Load Vanity', vanityId);
                    window.location.href = "?vu_id=" + tempVanityId;
                }
            }, 700);
            this.hasMarkdown = true;
            return;
        }

        setTimeout(() => {
            this.hasMarkdown = false;
            const markdownObject = Cookies.getJSON('markdown_object') || [];
            const vanityMarkdown = markdownObject.find((object) => object.markdown_id === 'vanity-markdown');
            const campaignMarkdown = markdownObject.find((object) => object.markdown_id === 'campaign_impression');

            console.log('checkVanityMarkdown -> vanityMarkdown', vanityMarkdown);

            if (!vanityMarkdown) {
                return;
            }

            const multiplier = Number(vanityMarkdown.markdown_multiplier);
            console.log('multiplier', multiplier);

            const discountUpgradeMap = {
                0.8: {
                    code: igot2CouponCode,
                    upgraded_discount: 0.75
                },
                0.75: {
                    code: 'GOT30',
                    upgraded_discount: 0.7
                },
                0.7: {
                    code: 'GOT35',
                    upgraded_discount: 0.65
                },
                0.65: {
                    code: 'GOT40',
                    upgraded_discount: 0.6
                }
            };

            const discountCode = discountUpgradeMap[multiplier];
            if (!discountCode) {
                return;
            }

            window.Shopify.vanity.stop();
            console.log('checkVanityMarkdown -> autoApplyCouponCode', discountCode.code);

            window.autoApplyCouponCode(discountCode.code);
            MarkdownPricePro.init({
                discount_code: discountCode.code,
                multiplier: discountCode.upgraded_discount,
                collections: discountCollections,
                id: igot2MarkdownId,
            });

            console.log('checkVanityMarkdown -> ' + discountCode.code + ' applied!!');

            this.updateBanner();
        }, 300);

        this.hasMarkdown = true;
    }

    checkVIPMarkdown() {
        const {
            discountCollections,
            igot2MarkdownId,
            igot2CouponCode,
            igot2CouponMultiplier
        } = this.config;
        setTimeout(() => {
            const {
                vanityId,
                tempVanityId,
                customerType
            } = this.cookies;
            const totalQty = this.calculateTotalQty();
            if (totalQty > 1) {
                MarkdownPricePro.init({
                    discount_code: igot2CouponCode,
                    multiplier: igot2CouponMultiplier,
                    collections: discountCollections,
                    id: igot2MarkdownId,
                });
                window.autoApplyCouponCode(igot2CouponCode);
                MarkdownPricePro.run();

                console.log('checkVIPMarkdown -> Update discount igot2');
            } else {
                MarkdownPricePro.clear(igot2MarkdownId);
                MarkdownPricePro.run();
                // if (customerType === 'Non-Purchaser' && igot2MarkdownId=='') {
                //     window.location.reload();
                // }
                console.log('remove markdown', igot2MarkdownId);
            }
            this.hasMarkdown = true;
            console.log('checkVIPMarkdown -> Eligible item: ', totalQty);
            this.updateBanner();
        }, 600);
    }

    checkMarkdownDiscount() {
        const self = this;
        const {
            igot2MarkdownId,
            igot2CouponCode,
            igot2CouponMultiplier
        } = this.config;

        const totalQty = self.calculateTotalQty();
        const markdownObject = Cookies.getJSON('markdown_object') || [];
        const AT20Markdown = markdownObject.find((object) => object.markdown_discount_code === 'AT20');
        const IGOT2Markdown = markdownObject.find((object) => object.markdown_discount_code === 'IGOT2');

        if (AT20Markdown) {
            if (totalQty > 1) {
                MarkdownPricePro.clear("campaign_impression");
                setTimeout(() => {
                    MarkdownPricePro.init({
                        discount_code: igot2CouponCode,
                        multiplier: igot2CouponMultiplier,
                        collections: self.discountCollections,
                        id: igot2MarkdownId,
                    });
                    console.log('checkMarkdownDiscount -> autoApplyCouponCode', igot2CouponCode);
                    window.autoApplyCouponCode(igot2CouponCode);
                    MarkdownPricePro.run();
                    console.log('checkMarkdownDiscount -> IGOT2 applied!!');
                }, 500);
            }
            self.hasMarkdown = true;
        }

        if (Cookies.get('markdown_discount_code') && Cookies.get('markdown_discount_code') === 'IGOT2') {
            if (totalQty < 2) {
                MarkdownPricePro.clear(igot2MarkdownId);
                MarkdownPricePro.init({
                    discount_code: 'AT20',
                    multiplier: '0.8',
                    collections: ["men-all-styles", "shade-shop", "green-wolf", "accessories", "blue-light", "readers", "shady-rays-rx", "snow-goggles-collection", "snow-goggle-collection", "snow-goggle-frames", "kids-snow-goggles", "kids", "react", "snow-goggles"],
                    id: "campaign_impression",
                });
                console.log('checkMarkdownDiscount -> autoApplyCouponCode', "AT20");
                window.autoApplyCouponCode("AT20");
                MarkdownPricePro.run();
                console.log('checkMarkdownDiscount -> AT20 applied!!');
            }
            self.hasMarkdown = true;
        }
        this.updateBanner();
    }

    updateBanner() {
        const {
            hasMarkdown,
            markdownObject,
            discountMultiMap
        } = this;

        if (!hasMarkdown) {
            return;
        }

        console.log('Has markdown load!');
        setTimeout(() => {
            const upsellTo2Pdp = document.querySelector('.sr-upsell-to-2-wrapper');
            const upsellTo2Cart = document.querySelector('.sr-upsell-to-2-cart-wrapper[data-promo="IGOT2"]');
            const totalQty = this.calculateTotalQty();
            console.log('updateBanner -> Has markdown', hasMarkdown);
            console.log('updateBanner -> Total qty', totalQty);

            if (totalQty > 1) {
                setTimeout(() => {
                    const markdownObject = Cookies.getJSON('markdown_object') || [];
                    const targetObject = markdownObject.find(obj => obj.markdown_id === "discount-igot2");
                    let percentMsg = '25%';
                    if (targetObject) {
                        console.log('target obj', targetObject.markdown_multiplier);
                        percentMsg = discountMultiMap[targetObject.markdown_multiplier].msg;
                    }
                    console.log('target obj per', percentMsg);

                    if (upsellTo2Pdp) {
                        console.log('target obj per --- ', percentMsg);
                        upsellTo2Pdp.innerHTML = `<div class="sr-upsell-to-2-copy">YOU’VE GOT <span class="discount-percent">${percentMsg} OFF </span>YOUR WHOLE ORDER</div>`;
                    }
                    if (upsellTo2Cart) {
                        console.log('target obj per --- ', percentMsg);
                        upsellTo2Cart.innerHTML = `<div class="sr-upsell-to-2-get">Deal Met! You’ve got <span>${percentMsg} OFF</span> your whole order</div>`;
                    }
                }, 1000);
            } else if (totalQty === 1) {
                const markdownObject = Cookies.getJSON('markdown_object') || [];
                const targetObject = markdownObject.find(obj => obj.markdown_id === "vanity-markdown");
                let percentMsg = '25%';
                if (targetObject) {
                    percentMsg = discountMultiMap[targetObject.markdown_multiplier].upmsg;
                }
                if (upsellTo2Pdp) {
                    console.log('Load PDP Upsell to 2 callout');
                    upsellTo2Pdp.innerHTML = `<div class="sr-upsell-to-2-copy"><span class="discount-percent">${percentMsg} OFF </span>WHEN YOU add 1 more pair</div>`;
                }
                if (upsellTo2Cart) {
                    upsellTo2Cart.innerHTML = `<div class="sr-upsell-to-2-cart"><div class="sr-upsell-to-2-cart-copy"><p class="discount-copy"><span class="discount-percent">${percentMsg} OFF </span>WHEN YOU add 1 more pair</p><div class="shop-men-women flex justify-center"><a href="/collections/men-all-styles">Shop Mens</a> <span>|</span> <a href="/collections/women-all-styles">Shop Womens</a></div><p class="sr-igot2-note"><i>Offer cannot be combined with other coupons.</i></p></div></div>`;
                }
            } else {
                const markdownObject = Cookies.getJSON('markdown_object') || [];
                const targetObject = markdownObject.find(obj => obj.markdown_id === "vanity-markdown");
                let percentMsg = '25%';
                console.log('No Items in the cart');
                if (targetObject) {
                    percentMsg = discountMultiMap[targetObject.markdown_multiplier].upmsg;
                }
                if (upsellTo2Pdp) {
                    upsellTo2Pdp.innerHTML = `<div class="sr-upsell-to-2-copy"><span class="discount-percent">${percentMsg} OFF </span>WHEN YOU get 2+ pairs</div>`;
                }
                if (upsellTo2Cart) {
                    upsellTo2Cart.innerHTML = '';
                }
            }
            if (upsellTo2Pdp) {
                upsellTo2Pdp.classList.remove('hidden');
            }

        }, 100);
    }

    static checkHighDemand() {
        const cartHighDemand = document.querySelector('.cart-high-demand');
        const cartHasHighDemand = document.querySelectorAll('[data-high-demand="true"]');
        if (cartHighDemand) {
            if (cartHasHighDemand.length > 0) {
                cartHighDemand.classList.remove('hidden');
            } else {
                cartHighDemand.classList.add('hidden');
            }
        }
    }

}
const igot2MarkdownHandler = new IGOT2MarkdownHandler();
document.addEventListener('DOMContentLoaded', function() {
    // Touchstart on mobile for product card in collection
    const img_link = document.querySelectorAll(".product-tap");
    img_link.forEach(link => {
        const imageWrapper = link.querySelector(".product-image-wrapper");
        const image = link.querySelector(".product-image-wrapper img");
        image.addEventListener('touchstart', () => {
            setTimeout(() => {
                window.location = link.href;
            }, 1000);
        });
        imageWrapper.addEventListener('touchstart', () => {
            setTimeout(() => {
                window.location = link.href;
            }, 1000);
        });
    });

    setTimeout(() => {
        if (document.body.classList.contains('loop-returns-activated')) {
            document.querySelector('.sr-btn-cart').classList.remove('hidden');
            document.querySelector('.sr-btn-checkout').classList.add('hidden');
            console.log('Loop Returns Activated!');
        } else {
            if (document.querySelector('.sr-btn-cart'))
                document.querySelector('.sr-btn-cart').classList.add('hidden');

            if (document.querySelector('.sr-btn-checkout'))
                document.querySelector('.sr-btn-checkout').classList.remove('hidden');
        }
    }, 500);

    /*
        const targetNode = document.querySelector('body');
        const classToMonitor = 'loop-returns-activated';
        const callback = (mutationsList) => {
            for (const mutation of mutationsList) {
                if (mutation.type === 'attributes' && mutation.attributeName === 'class') {
                    const currentClassList = mutation.target.classList;
                    if (currentClassList.contains(classToMonitor)) {
                        document.querySelector('.sr-btn-cart').classList.add('hidden');
                        document.querySelector('.sr-btn-checkout').classList.remove('hidden');
                        console.log('Loop Returns Activated!');
                    }
                }
            }
        };
        const observer = new MutationObserver(callback);
        observer.observe(targetNode, { attributes: true });
    */

    // Function to validate email format
    function checkIsValidEmail(email) {
        var regex = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;
        return regex.test(email);
    }

    // Handle click on elements with class 'btn-check-vip-status'
    document.querySelectorAll('.btn-check-vip-status').forEach(function(element) {
        element.addEventListener('click', function(e) {
            e.preventDefault();

            const form = this.closest('form');
            const button = this;
            const emailInput = form.querySelector('.stausemail');

            button.classList.add('is-loading');
            button.classList.remove('is-success');
            button.setAttribute('disabled', 'disabled');

            if (emailInput && emailInput.value && checkIsValidEmail(emailInput.value)) {
                checkVIPStatusByEmailForPopUp(btoa(emailInput.value), function(response) {
                    button.classList.remove('is-loading');
                    button.removeAttribute('disabled');
                    button.classList.add('is-success');
                });
            } else {
                button.classList.remove('is-loading');
                button.removeAttribute('disabled');
            }
        });
    });

    checkMysteryPairProduct();
    igot2MarkdownHandler.init();
    IGOT2MarkdownHandler.checkHighDemand();
});
/* SR React Custom Product end */


/* Attach event listener to the document */
document.addEventListener('on:cart:after-merge', function(e) {

    setTimeout(() => {
        if (document.body.classList.contains('loop-returns-activated')) {
            document.querySelector('.sr-btn-cart').classList.remove('hidden');
            document.querySelector('.sr-btn-checkout').classList.add('hidden');
            console.log('Loop Returns Activated!');
        } else {
            if (document.querySelector('.sr-btn-cart'))
                document.querySelector('.sr-btn-cart').classList.add('hidden');

            if (document.querySelector('.sr-btn-checkout'))
                document.querySelector('.sr-btn-checkout').classList.remove('hidden');
        }
    }, 500);

    setTimeout(() => {
        document.querySelectorAll('.cart-accordion').forEach((accordion) => {
            const toggleButton = accordion.querySelector('.accordion-angle');
            toggleButton.addEventListener('click', () => {
                // Toggle the active class on the clicked accordion
                accordion.classList.toggle('active');

                // Optionally close other accordions
                document.querySelectorAll('.cart-accordion').forEach((otherAccordion) => {
                    if (otherAccordion !== accordion) {
                        otherAccordion.classList.remove('active');
                    }
                });
            });
        });

        const cartItemJson = document.querySelector('script[data-json-id="cart-json"]');
        if (cartItemJson) {
            theme.globals.cartItems = JSON.parse(cartItemJson.innerHTML);
        }

    }, 100);

    setTimeout(() => {
        window.Shopify.vanity.init();
        igot2MarkdownHandler.init();
        IGOT2MarkdownHandler.checkHighDemand();
        MarkdownPricePro.run();
    }, 700);

});

document.addEventListener('on:cart:change', function(e) {
    if (e ? .detail ? .data) {
        theme.globals.cart = e.detail.data;
    }
});

document.addEventListener('collection:color-dot:change', function(e) {
    MarkdownPricePro.run();
});

document.addEventListener('product:color-dot:change', function(e) {
    MarkdownPricePro.run();
});


function checkMysteryPairProduct() {
    const body_tag = document.querySelector('body');
    const men_mp1 = 43630051983407;
    const women_mp1 = 43630052507695;
    const price_mp1 = '$19.45';

    const men_mp2 = 43630052114479;
    const women_mp2 = 43630052638767;
    const price_mp2 = '$22.00';

    const men_mp3 = 43630052278319;
    const women_mp3 = 43630052671535;
    const price_mp3 = '$24.00';

    const mp_handle = document.querySelector('.sr-box-mystery-details');
    if (body_tag.classList.contains("mystery-pair-1")) {
        mp_handle.querySelector('#mystery_men').value = men_mp1;
        mp_handle.querySelector('#mystery_women').value = women_mp1;
        mp_handle.querySelector('.price').innerHTML = price_mp1;
        //console.log('load mystery 1');
    } else if (body_tag.classList.contains("mystery-pair-2")) {
        mp_handle.querySelector('#mystery_men').value = men_mp2;
        mp_handle.querySelector('#mystery_women').value = women_mp2;
        mp_handle.querySelector('.price').innerHTML = price_mp2;
        //console.log('load mystery 2');
    } else if (body_tag.classList.contains("mystery-pair-3")) {
        mp_handle.querySelector('#mystery_men').value = men_mp3;
        mp_handle.querySelector('#mystery_women').value = women_mp3;
        mp_handle.querySelector('.price').innerHTML = price_mp3;
        //console.log('load mystery 3');
    }

    if (document.querySelector('.cart-mystery-pair-btn'))
        document.querySelector('.cart-mystery-pair-btn').removeAttribute('disabled');
}

document.addEventListener('markdown:after-run', function(e) {
    const markdownObject = e.detail ? .markdownObject;
    if (markdownObject) {
        new SchemaCorrector(markdownObject);
    }

});

class SchemaCorrector {

    constructor(markdownObject) {
        this.markdownObject = markdownObject;
        this.init();
    }

    init() {
        try {
            if (!theme.globals) return;

            const template = theme.globals.template;

            if (!template.includes('product')) return;

            const schemaElement = document.querySelector('script[type="application/ld+json"][data-product-schema-json]');
            if (!schemaElement) return;

            const schemaJson = JSON.parse(schemaElement.innerText);
            if (!schemaJson) return;

            const schemaType = schemaJson['@type'];

            if (schemaType !== 'ProductGroup' && schemaType !== 'Product') return;

            const user_currency = theme.globals.userCurrency;

            const formatter = new Intl.NumberFormat("en-US", {
                style: "decimal",
                currency: user_currency,
                maximumFractionDigits: 2,
                minimumFractionDigits: 2,
                useGrouping: !1,
            });

            const priceElement = document.querySelector('.product-form [data-product-collections] [data-value="markdown_price"]');
            if (!priceElement) return;

            const parentElement = priceElement.parentElement;

            if (!parentElement.dataset.productCollections) return;

            const collections = parentElement.dataset.productCollections.split(' ');
            const eligibleMarkdown = this.markdownObject.find((markdown) => {
                const eligibleCollections = markdown.markdown_collections.split(',');
                const filteredArray = collections.filter(value => eligibleCollections.includes(value));
                return filteredArray.length > 0;
            });

            if (!eligibleMarkdown) return;

            const mode = eligibleMarkdown.markdown_mode;
            const multiplier = Number(eligibleMarkdown.markdown_multiplier);

            const hasOfferData = schemaJson.hasVariant || schemaJson.offers;
            if (!hasOfferData) return;

            if (schemaJson.hasVariant) {
                schemaJson.hasVariant.map((offersData) => {
                    const offers = offersData.offers;
                    if (offers.discount) return;

                    const compareAtPrice = offers.price;

                    let newPrice = mode === "subtract" ?
                        compareAtPrice - Math.floor(multiplier * theme.globals.currencyConversion[theme.globals.userCurrency]) :
                        multiplier * compareAtPrice;

                    offers.price = formatter.format(newPrice);

                    if (compareAtPrice > newPrice) {
                        offers.originalPrice = formatter.format(compareAtPrice);
                        offers.discount = {
                            "@type": "Discount",
                            "amount": (compareAtPrice - newPrice).toFixed(2),
                            "percentOff": Math.round(((compareAtPrice - newPrice) / compareAtPrice) * 100)
                        };
                    }

                    return offers;
                });
            } else {
                const offers = schemaJson.offers;

                if (offers.discount) return;

                const compareAtPrice = offers.price;

                let newPrice = mode === "subtract" ?
                    compareAtPrice - Math.floor(multiplier * theme.globals.currencyConversion[theme.globals.userCurrency]) :
                    multiplier * compareAtPrice;

                offers.price = formatter.format(newPrice);

                if (compareAtPrice > newPrice) {
                    offers.originalPrice = formatter.format(compareAtPrice);
                    offers.discount = {
                        "@type": "Discount",
                        "amount": (compareAtPrice - newPrice).toFixed(2),
                        "percentOff": Math.round(((compareAtPrice - newPrice) / compareAtPrice) * 100)
                    };
                }

            }


            // Replace the old JSON-LD script with the updated one
            let updatedSchema = document.createElement("script");
            updatedSchema.type = "application/ld+json";
            updatedSchema.dataset.productSchemaJson = "";
            updatedSchema.classList.add("product-schema-json");
            updatedSchema.textContent = JSON.stringify(schemaJson, null, 2);

            // Remove old script and add the new one
            schemaElement.parentNode.replaceChild(updatedSchema, schemaElement);
        } catch (error) {
            console.log("Error updating product schema", error);
        }
    }

}
(function() {
    function handleFeatureLogic() {
        function getQueryParam(name) {
            const urlParams = new URLSearchParams(window.location.search);
            return urlParams.get(name) ? .toLowerCase() || null;
        }

        function setCookie(name, value) {
            document.cookie = `${name}=${value}; path=/; max-age=${24 * 60 * 60}`;
        }

        function getCookie(name) {
            const match = document.cookie.match(new RegExp(`(^| )${name}=([^;]+)`));
            return match ? match[2] : null;
        }

        const featureValue = getQueryParam("feature");
        const storedFeature = getCookie("feature");

        if (
            featureValue &&
            featureValue !== storedFeature &&
            document.body.classList.contains('show-alt-path')
        ) {
            setCookie("feature", featureValue);
        }

        const activeFeature = getCookie("feature");
        const homepageBanner = document.querySelector(".sr-homepage-banner");
        const stickyFilter = document.querySelector(".sticky-filter");

        document.querySelectorAll(".feature-section, .recent-btn:not(.shop-men)").forEach(section => {
            section.classList.add("hidden");
        });
        if (activeFeature) {
            homepageBanner ? .classList.add("hidden");

            const discountNote = document.querySelector('.top-discount-note');
            const slideshows = document.querySelectorAll('.section-sr-slideshow');
            if (discountNote && slideshows.length > 0) {
                const lastSlideshow = slideshows[slideshows.length - 1];
                lastSlideshow.parentNode.insertBefore(discountNote, lastSlideshow.nextSibling);
            }

            document.querySelector(`.sr-${activeFeature}`) ? .classList.remove("hidden");
            document.querySelector(`.shop-${activeFeature}`) ? .classList.remove("hidden");
            document.querySelector(".recently-viewed-bar") ? .classList.remove("hidden");

            if (stickyFilter) {
                stickyFilter.classList.add("rel-sticky-filter");
            }

            const featureCard = document.querySelector(`.card-${activeFeature}`);
            if (featureCard) {
                featureCard.style.order = "-1";
                featureCard.classList.remove("hidden");
            }

            if (activeFeature === "huron") {
                const allureCard = document.querySelector(".card-allure");
                if (allureCard) {
                    allureCard.classList.add("hidden");
                }
            }

            const reviewSection = document.querySelector(".review-section .image-overlap__image .fade-in-up");
            const reviewSection_mob = document.querySelector(".review-mobile-model");

            if (reviewSection) {
                const featureSlug = `${activeFeature}-rv`;
                const newImg = `
                    <img 
                        src="//shadyrays.com/cdn/shop/files/${featureSlug}.png?v=1699912370&amp;width=1140" 
                        alt="" 
                        width="1140" 
                        height="938" 
                        loading="lazy" 
                        sizes="(min-width: 1600px) 800px, (min-width: 768px) 50vw, 100vw" 
                        srcset="//shadyrays.com/cdn/shop/files/${featureSlug}.png?v=1699912370&amp;width=425 340w, 
                                //shadyrays.com/cdn/shop/files/${featureSlug}.png?v=1699912370&amp;width=600 480w, 
                                //shadyrays.com/cdn/shop/files/${featureSlug}.png?v=1699912370&amp;width=925 740w, 
                                //shadyrays.com/cdn/shop/files/${featureSlug}.png?v=1699912370&amp;width=1225 980w, 
                                //shadyrays.com/cdn/shop/files/${featureSlug}.png?v=1699912370&amp;width=1425 1140w" 
                        class="theme-img"
                    >
                `;
                reviewSection.innerHTML = newImg;
                if (reviewSection_mob) {
                    reviewSection_mob.innerHTML = newImg;
                }
            }

            if (document.body.classList.contains('template-collection') && typeof collectionTitle !== 'undefined') {
                if (collectionTitle === activeFeature) {
                    document.querySelector(".two-cols") ? .classList.add("hidden");
                    document.querySelector(".we-got-you-section.mobile-only") ? .classList.add("hidden");
                    document.querySelector(".trust-bar") ? .classList.remove("hidden");
                    document.querySelector(".review-section") ? .classList.remove("hidden");
                    document.querySelector(".hp-men-women-bestseller") ? .classList.remove("hidden");
                    document.querySelector(".section-sr-homepage-colorush") ? .style.setProperty("display", "block");
                    document.querySelector(".section-sr-homepage-replacement") ? .style.setProperty("display", "block");
                    document.querySelector(".recently-viewed-banner") ? .classList.add("hidden");
                }
            }
        } else {
            if (homepageBanner) {
                homepageBanner.style.opacity = "1";
            }
            if (stickyFilter) {
                stickyFilter.classList.remove("rel-sticky-filter");
            }
        }
    }

    setTimeout(handleFeatureLogic, 100);
})();
document.addEventListener("DOMContentLoaded", function() {
    const styleOptions = document.querySelectorAll('[data-option-name="style"]');
    const hardcaseContainer = document.getElementById("hardcase-container");

    if (styleOptions && hardcaseContainer) {
        const hardcaseData = JSON.parse(document.getElementById("hardcaseData").textContent);

        function normalizeString(str) {
            return str.toLowerCase().replace(/[-\s]+/g, "").trim();
        }

        function findMatchingVariant(normalizedStyle) {
            for (const key in hardcaseData.hardcaseVariants) {
                if (key.includes(normalizedStyle)) {
                    return hardcaseData.hardcaseVariants[key];
                }
            }
            return null;
        }

        function decodeHtml(html) {
            let txt = document.createElement("textarea");
            txt.innerHTML = html;
            return txt.value;
        }

        function loadHardcaseVariant(selectedStyle) {
            const normalizedStyle = normalizeString(selectedStyle);
            const variantData = findMatchingVariant(normalizedStyle);
            let selectedHardcase = variantData || hardcaseData.defaultHardcase || null;

            if (!selectedHardcase) {
                hardcaseContainer.innerHTML = "";
                return;
            }
            hardcaseContainer.innerHTML = `
                <sr-hardcase-product-card class="hardcase-card">
                    <div class="lightly-spaced-row">
                        <div class="product-info-block-text">
                            <div class="hardcase">
                                <details>
                                    <summary>
                                        <div class="hardcase-title">
                                            <span>${selectedHardcase.title}</span> <span class="hardcase-price-container">${decodeHtml(selectedHardcase.pp)}</span>
                                        </div>
                                        <label for="hardcase-checkbox" class="sr-toggle">
                                            <input type="checkbox" id="hardcase-checkbox" checked class="hardcase__checkbox sr-toggle-chk" value="${selectedHardcase.variantId}" data-hardcase-handle="${selectedHardcase.handle}"/>
                                            <span class="sr-toggle-slide"></span>
                                        </label>    
                                    </summary>
                                    <div class="flex">
                                        <div class="hardcase-img">
                                            <img src="${selectedHardcase.image}" alt="${selectedHardcase.title}">
                                        </div>
                                        <div class="hardcase-description">
                                            <h3>${selectedHardcase.model_heading}:</h3>
                                            ${selectedHardcase.description}
                                        </div>
                                    </div>
                                </details>
                            </div>
                        </div>
                    </div>
                </sr-hardcase-product-card>
            `;
            MarkdownPricePro.run();
        }

        if (styleOptions.length) {
            styleOptions.forEach(option => {
                option.addEventListener("change", function() {
                    loadHardcaseVariant(this.value);
                });

                if (option.checked) {
                    loadHardcaseVariant(option.value);
                }
            });
        }
    }

    //loadVIPProcessing();
    if (document.body.classList.contains("show-pdp-gallery")) {
        addcollectionimage();
    }
});


function loadVIPProcessing() {
    const vipProductData = document.getElementById("vip-product-data");
    if (!vipProductData) return;
    const checkbox = document.querySelector(".stl-vip-chk");

    const productData = JSON.parse(vipProductData.textContent);
    const variants = productData.variants || [];

    const vipVariant = variants.find(v => v.title === "VIP");
    const nonVipVariant = variants.find(v => v.title === "NON VIP");
    if (!vipVariant || !nonVipVariant) return;

    const isVipCustomer = Cookies.get('customer_vip') === 'vip' || Cookies.get('SR_PR_kStatus') === 'VIP';
    const selectedVariant = isVipCustomer ? vipVariant : nonVipVariant;
    const formatCurrency = (price) => {
        const curr = theme.globals.userCurrency === 'GBP' ? '£' : '$';
        let prices = price.toString().match(/[\d,]*\.?\d+/g) || [];
        const priceValue = parseFloat(prices[0] ? .replace(/,/g, '') || 0) / 100;
        return `${curr}${priceValue.toFixed(2)}`;
    };

    const updatePricingDetails = (variant) => {
        const priceDisplay = document.querySelector(".price-display");
        const compareAtPriceDisplay = document.querySelector(".compare-at-price");

        if (!checkbox || !priceDisplay || !compareAtPriceDisplay) return;

        checkbox.value = variant.id;
        priceDisplay.innerHTML = formatCurrency(variant.price);

        if (variant.compare_at_price && variant.compare_at_price > variant.price) {
            compareAtPriceDisplay.innerHTML = formatCurrency(variant.compare_at_price);
            compareAtPriceDisplay.style.display = "inline";
            priceDisplay.classList.add("sale-price");
        } else {
            compareAtPriceDisplay.style.display = "none";
            priceDisplay.classList.remove("sale-price");
        }
    };

    updatePricingDetails(selectedVariant);
    if (isVipCustomer) {
        checkbox.checked = true;
        addVipToCart(vipVariant.id);
        checkbox.disabled = true;
    }
}

addVipToCart = (variantId) => {
    const formData = {
        'items': [{
            'id': variantId,
            'quantity': 1,
            'properties': {
                '_vip_bundle': true
            }
        }]
    };

    fetch(theme.routes.cartAdd, {
            method: 'POST',
            body: JSON.stringify(formData),
            headers: {
                'Content-Type': 'application/json'
            }
        })
        .then((response) => {
            if (!response.ok) {
                throw new Error(`HTTP error! Status: ${response.status}`);
            }
            return response.json();
        })
        .then((data) => {
            document.dispatchEvent(new CustomEvent('on:cart:change', {
                bubbles: true,
                cancelable: false,
                detail: {
                    data
                }
            }));
        })
        .catch((error) => {
            console.log(error.message);
            window.location.reload();
        });
};


function addcollectionimage() {
    const grid = document.querySelector('.product-media-collage.desktop-only');
    const variantSelector = document.querySelectorAll('[data-option-name="style"]');

    // if (!grid || !collectionImages[collectionType]) return;

    const createImageElement = (mediaId, imageUrl) => `
    <div class="product-media-collage__item" data-media-id="${mediaId}">
            <div class="product-media-wrapper" data-media-id="${mediaId}" tabindex="-1">
                <div class="product-media product-media--image">
                    <img src="${imageUrl}" alt="${mediaId}" width="1280" height="960"
                    sizes="(min-width: 1600px) 800px, (min-width: 768px) 50vw, 100vw" 
                    srcset="${imageUrl}" class="theme-img">
                </div>
            </div>
        </div>
    `;
    if (collectionImages[collectionType]) {
        const mainImageDiv = document.createElement("div");
        mainImageDiv.innerHTML = createImageElement(collectionType, collectionImages[collectionType]);
        grid.insertBefore(mainImageDiv.firstElementChild, grid.children[3] || null);
    }
    let additionalImageType = null;
    if (["classics", "talon", "cayman"].includes(collectionType)) {
        additionalImageType = "lb-men";
    } else if (["allure", "aviator"].includes(collectionType)) {
        additionalImageType = "lb-women";
    }
    if (pro_handle.includes("tangle")) {
        const videoHTML = `
            <div class="product-media-collage__item" data-media-id="tangle-video">
                <div class="product-media-wrapper" data-media-id="tangle-video" tabindex="-1">
                    <div class="product-media product-media--video">
                        <video autoplay loop muted playsinline width="100%" height="auto">
                            <source src="https://cdn.shopify.com/videos/c/o/v/f5e3676a64b84157b5980c4448aaf662.mp4" type="video/mp4">
                        </video>
                    </div>
                </div>
            </div>
        `;
        const videoElement = document.createElement("div");
        videoElement.innerHTML = videoHTML;
        grid.appendChild(videoElement.firstElementChild);
    }

    if (additionalImageType) {
        const additionalImageDiv = document.createElement("div");
        additionalImageDiv.innerHTML = createImageElement(additionalImageType, collectionImages[additionalImageType]);
        grid.appendChild(additionalImageDiv.firstElementChild);
    }
    const updateVariantImages = (selectedVariant) => {
        const isColorush = selectedVariant.includes("colorush");
        const mediaIdToAdd = isColorush ? "cr-variant" : "non-cr-variant";
        const mediaIdToRemove = isColorush ? "non-cr-variant" : "cr-variant";
        const imageUrl = collectionImages[mediaIdToAdd];

        if (!imageUrl) return;

        document.querySelectorAll(`[data-media-id="${mediaIdToRemove}"]`).forEach(el => el.remove());
        document.querySelectorAll(`[data-media-id="${mediaIdToAdd}"]`).forEach(el => el.remove());

        const variantImageDiv = document.createElement("div");
        variantImageDiv.innerHTML = createImageElement(mediaIdToAdd, imageUrl);
        grid.insertBefore(variantImageDiv.firstElementChild, grid.lastElementChild);
    };
    var has_colorush = Array.from(variantSelector).some(option => option.value.toLowerCase() === "colorush");
    if (has_colorush && collectionImages[collectionType]) {
        if (variantSelector) {
            variantSelector.forEach(option => {
                option.addEventListener("change", function() {
                    updateVariantImages(this.value.toLowerCase());
                });

                if (option.checked) {
                    updateVariantImages(option.value.toLowerCase());
                }
            });
        }
    }
}