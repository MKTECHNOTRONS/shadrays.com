var customer_vip = '';

function activateVIP(customer_vip) {
    Cookies.set('customer_vip', customer_vip);

    if (customer_vip === 'vip') {
        document.body.classList.add('vip');
        const contactVip = document.getElementById('contactVip');
        if (contactVip) {
            contactVip.value = 'Yes';
        }
        MarkdownPricePro.init({
            id: 'vip-discount',
            //collections: ['hard-case', 'graphic-tee-shirts', 'uv-protection-shirts', 'snow-goggle-collection', 'snow-goggle-frames', 'snow-goggle-frames'],
            //collections: ['shade-shop', 'hard-case', 'graphic-tee-shirts', 'uv-protection-shirts', 'snow-goggle-collection', 'snow-goggle-frames', 'snow-goggle-frames', 'green-wolf', 'shady-rays-rx', 'kids', 'all'],
            collections: ['all', 'shady-rays-rx', 'hard-case'],
            multiplier: 1,
            discount_code: 'VIP',
            autoApplyCoupon: false
        });

    } else if (customer_vip === 'almostvip') {
        document.body.classList.add('almostvip');
    }
}

function getUrlParam(name, defaultValue) {
    const urlParams = new URLSearchParams(window.location.search);
    return urlParams.has(name) ? urlParams.get(name) : defaultValue;
}

document.addEventListener('DOMContentLoaded', function() {
    /* VIP SITE */
    if (document.body.classList.contains('vip')) {
        customer_vip = 'vip';
    } else if (document.body.classList.contains('almostvip')) {
        customer_vip = 'almostvip';
    } else if (!document.body.classList.contains('vip') && document.body.classList.contains('loggedin')) {
        customer_vip = '';
    } else {
        customer_vip = Cookies.get('customer_vip') || '';
        var param_customer_vip = getUrlParam('cs', false);
        if (param_customer_vip === 'vip') {
            customer_vip = 'vip';
        } else if (param_customer_vip === 'boderline') {
            customer_vip = 'vip';
        } else if (param_customer_vip === 'almostvip') {
            customer_vip = 'almostvip';
        } else if (param_customer_vip === 'clear') {
            customer_vip = '';
        }
    }
    activateVIP(customer_vip);
});