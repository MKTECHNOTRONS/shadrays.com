const defaultCollectionLink = '/collections/men-all-styles';
window.VIP_DISCOUNT_MULTIPLIER = 0.95;
window.VIP_DISCOUNT_CODE = 'VIP 5% Off';
window.INVALID_PRODUCT_TYPES = ['Gift Card', 'Warranty', 'Craftsmanship Replacement', 'Lost-Broken Replacement'];

window.MarkdownPricePro = {

    allowed() {
        return ['AD40-markdown', 'vanity-markdown', 'outlet-promo', 'campaign_impression', 'mens-homepage-discount', 'attentive-AT20', 'vip-discount', 'discount-igot2'];
    },
    init({
        discount_code,
        multiplier = 0,
        collections = [],
        subtract = false,
        expires = 7,
        autoApplyCoupon = true,
        id,
        specialVariants = [],
        specialMultiplier = 0,
        scriptDiscountMessage = '',
    }) {
        if (!id) return console.error('Markdown ID is required to initialize multiple markdown!');
        if (!Array.isArray(collections) || !collections.length)
            return console.error('At least one collection is required to initialize Markdown! E.g. ["sunglasses", "blue-light"]');
        if (multiplier <= 0) console.warn(`0% discount will be applied on checkout`);

        if (BLACKLISTED_COUPON_CODES.includes(discount_code)) {
            return console.error(`This coupon code is no longer in use!`);
        }

        if (!this.allowed().includes(id)) {
            return console.error(`This markdown is not currently allowed. If allowed please add it to the white list!`);
        }

        let markdownObject = Cookies.getJSON('markdown_object') || [];
        // console.log('Markdown Object:', markdownObject);

        let existingMarkdown = null;
        let newMarkdown = {};

        if (markdownObject.length) {
            existingMarkdown = markdownObject.find((obj) => obj.markdown_id === `${id}`);
            if (existingMarkdown) {
                markdownObject = markdownObject.filter((obj) => obj.markdown_id !== `${id}`);
                newMarkdown = existingMarkdown;
            }
        }

        const selector = collections
            .map((col) => {
                return `[data-product-collections~="${col}"] span[data-target="price-element"]`;
            }).join(', ');

        newMarkdown.markdown_multiplier = `${multiplier}`;
        newMarkdown.markdown_id = `${id}`;
        newMarkdown.markdown_mode = subtract ? 'subtract' : 'multiply';
        newMarkdown.markdown_collections = collections.join(',');
        newMarkdown.markdown_selector = selector;
        if (discount_code) {
            newMarkdown.markdown_discount_code = discount_code;
        }
        if (specialVariants.length) {
            newMarkdown.markdown_special_variants = specialVariants.join(',');
            newMarkdown.markdown_special_multiplier = specialMultiplier || multiplier;
        }
        newMarkdown.markdown_auto_apply_coupon = autoApplyCoupon;
        newMarkdown.markdown_initialized = 'initialized';
        newMarkdown.markdown_expires = expires;
        newMarkdown.script_discount_message = scriptDiscountMessage;

        if (existingMarkdown) {
            // Check if all fields match
            const isAlreadyInitialized = Object.entries(newMarkdown).every(
                ([key, expectedValue]) => existingMarkdown[key] == expectedValue
            );

            if (isAlreadyInitialized) {
                console.warn(`Markdown with this ID ${id} already initialized!`);
                return this.run();
            }

            // Update markdown if not already initialized
            console.log(`Markdown with id ${id} updated! ${new Date().toDateString()}`);
            this.update(id, newMarkdown, markdownObject);
            return this.run();
        }
        markdownObject.push(newMarkdown);
        setCookieWithExpiry('markdown_object', markdownObject, expires);
        console.log(`Markdown with id ${id} initialized! ${new Date().toDateString()}`);
        this.run();
    },

    update(id, fields, markdownObject = null) {
        if (!id) return console.warn('Markdown ID is required to update a markdown!');
        const markdowns = markdownObject || Cookies.getJSON('markdown_object') || [];

        if (!markdowns.length) return console.warn('No markdown available to update');

        let existing;
        let existingIndex;

        for (let index = 0; index < markdowns.length; index++) {
            const element = markdowns[index];
            if (element.markdown_id === `${id}`) {
                existing = element;
                existingIndex = index;
            }
        }

        if (!existing) return console.warn('No markdown found with the given ID');

        markdowns[existingIndex] = { ...existing,
            ...fields
        };

        setCookieWithExpiry('markdown_object', markdowns, existing.markdown_expires || 7);

        return markdowns;
    },

    clear(id) {
        if (!id) {
            return console.warn('You need to supply the ID of the markdown to clear');
        }
        if (id === 'clear-all') {
            Cookies.remove('markdown_object');
        } else {
            const markdownObject = Cookies.getJSON('markdown_object') || [];
            const existing = markdownObject.find((obj) => obj.markdown_id === `${id}`);

            if (!existing) {
                return console.warn('No such markdown initialized!');
            }
            const {
                markdown_discount_code
            } = existing;
            if (markdown_discount_code) {
                Cookies.remove('markdown_discount_code');
                Cookies.remove('discount_code');
                Cookies.remove('discount_code_applied');
            }
            const rest = markdownObject.filter((obj) => obj.markdown_id !== `${id}`);
            if (rest.length) {
                setCookieWithExpiry('markdown_object', rest, 1.5);
            } else {
                Cookies.remove('markdown_object');
            }
        }
        const markdownAnchor = document.getElementById('markdown-anchor');
        if (markdownAnchor) markdownAnchor.innerHTML = '';
    },

    run({
        is_product_page = false,
        markdowns = null
    } = {}) {
        if (this.getDisabledOnPage()) return;
        const self = this;
        const markdownObject = markdowns || Cookies.getJSON('markdown_object') || [];
        const isVipCustomer = this.isVipCustomer();

        // this.resetItemPrice(); // reset item price
        const notOutletMarkdowns = markdownObject.filter((obj) => obj.markdown_id !== 'outlet-promo');
        notOutletMarkdowns.forEach((object) => {
            self.resetItemPrice(object);
        });

        markdownObject.forEach((object) => {
            const multiplier = Number(object.markdown_multiplier);
            const specialMultiplier = Number(object.markdown_special_multiplier);
            const selectors = object.markdown_selector;
            const initialized = object.markdown_initialized;
            const mode = object.markdown_mode;
            if (initialized !== 'initialized') {
                return console.log(`Markdown Price with ${object.markdown_id} not initialized!`);
            }

            let priceElements = document.querySelectorAll(selectors);

            const markDownSpecialVariants = object.markdown_special_variants;
            const specialVariants = markDownSpecialVariants ? markDownSpecialVariants.split(',') : [];

            if (is_product_page) {
                priceElements = Array.from(priceElements).filter(function(element) {
                    return element.closest('.product-price') !== null;
                });
            }

            priceElements.forEach(function(element) {
                const parent = element.parentElement;
                const realPrice = element.closest('[data-product-collections]').dataset.realPrice;
                const priceElement = element.querySelector('.original-price') || element;
                const price = priceElement.innerHTML;
                const curr = theme.globals.userCurrency === 'GBP' ? '£' : '$';
                let prices = price.match(/[-+]?[0-9]*\.?[0-9]+/g);
                if (!prices) {
                    prices = [];
                }

                const price_value = parseFloat(prices[0] || 0);

                const toBeDiscounted = realPrice ? (realPrice) / 100 : price_value;
                const otherPrice = price_value > toBeDiscounted ? price_value - toBeDiscounted : 0;
                const vipDiscount = parent.dataset.vipDiscount ? parseInt(parent.dataset.vipDiscount) : 0;
                const eligibleForVipDiscount = self.eligibleForVipDiscount(parent.dataset);
                const vipDiscountMultiplier = (isVipCustomer || vipDiscount) && eligibleForVipDiscount ? VIP_DISCOUNT_MULTIPLIER : 1;
                const variant = parent.dataset.productSelectedVariant;
                const isSpecialVariant = specialVariants.includes(variant);
                const multiplierToUse = (isSpecialVariant ? specialMultiplier : multiplier) * vipDiscountMultiplier;

                let discountedPrice =
                    mode === 'subtract' ?
                    (toBeDiscounted - Math.floor(multiplierToUse * theme.globals.currencyConversion[theme.globals.userCurrency])) :
                    (multiplierToUse * toBeDiscounted);

                discountedPrice = Number(discountedPrice.toFixed(2));

                const markdownPrice = discountedPrice + otherPrice;
                const originalPrice = price_value;

                if (originalPrice === markdownPrice) return;

                const content = price_value ?
                    `<span class="price--on-sale" data-target="price-element" data-value="markdown_price" data-markdown-discounted="true">
        <span class="price-label money markdown-price">${curr}${markdownPrice.toFixed(2)}</span>
        <span class="price-label original-price price__was">${curr}${originalPrice.toFixed(2)}</span>
        </span>` :
                    `<span data-target="price-element" data-value="markdown_price">
        <span class="price-label money">${price}</span>
        </span>`;

                const wasElement = parent.querySelector('.price__was');
                if (wasElement) {
                    wasElement.classList.add('hidden');
                }

                if (element.classList.contains('original-price')) {
                    parent.outerHTML = content;
                } else {
                    element.outerHTML = content;
                }

                parent.dataset.discountedPrice = markdownPrice;
                if (parent.classList.contains('price__was')) {
                    parent.style.display = 'none';
                }
            });
        });

        if (notOutletMarkdowns.length) {
            this.calculateCart(false);
        }

        document.dispatchEvent(new CustomEvent('markdown:after-run', {
            detail: {
                markdownObject
            }
        }));
    },

    resetItemPrice(object) {
        const notSelectors = object.markdown_collections.split(',').map((col) => `:not([data-product-collections~="${col}"])`).join('');
        document.querySelectorAll(`[data-product-collections]${notSelectors} span[data-target="price-element"]`).forEach((priceEl) => {
            const priceElement = priceEl.querySelector('.original-price') || priceEl;
            const price = priceElement.innerHTML;
            let prices = price.match(/[-+]?[0-9]*\.?[0-9]+/g);
            if (!prices) {
                prices = [];
            }
            priceEl.outerHTML = `<span data-target="price-element" data-value="markdown_price">${price}</span>`;
        });
    },

    isVipCustomer() {
        return Cookies.get('customer_vip') === 'vip' || Cookies.get('SR_PR_kStatus') === 'VIP' || false;
    },

    eligibleForVipDiscount(item) {
        if (item.isVipProduct) {
            return item.isVipProduct === 'false' && item.isOutletProduct === 'false' && !INVALID_PRODUCT_TYPES.includes(item.productType);
        }
        if (!item.tags || !item.product_type) {
            return false;
        }
        return !item.tags.includes('vip-product') && !item.tags.includes('noreploutlet') && !INVALID_PRODUCT_TYPES.includes(item.product_type);
    },

    getDiscountedCart() {
        let all = [...theme.globals.cartItems];

        const self = this;
        const markdownObject = Cookies.getJSON('markdown_object') || [];
        const activeMarkdowns = markdownObject.filter((obj) => obj.markdown_initialized === 'initialized');
        const isVipCustomer = this.isVipCustomer();

        activeMarkdowns.forEach((object) => {
            const multiplier = Number(object.markdown_multiplier);
            const specialMultiplier = Number(object.markdown_special_multiplier);

            const markDownCollections = object.markdown_collections;
            const collections = markDownCollections ? markDownCollections.split(',') : [];
            const markDownSpecialVariants = object.markdown_special_variants;
            const specialVariants = markDownSpecialVariants ? markDownSpecialVariants.split(',') : [];
            const markdownDiscountCode = (object.script_discount_message || object.markdown_discount_code).toLowerCase();
            const mode = object.markdown_mode;

            all = all.map((item) => {
                let price = item.line_price;
                let {
                    variant_title
                } = item;

                if (!variant_title) {
                    variant_title = item.variant_options[0];
                }
                const variant = variant_title.replace(' - ', '-').replace(' / ', '-').replace(' ', '-').toLowerCase();
                const isSpecialVariant = specialVariants.includes(variant);
                const vipDiscount = item.line_level_discount_allocations.find((i) => i.title == VIP_DISCOUNT_CODE);
                const appliedDiscountCodes = item.line_level_discount_allocations.map((i) => i.title.toLowerCase());
                const vipDiscountMultiplier = isVipCustomer && !vipDiscount ? VIP_DISCOUNT_MULTIPLIER : 1;

                const multiplierToUse = (isSpecialVariant ? specialMultiplier : multiplier) * vipDiscountMultiplier;

                item.isDiscounted = item.isDiscounted || false;
                item.discountedPrice = item.discountedPrice || item.discounted_price * item.quantity;

                const collectionsSet = new Set(collections);
                const commonCollections = item._collections.filter(c => collectionsSet.has(c));

                if (!item.isDiscounted && commonCollections.length) {
                    const eligibleForVipDiscount = self.eligibleForVipDiscount(item);
                    if (!appliedDiscountCodes.includes(markdownDiscountCode)) {
                        price = mode === 'subtract' ?
                            price - Math.floor(multiplierToUse * theme.globals.currencyConversion[theme.globals.userCurrency] * item.quantity) * 100 :
                            price * multiplierToUse;
                    }

                    if (!appliedDiscountCodes.includes(VIP_DISCOUNT_CODE.toLowerCase()) && eligibleForVipDiscount && isVipCustomer) {
                        price = price * vipDiscountMultiplier;
                    }

                    item.discountedPrice = price;
                    item.isDiscounted = true;
                }
                return item;
            });

        });

        return {
            items: all,
            activeMarkdowns
        };
    },

    calculateCartDiscount({
        run = true,
        eligibilityFilter
    } = {}) {
        const {
            items,
            activeMarkdowns
        } = this.getDiscountedCart();

        if (activeMarkdowns.length && run) {
            this.run();
        }

        const eligibleItems = eligibilityFilter && typeof eligibilityFilter === 'function' ? items.filter(eligibilityFilter) : items;
        const discountedItems = eligibleItems.filter((item) => item.isDiscounted);
        const discountedPrice = items.reduce((prev, curr) => prev + curr.discountedPrice, 0);
        const eligibleDiscountedPrice = eligibleItems.reduce((prev, curr) => prev + curr.discountedPrice, 0);
        const totalPrice = items.reduce((prev, curr) => prev + curr.original_line_price, 0);

        return {
            totalPrice: totalPrice / 100,
            discountedPrice: discountedPrice / 100,
            discountedItems,
            eligibleItems,
            items,
            eligibleDiscountedPrice: eligibleDiscountedPrice / 100,
            activeMarkdowns,
        };

    },
    calculateCart(run = true) {

        if (this.getDisabledOnPage()) return;

        const {
            discountedPrice,
            totalPrice,
            items,
            activeMarkdowns
        } = this.calculateCartDiscount({
            run
        });
        if (discountedPrice < totalPrice) {
            const curr = theme.globals.userCurrency === 'GBP' ? '£' : '$';
            const subTotalEl = document.querySelector('[data-cart-subtotal]');

            if (subTotalEl) {
                subTotalEl.innerHTML = `
          <span data-value="markdown_price" class="price--on-sale" data-markdown-discounted="true">
            <span class="price-label money markdown-price">${curr}${discountedPrice.toFixed(2)}</span>
            <span class="price-label original-price price__was">${curr}${totalPrice.toFixed(2)}</span>
          </span>`;
            }
        }

        const cartSubtotalEl = document.querySelector('[data-cart-subtotal]');
        if (cartSubtotalEl) {
            cartSubtotalEl.setAttribute('data-markdown-price', discountedPrice.toFixed(2));
        }

        const {
            hasAnniversaryExtra,
            hasColorush
        } = checkAnniversaryExtra(items);
        const anniversaryExtraActive = activeMarkdowns.some(
            (obj) => obj.markdown_discount_code === 'ANNIV24'
        );
        const shouldSwap = hasColorush && !hasAnniversaryExtra;
        autoApplyCouponCode(anniversaryExtraActive ? (shouldSwap ? 'ANNIV24CR' : 'ANNIV24') : undefined);
    },

    disableOnPage: false,

    getDisabledOnPage() {
        return this.disableOnPage || window.disableMarkdownOnPage;
    },

    clearNonWhiteListed() {
        const allowed = this.allowed();
        const otherMarkdowns = (Cookies.getJSON('markdown_object') || []).filter((obj) => !allowed.includes(obj.markdown_id));

        if (otherMarkdowns.length) {
            otherMarkdowns.forEach((object) => {
                this.clear(object.markdown_id);
            });
            location.reload();
        }
    },
};

function setCookieWithExpiry(name, value, expires) {
    Cookies.set(name, value, {
        expires: expires
    });
}

function checkAnniversaryExtra(items) {
    if (!isCartPage()) return {
        hasAnniversaryExtra: false,
        hasColorush: false
    };
    const hasAnniversaryExtra = items.some(
        (item) =>
        item.tags.includes('anniversary-sale-extra') ||
        item._collections.includes('anniversary-extra-2024')
    );
    const hasColorush = items.some(
        (item) =>
        item.tags.includes('product-colorush') ||
        item._collections.includes('colorush')
    );
    return {
        hasAnniversaryExtra,
        hasColorush
    };
}

class MysteryPairUpsell {
    firstTimeVisitor = false;

    constructor() {
        this.mysteryFreeGiftId = 41791465095215;
        this.basketRight = '#basket-right';
        this.sideBanner =
            'https://cdn.shopify.com/s/files/1/0350/5401/files/bfcm-free-mystery-gift-desk.svg';
        this.sideBannerMobile =
            'https://cdn.shopify.com/s/files/1/0350/5401/files/bfcm-free-mystery-gift-mob.svg';
    }

    init(collections = ['shade-shop']) {
        if (!isCartPage()) return;

        this.firstTimeVisitor = !(Cookies.get('visited_cart_ldw') || false);
        const cartCount = this.eligibleCartItemsCount(collections);
        const alreadyAdded = this.cartHasFreeGift();

        if (cartCount && this.firstTimeVisitor) {
            Cookies.set('visited_cart_ldw', true);
            Cookies.set('first_item_count', cartCount);
        }

        const cookieCount = Cookies.get('first_item_count');
        const cookieCartVisited = Cookies.get('visited_cart_ldw');

        if (cartCount < 2 && alreadyAdded) {
            this.removeGift();
        }

        if (cookieCount == 1 && cookieCartVisited) {
            if (cartCount === 1) {
                gaCall('send', 'pageview', {
                    dimension10: 'Promo Shown'
                });
                this.showFreeGift();
            }
            if (cartCount === 2 && !alreadyAdded) {
                this.addFreeGift();
            }
        }
        this.hideCartMessage();
    }

    eligibleCartItemsCount(collections = ['shade-shop']) {
        return theme.globals.cartItems
            .filter((item) => {
                let eligible = false;
                for (let index = 0; index < item._collections.length; index++) {
                    if (collections.includes(item._collections[index])) {
                        eligible = true;
                        break;
                    }
                }
                return eligible;
            })
            .map((item) => item.quantity)
            .reduce((prev, curr) => prev + curr, 0);
    }

    cartHasFreeGift() {
        return theme.globals.cartItems.filter((item) => item.id == this.mysteryFreeGiftId).length;
    }

    addFreeGift() {
        const formData = {
            items: [{
                id: this.mysteryFreeGiftId,
                quantity: 1,
            }, ],
        };
        fetch(window.Shopify.routes.root + 'cart/add.js', {
                method: 'POST',
                headers: {
                    'Content-Type': 'application/json',
                },
                body: JSON.stringify(formData),
            })
            .then((response) => {
                window.location.reload();
                return response.json();
            })
            .catch((error) => {
                console.error('Error:', error);
            });
    }

    showFreeGift() {
        const basketRight = document.querySelector(this.basketRight);
        if (basketRight) {
            const promoDiv = document.createElement('div');
            promoDiv.className = 'special-offer__tags-sales';
            promoDiv.id = 'memorial-day-2023';
            promoDiv.innerHTML = `
        <a href="${defaultCollectionLink}">
          <picture>
            <source media="(min-width: 981px)" srcset="${this.sideBanner}">
            <source media="(min-width: 200px)" srcset="${this.sideBannerMobile}">
            <img src="${this.sideBanner}" data-src="${this.sideBanner}" alt="Memorial day promo">
          </picture>
        </a>
      `;
            basketRight.insertBefore(promoDiv, basketRight.firstChild);
        }
    }

    hideMysteryPair() {
        document
            .querySelectorAll('[data-promotion-id="promotion-cart-mystery-pair"]:not(.mystery-pair-blue-light)')
            .forEach((element) => (element.style.display = 'none'));
    }

    replaceCartMessage() {
        const discountContent = document.querySelector(
            '[data-promotion-id="promotion-cart-code-instruction"] #discountContent'
        );
        if (discountContent) {
            discountContent.innerHTML = `
        <a href="${defaultCollectionLink}" style="display:block">
          <h3><strong>LABOR DAY SALE</strong></h3>
          <p>
            Get 35% OFF All Shades.
            <a href="/collections/labor-day-sale"><u>SHOP SALE</u></a>
            <small><em>Offer cannot be combined with other coupons</em></small>
          </p>
        </a>
      `;
        }
    }

    hideCartMessage() {
        document
            .querySelectorAll('[data-promotion-id="promotion-cart-code-instruction"]')
            .forEach((element) => (element.style.display = 'none'));
    }

    removeGift() {
        const formData = {
            updates: {
                [this.mysteryFreeGiftId]: 0,
            },
        };
        fetch(window.Shopify.routes.root + 'cart/update.js', {
                method: 'POST',
                headers: {
                    'Content-Type': 'application/json',
                },
                body: JSON.stringify(formData),
            })
            .then((response) => {
                window.location.reload();
                return response.json();
            })
            .catch((error) => {
                console.error('Error:', error);
            });
    }
}

window.CartManager = class CartManager {
    request({
        url,
        method = 'POST',
        body = null
    }) {
        return fetch(url, {
                method,
                headers: {
                    'Content-Type': 'application/json',
                },
                body: body ? JSON.stringify(body) : null,
            })
            .then((response) => response.json())
            .catch((error) => {
                console.error('Error:', error);
                throw new Error(error);
            });
    }

    addToCart(id, quantity = 1) {
        this.request({
                url: '/cart/add.js',
                body: {
                    items: [{
                        id,
                        quantity
                    }]
                },
            })
            .then(() => {
                window.location.reload();
            })
            .catch((error) => {
                console.error('Error:', error);
            });
    }

    updateCart(updates) {
        this.request({
                url: '/cart/update.js',
                body: {
                    updates
                },
            })
            .then(() => {
                window.location.reload();
            })
            .catch((error) => {
                console.error('Error:', error);
            });
    }

    removeFromCart(id) {
        this.updateCart({
            [id]: 0
        });
    }

    changeItemProperties(itemKey, properties) {
        if (!Object.keys(properties).length) return;
        return this.request({
            url: '/cart/change.js',
            body: {
                id: itemKey,
                properties
            }
        });
    }
};

window.FreeGiftCard = class FreeGiftCard extends CartManager {
    constructor({
        minimumItemCount = 0,
        minimumCartTotal = 100,
        freeGiftAmount = 25
    } = {}) {
        super();
        this.freeGiftId = 32815922511919;
        this.minimumItemCount = minimumItemCount;
        this.minimumCartTotal = minimumCartTotal;
        this.freeGiftAmount = freeGiftAmount;
        this.eligibleItems = [];
        this.items = [];
        this.discountedPrice = 0;
        this.cartMessageEl = document.querySelector('[data-promotion-id="promotion-cart-code-instruction"]');

        this.handle();
    }

    eligibilityFilter(item) {
        return item.product_type !== 'Gift Card' && !item.gift_card;
    }

    handle() {
        const {
            eligibleItems,
            items,
            eligibleDiscountedPrice
        } = this.getDiscountedCart();
        this.discountedPrice = eligibleDiscountedPrice / theme.globals.currencyConversion[theme.globals.userCurrency || 'USD'];
        this.eligibleItems = eligibleItems;
        this.items = items;

        if (document.body.classList.contains('loop-returns-activated')) {
            this.hideGiftCardUpsell();
            return;
        }

        this.changeTopBarMessage();
        if (this.cartMessageEl) {
            this.cartMessageEl.classList.add('hidden');
            this.cartMessageEl.style.display = 'none';
        }

        if (this.isEligible()) {
            this.hideGiftCardUpsell();
            if (!isCartPage()) return;
            this.addFreeGift();
        } else {
            this.removeFreeGift();
            this.showGiftCardUpsell();
        }

        if (this.cartHasRx()) {
            this.hidePlainGiftBox();
        }
    }

    getDiscountedCart() {
        return MarkdownPricePro.calculateCartDiscount({
            eligibilityFilter: (item) => this.eligibilityFilter(item)
        });
    }

    cartHasRx() {
        return this.items.some((item) => item.product_type === 'Rx' && item._collections.includes('shady-rays-rx'));
    }

    cartHasNonRx() {
        return this.items
            .filter((item) => item.id !== this.mysteryFreeGiftId && item.sku !== 'PB-1' && item.id !== this.freeGiftId)
            .some((item) => item.product_type !== 'Rx' && (item.tags.includes('NON-RX') || !item.tags.includes('RX')));
    }

    cartHasBothRxAndNonRx() {
        return this.cartHasRx() && this.cartHasNonRx();
    }

    cartHasFreeGift() {
        return this.items.some((item) => item.id === this.freeGiftId);
    }

    cartHasFreeGiftProperty() {
        return this.items.some((item) => item.properties['Gift Card']);
    }

    isEligible() {
        return this.eligibleItems.length >= this.minimumItemCount && this.discountedPrice >= this.minimumCartTotal;
    }

    getFirstEligibleRxFrame(withGiftCard = false) {
        return this.eligibleItems.find((item) => {
            let isRxFrame = item.product_type === 'Rx' && item._collections.includes('shady-rays-rx');
            if (withGiftCard) {
                isRxFrame = isRxFrame && item.properties['Gift Card'];
            }
            return isRxFrame;
        });
    }

    addFreeGift() {
        if (this.cartHasNonRx()) {
            if (this.cartHasFreeGiftProperty()) {
                this.removeFreeGiftProperties();
            }
            if (!this.cartHasFreeGift()) {
                this.addFreeGiftSku();
            }
        } else {
            if (this.cartHasFreeGift()) {
                this.removeFreeGiftSku();
            }
            if (!this.cartHasFreeGiftProperty()) {
                this.addFreeGiftProperties();
            }
        }
        this.renderGiftCartItem();
    }

    removeFreeGift() {
        if (this.cartHasNonRx()) {
            if (this.cartHasFreeGift()) {
                this.removeFreeGiftSku();
            }
        } else {
            if (this.cartHasFreeGiftProperty()) {
                this.removeFreeGiftProperties();
            }
        }
        this.hideGiftCartItem();
    }

    addFreeGiftSku() {
        this.addToCart(this.freeGiftId);
    }

    removeFreeGiftSku() {
        this.removeFromCart(this.freeGiftId);
    }

    addFreeGiftProperties() {
        const firstRxItem = this.getFirstEligibleRxFrame();
        if (!firstRxItem) return;
        const properties = firstRxItem.properties;
        properties['Gift Card'] = `$25 Physical Gift Card`;
        return this.changeItemProperties(firstRxItem.key, properties);
    }

    removeFreeGiftProperties() {
        const firstRxItem = this.getFirstEligibleRxFrame(true);
        if (!firstRxItem) return;
        const properties = firstRxItem.properties;
        delete properties['Gift Card'];
        delete properties['_Gift Card'];

        return this.changeItemProperties(firstRxItem.key, properties);
    }

    renderGiftCartItem() {
        if (!(this.cartHasFreeGift() || this.cartHasFreeGiftProperty())) return;
        const element = `
      <div class="single-cart-item" data-target="free-gift-card" data-item-id="${this.freeGiftId}">
        <div class="cart-product-img-info">
          <div class="cart-product-img">
            <a href="/products/25-physical-gift-card?variant=32815922511919" title="$25 USD Physical Gift Card - Expires on 3/31">
              <img src="//shadyrays.com/cdn/shop/products/GC_e3f667d2-a616-4f7b-a224-e0d7a594f1d8_compact.png?v=1626380825" alt="$25 Physical Gift Card Gift Card Shady Rays Polarized Sunglasses">
            </a>
          </div>
          <div class="cart-product-info">
            <div class="cart-product-info-top">
              <span>$25 USD Physical Gift Card</span>
              <h4 class="font-size-18 lh-125 fw-600 mgt-10 text-left">
                <a href="/products/25-physical-gift-card?variant=32815922511919" title="$25 USD Physical Gift Card - Expires on 3/31">
                  Expires on 3/31
                </a>
              </h4>
            </div>
            <div class="cart-qty-price">
              <div class="cart-price font-size-16 lh-120 fw-500" data-product-collections="all-shades-replacement-1" data-product-variant-titles="default-title" data-product-selected-variant="default-title" data-real-price="0">
                <span data-target="price-element"><span class="money">$0.00</span></span>
              </div>
              <input id="updates_32815922511919" type="hidden" value="1">
            </div>
          </div>
        </div>
      </div>
    `;

        const existing = document.querySelectorAll(`.single-cart-item[data-item-id="${this.freeGiftId}"]:not([data-target="free-gift-card"])`);
        existing.forEach(el => el.remove());

        const cartContainer = document.querySelector('.cart-items-container');
        if (cartContainer) {
            cartContainer.insertAdjacentHTML('afterbegin', element);
        }
    }

    hideGiftCartItem() {
        document.querySelectorAll('.single-cart-item[data-target="free-gift-card"]').forEach(el => el.remove());
    }

    showGiftCardUpsell() {
        const pdpBanner = `
      <div class="cart-e-gift-card25">
        <a href="${defaultCollectionLink}">
          <img class="sr-desktop" src="//shadyrays.com/cdn/shop/files/pdp-egift-card-desk.png?v=546516286765338009" alt="E-Gift Card">
          <img class="sr-mobile" src="//shadyrays.com/cdn/shop/files/pdp-egift-card-mob.png?v=4187600488015754665" alt="E-Gift Card">
        </a>
      </div>`;
        const cartBanner = `
      <div class="cart-e-gift-card25" data-target="free-gift-card-upsell">
        <a href="${defaultCollectionLink}">
          <img class="sr-desktop" src="//shadyrays.com/cdn/shop/files/cart-egift-card-desk.png?v=1789707190604051503" alt="E-Gift Card">
          <img class="sr-mobile" src="//shadyrays.com/cdn/shop/files/cart-egift-card-mob.png?v=4187600488015754665" alt="E-Gift Card">
        </a>
      </div>`;
        const productUpsell = document.querySelector('[data-promotion-id="promotion-product-upsell"]');
        const cartUpsell = document.querySelector('[data-promotion-id="promotion-cart-upsell"]');

        if (productUpsell) {
            productUpsell.innerHTML = pdpBanner;
            productUpsell.classList.remove('hidden');
            productUpsell.style.display = 'block';
        }

        if (cartUpsell) {
            cartUpsell.innerHTML = cartBanner;
            cartUpsell.classList.remove('hidden');
            cartUpsell.style.display = 'block';
        }
    }

    hideGiftCardUpsell() {
        document.querySelectorAll('[data-promotion-id="promotion-product-upsell"], [data-promotion-id="promotion-cart-upsell"]').forEach(el => {
            el.innerHTML = '';
            el.classList.add('hidden');
            el.style.display = 'none';
        });
    }

    changeTopBarMessage() {
        const curr = theme.globals.userCurrency === 'GBP' ? '£' : '$';
        const minimum = Math.ceil(this.minimumCartTotal * theme.globals.currencyConversion[theme.globals.userCurrency || 'USD']);
        const freeGiftAmount = Math.round(this.freeGiftAmount * theme.globals.currencyConversion[theme.globals.userCurrency || 'USD']);

        const topBar = document.querySelector('[data-promotion-id="promotion-top-banner"]');
        if (topBar) {
            topBar.classList.add('hidden');
            topBar.style.display = 'none';
        }

        const giftMessageEl = document.querySelector('[data-target="free-gift-card-message"]');
        if (giftMessageEl) {
            giftMessageEl.classList.remove('hidden');
            giftMessageEl.style.display = 'block';
        } else if (topBar && topBar.parentElement) {
            topBar.parentElement.insertAdjacentHTML('afterbegin', `
        <div data-target="free-gift-card-message" class="span-price-element summer-promotion-default">
          <strong>FREE ${curr}${freeGiftAmount} gift card</strong> FOR ORDERS ABOVE ${curr}${minimum} ${theme.globals.userCurrency} • 
          <a href="${defaultCollectionLink}"><strong>shop NOW</strong></a>
        </div>
      `);
        }
    }

    revertTopBarMessage() {
        const giftMessageEl = document.querySelector('[data-target="free-gift-card-message"]');
        if (giftMessageEl) {
            giftMessageEl.classList.add('hidden');
            giftMessageEl.style.display = 'none';
        }

        const topBar = document.querySelector('[data-promotion-id="promotion-top-banner"]');
        if (topBar) {
            topBar.classList.remove('hidden');
            topBar.style.display = 'block';
        }
    }

    hidePlainGiftBox() {
        const plainGiftBox = document.querySelector('[data-target="plain-gift-box"]');
        if (plainGiftBox) {
            plainGiftBox.classList.add('hidden');
            plainGiftBox.style.display = 'none';
        }
    }
};

window.FreeGift = class FreeGift extends CartManager {
    constructor({
        minimumItemCount = 0,
        minimumCartTotal = 100,
        freeGiftId = 32815922511919,
        ineligibleTags = [],
        eligibleCollections = [],
        enabled = true,
    } = {}) {
        super();
        this.freeGiftId = freeGiftId;
        this.minimumItemCount = minimumItemCount;
        this.minimumCartTotal = minimumCartTotal;
        this.ineligibleTags = ineligibleTags;
        this.eligibleItems = [];
        this.eligibleCollections = eligibleCollections;
        this.eligibleItemsCount = 0;
        this.items = [];
        this.discountedPrice = 0;
        this.enabled = enabled;
        this.handle();
    }

    handle() {
        const {
            items,
            eligibleDiscountedPrice,
            eligibleItems
        } = this.getDiscountedCart();
        this.discountedPrice = eligibleDiscountedPrice / theme.globals.currencyConversion[theme.globals.userCurrency || 'USD'];
        //console.log('eligibleItems', eligibleItems);
        this.eligibleItems = eligibleItems;
        this.eligibleItemsCount = this.eligibleItems.reduce((prev, curr) => prev + curr.quantity, 0);
        this.items = items;
        if (this.enabled) {
            if (document.body.classList.contains('loop-returns-activated')) {
                return;
            }
            this.setShouldSeeUpsell();
            if (this.isEligible()) {
                const upsellShown = Cookies.get('free_gift_upsell_shown') === 'true';
                if (upsellShown) {
                    this.addFreeGift();
                }
            } else {
                this.removeFreeGift();
                const shouldSeeUpsell = Cookies.get('should_see_upsell') === 'true';
                if (shouldSeeUpsell && this.hasEligibleItem()) {
                    this.showFreeGiftUpsell();
                }
            }
            this.hideGiftItemButtons();
            this.hideUpsellToTwo();
            this.removeMultipleFreeGifts();
        } else {
            this.clearFreeGift();
        }
    }

    eligibilityFilter(item) {
        return (
            item.id !== this.freeGiftId &&
            !this.ineligibleTags.some((tag) => item.tags.includes(tag)) &&
            this.eligibleCollections.some((col) => item._collections.includes(col))
        );
    }

    getDiscountedCart() {
        return MarkdownPricePro.calculateCartDiscount({
            eligibilityFilter: (item) => this.eligibilityFilter(item)
        });
    }

    cartHasFreeGift() {
        return this.items.some((item) => item.id === this.freeGiftId);
    }

    isEligible() {
        return this.eligibleItemsCount >= this.minimumItemCount && this.discountedPrice >= this.minimumCartTotal;
    }

    hasEligibleItem() {
        return this.eligibleItemsCount > 0;
    }

    setShouldSeeUpsell() {
        const visited = Cookies.get('visited_cart_page') === 'true';
        const shouldSeeUpsell = Cookies.get('should_see_upsell') === 'true';
        if (shouldSeeUpsell || !isCartPage()) return;
        if (this.eligibleItemsCount === 1 && !visited) {
            setCookieWithExpiry('should_see_upsell', 'true');
        }
        setCookieWithExpiry('visited_cart_page', 'true');
    }

    addFreeGift() {
        if (!this.cartHasFreeGift()) {
            this.addToCart(this.freeGiftId);
        }
    }

    removeMultipleFreeGifts() {
        const freeGifts = this.items.filter((item) => item.id === this.freeGiftId);
        if (freeGifts.length > 1) {
            freeGifts.shift();
            const updates = {};
            freeGifts.forEach((item) => {
                updates[item.key] = 0;
            });
            this.updateCart(updates);
        }
    }

    removeFreeGift() {
        if (this.cartHasFreeGift()) {
            this.removeFromCart(this.freeGiftId);
        }
    }

    clearFreeGift() {
        this.removeFreeGift();
    }

    hideGiftItemButtons() {
        const removeButton = document.getElementById(`remove_${this.freeGiftId}`);
        const qtyPrice = document.getElementById(`updates_${this.freeGiftId}`);
        const productInfo = qtyPrice ? qtyPrice.closest('.cart-product-info') : null;

        if (removeButton) removeButton.style.display = 'none';
        if (qtyPrice) qtyPrice.closest('.cart-qty-price').style.display = 'none';
        if (productInfo) {
            const attributes = productInfo.querySelector('.cart-product-attributes');
            if (attributes) attributes.style.display = 'none';
        }
    }

    hideUpsellToTwo() {
        const checkoutMessage = document.getElementById('Checkout-Message');
        if (checkoutMessage) {
            checkoutMessage.classList.add('hidden');
            checkoutMessage.style.display = 'none';
        }
    }

    showFreeGiftUpsell() {
        if (isCartPage()) {
            const promoEL = document.querySelector('[data-promotion-id="promotion-cart-upsell"]');
            if (promoEL) {
                promoEL.innerHTML = `<div class="mdw2024-mystery-pair mgb-20">
          <a href="${defaultCollectionLink}">
            <picture>
              <source media="(min-width: 741px)" srcset="//shadyrays.com/cdn/shop/files/mdw2024-cart-fmbs-desk.png?v=17496729464428356193">
              <source media="(min-width: 200px)" srcset="//shadyrays.com/cdn/shop/files/mdw2024-cart-fmbs-mob.png?v=18227661671950205831">
              <img src="//shadyrays.com/cdn/shop/files/mdw2024-cart-fmbs-desk.png?v=17496729464428356193" alt="Free Mystery Best Seller">
            </picture>
          </a>
        </div>`;
                setCookieWithExpiry('free_gift_upsell_shown', 'true');
            }
        }
    }
};

window.FreeShipping = class FreeShipping {
    constructor({
        minimumCartTotal = 100
    }) {
        this.minimumCartTotal = minimumCartTotal;
        this.handle();
        this.amountRemaining = minimumCartTotal;
        this.percentage = 0;
    }

    handle() {
        if (document.body.classList.contains('loop-returns-activated')) {
            return;
        }

        if (!isCartPage()) return;
        this.renderShippingMessage();
    }

    getDiscountedCart() {
        return MarkdownPricePro.calculateCartDiscount();
    }

    calculateEligibility(includesHardCase = false) {
        const {
            discountedPrice
        } = this.getDiscountedCart();
        const total = discountedPrice / theme.globals.currencyConversion[theme.globals.userCurrency || 'USD'];
        const remaining = this.minimumCartTotal - (includesHardCase ? total + 8 : total);
        const percentage = (total / this.minimumCartTotal) * 100;

        const isVipCustomer = Cookies.get('SR_PR_kStatus');
        const dealMet = (isVipCustomer == 'VIP') ? true : (remaining <= 0);

        return {
            dealMet,
            remaining,
            percentage: dealMet ? 100 : percentage,
        };
    }

    renderShippingMessage() {
        const {
            dealMet,
            remaining,
            percentage
        } = this.calculateEligibility();
        const shippingMessageEl = document.querySelector('[data-promotion-id="shipping-message"]');
        if (!shippingMessageEl) return;

        const curr = theme.globals.userCurrency === 'GBP' ? '£' : '$';
        const message = dealMet ?
            `<p class="fw-500 lh-11 flex align-items-center justify-content-center">
        <svg xmlns="http://www.w3.org/2000/svg" width="18" height="14" viewBox="0 0 18 14" fill="none">
          <path d="M5.17301 12.6667C6.09349 12.6667 6.83968 11.9205 6.83968 11C6.83968 10.0795 6.09349 9.33334 5.17301 9.33334C4.25254 9.33334 3.50635 10.0795 3.50635 11C3.50635 11.9205 4.25254 12.6667 5.17301 12.6667Z" stroke="#444444" stroke-linecap="round" stroke-linejoin="round"/>
          <path d="M13.5065 12.6667C14.427 12.6667 15.1732 11.9205 15.1732 11C15.1732 10.0795 14.427 9.33334 13.5065 9.33334C12.586 9.33334 11.8398 10.0795 11.8398 11C11.8398 11.9205 12.586 12.6667 13.5065 12.6667Z" stroke="#444444" stroke-linecap="round" stroke-linejoin="round"/>
          <path d="M3.50635 11H1.83968V7.66667M1.00635 1H10.173V11M6.83968 11H11.8397M15.173 11H16.8397V6M16.8397 6H10.173M16.8397 6L14.3397 1.83333H10.173" stroke="#444444" stroke-linecap="round" stroke-linejoin="round"/>
          <path d="M1.83984 4.33334H5.17318" stroke="#444444" stroke-linecap="round" stroke-linejoin="round"/>
        </svg>
        <span>You unlocked Free Shipping!</span>
      </p>` :
            `<p class="fw-500 lh-11">You are ${curr}${Math.ceil(
        remaining
      )} away from free shipping! <a class="fw-600 lh-11" href="${defaultCollectionLink}">Continue Shopping</a></p>`;

        shippingMessageEl.innerHTML = `<div class="free-ship-progress-section">
        <div class="free-ship-progress">
            <div class="free-ship-msg text-center">
                ${message}
            </div>
            <div class="ship-progress-bar">
                <span style="width:${percentage}%"></span>
            </div>
        </div>
      </div>`;

        shippingMessageEl.classList.remove('hidden');
        shippingMessageEl.style.display = 'block';
    }

    updatePDPShippingMessage(includesHardCase = false) {
        const {
            dealMet,
            remaining
        } = this.calculateEligibility(includesHardCase);
        const shippingMessageEl = document.querySelector('[data-promotion-id="shipping-message-pdp"]');
        const curr = theme.globals.userCurrency === 'GBP' ? '£' : '$';
        const message = dealMet ?
            `<p class="fw-500 lh-11">You unlocked Free shipping!</p>` :
            `<p class="fw-500 lh-11">You are ${curr}${Math.ceil(remaining)} away from free shipping!</p>`;
        shippingMessageEl.innerHTML = `<div class="free-ship-msg text-center">${message}</div>`;
        shippingMessageEl.classList.remove('hidden');
        shippingMessageEl.style.display = 'block';
    }
};

window.SpecialPromotions = class SpecialPromotions {
    constructor() {
        this.promo = {
            value: 0,
            code: '',
        };
        this.init();
    }
    init() {
        let promo = Cookies.getJSON('sr_promo');
        const promoInUrl = getUrlParam('sr_promo') || '';
        if (promoInUrl) {
            const promoCode = getUrlParam('sr_promo_code') || '';
            promo = {
                value: promoInUrl.split('-')[1],
                code: promoCode,
            };
            setCookieWithExpiry('sr_promo', promo, 1);
        }

        if (promo ? .value) {
            this.promo = promo;
            this.applyPromotion();
        }
    }
    applyPromotion() {
        this.changeTopBarMessage();
        this.applyPromoCode();
    }
    getPromoMessage() {
        return `Use Nift Gift Code for $${this.promo.value} off a $54 Order`;
    }
    changeTopBarMessage() {
        const topBar = document.querySelector('[data-promotion-id="promotion-top-banner"]');
        topBar.classList.add('hidden');
        topBar.style.display = 'none';
        const message = this.getPromoMessage();
        const parent = topBar.parentElement;
        const promoMessage = document.createElement('div');
        promoMessage.setAttribute('data-target', 'special-promo-message');
        promoMessage.classList.add('span-price-element', 'summer-promotion-default');
        promoMessage.innerHTML = `<strong>${message}</strong>`;
        parent.insertBefore(promoMessage, parent.firstChild);
    }
    applyPromoCode() {
        if (this.promo.code && isCartPage()) {
            autoApplyCouponCode(this.promo.code);
        }
    }
};

function activateMemorialDaySales() {
    MarkdownPricePro.init({
        id: 'mdw-2024',
        collections: ['shade-shop', 'promo-rx', 'kids', 'azalea', 'react-collection', 'react-type-s-lenses', 'react-type-r-lenses', 'readers'],
        multiplier: 0.65,
        discount_code: 'MDW',
    });

    if (isCartPage()) {
        new FreeGift({
            minimumItemCount: 2,
            minimumCartTotal: 50,
            freeGiftId: 42809517834287,
            eligibleCollections: ['shade-shop']
        });
    }

    const kidsBundleUpsell = document.querySelector('[data-promotion-id="kids-bundle-upsell"]');
    if (kidsBundleUpsell) {
        kidsBundleUpsell.classList.add('hidden');
        kidsBundleUpsell.style.display = 'none';
    }
}

document.addEventListener('DOMContentLoaded', function() {
    MarkdownPricePro.clearNonWhiteListed();
    MarkdownPricePro.init({
        id: 'outlet-promo',
        collections: ['womens-outlet-collection', 'sr-outlet'],
        multiplier: 0.45,
        autoApplyCoupon: false,
        scriptDiscountMessage: 'FINAL SALE NO RETURNS/EXCHANGES/REPLACEMENTS',
    });
    window.activeFreeShipping = new FreeShipping({
        minimumCartTotal: 60
    });
});