export default function getPageURL(): string {
  return window.location.href;
}
