! function(e) {
    "use strict";
    const n = {
            TRACKING_ACCEPTED: "trackingConsentAccepted",
            TRACKING_DECLINED: "trackingConsentDeclined",
            MARKETING_ACCEPTED: "firstPartyMarketingConsentAccepted",
            SALE_OF_DATA_ACCEPTED: "thirdPartyMarketingConsentAccepted",
            ANALYTICS_ACCEPTED: "analyticsConsentAccepted",
            PREFERENCES_ACCEPTED: "preferencesConsentAccepted",
            MARKETING_DECLINED: "firstPartyMarketingConsentDeclined",
            SALE_OF_DATA_DECLINED: "thirdPartyMarketingConsentDeclined",
            ANALYTICS_DECLINED: "analyticsConsentDeclined",
            PREFERENCES_DECLINED: "preferencesConsentDeclined",
            CONSENT_COLLECTED: "visitorConsentCollected",
            CONSENT_TRACKING_API_LOADED: "consentTrackingApiLoaded"
        },
        t = "2.1",
        o = "3",
        r = {
            ACCEPTED: "yes",
            DECLINED: "no",
            NO_INTERACTION: "no_interaction",
            NO_VALUE: ""
        },
        i = {
            NO_VALUE: "",
            ACCEPTED: "1",
            DECLINED: "0"
        },
        c = {
            PREFERENCES: "p",
            ANALYTICS: "a",
            MARKETING: "m",
            SALE_OF_DATA: "t"
        },
        a = {
            MARKETING: "m",
            ANALYTICS: "a",
            PREFERENCES: "p",
            SALE_OF_DATA: "s"
        },
        s = {
            MARKETING: "marketing",
            ANALYTICS: "analytics",
            PREFERENCES: "preferences",
            SALE_OF_DATA: "sale_of_data",
            EMAIL: "email"
        },
        u = {
            HEADLESS_STOREFRONT: "headlessStorefront",
            ROOT_DOMAIN: "rootDomain",
            CHECKOUT_ROOT_DOMAIN: "checkoutRootDomain",
            STOREFRONT_ROOT_DOMAIN: "storefrontRootDomain",
            STOREFRONT_ACCESS_TOKEN: "storefrontAccessToken",
            IS_EXTENSION_TOKEN: "isExtensionToken",
            METAFIELDS: "metafields"
        };

    function l(e, n) {
        var t = Object.keys(e);
        if (Object.getOwnPropertySymbols) {
            var o = Object.getOwnPropertySymbols(e);
            n && (o = o.filter((function(n) {
                return Object.getOwnPropertyDescriptor(e, n).enumerable
            }))), t.push.apply(t, o)
        }
        return t
    }

    function E(e) {
        for (var n = 1; n < arguments.length; n++) {
            var t = null != arguments[n] ? arguments[n] : {};
            n % 2 ? l(Object(t), !0).forEach((function(n) {
                d(e, n, t[n])
            })) : Object.getOwnPropertyDescriptors ? Object.defineProperties(e, Object.getOwnPropertyDescriptors(t)) : l(Object(t)).forEach((function(n) {
                Object.defineProperty(e, n, Object.getOwnPropertyDescriptor(t, n))
            }))
        }
        return e
    }

    function d(e, n, t) {
        return n in e ? Object.defineProperty(e, n, {
            value: t,
            enumerable: !0,
            configurable: !0,
            writable: !0
        }) : e[n] = t, e
    }

    function f() {
        try {
            return !1
        } catch (e) {
            if (e instanceof ReferenceError) return !0;
            throw e
        }
    }
    class A {}
    A.warn = e => {
        f() || console.warn(e)
    }, A.error = e => {
        f() || console.error(e)
    }, A.info = e => {
        f() || console.info(e)
    }, A.debug = e => {
        f() || console.debug(e)
    }, A.trace = e => {
        f() || console.trace(e)
    };
    const C = A;

    function p(e) {
        let n = arguments.length > 1 && void 0 !== arguments[1] && arguments[1];
        const t = document.cookie ? document.cookie.split("; ") : [];
        for (let n = 0; n < t.length; n++) {
            const [o, r] = t[n].split("=");
            if (e === decodeURIComponent(o)) {
                return decodeURIComponent(r)
            }
        }
        if (n && "_tracking_consent" === e && !window.localStorage.getItem("tracking_consent_fetched")) {
            if (f()) return;
            return console.debug("_tracking_consent missing"),
                function() {
                    let e = arguments.length > 0 && void 0 !== arguments[0] ? arguments[0] : "/";
                    const n = new XMLHttpRequest;
                    n.open("HEAD", e, !1), n.withCredentials = !0, n.send()
                }(), window.localStorage.setItem("tracking_consent_fetched", "true"), p(e, !1)
        }
    }

    function g(e) {
        return e === encodeURIComponent(decodeURIComponent(e))
    }

    function T(e, n, t, o) {
        if (!g(o)) throw new TypeError("Cookie value is not correctly URI encoded.");
        if (!g(e)) throw new TypeError("Cookie name is not correctly URI encoded.");
        let r = "".concat(e, "=").concat(o);
        r += "; path=/", n && (r += "; domain=".concat(n)), r += "; expires=".concat(new Date((new Date).getTime() + t).toUTCString()), document.cookie = r
    }
    const _ = "_tracking_consent",
        h = 31536e6;

    function N() {
        const e = p(_);
        if (void 0 !== e) return function(e) {
            const n = e.slice(0, 1);
            if ("{" == n) return function(e) {
                var n;
                let o;
                try {
                    o = JSON.parse(e)
                } catch (e) {
                    return
                }
                if (o.v !== t) return;
                if (null === (n = o.con) || void 0 === n || !n.CMP) return;
                return o
            }(e);
            if ("3" == n) return function(e) {
                const n = e.slice(1).split("_"),
                    [t, r, s, u, l] = n;
                let E, d;
                try {
                    E = n[5] ? JSON.parse(n.slice(5).join("_")) : void 0
                } catch (e) {}
                if (l) {
                    const e = l.replace(/\*/g, "/").replace(/-/g, "+"),
                        n = Array.from(atob(e)).map((e => e.charCodeAt(0).toString(16).padStart(2, "0"))).join("");
                    d = [8, 13, 18, 23].reduce(((e, n) => e.slice(0, n) + "-" + e.slice(n)), n)
                }

                function f(e) {
                    const n = t.split(".")[0];
                    return n.includes(e.toLowerCase()) ? i.DECLINED : n.includes(e.toUpperCase()) ? i.ACCEPTED : i.NO_VALUE
                }

                function A(e) {
                    return t.includes(e.replace("t", "s").toUpperCase())
                }
                return {
                    v: o,
                    con: {
                        CMP: {
                            [a.ANALYTICS]: f(a.ANALYTICS),
                            [a.PREFERENCES]: f(a.PREFERENCES),
                            [a.MARKETING]: f(a.MARKETING),
                            [a.SALE_OF_DATA]: f(a.SALE_OF_DATA)
                        }
                    },
                    region: r || "",
                    cus: E,
                    purposes: {
                        [c.ANALYTICS]: A(c.ANALYTICS),
                        [c.PREFERENCES]: A(c.PREFERENCES),
                        [c.MARKETING]: A(c.MARKETING),
                        [c.SALE_OF_DATA]: A(c.SALE_OF_DATA)
                    },
                    sale_of_data_region: "t" == u,
                    display_banner: "t" == s,
                    consent_id: d
                }
            }(e);
            return
        }(e)
    }

    function m() {
        try {
            let e = N();
            if (!e) return;
            return e
        } catch (e) {
            return
        }
    }

    function S() {
        return {
            m: R(a.MARKETING),
            a: R(a.ANALYTICS),
            p: R(a.PREFERENCES),
            s: R(a.SALE_OF_DATA)
        }
    }

    function w() {
        return S()[a.SALE_OF_DATA]
    }

    function y() {
        let e = arguments.length > 0 && void 0 !== arguments[0] ? arguments[0] : null;
        return null === e && (e = m()), void 0 === e
    }

    function D(e) {
        switch (e) {
            case i.ACCEPTED:
                return r.ACCEPTED;
            case i.DECLINED:
                return r.DECLINED;
            default:
                return r.NO_VALUE
        }
    }

    function I(e) {
        switch (e) {
            case a.ANALYTICS:
                return s.ANALYTICS;
            case a.MARKETING:
                return s.MARKETING;
            case a.PREFERENCES:
                return s.PREFERENCES;
            case a.SALE_OF_DATA:
                return s.SALE_OF_DATA
        }
    }

    function R(e) {
        const n = m();
        if (!n) return i.NO_VALUE;
        const t = n.con.CMP;
        return t ? t[e] : i.NO_VALUE
    }

    function O() {
        const e = m();
        return y(e) ? "" : e.region || ""
    }

    function P(e) {
        const n = N();
        if (!n || !n.purposes) return !0;
        const t = n.purposes[e];
        return "boolean" != typeof t || t
    }

    function L() {
        return P(c.PREFERENCES)
    }

    function v() {
        return P(c.ANALYTICS)
    }

    function k() {
        return P(c.MARKETING)
    }

    function b() {
        return P(c.SALE_OF_DATA)
    }

    function M() {
        const e = N();
        return !!e && ("boolean" == typeof e.display_banner && e.display_banner)
    }

    function F() {
        const e = N();
        return e && e.sale_of_data_region || !1
    }
    class K {
        constructor() {
            let e = arguments.length > 0 && void 0 !== arguments[0] && arguments[0];
            if (this.useInstrumentation = void 0, K.instance) return K.instance;
            K.instance = this, this.useInstrumentation = e
        }
        instrumentationEnabled() {
            return this.useInstrumentation
        }
        setUseInstrumentation(e) {
            this.useInstrumentation = e
        }
        produce(e, n) {
            if (this.instrumentationEnabled() && v()) try {
                const t = {
                        schema_id: "customer_privacy_api_events/2.0",
                        payload: {
                            shop_domain: window.location.host,
                            method_name: e,
                            call_details: n || null
                        }
                    },
                    o = {
                        accept: "*/*",
                        "accept-language": "en-GB,en-US;q=0.9,en;q=0.8",
                        "content-type": "application/json; charset=utf-8",
                        "x-monorail-edge-event-created-at-ms": String(Date.now()),
                        "x-monorail-edge-event-sent-at-ms": String(Date.now())
                    };
                if (!window.location.host.endsWith("spin.dev")) return fetch("https://monorail-edge.shopifysvc.com/v1/produce", {
                    headers: o,
                    body: JSON.stringify(t),
                    method: "POST",
                    mode: "cors",
                    credentials: "omit"
                });
                console.log("Monorail event from consent API:", o, t)
            } catch (e) {}
        }
    }

    function G(e) {
        void 0 !== e.granular_consent && function(e) {
            const t = e[c.MARKETING],
                o = e[c.SALE_OF_DATA],
                r = e[c.ANALYTICS],
                i = e[c.PREFERENCES];
            !0 === t ? j(n.MARKETING_ACCEPTED) : !1 === t && j(n.MARKETING_DECLINED);
            !0 === o ? j(n.SALE_OF_DATA_ACCEPTED) : !1 === o && j(n.SALE_OF_DATA_DECLINED);
            !0 === r ? j(n.ANALYTICS_ACCEPTED) : !1 === r && j(n.ANALYTICS_DECLINED);
            !0 === i ? j(n.PREFERENCES_ACCEPTED) : !1 === i && j(n.PREFERENCES_DECLINED);
            const a = function(e) {
                const n = {
                    marketingAllowed: e[c.MARKETING],
                    saleOfDataAllowed: e[c.SALE_OF_DATA],
                    analyticsAllowed: e[c.ANALYTICS],
                    preferencesAllowed: e[c.PREFERENCES],
                    firstPartyMarketingAllowed: e[c.MARKETING],
                    thirdPartyMarketingAllowed: e[c.SALE_OF_DATA]
                };
                return n
            }(e);
            j(n.CONSENT_COLLECTED, a);
            const s = [r, i, t, o];
            s.every((e => !0 === e)) && j(n.TRACKING_ACCEPTED);
            s.every((e => !1 === e)) && j(n.TRACKING_DECLINED)
        }({
            [c.PREFERENCES]: L(),
            [c.ANALYTICS]: v(),
            [c.MARKETING]: k(),
            [c.SALE_OF_DATA]: b()
        })
    }

    function j(e, n) {
        document.dispatchEvent(new CustomEvent(e, {
            detail: n || {}
        }))
    }

    function U(e, n) {
        if (null === e) return "null";
        if (Array.isArray(e)) {
            const n = e.map((e => U(e, !0))).join(",");
            return "[".concat(n, "]")
        }
        if ("object" == typeof e) {
            let t = [];
            for (const n in e) e.hasOwnProperty(n) && void 0 !== e[n] && t.push("".concat(n, ":").concat(U(e[n], !0)));
            const o = t.join(",");
            return n ? "{".concat(o, "}") : o
        }
        return "string" == typeof e ? '"'.concat(e, '"') : "".concat(e)
    }
    K.instance = void 0;
    const Y = "95ba910bcec4542ef2a0b64cd7ca666c";

    function B(e, n, t) {
        try {
            var o;
            ! function(e) {
                const n = new XMLHttpRequest;
                n.open("POST", "https://error-analytics-production.shopifysvc.com", !0), n.setRequestHeader("Content-Type", "application/json"), n.setRequestHeader("Bugsnag-Api-Key", Y), n.setRequestHeader("Bugsnag-Payload-Version", "5");
                const t = function(e) {
                    const n = function(e) {
                            return e.stackTrace || e.stack || e.description || e.name
                        }(e.error),
                        [t, o] = (n || "unknown error").split("\n")[0].split(":");
                    return JSON.stringify({
                        payloadVersion: 5,
                        notifier: {
                            name: "ConsentTrackingAPI",
                            version: "latest",
                            url: "-"
                        },
                        events: [{
                            exceptions: [{
                                errorClass: (t || "").trim(),
                                message: (o || "").trim(),
                                stacktrace: [{
                                    file: "consent-tracking-api.js",
                                    lineNumber: "1",
                                    method: n
                                }],
                                type: "browserjs"
                            }],
                            context: e.context || "general",
                            app: {
                                id: "ConsentTrackingAPI",
                                version: "latest"
                            },
                            metaData: {
                                request: {
                                    shopId: e.shopId,
                                    shopUrl: window.location.href
                                },
                                device: {
                                    userAgent: window.navigator.userAgent
                                },
                                "Additional Notes": e.notes
                            },
                            unhandled: !1
                        }]
                    })
                }(e);
                n.send(t)
            }({
                error: e,
                context: n,
                shopId: V() || (null === (o = window.Shopify) || void 0 === o ? void 0 : o.shop),
                notes: t
            })
        } catch (e) {}
    }

    function x(e) {
        return function() {
            try {
                return e(...arguments)
            } catch (e) {
                throw e instanceof TypeError || B(e), e
            }
        }
    }

    function V() {
        try {
            const e = document.getElementById("shopify-features").textContent;
            return JSON.parse(e).shopId
        } catch (e) {
            return null
        }
    }

    function q() {
        return k()
    }

    function H() {
        return b()
    }

    function J() {
        const e = {},
            n = S();
        for (const t of Object.keys(n)) e[I(t)] = D(n[t]);
        return e
    }

    function X(e, n) {
        const o = new K;
        return o.produce("setTrackingConsent"), "object" == typeof e && e.headlessStorefront && !e.storefrontAccessToken ? (C.warn("Headless consent has been updated. Please read shopify.dev/docs/api/customer-privacy to integrate."), o.produce("setTrackingConsent-Headless"), function(e, n) {
            function o(e) {
                let n = arguments.length > 1 && void 0 !== arguments[1] ? arguments[1] : i.NO_VALUE;
                return !0 === e ? i.ACCEPTED : !1 === e ? i.DECLINED : n
            }
            const r = {
                    [a.ANALYTICS]: o(e[s.ANALYTICS], i.DECLINED),
                    [a.MARKETING]: o(e[s.MARKETING], i.DECLINED),
                    [a.PREFERENCES]: o(e[s.PREFERENCES], i.DECLINED),
                    [a.SALE_OF_DATA]: o(e[s.SALE_OF_DATA])
                },
                c = {
                    v: t,
                    reg: "",
                    con: {
                        CMP: r
                    }
                },
                u = encodeURIComponent(JSON.stringify(c));
            return T(_, e.rootDomain, h, u), n(null), new Promise(((e, n) => {}))
        }(e, n || (() => {}))) : function(e, n) {
            if (function(e) {
                    if ("boolean" != typeof e && "object" != typeof e) throw TypeError("setTrackingConsent must be called with a boolean or object consent value");
                    if ("object" == typeof e) {
                        const n = Object.keys(e);
                        if (0 === n.length) throw TypeError("The submitted consent object is empty.");
                        const t = [s.MARKETING, s.ANALYTICS, s.PREFERENCES, s.SALE_OF_DATA, s.EMAIL, u.ROOT_DOMAIN, u.CHECKOUT_ROOT_DOMAIN, u.STOREFRONT_ROOT_DOMAIN, u.STOREFRONT_ACCESS_TOKEN, u.HEADLESS_STOREFRONT, u.IS_EXTENSION_TOKEN, u.METAFIELDS];
                        for (const e of n)
                            if (!t.includes(e)) throw TypeError("The submitted consent object should only contain the following keys: ".concat(t.join(", "), ". Extraneous key: ").concat(e, "."))
                    }
                }(e), void 0 !== n && "function" != typeof n) throw TypeError("setTrackingConsent must be called with a callback function if the callback argument is provided");
            let t;
            if (!0 === e || !1 === e) {
                C.warn("Binary consent is deprecated. Please update to granular consent (shopify.dev/docs/api/consent-tracking)");
                t = {
                    analytics: e,
                    preferences: e,
                    marketing: e
                }
            } else t = e;
            const o = function(e) {
                    if (!e) return null;
                    return le() ? document.referrer : ""
                }(t.analytics),
                r = function(e) {
                    if (!e) return null;
                    return le() ? window.location.pathname + window.location.search : "/"
                }(t.analytics);
            return re(E(E({
                granular_consent: t
            }, null !== o && {
                referrer: o
            }), null !== r && {
                landing_page: r
            }), n)
        }(e, n)
    }
    const W = e => {
        let {
            useBugsnagReporting: n,
            useInstrumentation: t
        } = e;
        w() != i.DECLINED && !1 === fe() && ie(!1, (() => !1));
        const o = {
            getTrackingConsent: ce,
            setTrackingConsent: X,
            userCanBeTracked: de,
            getRegulation: ae,
            isRegulationEnforced: Ee,
            getShopPrefs: se,
            shouldShowGDPRBanner: Ce,
            userDataCanBeSold: Ae,
            setCCPAConsent: ie,
            getCCPAConsent: pe,
            shouldShowCCPABanner: ge,
            doesMerchantSupportGranularConsent: Te,
            analyticsProcessingAllowed: v,
            preferencesProcessingAllowed: L,
            marketingAllowed: q,
            firstPartyMarketingAllowed: q,
            saleOfDataAllowed: H,
            thirdPartyMarketingAllowed: H,
            currentVisitorConsent: J,
            shouldShowBanner: M,
            saleOfDataRegion: F,
            getRegion: ue,
            getTrackingConsentMetafield: _e,
            unstable: {
                analyticsProcessingAllowed: v,
                preferencesProcessingAllowed: L,
                marketingAllowed: q,
                saleOfDataAllowed: H,
                currentVisitorConsent: J,
                shouldShowBanner: M,
                saleOfDataRegion: F
            },
            __metadata__: {
                name: "@shopify/consent-tracking-api",
                version: "v0.1",
                description: "Shopify Consent Tracking API"
            }
        };
        if (new K(t), !n) return o;
        const r = ["unstable", "__metadata__"];
        for (const e in o) o.hasOwnProperty(e) && (o[e] = r.includes(e) ? o[e] : x(o[e]));
        return o
    };

    function $() {
        return W(arguments.length > 0 && void 0 !== arguments[0] ? arguments[0] : {
            useBugsnagReporting: !1,
            useInstrumentation: !1
        })
    }

    function Z(e) {
        if (!e) return;
        const n = function(e) {
            const n = new URL(e, window.location.origin),
                t = Q(e) ? z(n) : z(n).replace(window.location.origin, "");
            return document.querySelectorAll('a[href^="'.concat(t, '"]'))
        }(e);
        if (!n.length) return;
        const t = function() {
                const e = N();
                return e && e.consent_id || ""
            }(),
            o = function() {
                const e = J();
                if (!e) return null;
                if (!("analytics" in e && "marketing" in e && "preferences" in e)) return null;
                const n = ee(e.analytics),
                    t = ee(e.marketing),
                    o = ee(e.preferences);
                return "" === n && "" === t && "" === o ? null : "a".concat(n, "m").concat(t, "p").concat(o)
            }();
        for (const r of Array.from(n)) {
            const n = r.getAttribute("href");
            if (!n) continue;
            const i = new URL(n, window.location.origin);
            if (t && i.searchParams.set("consent_id", t), o && i.searchParams.set("consent", o), t || o) {
                const n = Q(e) ? i.toString() : i.toString().replace(window.location.origin, "");
                r.setAttribute("href", n)
            }
        }
    }

    function z(e) {
        return "".concat(e.origin).concat(e.pathname.replace(/\/$/, ""))
    }

    function Q(e) {
        return e.startsWith("http://") || e.startsWith("https://")
    }

    function ee(e) {
        switch (e) {
            case r.ACCEPTED:
                return "1";
            case r.DECLINED:
                return "0";
            default:
                return ""
        }
    }
    const ne = "_landing_page",
        te = "_orig_referrer";

    function oe(e) {
        const n = e.granular_consent,
            t = U(E(E({
                visitorConsent: E({
                    marketing: n.marketing,
                    analytics: n.analytics,
                    preferences: n.preferences,
                    saleOfData: n.sale_of_data
                }, n.metafields && {
                    metafields: n.metafields
                })
            }, n.email && {
                visitorEmail: n.email
            }), {}, {
                origReferrer: e.referrer,
                landingPage: e.landing_page
            }));
        return {
            query: "query { consentManagement { cookies(".concat(t, ") { trackingConsentCookie cookieDomain landingPageCookie origReferrerCookie } customerAccountUrl } }"),
            variables: {}
        }
    }

    function re(e, n) {
        const t = e.granular_consent,
            o = t.storefrontAccessToken || function() {
                const e = document.documentElement.querySelector("#shopify-features"),
                    n = "Could not find liquid access token";
                if (!e) return void C.warn(n);
                const t = JSON.parse(e.textContent || "").accessToken;
                if (!t) return void C.warn(n);
                return t
            }(),
            r = t.checkoutRootDomain || window.location.host,
            i = t.isExtensionToken ? "Shopify-Storefront-Extension-Token" : "x-shopify-storefront-access-token",
            c = {
                headers: E({
                    "content-type": "application/json",
                    [i]: o
                }, !1),
                body: JSON.stringify(oe(e)),
                method: "POST"
            };
        return fetch("https://".concat(r, "/api/unstable/graphql.json"), c).then((e => {
            if (e.ok) return e.json();
            throw new Error("Server error")
        })).then((o => {
            var r, i;
            const c = 31536e6,
                a = 12096e5,
                s = o.data.consentManagement.cookies.cookieDomain,
                u = s || t.checkoutRootDomain || window.location.hostname,
                l = t.storefrontRootDomain || s || window.location.hostname,
                E = o.data.consentManagement.cookies.trackingConsentCookie,
                d = o.data.consentManagement.cookies.landingPageCookie,
                f = o.data.consentManagement.cookies.origReferrerCookie,
                A = null !== (r = null === (i = o.data.consentManagement) || void 0 === i ? void 0 : i.customerAccountUrl) && void 0 !== r ? r : "";
            return T(_, u, c, E), d && f && (T(ne, u, a, d), T(te, u, a, f)), l !== u && (T(_, l, c, E), d && f && (T(ne, l, a, d), T(te, l, a, f))), G(e), Z(A), void 0 !== n && n(null, o), o
        })).catch((e => {
            const t = "Error while setting storefront API consent: " + e.message;
            if (void 0 === n) throw {
                error: t
            };
            n({
                error: t
            })
        }))
    }

    function ie(e, n) {
        if (C.warn("This method is deprecated. Please read shopify.dev/docs/api/customer-privacy for the latest information."), "boolean" != typeof e) throw TypeError("setCCPAConsent must be called with a boolean consent value");
        if ("function" != typeof n) throw TypeError("setCCPAConsent must be called with a callback function");
        return re({
            granular_consent: {
                sale_of_data: e
            }
        }, n)
    }

    function ce() {
        if ((new K).produce("getTrackingConsent"), y()) return r.NO_VALUE;
        const e = S();
        return e[a.MARKETING] === i.ACCEPTED && e[a.ANALYTICS] === i.ACCEPTED ? r.ACCEPTED : e[a.MARKETING] === i.DECLINED || e[a.ANALYTICS] === i.DECLINED ? r.DECLINED : r.NO_INTERACTION
    }

    function ae() {
        (new K).produce("getRegulation"), C.warn("getRegulation is deprecated and will be removed.");
        const e = O();
        return "" === e ? "" : ["AT", "BE", "BG", "HR", "CY", "CZ", "DK", "EE", "FI", "FR", "DE", "GR", "HU", "IS", "IE", "IT", "LV", "LI", "LT", "LU", "MT", "NL", "NO", "PL", "PT", "RO", "SI", "SK", "ES", "SE", "GB"].includes(e.slice(0, 2)) ? "GDPR" : "US" === e.slice(0, 2) && ["CA", "VA"].includes(e.slice(2, 4)) ? "CCPA" : ""
    }

    function se() {
        return (new K).produce("getShopPrefs"), C.warn("getShopPrefs is deprecated and will be removed."), {
            limit: []
        }
    }

    function ue() {
        return O()
    }

    function le() {
        if ("" === document.referrer) return !0;
        const e = document.createElement("a");
        return e.href = document.referrer, window.location.hostname != e.hostname
    }

    function Ee() {
        return (new K).produce("isRegulationEnforced"), C.warn("isRegulationEnforced is deprecated and will be removed."), !0
    }

    function de() {
        return !!y() || k() && v()
    }

    function fe() {
        return F() ? "string" == typeof navigator.globalPrivacyControl ? "1" !== navigator.globalPrivacyControl : "boolean" == typeof navigator.globalPrivacyControl ? !navigator.globalPrivacyControl : null : null
    }

    function Ae() {
        return C.warn("userDataCanBeSold is deprecated and will be replaced with saleOfDataAllowed."), b()
    }

    function Ce() {
        return M() && ce() === r.NO_INTERACTION
    }

    function pe() {
        return !1 === fe() ? r.DECLINED : (e = w(), y() ? r.NO_VALUE : e === i.NO_VALUE ? r.NO_INTERACTION : D(e));
        var e
    }

    function ge() {
        return (new K).produce("shouldShowCCPABanner"), C.warn("shouldShowCCPABanner is deprecated and will be removed."), F() && pe() === r.NO_INTERACTION
    }

    function Te() {
        return !0
    }

    function _e(e) {
        return function(e) {
            const n = m();
            if (y(n) || !n.cus) return;
            const t = n.cus[encodeURIComponent(e)];
            return t ? decodeURIComponent(t) : t
        }(e)
    }

    function he() {
        var e, t;
        const o = $({
            useBugsnagReporting: !0,
            useInstrumentation: !0
        });
        if (window.Shopify.trackingConsent || window.Shopify.customerPrivacy) {
            const n = null === (e = window.Shopify.customerPrivacy.__metadata__) || void 0 === e ? void 0 : e.version,
                r = null === (t = o.__metadata__) || void 0 === t ? void 0 : t.version,
                i = `Multiple versions of Shopify.trackingConsent or Shopify.customerPrivacy loaded -  Version '${n}' is already loaded but replacing with version '${r}'.\n\nThis could result in unexpected behavior. See documentation https://shopify.dev/docs/api/customer-privacy for more information.`,
                c = "Shopify.trackingConsent or Shopify.customerPrivacy already exists.\n\nLoading multiple versions could result in unexpected behavior. See documentation https://shopify.dev/docs/api/customer-privacy for more information.";
            try {
                console.warn(n && r ? i : c)
            } catch (e) {
                if (!(e instanceof ReferenceError)) throw e
            }
        }
        window.Shopify.customerPrivacy = window.Shopify.trackingConsent = o, j(n.CONSENT_TRACKING_API_LOADED)
    }
    window.Shopify = window.Shopify ? window.Shopify : {}, he(), e.default = $, e.setGlobalObject = he, Object.defineProperty(e, "__esModule", {
        value: !0
    })
}({});
//# sourceMappingURL=consent-tracking-api.js.map