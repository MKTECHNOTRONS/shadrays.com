! function() {
    "use strict";
    try {
        window.snaptr.cfg('32645ddf-b9f5-433d-9f5a-65d32b462fe1', {
            "asc": [],
            "gw": null,
            "a": ["PII", "AV3"],
            "ipg": "92",
            "b": [],
            "t": "",
            "v": "3.7.5-2401032347",
            "tpd": [],
            "ec": []
        })
    } catch (e) {}
}();