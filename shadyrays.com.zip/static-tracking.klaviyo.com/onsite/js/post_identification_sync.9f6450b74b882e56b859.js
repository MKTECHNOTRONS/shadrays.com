(self.webpackChunk_klaviyo_onsite_modules = self.webpackChunk_klaviyo_onsite_modules || []).push([
    [7327], {
        12311: function(e, t, n) {
            "use strict";
            var a = n(45933);
            n(56816);
            const r = "kl-post-identification-sync",
                o = JSON.stringify([]),
                s = (e, t) => {
                    (async e => {
                        const t = localStorage.getItem(r),
                            n = null === t ? [] : JSON.parse(t);
                        n.push(e), n.length > 1e4 && n.shift(), localStorage.setItem(r, JSON.stringify(n))
                    })(e).finally((() => {
                        t && t()
                    }))
                },
                i = async (e = 1e3) => (async e => {
                    const t = JSON.parse(localStorage.getItem(r) || o),
                        n = t.slice(0, e),
                        a = t.slice(e);
                    return {
                        events: n || [],
                        deleteCallback: async () => {
                            localStorage.setItem(r, JSON.stringify(a))
                        }
                    }
                })(e),
                l = () => (async () => {
                    localStorage.removeItem(r)
                })(),
                c = (e, t) => {
                    var n;
                    const a = (new Date).toISOString(),
                        r = {
                            name: e.event,
                            time: (null == (n = e.properties) ? void 0 : n.time) || a,
                            properties: e.properties || {}
                        };
                    s(r, t)
                };
            var u = n(87789),
                p = n.n(u),
                m = (n(92461), n(44159), n(60873), n(7739)),
                d = n(5762),
                h = n(59824),
                y = n(32138);
            n(70917), n(93677), n(84304), n(75723), n(20696), n(38528), n(72418);
            const f = new Set(["$exchange_id", "email", "id", "$email", "$id", "$anonymous", "$phone_number"]),
                v = ["name", "properties"];
            let b = !1;
            const g = (e, t, n, a) => {
                    const r = ((e, t, n) => ({
                        data: {
                            type: "event-bulk-create",
                            attributes: {
                                profile: {
                                    data: {
                                        type: "profile",
                                        attributes: Object.assign({}, t)
                                    }
                                },
                                events: {
                                    data: e.map((e => {
                                        const {
                                            name: t,
                                            properties: a
                                        } = e, r = p()(e, v), o = Object.assign({}, a, n || {});
                                        return {
                                            type: "event",
                                            attributes: Object.assign({
                                                metric: {
                                                    data: {
                                                        type: "metric",
                                                        attributes: {
                                                            name: t
                                                        }
                                                    }
                                                }
                                            }, r, {
                                                properties: o
                                            })
                                        }
                                    }))
                                }
                            }
                        }
                    }))(e, n, a);
                    return (0, d.W)((() => ((e, t) => fetch(`https://a.klaviyo.com/client/event-bulk-create/?company_id=${e}`, {
                        method: "POST",
                        headers: Object.assign({
                            "Access-Control-Allow-Headers": "*",
                            "Content-Type": "application/json"
                        }, (0, m.h)(), {
                            revision: "2025-01-15"
                        }),
                        body: JSON.stringify(t)
                    }))(t, r)), 5, 1e3 + 1e3 * Math.random(), [429])
                },
                _ = {
                    $exchange_id: "_kx",
                    email: "email",
                    $email: "email",
                    $phone_number: "phone_number",
                    phone_number: "phone_number",
                    $id: "external_id",
                    id: "id",
                    $kid: "id",
                    $anonymous: "anonymous_id"
                },
                k = e => {
                    let t = {};
                    return Object.keys(_).forEach((n => {
                        if (a = n, Set.prototype.has.call(f, a)) {
                            const a = e[n];
                            if (a) {
                                const e = ("$email" === n || "email" === n) && !(0, h.v)(a),
                                    r = "$phone_number" === n && !(0, y.y)(a);
                                e || r || (t = Object.assign({}, t, {
                                    [_[n]]: a
                                }))
                            }
                        }
                        var a
                    })), t
                },
                O = (e, t, n, a) => {
                    if (0 !== e.events.length) return g(e.events, t, n, a).then((async r => {
                        if (429 === r.status) throw Error("Saving event cache due to rate limit.");
                        return e.deleteCallback && await e.deleteCallback(), i().then((e => O(e, t, n, a)))
                    }))
                },
                S = async (e, t, n, a) => {
                    const r = e || window.__klKey;
                    if (!r || b) return;
                    const o = k(t);
                    o && 0 !== Object.keys(o).length && (b = !0, i().then((e => O(e, r, o, n))).catch((e => {
                        throw console.error("Failed to send bulk events", e), e
                    })).then((() => {
                        l(), a && a()
                    })).catch((e => {
                        console.error("Failed to clear storage", e)
                    })).finally((() => {
                        b = !1
                    })))
                };
            (() => {
                (0, a.e)("cacheEvent", c), (0, a.e)("sendCachedEvents", S)
            })()
        },
        87789: function(e) {
            e.exports = function(e, t) {
                if (null == e) return {};
                var n = {};
                for (var a in e)
                    if ({}.hasOwnProperty.call(e, a)) {
                        if (t.includes(a)) continue;
                        n[a] = e[a]
                    }
                return n
            }, e.exports.__esModule = !0, e.exports.default = e.exports
        }
    },
    function(e) {
        e.O(0, [2462], (function() {
            return t = 12311, e(e.s = t);
            var t
        }));
        e.O()
    }
]);