! function() {
    'use strict';

    function t() {
        const t = `${e}?t=e&message=${encodeURI('failed to load')}&v=${n}`,
            o = new Image(1, 1);
        return o.src = t, o
    }
    const e = 'https://events.attentivemobile.com/e',
        n = '4-latest_c98022a08d',
        o = 'eyJjb21wYW55Ijoic2hhZHlyYXlzIiwiY2VpZCI6ImhnQiIsInRjIjpmYWxzZSwidWEiOmZhbHNlLCJhcCI6eyJ0cmciOlt7InB0Ijoic3BwIiwiaWQiOiJ0MCIsInB0Ijoic3BwIiwicGwiOnsiZW5yIjpbInNocCIsImx0YyIsImpsZCIsIm1ldCJdLCJ0cm4iOlsiZHMiXX0sIm10IjpbIkFkZCB0byBjYXJ0IiwiQWRkIHRvIEJhZyIsIkJ1eSBOb3ciLCJBZGQiLCIjYWRkVG9DYXJ0IiwiI2FkZC10by1jYXJ0IiwiI0FkZFRvQ2FydCIsIk9yZGVyIE5vdyIsIkJ1eSBpdCBub3ciLCIucHJvZHVjdF9fYWRkLXRvLWNhcnQiLCJbbmFtZT1cImFkZFwiXSIsIltkYXRhLWxhYmVsPVwiQWRkIHRvIENhcnRcIl0iLCJbZGF0YS1hZGQtdG8tY2FydF0iLCIjYWRkVG9DYXJ0QnRuIiwiW3ZhbHVlPVwiQWRkIHRvIEJhZ1wiXSIsIlt2YWx1ZT1cIkFkZCB0byBDYXJ0XCJdIiwiW3ZhbHVlPVwiQWRkIHRvIE9yZGVyXCJdIl0sImVhdGMiOmZhbHNlLCJlc2l0Ijp0cnVlfSx7InB0IjoidDAiLCJpZCI6InQxIiwiY25kIjpbeyJ0eXBlIjoid3MiLCJ0eXBlIjoid3MiLCJ3cyI6ImNhcnRfanNvbiJ9XSwicHQiOiJ0MCIsIm11IjoiL3B1cmNoYXNlL3RoYW5rcyIsIm10IjpbXSwidG1zIjowLCJ0IjoicCIsInBsIjp7ImVuciI6WyJyZWMiLCJsdGMiXSwidHJuIjpbInJlIiwiZHMiXX19LHsicHQiOiJ0MCIsImlkIjoidDIiLCJjbmQiOlt7InR5cGUiOiJ3cyIsInR5cGUiOiJ3cyIsIndzIjoiY2hEYXRhLm9yZGVyIn1dLCJwdCI6InQwIiwibXUiOiIvc2VjdXJlL3RoYW5rLXlvdSIsIm10IjpbXSwidG1zIjowLCJ0IjoicCIsInBsIjp7ImVuciI6WyJjYXIiLCJsdGMiXSwidHJuIjpbImNoIiwiZHMiXX19XSwiZW5yIjp7ImNhciI6eyJwdCI6IndzcCIsInB0Ijoid3NwIiwibXAiOnsiZW1haWwiOiJjaERhdGEub3JkZXIuY3VzdG9tZXIuZW1haWwiLCJpdGVtcyI6ImNoRGF0YS5vcmRlci5saW5lX2l0ZW1zIiwicGhvbmUiOiJjaERhdGEub3JkZXIuYmlsbGluZ19hZGRyZXNzLnBob25lIiwib3JkZXJJZCI6ImNoRGF0YS5vcmRlci5vcmRlcl9udW1iZXIiLCJjYXJ0VG90YWwiOiJjaERhdGEub3JkZXIuc3VidG90YWxfcHJpY2UifX0sImpsZCI6eyJwdCI6ImpsZCIsInB0IjoiamxkIiwibXAiOnsic2t1Ijoic2t1IiwibmFtZSI6Im5hbWUiLCJpbWFnZSI6ImltYWdlIn19LCJsdGMiOnsicHQiOiJsdGMiLCJwdCI6Imx0YyJ9LCJtZXQiOnsicHQiOiJtZXQiLCJwdCI6Im1ldCIsIm1wIjp7Im5hbWUiOiJvZzp0aXRsZSIsImltYWdlIjoib2c6aW1hZ2UiLCJwcmljZSI6Im9nOnByaWNlOmFtb3VudCIsImN1cnJlbmN5Ijoib2c6cHJpY2U6Y3VycmVuY3kifX0sInJlYyI6eyJwdCI6IndzcCIsInB0Ijoid3NwIiwibXAiOnsiZW1haWwiOiJjYXJ0X2pzb24uZW1haWwiLCJpdGVtcyI6ImNhcnRfanNvbi5saW5lX2l0ZW1zIiwicGhvbmUiOiJjYXJ0X2pzb24ucGhvbmUiLCJvcmRlcklkIjoiY2FydF9qc29uLmNoYXJnZV9pZCIsImNhcnRUb3RhbCI6ImNhcnRfanNvbi5zdWJ0b3RhbF9wcmljZSJ9fSwic2hwIjp7InB0Ijoic2hwIiwicHQiOiJzaHAiLCJ2aWRjIjpbeyJtcCI6eyJzdWJQcm9kdWN0SWQiOnsicyI6IltuYW1lPWlkXSIsInByb3AiOiJ2YWx1ZSJ9fSwicHQiOiJkc3AiLCJjc2siOiJpdGVtcyJ9LHsibXAiOnsic3ViUHJvZHVjdElkIjpbeyJwdCI6IndzcCIsIndzIjoiU2hvcGlmeUFuYWx5dGljcy5tZXRhLnNlbGVjdGVkVmFyaWFudElkIn1dfSwicHQiOiJjbXBzIn0seyJtcCI6eyJzdWJQcm9kdWN0SWQiOlt7InB0IjoicXBzcCIsInFwIjoidmFyaWFudCJ9XX0sInB0IjoiY21wcyJ9XX0sImludGwiOnsicHQiOiJjbXBzIiwicHQiOiJjbXBzIiwibXAiOnsiY3VycmVuY3kiOlt7InB0Ijoid3NwIiwicHQiOiJ3c3AiLCJ3cyI6IlNob3BpZnkuY2hlY2tvdXQucHJlc2VudG1lbnRfY3VycmVuY3kifSx7InB0Ijoid3NwIiwicHQiOiJ3c3AiLCJ3cyI6IlNob3BpZnkuQ2hlY2tvdXQuY3VycmVuY3kifV0sImNhcnRDdXJyZW5jeSI6W3sicHQiOiJ3c3AiLCJwdCI6IndzcCIsIndzIjoiU2hvcGlmeS5jaGVja291dC5wcmVzZW50bWVudF9jdXJyZW5jeSJ9LHsicHQiOiJ3c3AiLCJwdCI6IndzcCIsIndzIjoiU2hvcGlmeS5DaGVja291dC5jdXJyZW5jeSJ9XX19fSwidHJuIjp7ImNoIjp7InB0IjoibXYiLCJwdCI6Im12IiwicHRoIjpbImNhci5pdGVtcyJdLCJtcCI6eyJpZCI6InNrdSIsInRpdGxlIjoibmFtZSIsInZhcmlhbnRfaWQiOiJzdWJQcm9kdWN0SWQifX0sImRzIjp7InB0IjoiZHMiLCJwdCI6ImRzIiwibXAiOnsic2t1IjpbInJlYyIsImNhciIsInNocCIsIioiLCJqbGQiXSwibmFtZSI6WyJyZWMiLCJjYXIiLCJzaHAiLCIqIiwibWV0IiwiamxkIl0sImVtYWlsIjpbInJlYyIsImNhciIsIioiLCJsdGMiXSwiaW1hZ2UiOlsicmVjIiwiY2FyIiwiKiIsInNocCIsIm1ldCJdLCJwaG9uZSI6WyJyZWMiLCJjYXIiLCJzaHAiLCJsdGMiXSwicHJpY2UiOlsicmVjIiwiY2FyIiwic2hwIiwiKiIsIm1ldCJdLCJvcmRlcklkIjpbInJlYyIsImNhciIsIioiLCJzaHAiXSwiY2F0ZWdvcnkiOlsiKiIsInNocCJdLCJjdXJyZW5jeSI6WyJpbnRsIiwiKiIsInNocCIsIm1ldCJdLCJxdWFudGl0eSI6WyJyZWMiLCJjYXIiLCIqIiwic2hwIl0sImNhcnRUb3RhbCI6WyJyZWMiLCJjYXIiLCIqIiwic2hwIl0sInByb2R1Y3RJZCI6WyJyZWMiLCJjYXIiLCJzaHAiLCIqIiwiamxkIl0sImNhcnRDb3Vwb24iOlsiKiIsInNocCIsImx0YyJdLCJjYXJ0Q3VycmVuY3kiOlsiaW50bCIsIioiLCJzaHAiLCJtZXQiXSwiY2FydERpc2NvdW50IjpbIioiLCJzaHAiXSwic3ViUHJvZHVjdElkIjpbInJlYyIsImNhciIsInNocCIsIioiXX19LCJyZSI6eyJwdCI6Im12IiwicHQiOiJtdiIsInB0aCI6WyJyZWMuaXRlbXMiXSwibXAiOnsic2t1IjoicHJvZHVjdElkIiwidGl0bGUiOiJuYW1lIiwicHJvZHVjdF9pZCI6InNrdSIsInZhcmlhbnRfaWQiOiJzdWJQcm9kdWN0SWQifX19fSwiY2MiOnsiaXQiOnRydWV9LCJiY3R1IjoiaHR0cHM6Ly9ranpkci5zaGFkeXJheXMuY29tIn0=',
        a = 'shadyrays.attn.tv',
        i = 'https://cdn.attn.tv/tag';
    const d = '4-latest';
    let c = {};
    try {
        c = JSON.parse(atob(o))
    } catch {
        t()
    }

    function r(t, e, n) {
        const o = document.createElement('script');
        return o.setAttribute('async', 'true'), o.type = 'text/javascript', e && (o.onload = e), n && (o.onerror = n), o.src = t, ((document.getElementsByTagName('head') || [null])[0] || document.getElementsByTagName('script')[0].parentNode).appendChild(o), o
    }

    function s(t) {
        return `${i}/${d}/${t}?v=${n}`
    }

    function _(e = (() => {})) {
        r(s('unified-' + (window.navigator.userAgent.indexOf('MSIE ') > 0 || navigator.userAgent.match(/Trident.*rv:11\./) ? 'tag-ie.js' : 'tag.js')), e, t)
    }! function(e, n) {
        var i;

        function u(t) {
            return function() {
                e.attn_d0x0b_evt.push({
                    func: t,
                    args: arguments
                })
            }
        }

        function w() {
            ! function() {
                try {
                    const [t] = window.location.hash.split(/\?/);
                    if (t.indexOf('attn') > -1) {
                        const t = window.location.hash.slice(5);
                        sessionStorage.setItem('_d0x0b_', t)
                    }
                    const e = sessionStorage.getItem('_d0x0b_');
                    return !!e && (window.attn_d0x0b_cfg = e, !0)
                } catch (t) {
                    return !1
                }
            }() ? _(): function(e = (() => {})) {
                r(s('tag-debug.js'), e, t)
            }(), n.removeEventListener('DOMContentLoaded', w)
        }
        e.attn_d0x0b_cfg = o, e.__attentive_cfg = JSON.parse('{\"ceid\":\"hgB\",\"os\":\"META\",\"mov\":\"3.08.12\",\"lt\":\"2\",\"ze\":\"2147483643\",\"esms\":\"klaviyo\"}'), window.__attentive_domain = a, window.__attentive || (window.__attentive = {
            invoked: !1,
            show: function() {
                window.__attentive.invoked = !0
            }
        }), (null == (i = null == c ? void 0 : c.cc) ? void 0 : i.dap) || function() {
            if (window.__poll_for_path_change) return;
            let t = window.location.pathname;
            const e = () => {
                window.__attentive && window.__attentive.show && window.__attentive.show()
            };
            window.__poll_for_path_change = !0, setInterval((function() {
                if (t !== window.location.pathname) {
                    const n = document.querySelector('#attentive_overlay');
                    null != n && n.parentNode && n.parentNode.removeChild(n), t = window.location.pathname, e()
                }
            }), 500), e()
        }(), e.__attnLoaded || (e.__attnLoaded = !0, e.attn_d0x0b_evt = e.attn_d0x0b_evt || [], e.attentive = {
            version: d,
            analytics: {
                enable: u('enable'),
                disable: u('disable'),
                track: u('track'),
                pageView: u('pageView'),
                addToCart: u('addToCart'),
                productView: u('productView'),
                purchase: u('purchase')
            }
        }, 'loading' === n.readyState ? n.addEventListener('DOMContentLoaded', w) : w())
    }(window, document)
}();