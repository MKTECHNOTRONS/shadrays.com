(function() {
    "use strict";
    const t = {
        CUSTOM_EMAIL_LEAD_EVENTS: ({
            email: a,
            creativeId: i
        }) => {
            window.attenCallback2 && window.attenCallback2("email_submit", {
                email: a,
                creativeId: i
            })
        },
        CUSTOM_IMPRESSION_EVENTS: () => {
            window.attentiveCallback && window.attentiveCallback("impression", 1)
        },
        CUSTOM_LEAD_EVENTS: () => {
            window.attentiveCallback && window.attentiveCallback("sms_submit", 1)
        }
    };
    window.__attentive_client_cfg = t
})();