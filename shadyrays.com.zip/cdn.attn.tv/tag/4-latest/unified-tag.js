! function() {
    'use strict';

    function e(t) {
        return e = 'function' == typeof Symbol && 'symbol' == typeof Symbol.iterator ? function(e) {
            return typeof e
        } : function(e) {
            return e && 'function' == typeof Symbol && e.constructor === Symbol && e !== Symbol.prototype ? 'symbol' : typeof e
        }, e(t)
    }
    var t = function() {
        return t = Object.assign || function(e) {
            for (var t, n = 1, r = arguments.length; n < r; n++)
                for (var i in t = arguments[n]) Object.prototype.hasOwnProperty.call(t, i) && (e[i] = t[i]);
            return e
        }, t.apply(this, arguments)
    };

    function n(e, t) {
        var n = {};
        for (var r in e) Object.prototype.hasOwnProperty.call(e, r) && t.indexOf(r) < 0 && (n[r] = e[r]);
        if (null != e && 'function' == typeof Object.getOwnPropertySymbols) {
            var i = 0;
            for (r = Object.getOwnPropertySymbols(e); i < r.length; i++) t.indexOf(r[i]) < 0 && Object.prototype.propertyIsEnumerable.call(e, r[i]) && (n[r[i]] = e[r[i]])
        }
        return n
    }

    function r(e, t, n, r) {
        return new(n || (n = Promise))((function(i, a) {
            function o(e) {
                try {
                    u(r.next(e))
                } catch (e) {
                    a(e)
                }
            }

            function c(e) {
                try {
                    u(r.throw(e))
                } catch (e) {
                    a(e)
                }
            }

            function u(e) {
                var t;
                e.done ? i(e.value) : (t = e.value, t instanceof n ? t : new n((function(e) {
                    e(t)
                }))).then(o, c)
            }
            u((r = r.apply(e, t || [])).next())
        }))
    }

    function i(e, t) {
        var n, r, i, a, o = {
            label: 0,
            sent: function() {
                if (1 & i[0]) throw i[1];
                return i[1]
            },
            trys: [],
            ops: []
        };
        return a = {
            next: c(0),
            throw: c(1),
            return: c(2)
        }, 'function' == typeof Symbol && (a[Symbol.iterator] = function() {
            return this
        }), a;

        function c(c) {
            return function(u) {
                return function(c) {
                    if (n) throw new TypeError('Generator is already executing.');
                    for (; a && (a = 0, c[0] && (o = 0)), o;) try {
                        if (n = 1, r && (i = 2 & c[0] ? r.return : c[0] ? r.throw || ((i = r.return) && i.call(r), 0) : r.next) && !(i = i.call(r, c[1])).done) return i;
                        switch (r = 0, i && (c = [2 & c[0], i.value]), c[0]) {
                            case 0:
                            case 1:
                                i = c;
                                break;
                            case 4:
                                return o.label++, {
                                    value: c[1],
                                    done: !1
                                };
                            case 5:
                                o.label++, r = c[1], c = [0];
                                continue;
                            case 7:
                                c = o.ops.pop(), o.trys.pop();
                                continue;
                            default:
                                if (!(i = o.trys, (i = i.length > 0 && i[i.length - 1]) || 6 !== c[0] && 2 !== c[0])) {
                                    o = 0;
                                    continue
                                }
                                if (3 === c[0] && (!i || c[1] > i[0] && c[1] < i[3])) {
                                    o.label = c[1];
                                    break
                                }
                                if (6 === c[0] && o.label < i[1]) {
                                    o.label = i[1], i = c;
                                    break
                                }
                                if (i && o.label < i[2]) {
                                    o.label = i[2], o.ops.push(c);
                                    break
                                }
                                i[2] && o.ops.pop(), o.trys.pop();
                                continue
                        }
                        c = t.call(e, o)
                    } catch (e) {
                        c = [6, e], r = 0
                    } finally {
                        n = i = 0
                    }
                    if (5 & c[0]) throw c[1];
                    return {
                        value: c[0] ? c[1] : void 0,
                        done: !0
                    }
                }([c, u])
            }
        }
    }

    function a(e, t, n) {
        if (n || 2 === arguments.length)
            for (var r, i = 0, a = t.length; i < a; i++) !r && i in t || (r || (r = Array.prototype.slice.call(t, 0, i)), r[i] = t[i]);
        return e.concat(r || Array.prototype.slice.call(t))
    }
    const o = 'attn-waitlist-trigger-btn',
        c = 'attn-waitlist-trigger',
        u = 'attn-waitlist-eligibility',
        s = 'data-bis-opt-ins';

    function d() {
        return document.getElementById(o)
    }

    function l(e, t) {
        const n = d() ? ? function() {
                const e = document.createElement('button');
                return e.id = o, e.type = 'button', e
            }(),
            {
                text: r,
                classList: i,
                alignment: a,
                enrolledText: c
            } = e.settings;
        n.innerText = r, n.setAttribute('data-enabled-text', r), n.setAttribute('data-disabled-text', c), n.setAttribute('data-signup-complete', `${t}`), n.classList.add(...i.split(','));
        const u = f();
        return u && (u.style.textAlign = a), n
    }

    function v(e) {
        const t = e.getAttribute('data-disabled-text');
        t && (e.disabled = !0, e.innerText = t)
    }

    function f() {
        return document.getElementById(c)
    }

    function p() {
        return document.getElementById(u)
    }

    function g({
        productId: e,
        variantId: t
    }) {
        return `${e}:${t}`
    }

    function m() {
        const e = f();
        return e ? e.getAttribute(s) ? .split(',') ? ? [] : []
    }
    const y = 'attn-inline-price-trigger-btn',
        h = 'attn-inline-price-trigger';

    function _() {
        return document.getElementById(y)
    }

    function E(e) {
        const t = _() ? ? function() {
                const e = document.createElement('button');
                return e.id = y, e.type = 'button', e
            }(),
            {
                beforeOfferText: n,
                offer: r,
                afterOfferText: i,
                classList: a,
                alignment: o
            } = e.settings,
            c = C();
        c && (c.style.textAlign = o);
        const u = c ? .getAttribute('data-product-price'),
            s = [n, u ? function(e, t) {
                const n = t.replace(/\W/g, '');
                if (t.includes('%')) {
                    const t = (e * (1 - Number(n) / 100)).toFixed(2);
                    return t.endsWith('00') ? ['$', Math.round(Number(t))].join('') : ['$', t].join('')
                }
                return t.includes('$') ? ['$', e - Number(n)].join('') : t
            }(Number(u), r) : r, i].join(' ');
        return t.innerText = s, t.setAttribute('data-enabled-text', s), t.classList.add(...a.split(',')), t
    }

    function C() {
        return document.getElementById(h)
    }

    function I(e) {
        e.removeAttribute('data-product-price'), e.style.display = 'none'
    }
    var w = (e => (e.TagCoreLoaded = 'attn.tag-core.loaded', e.TagCreativesLoaded = 'attn.tag-creatives.loaded', e.FetchCreativesStart = 'attn.fetch-creatives.start', e.FetchCreativesEnd = 'attn.fetch-creatives.end', e))(w || {});

    function b(e) {
        return e && e.__esModule && Object.prototype.hasOwnProperty.call(e, 'default') ? e.default : e
    }
    var T, A = {
        exports: {}
    };
    T = function() {
        function e() {
            for (var e = 0, t = {}; e < arguments.length; e++) {
                var n = arguments[e];
                for (var r in n) t[r] = n[r]
            }
            return t
        }

        function t(e) {
            return e.replace(/(%[0-9A-Z]{2})+/g, decodeURIComponent)
        }
        return function n(r) {
            function i() {}

            function a(t, n, a) {
                if ('undefined' != typeof document) {
                    'number' == typeof(a = e({
                        path: '/'
                    }, i.defaults, a)).expires && (a.expires = new Date(1 * new Date + 864e5 * a.expires)), a.expires = a.expires ? a.expires.toUTCString() : '';
                    try {
                        var o = JSON.stringify(n);
                        /^[\{\[]/.test(o) && (n = o)
                    } catch (e) {}
                    n = r.write ? r.write(n, t) : encodeURIComponent(String(n)).replace(/%(23|24|26|2B|3A|3C|3E|3D|2F|3F|40|5B|5D|5E|60|7B|7D|7C)/g, decodeURIComponent), t = encodeURIComponent(String(t)).replace(/%(23|24|26|2B|5E|60|7C)/g, decodeURIComponent).replace(/[\(\)]/g, escape);
                    var c = '';
                    for (var u in a) a[u] && (c += '; ' + u, !0 !== a[u] && (c += '=' + a[u].split(';')[0]));
                    return document.cookie = t + '=' + n + c
                }
            }

            function o(e, n) {
                if ('undefined' != typeof document) {
                    for (var i = {}, a = document.cookie ? document.cookie.split('; ') : [], o = 0; o < a.length; o++) {
                        var c = a[o].split('='),
                            u = c.slice(1).join('=');
                        n || '"' !== u.charAt(0) || (u = u.slice(1, -1));
                        try {
                            var s = t(c[0]);
                            if (u = (r.read || r)(u, s) || t(u), n) try {
                                u = JSON.parse(u)
                            } catch (e) {}
                            if (i[s] = u, e === s) break
                        } catch (e) {}
                    }
                    return e ? i[e] : i
                }
            }
            return i.set = a, i.get = function(e) {
                return o(e, !1)
            }, i.getJSON = function(e) {
                return o(e, !0)
            }, i.remove = function(t, n) {
                a(t, '', e(n, {
                    expires: -1
                }))
            }, i.defaults = {}, i.withConverter = n, i
        }((function() {}))
    }, A.exports = T();
    const S = b(A.exports);

    function O(e) {
        return S.get(e)
    }
    const L = window.__attentive_cfg ? .cxd || null,
        N = 390;

    function P(e, t, n) {
        const r = {
            secure: window.location.protocol.includes('https'),
            ...n,
            expires: k(n ? .expires)
        };
        return L && window.location.host.includes(L.replace(/^\./, '')) && (r.domain = L), S.set(e, t, r)
    }

    function R(e, t) {
        S.remove(e, t)
    }

    function k(e) {
        if (!e) return N;
        if (e instanceof Date) {
            return e < new Date(Date.now() + 864e5 * N) ? e : N
        }
        return Math.min(N, e)
    }
    const D = !1,
        x = '4.39.19',
        B = 'https://events.attentivemobile.com/e',
        M = 'ad31a04c9f',
        U = D ? 'An error occurred during dispatch' : '0',
        F = D ? 'The performance api required for tracking is missing on this device' : '1',
        H = D ? 'Could not write to storage' : '2',
        V = D ? 'Could not read from storage' : '3',
        j = D ? 'An error occurred in the analytic collection loop' : '6',
        G = D ? 'Failed to decode configuration' : '8',
        q = D ? 'Failed to load shopify cart' : '9',
        Y = D ? 'WooCommerce Cart Trigger Error' : '10',
        $ = D ? 'Magento Product View Trigger Error' : '11',
        W = D ? 'Magento Purchase Trigger Error' : '12',
        J = 'fb',
        K = 'ga',
        X = 't0',
        z = 'np',
        Z = 'spp',
        Q = 'wct',
        ee = 'mgt',
        te = 'gtag',
        ne = 'ds',
        re = 'mv',
        ie = 'vv',
        ae = 'x',
        oe = 'i',
        ce = 'r',
        ue = 'm',
        se = 'trg',
        de = 'enr',
        le = 'trn',
        ve = 'id',
        fe = 'pth',
        pe = 'pt',
        ge = 'es',
        me = 'mp',
        ye = 'ev',
        he = 'ep',
        _e = 'e2p',
        Ee = 'a',
        Ce = 'mu',
        Ie = 'mt',
        we = 'rgx',
        be = 'tms',
        Te = 'csk',
        Ae = 's',
        Se = 'ws',
        Oe = 'atr',
        Le = 'prop',
        Ne = 'ro',
        Pe = 'cnd',
        Re = 'qp',
        ke = 'vidc',
        De = 'esit',
        xe = 'cs',
        Be = 'c',
        Me = 'ceid',
        Ue = 'm',
        Fe = 'cb',
        He = 't',
        Ve = 'lt',
        je = 'pd',
        Ge = 'r',
        qe = 'v',
        Ye = 'u',
        $e = 'mfbc',
        We = 'mfbp',
        Je = 'meid',
        Ke = 'mcns',
        Xe = 'frid',
        ze = 'fvid',
        Ze = 'fcds',
        Qe = 'tag',
        et = 'tc',
        tt = 'ane',
        nt = 'evs',
        rt = 'idc',
        it = 'sbc',
        at = 'dae',
        ot = 'swpe',
        ct = 'bctu',
        ut = 'ses',
        st = '@_@',
        dt = 'vid',
        lt = 'ust',
        vt = 'tga',
        ft = 'pd',
        pt = 'snd',
        gt = 'cu',
        mt = 'c',
        yt = 'v',
        ht = 'd',
        _t = 'p',
        Et = 'e',
        Ct = 'o',
        It = 'oc',
        wt = 'pl',
        bt = 'idn',
        Tt = 'sa',
        At = ['Add to cart', 'Add to Bag', 'Buy Now', 'Add', '#addToCart', '#add-to-cart', '#AddToCart', 'Order Now', 'Buy it now', '.product__add-to-cart', '[name="add"]', '[data-label="Add to Cart"]', '[data-add-to-cart]', '#addToCartBtn', '[value="Add to Bag"]', '[value="Add to Cart"]', '[value="Add to Order"]'],
        St = 'emc';
    var Ot = (e => (e.Click = 'click', e.DataLayer = 'datalayer', e.OrderConfirmedIdentifiers = 'order confirmed identifiers', e))(Ot || {}),
        Lt = (e => (e.ADD_TO_CART_TRIGGER = 'AddToCartTrigger', e.DATA_LAYER_FOR_ADD_TO_CART = 'DataLayerForAddToCart', e.DATA_LAYER_FOR_ALL_EVENTS = 'DataLayerForAllEvents', e.DATA_LAYER_FOR_PRODUCT_VIEW = 'DataLayerForProductView', e.DATA_LAYER_FOR_PURCHASE = 'DataLayerForPurchase', e))(Lt || {});
    Ot.Click, Lt.ADD_TO_CART_TRIGGER, Ot.DataLayer, Lt.DATA_LAYER_FOR_ADD_TO_CART, Lt.DATA_LAYER_FOR_ALL_EVENTS, Lt.DATA_LAYER_FOR_PRODUCT_VIEW, Lt.DATA_LAYER_FOR_PURCHASE, Ot.OrderConfirmedIdentifiers;
    const Nt = 'co',
        Pt = 'uo',
        Rt = 'ma',
        kt = 'in';

    function Dt(e) {
        return null != e && 'object' == typeof e && null != e.val
    }

    function xt(e) {
        return Object.entries(e).reduce(((e, [t, n]) => (Dt(n) ? Dt(n) && !n[kt] && e.push(`${t}=${encodeURIComponent(n.val)}`) : 'object' == typeof n && null != n ? e.push(`${t}=${encodeURIComponent(JSON.stringify(n))}`) : 'string' != typeof n && 'number' != typeof n && 'boolean' != typeof n || e.push(`${t}=${encodeURIComponent(n)}`), e)), []).join('&')
    }
    const Bt = {};

    function Mt(e, t) {
        const n = {
            errorCode: e,
            message: t.message,
            name: t.name,
            errorStack: t.stack
        };
        if (Bt[e] && Bt[e].message === t.message && Bt[e].name === t.name) return null;
        Bt[e] = n;
        const r = xt({ ...n,
                [He]: Et,
                [qe]: x
            }),
            i = `${B}?${r}`,
            a = new Image(1, 1);
        return a.src = i, a
    }
    const Ut = 0,
        Ft = 1,
        Ht = 2,
        Vt = 6,
        jt = 7,
        Gt = 8,
        qt = 9,
        Yt = 'edgetag_user_id';

    function $t(e = []) {
        const t = [{
                vendor: Ut,
                id: window.ShopifyAnalytics ? .meta ? .page ? .customerId ? ? null
            }, {
                vendor: Ft,
                id: new URLSearchParams(window.location.search).get('utm_klaviyo_id') ? ? null
            }, {
                vendor: Ht,
                id: O('__attentive_client_user_id') ? ? null
            }, {
                vendor: jt,
                id: window.triggermail ? .persist ? .read_prop('distinct_id') ? ? O('__attentive_bluecore_id') ? ? null
            }, {
                vendor: Gt,
                id: O('_shopify_y') ? ? null
            }, {
                vendor: qt,
                id: O('__cq_uuid') ? ? null
            }],
            n = O('__attentive_custom_ids');
        if (n) {
            JSON.parse(n).forEach((e => {
                t.push({
                    vendor: Vt,
                    name: e.name,
                    id: e.value
                })
            }))
        }
        const r = {
            vendor: Vt,
            id: window.edgetag ? .('getUserId') ? ? null,
            name: Yt
        };
        r.id && t.push(r);
        const i = t.filter((t => t.id && e.includes(t.vendor)));
        return i.length ? i : null
    }
    const Wt = /[\s|()-]/g,
        Jt = /^\(?(\d{3})\)?[- ]?(\d{3})[- ]?(\d{4})$/,
        Kt = /^(((\+44\s?\d{4}|\(?0\d{4}\)?)\s?\d{3}\s?\d{3})|((\+44\s?\d{3}|\(?0\d{3}\)?)\s?\d{3}\s?\d{4})|((\+44\s?\d{2}|\(?0\d{2}\)?)\s?\d{4}\s?\d{4}))(\s?#(\d{4}|\d{3}))?$/,
        Xt = /(?:[a-z0-9!#$%&'*+/=?^_`{|}~-]+(?:\.[a-z0-9!#$%&'*+/=?^_`{|}~-]+)*)@(?:(?:[a-z0-9](?:[a-z0-9-]*[a-z0-9])?\.)+[a-z0-9](?:[a-z0-9-]*[a-z0-9])?|\[(?:(?:25[0-5]|2[0-4][0-9]|[01]?[0-9][0-9]?)\.){3}(?:25[0-5]|2[0-4][0-9]|[01]?[0-9][0-9]?|[a-z0-9-]*[a-z0-9]:+))/,
        zt = /[^.\d]/g,
        Zt = /\.(.*?\d*)/g,
        Qt = /^[.,]|[.,]$|\s/g,
        en = (e, t = !1) => {
            if ('string' != typeof e) return e;
            const n = e.replace(Wt, ''),
                r = Jt.test(n),
                i = Kt.test(n);
            return r ? n : i ? function(e) {
                return '0' === e[0] ? e.substring(1) : '+44' === e.substring(0, 3) ? e.substring(3) : e
            }(n) : t ? null : e.replace(zt, '')
        },
        tn = e => {
            const t = nn(e);
            return Xt.test(t) ? e : null
        },
        nn = e => e.replace(Qt, ''),
        rn = e => {
            if ('string' != typeof e) return e;
            let t = e.replace(zt, '');
            const n = t.indexOf('.');
            return n >= 0 && (t = t.substring(0, n + 3)), t
        },
        an = e => 'string' != typeof e ? e : e.replace(zt, '').replace(Zt, ''),
        on = e => 'string' != typeof e ? e : e.replace('\n', '').trim(),
        cn = e => {
            if ('string' != typeof e) return e;
            const t = e.indexOf('#');
            return (-1 === t ? e : e.substring(t + 1)).trim()
        },
        un = e => {
            try {
                return new URL(function(e) {
                    /(^\/\/).*/.test(e) && (e = 'https:' + e);
                    return e
                }(e)).href
            } catch {
                return e
            }
        };

    function sn(e) {
        return (t, n, r) => {
            const i = e[n.type];
            'function' == typeof i && i(t, n, r)
        }
    }
    const dn = function() {
            const e = '_-_';
            try {
                return sessionStorage.setItem(e, e), sessionStorage.removeItem(e), !0
            } catch (e) {
                return !1
            }
        }(),
        ln = function() {
            const e = '_-_';
            try {
                return localStorage.setItem(e, e), localStorage.removeItem(e), !0
            } catch (e) {
                return !1
            }
        }();

    function vn() {
        let e = Date.now() + performance.now();
        return 'xxxxxxxxxxxx4xxxyxxxxxxxxxxxxxxx'.replace(/[xy]/g, (t => {
            const n = (e + 16 * Math.random()) % 16 | 0;
            return e = Math.floor(e / 16), ('x' === t ? n : 3 & n | 8).toString(16)
        }))
    }

    function fn(e) {
        return /^[0-9a-fA-F]{32}$/.test(e)
    }

    function pn(e) {
        return function(t, n) {
            return {
                type: e,
                data: t,
                meta: n
            }
        }
    }
    const gn = pn(st),
        mn = pn(vt),
        yn = pn(dt),
        hn = pn(lt),
        _n = pn('uc'),
        En = pn('cd'),
        Cn = pn(ft),
        In = pn(pt),
        wn = pn('imp');

    function bn(e) {
        var t, n;
        return e && {
            name: e.name,
            category: e.category,
            image: e.productImage,
            price: null === (t = e.price) || void 0 === t ? void 0 : t.value,
            currency: null === (n = e.price) || void 0 === n ? void 0 : n.currency,
            quantity: e.quantity ? String(e.quantity) : '',
            productId: e.productId,
            subProductId: e.productVariantId
        }
    }

    function Tn(e) {
        return e && {
            items: e.map(bn)
        }
    }

    function An(e) {
        return e && {
            phone: e.phone,
            email: e.email
        }
    }

    function Sn(e) {
        return e && {
            cartId: e.cartId,
            cartCoupon: e.cartCoupon
        }
    }
    var On = '_attn_';

    function Ln() {
        var e;
        try {
            var n = null;
            if (dn) {
                var r = sessionStorage.getItem(On);
                n = r ? JSON.parse(r) : null
            }
            var i = function(e) {
                    if (!e) throw new Error(V);
                    try {
                        return JSON.parse(atob(e))
                    } catch (t) {
                        try {
                            return JSON.parse(e)
                        } catch (e) {
                            throw new Error(V)
                        }
                    }
                }(O(On)),
                a = i ? Object.keys(i).reduce((function(e, t) {
                    var n = JSON.parse(i[t]);
                    return e[t] = function(e) {
                        if (!e) return !0;
                        const t = 24 * e[Rt] * 60 * 60 * 1e3;
                        return e[Nt] + t < Date.now()
                    }(n) ? null : n, e
                }), {}) : null;
            e = t(t({}, n), a)
        } catch (e) {
            throw new Error(V)
        }
        return e
    }

    function Nn(e) {
        try {
            dn && sessionStorage.setItem(On, JSON.stringify(e));
            var t = Object.keys(e).reduce((function(t, n) {
                return Dt(e[n]) && (t[n] = JSON.stringify(e[n])), t
            }), {});
            return P(On, btoa(JSON.stringify(t)), {
                sameSite: 'strict',
                expires: 3650
            }), e
        } catch (e) {
            throw new Error(H)
        }
    }

    function Pn(e, n) {
        var r, i, a, o, c, u, s;

        function d(n, r) {
            var i, a, o, c = Date.now(),
                u = e[n];
            return (i = {})[n] = t(((a = {})[Nt] = Dt(u) ? u[Nt] : c, a[Pt] = c, a[Rt] = 3650, a[kt] = !1, a), r), o = i, t(t({}, e), o)
        }
        switch (n.type) {
            case st:
                try {
                    var l = function(e) {
                        var n, r, i, a = Ln();
                        return t(t(((n = {})[yt] = 0, n[je] = '', n[Ye] = null, n[tt] = null, n), a), ((r = {})[Be] = e.data.clientConfiguration.company, r[Me] = e.data.clientConfiguration.ceid, r[ot] = Rn(e.data.clientConfiguration), r[ct] = null !== (i = e.data.clientConfiguration[ct]) && void 0 !== i ? i : '', r[Ve] = (new Date).getTime(), r[ut] = null, r))
                    }(n);
                    return (null === (c = window.__attentive_cfg) || void 0 === c ? void 0 : c.cxd) && function(e) {
                        P('__attentive_domain', e.data.clientConfiguration.company, {
                            expires: 7
                        }), P('__attentive_ceid', e.data.clientConfiguration.ceid, {
                            expires: 7
                        })
                    }(n), Nn(l)
                } catch (e) {
                    return dn && sessionStorage.removeItem(On), R(On), Nn(((r = {})[yt] = 0, r[je] = window.location.href, r[Ye] = null, r[tt] = null, r[Be] = n.data.clientConfiguration.company, r[Me] = n.data.clientConfiguration.ceid, r[ot] = Rn(n.data.clientConfiguration), r[ct] = null !== (u = n.data.clientConfiguration[ct]) && void 0 !== u ? u : '', r[Ve] = (new Date).getTime(), r[ut] = null, r))
                }
            case dt:
                return Nn(d(Ye, ((i = {
                    val: n.data.id
                })[Rt] = n.data.maxAge, i)));
            case lt:
                return Nn(t(t({}, e), n.data));
            case vt:
                return Nn(d(tt, ((a = {
                    val: n.data.on || !1
                })[Rt] = n.data.maxAge || 365, a[kt] = !0, a)));
            case pt:
                return window.location.href === e[je] && (null === (s = n.meta) || void 0 === s ? void 0 : s.dataType) !== yt ? e : Nn(t(t({}, e), ((o = {})[je] = window.location.href, o[yt] = 'number' == typeof e[yt] ? e[yt] + 1 : 1, o)));
            default:
                return e
        }
    }

    function Rn(e) {
        return null == e[ot] ? '' : Object.entries(e[ot]).reduce((function(e, t) {
            var n = t[0];
            return t[1] ? ''.concat(e).concat(n, ',') : e
        }), '').slice(0, -1)
    }
    var kn, Dn, xn = !1,
        Bn = !1;

    function Mn(e) {
        var n = e.clientConfiguration,
            r = e.services,
            i = void 0 === r ? [] : r;
        if (xn) return Dn;

        function a(e) {
            if (e && e.type)
                if (Bn) queueMicrotask((function() {
                    return a(e)
                }));
                else {
                    Bn = !0;
                    try {
                        var t = {
                            dispatch: a
                        };
                        kn = Pn(kn, e);
                        for (var n = 0, r = i; n < r.length; n++) {
                            (0, r[n])(kn, e, t)
                        }
                    } catch (e) {
                        Mt(U, e)
                    } finally {
                        Bn = !1
                    }
                }
        }
        return a(gn({
            clientConfiguration: n
        })), Dn = function(e) {
            function n(n) {
                return function(r) {
                    var i, a, o = {};
                    switch (n) {
                        case ht:
                            o = r ? t(t({}, Tn(r.items)), An(r.user)) : null;
                            break;
                        case mt:
                            o = r ? t(t(t({}, Tn(r.items)), Sn(r.cart)), An(r.user)) : null;
                            break;
                        case _t:
                            o = r ? t(t(t(t({}, Tn(r.items)), Sn(r.cart)), (a = r.order) && {
                                orderId: a.orderId
                            }), An(r.user)) : null;
                            break;
                        case gt:
                            o = r ? t(t(t({}, Sn(r.cart)), {
                                products: null === (i = Tn(r.items)) || void 0 === i ? void 0 : i.items
                            }), An(r.user)) : null
                    }
                    e(Cn(o || {}, {
                        source: ue,
                        dataType: n
                    }))
                }
            }
            var r, i = {
                version: x,
                analytics: {
                    enable: function(t) {
                        return e(mn({
                            on: !0,
                            maxAge: (null == t ? void 0 : t.expires) || 365
                        }))
                    },
                    disable: function() {
                        return e(mn({
                            on: !1
                        }))
                    },
                    track: function(e, t) {
                        var n = {
                            page_view: i.analytics.pageView,
                            product_view: i.analytics.productView,
                            add_to_cart: i.analytics.addToCart,
                            purchase: i.analytics.purchase,
                            identify: i.analytics.identify
                        };
                        n[e] && n[e](t)
                    },
                    addToCart: n(mt),
                    pageView: n(yt),
                    productView: n(ht),
                    purchase: n(_t),
                    identify: (r = bt, function(t) {
                        var n = {
                            phone: null == t ? void 0 : t.phone,
                            email: null == t ? void 0 : t.email
                        };
                        (null == t ? void 0 : t.externalIdentifiers) && P('__attentive_custom_ids', JSON.stringify(null == t ? void 0 : t.externalIdentifiers)), e(Cn(n || {}, {
                            source: ue,
                            dataType: r
                        }))
                    }),
                    cartUpdated: n(gt)
                }
            };
            return window.dataLayer && window.__attentive_cfg && '1' === window.__attentive_cfg.gtm && window.dataLayer.push({
                event: 'attentive_loaded'
            }), i
        }(a), xn = !0, Dn
    }

    function Un(e) {
        var t;
        return (null === (t = null == e ? void 0 : e.meta) || void 0 === t ? void 0 : t.source) === ue
    }
    var Fn = 'timeout',
        Hn = 'cancelled',
        Vn = 3e5;

    function jn(e, t, n, r) {
        if (void 0 === t && (t = 1e4), void 0 === n && (n = 250), void 0 === r && (r = !0), D && t > Vn) throw new Error('timeout is too large, max allowed value is '.concat(Vn));
        var i, a = Number(new Date) + t,
            o = !1,
            c = n,
            u = new Promise((function t(u, s) {
                if (o) return s({
                    reason: Hn
                });
                var d = e();
                d ? u({
                    result: d
                }) : Number(new Date) < a ? (i && clearTimeout(i), i = setTimeout(t, c, u, s), r && (c = Math.min(c + n / 4, 1e3))) : s({
                    reason: Fn
                })
            }));
        return u.cancel = function() {
            o || (o = !0)
        }, u
    }
    var Gn = 'b',
        qn = 'a',
        Yn = 'e',
        $n = 'u';

    function Wn(e) {
        return r(this, void 0, void 0, (function() {
            var t;
            return i(this, (function(n) {
                return t = [], [2, new Promise((function(n) {
                    var r = function(e) {
                        switch (e) {
                            case Yn:
                                return n('error');
                            case Gn:
                                return t.includes(XMLHttpRequest.HEADERS_RECEIVED) ? n('adblocked') : n('browser');
                            case qn:
                                return n('none');
                            case $n:
                                return n('unknown')
                        }
                    };
                    try {
                        var i = new XMLHttpRequest;
                        i.onreadystatechange = function() {
                            if (t.push(i.readyState), i.readyState === XMLHttpRequest.DONE) {
                                if (0 === i.status || i.responseURL !== e) return r(Gn);
                                200 === i.status && r(qn), r($n)
                            }
                        }, i.open('HEAD', e, !0), i.send(null)
                    } catch (e) {
                        r(Yn)
                    }
                }))]
            }))
        }))
    }
    var Jn, Kn = '_attn_bopd_';
    var Xn = function(e) {
        return '[object Object]' === Object.prototype.toString.call(e)
    };

    function zn(e, t) {
        if (void 0 === t && (t = []), 'function' == typeof e) return null;
        if (Xn(e)) {
            if (t.indexOf(e) >= 0) return null;
            t.push(e);
            for (var n = {}, r = 0, i = Object.entries(e); r < i.length; r++) {
                var a = i[r],
                    o = a[0],
                    c = a[1];
                n[o] = zn(c, t)
            }
            return n
        }
        return Array.isArray(e) ? e.map((function(e) {
            return zn(e, t)
        })) : e
    }
    var Zn = function(e, t) {
            var n;
            return (null === (n = t.querySelector(e)) || void 0 === n ? void 0 : n.textContent) || null
        },
        Qn = function(e, t, n) {
            var r;
            return e || n instanceof Document ? e && (null === (r = n.querySelector(e)) || void 0 === r ? void 0 : r.getAttribute(t)) || null : n.getAttribute(t) || null
        },
        er = function(e, t, n) {
            var r = n.querySelector(e);
            if (r && t in r) {
                var i = r[t];
                if (null != i) return ''.concat(i)
            }
            return null
        };

    function tr(e, t) {
        return Object.entries(e).reduce((function(e, n) {
            var r = n[0],
                i = n[1];
            return e[r] = function(e, t) {
                var n = null;
                if ('string' == typeof(n = 'string' == typeof e[Le] ? er(e[Ae], e[Le], t) : 'string' == typeof e[Oe] ? Qn(e[Ae], e[Oe], t) : Zn(e[Ae], t))) {
                    n = n.replace(/\n\t/g, '').trim();
                    var r = new RegExp(e[we] || '.*'),
                        i = n.match(r);
                    n = i ? i[0] : n
                }
                return n
            }(i, t), e
        }), {})
    }
    var nr = {
        prop: function(e, t) {
            return t[e.target]
        },
        idx: function(e, t) {
            if (!(e.key < 0)) return e.target && t[e.target] ? t[e.target][Number(e.key)] : t[Number(e.key)];
            if (e.target) return t[e.target][t[e.target].length + e.key];
            if (Array.isArray(t)) return t[t.length + e.key]
        },
        exists: function(e, t) {
            if (Array.isArray(t[e.target])) return t[e.target].find((function(t) {
                return null != (null == t ? void 0 : t[e.key]) || Array.isArray(t) && (null == t ? void 0 : t.includes(e.key))
            }))
        },
        eq: function(e, t) {
            return Array.isArray(t[e.target]) ? t[e.target].find((function(t) {
                return t[e.key] === e.val
            })) : 'object' == typeof t[e.target] && t[e.target][e.key] === e.val ? t[e.target] : void 0
        }
    };

    function rr(e, t) {
        var n = function(e) {
            for (var t = [], n = e.split(''), r = '.', i = '<', a = '>', o = !1, c = '', u = 0, s = n; u < s.length; u++) {
                var d = s[u];
                d !== i ? d !== a ? d !== r || o ? null != d && (c += d) : (t.push(c), c = '') : o = !1 : o = !0
            }
            return t.push(c), t
        }(e);
        return function(e) {
            var r = t || null;
            return 'object' != typeof e ? r : n.reduce((function(e, t) {
                if (e) {
                    var n = (a = /\[.*\]/.test(i = t), o = i.match(/\[(.*)\]/), c = i.match(/\["(.*)"\]/), u = i.match(/\[(-?\d*)\]/), s = i.match(/\[(\w*)="(.*)"\]/), d = a ? i.slice(0, i.indexOf('[')) : i, null != u && u[1] ? {
                        type: 'idx',
                        target: d,
                        key: Number(u[1])
                    } : s && s[1] && s[2] ? {
                        type: 'eq',
                        target: d,
                        key: s[1],
                        val: s[2]
                    } : c ? {
                        type: 'exists',
                        target: d,
                        key: c[1]
                    } : a && Array.isArray(o) ? {
                        type: 'exists',
                        target: d,
                        key: o[1]
                    } : {
                        type: 'prop',
                        target: d
                    });
                    return nr[n.type](n, e) || r
                }
                var i, a, o, c, u, s, d;
                return r
            }), e)
        }
    }
    var ir = function(e, t) {
            var n;
            return null === (n = t.querySelector(e)) || void 0 === n ? void 0 : n.textContent
        },
        ar = function(e, t, n) {
            var r;
            return e || n instanceof Document ? e ? null === (r = n.querySelector(e)) || void 0 === r ? void 0 : r.getAttribute(t) : void 0 : n.getAttribute(t)
        },
        or = function(e, t, n) {
            var r = n.querySelector(e);
            if (r && t in r) {
                var i = r[t];
                if (null != i) return ''.concat(i)
            }
        };

    function cr(e, t) {
        for (var n = {}, r = 0, i = Object.keys(e); r < i.length; r++) {
            var a = i[r],
                o = e[a];
            n[a] = ur(o, t)
        }
        return n
    }

    function ur(e, t) {
        var n = null;
        if ('string' == typeof(n = 'string' == typeof e[Le] ? or(e[Ae], e[Le], t) : 'string' == typeof e[Oe] ? ar(e[Ae], e[Oe], t) : ir(e[Ae], t))) {
            n = n.replace(/\n\t/g, '').trim();
            var r = new RegExp(e[we] || '.*'),
                i = n.match(r);
            n = i ? i[0] : n
        }
        return n
    }
    var sr = [];
    var dr = 'attntv_mstore_';

    function lr(e) {
        var t = O(dr + e);
        return t ? t.split(':')[0] : null
    }

    function vr(e) {
        return function(t) {
            return document.querySelector('meta['.concat(e, '="').concat(t, '"]'))
        }
    }

    function fr(e) {
        if (!e.includes('?')) return {};
        var t = e.slice(e.indexOf('?') + 1);
        return t ? t.split('&').reduce((function(e, t) {
            var n = t.split('='),
                r = n[0],
                i = n[1];
            return e[r] = i, e
        }), {}) : {}
    }

    function pr(e) {
        return e && Number.isInteger(e) ? String((e / 100).toFixed(2)) : null
    }
    var gr = function(e) {
        var n, r, i, a;
        e || (e = function() {
            var e, t, n;
            if (hr()) {
                var r = null !== (t = null === (e = window.ShopifyAnalytics) || void 0 === e ? void 0 : e.meta) && void 0 !== t ? t : {},
                    i = r.selectedVariantId,
                    a = r.product,
                    o = r.currency,
                    c = void 0;
                if (i || (i = function(e, t) {
                        if ('string' == typeof t) return fr(e)[t] || null;
                        var n = fr(e),
                            r = Object.keys(n).find((function(e) {
                                return t.test(e)
                            }));
                        return r && n[r] ? n[r] : null
                    }(null === (n = null === window || void 0 === window ? void 0 : window.location) || void 0 === n ? void 0 : n.href, 'variant') || ''), a) {
                    var u = a.id,
                        s = a.variants,
                        d = a.type;
                    return s && 'string' == typeof i && i.length > 0 ? c = s.find((function(e) {
                        return String(e.id) === i
                    })) : s && s.length > 0 && (c = s[0]), {
                        id: u,
                        type: d,
                        selectedVariantId: i,
                        selectedVariant: c || void 0,
                        currency: o
                    }
                }
            }
            return null
        }());
        var o = function() {
                var e;
                if (function() {
                        var e;
                        return Boolean(null === (e = window.Shopify) || void 0 === e ? void 0 : e.checkout)
                    }()) return null === (e = window.Shopify) || void 0 === e ? void 0 : e.checkout
            }(),
            c = {};
        if (null != e && (c = {
                currency: e.currency,
                category: e.type,
                sku: String(e.id),
                subProductId: e.selectedVariantId
            }, null != e.selectedVariant)) {
            var u = e.selectedVariant,
                s = u.id,
                d = u.price,
                l = u.name;
            c = t(t({}, c), {
                name: l,
                price: pr(d),
                subProductId: String(s)
            })
        }
        return null != o && (c = t({
            uid: String(o.customer_id),
            orderId: String(o.order_id),
            cartTotal: o.total_price,
            email: o.email,
            phone: null === (n = o.billing_address) || void 0 === n ? void 0 : n.phone,
            cartCoupon: null === (r = null == o ? void 0 : o.discount) || void 0 === r ? void 0 : r.code,
            cartDiscount: null === (i = null == o ? void 0 : o.discount) || void 0 === i ? void 0 : i.amount,
            cartCurrency: null == o ? void 0 : o.currency,
            items: null === (a = o.line_items) || void 0 === a ? void 0 : a.map((function(e) {
                return {
                    name: e.title,
                    price: e.price,
                    quantity: String(e.quantity),
                    image: e.image_url,
                    sku: e.product_id,
                    subProductId: e.variant_id
                }
            }))
        }, c)), c
    };
    var mr = function() {
            var e, t;
            if (hr()) {
                var n = (null !== (t = null === (e = window.ShopifyAnalytics) || void 0 === e ? void 0 : e.meta) && void 0 !== t ? t : {}).product;
                if (n) {
                    var r = n.variants;
                    if (r && r.length > 0) return r
                }
            }
            return []
        },
        yr = function(e) {
            return e.find((function(e) {
                return !!e
            }))
        };

    function hr() {
        return Boolean(rr('ShopifyAnalytics.meta.product')(window))
    }
    var _r;

    function Er() {
        var e, t, n, r = Boolean(rr('attn_product')(window)) ? window.attn_product : void 0,
            i = function() {
                if (Boolean(rr('attn_order')(window))) return window.attn_order
            }(),
            a = {};
        return null != r && (a = {
            currency: null === (e = r.price) || void 0 === e ? void 0 : e.currency,
            category: r.category,
            sku: r.productId,
            subProductId: r.productVariantId,
            name: r.name,
            image: r.productImage,
            quantity: r.quantity,
            price: null === (t = r.price) || void 0 === t ? void 0 : t.value
        }), null != i && (a = {
            cartTotal: i.orderTotal,
            email: i.email,
            phone: i.phone,
            orderId: i.orderId,
            items: null === (n = i.products) || void 0 === n ? void 0 : n.map((function(e) {
                return {
                    sku: e.id,
                    image: e.image,
                    name: e.name,
                    subProductId: e.variantId,
                    price: e.price,
                    quantity: e.quantity
                }
            }))
        }), a
    }
    var Cr = ((_r = {}).jld = function(e) {
        var t = e[me],
            n = document.querySelectorAll('script[type="application/ld+json"]');
        if (n.length > 0) {
            var r = {};
            return Array.from(n).some((function(e) {
                var t;
                try {
                    var n = JSON.parse(e.innerHTML);
                    if (n && 'product' === (null === (t = n['@type']) || void 0 === t ? void 0 : t.toLowerCase())) return r = n, !0
                } catch (e) {}
                return !1
            })), Object.keys(t).reduce((function(e, n) {
                var i = t[n];
                if ('string' == typeof i) {
                    var a = r[i];
                    a && ('object' != typeof a ? e[n] = a : 'object' == typeof a && a[n] && (e[n] = a[n]))
                }
                return e
            }), {})
        }
        return {}
    }, _r.met = function(e) {
        for (var n = {}, r = Object.entries(t({}, e[me])), i = vr('property'), a = vr('name'), o = vr('itemprop'), c = 0, u = r; c < u.length; c++) {
            var s = u[c],
                d = s[0],
                l = s[1];
            if ('string' == typeof l) {
                var v = i(l) || a(l) || o(l);
                v && (n[d] = v.getAttribute('content'))
            }
        }
        return n
    }, _r.shp = function(e, t) {
        var n;
        return (null == e ? void 0 : e[ke]) && (n = function(e, t) {
            var n = [],
                r = mr();
            return null == e || e.forEach((function(e) {
                    var i = (0, Cr[e[pe]])(e, t),
                        a = function(e, t) {
                            return t.find((function(t) {
                                return String(t.id) === e
                            }))
                        }(null == i ? void 0 : i.subProductId, r);
                    a && n.push(a)
                })), n.push(r[0]),
                function(e) {
                    var t, n;
                    if (hr()) {
                        var r = null !== (n = null === (t = window.ShopifyAnalytics) || void 0 === t ? void 0 : t.meta) && void 0 !== n ? n : {},
                            i = r.product,
                            a = r.currency;
                        if (i) return {
                            id: i.id,
                            type: i.type,
                            selectedVariantId: ''.concat((null == e ? void 0 : e.id) || ''),
                            selectedVariant: e || void 0,
                            currency: a
                        }
                    }
                    return null
                }(yr(n))
        }(e[ke], t)), gr(n)
    }, _r.ltc = function() {
        return {
            email: lr('email'),
            phone: lr('phone'),
            cartCoupon: lr('cartCoupon')
        }
    }, _r.dsp = function(e, t) {
        var n, r = e[me],
            i = e.cs;
        if (null != i && e[Te]) {
            var a = document.querySelectorAll(i),
                o = Array.from(a).map((function(e) {
                    return cr(r, e)
                }));
            return (n = {})[e[Te] || ''] = o, n
        }
        return t && t.trigger && t.trigger[Ne] ? cr(r, t.trigger[Ne]) : cr(r, document)
    }, _r.wsp = function(e) {
        var t, n = e[me];
        return t = e[Ne] ? rr(e[Ne] || '')(window) : window, Object.entries(n).reduce((function(e, n) {
            var r = n[0],
                i = n[1];
            return e[r] = rr(i || '', null)(t), e
        }), {})
    }, _r.dls = function(e, t) {
        var n;
        if (!window.dataLayer || !Array.isArray(window.dataLayer)) return {};
        var r = {},
            i = ((n = {})[gt] = [], n[ht] = ['viewitem', 'viewcontent'], n[mt] = ['addtocart'], n[_t] = ['purchase'], n[It] = [], n.i = [], n[bt] = [], n);
        if ((null == t ? void 0 : t.dataType) && t.dataType in i) {
            var a = i[t.dataType],
                o = window.dataLayer.find((function(e) {
                    if (function(e) {
                            return 'object' == typeof e
                        }(e) && 'string' == typeof(null == e ? void 0 : e.event)) {
                        var t = e.event.toLowerCase().replace(/[^a-z]/gi, '');
                        return a.includes(t) && !sr.includes(e)
                    }
                    return !1
                }));
            o && (sr.push(o), r = 'object' == typeof(null == o ? void 0 : o.ecommerce) ? o.ecommerce : o)
        }
        return r
    }, _r.wce = Er, _r.cmps = function(e, t) {
        for (var n, r = {}, i = 0, a = Object.entries(e[me] || {}); i < a.length; i++) {
            var o = a[i],
                c = o[0],
                u = o[1];
            if (u)
                for (var s = 0, d = u; s < d.length; s++) {
                    var l = d[s],
                        v = null;
                    if ('dsp' === l[pe]) {
                        var f = document,
                            p = null === (n = null == t ? void 0 : t.trigger) || void 0 === n ? void 0 : n[Ne];
                        if ('string' == typeof p) {
                            var g = document.querySelector(p);
                            null != g && (f = null != g ? g : document)
                        } else p instanceof HTMLElement && (f = p);
                        v = ur(l, f)
                    } else 'wsp' === l[pe] ? v = rr(l[Se], null)(window) : 'qpsp' === l[pe] && (v = new URLSearchParams(location.search).get(l[Re]));
                    if (v) {
                        r[c] = v;
                        break
                    }
                }
        }
        return r
    }, _r.crt = function(e) {
        var t = e.pf,
            n = e.rs,
            r = e.ps,
            i = document.querySelector(n);
        return i ? function(e, t, n) {
            var r = n.querySelectorAll(t);
            return {
                items: Array.from(r).map((function(t) {
                    return tr(e, t)
                }))
            }
        }(t, r, i) : {}
    }, _r);
    var Ir = function(e, t) {
        var n = t && t[me] || {},
            r = a(a([], ['cartCoupon', 'cartDiscount', 'cartTotal', 'category', 'currency', 'email', 'image', 'items', 'name', 'orderId', 'phone', 'price', 'productId', 'quantity', 'sku', 'subProductId', 'uid'], !0), Object.keys(n), !0),
            i = ['*'];
        return 'object' == typeof e.enr && i.push.apply(i, Object.keys(e.enr)),
            function(e) {
                for (var t = {}, a = 0, o = r; a < o.length; a++)
                    for (var c = o[a], u = 0, s = n[c] || i; u < s.length; u++) {
                        var d = s[u];
                        '*' !== d || t[c] || (t[c] = null == e ? void 0 : e.trigger[c]), e[d] && e[d][c] && !t[c] && (t[c] = e[d][c])
                    }
                if (e.trigger)
                    for (var l = 0, v = Object.keys(e.trigger); l < v.length; l++) {
                        t[c = v[l]] || (t[c] = null == e ? void 0 : e.trigger[c])
                    }
                for (var f = 0, p = r; f < p.length; f++) {
                    t[c = p[f]] || delete t[c]
                }
                return t
            }
    };

    function wr(e) {
        var t = e.split('.');
        return function(e) {
            var n = {};
            if ('object' == typeof e) {
                for (var r = 0, i = t; r < i.length; r++) {
                    var a = i[r];
                    n = e[a] ? e[a] : e
                }
                return n
            }
        }
    }

    function br(e, t) {
        var n, r, i = null;
        if (Array.isArray(t)) i = t.map((function(t) {
            return br(e, t)
        }));
        else if (null !== t && 'object' == typeof t && e[me]) {
            for (var a = 0, o = Object.keys(t); a < o.length; a++) {
                var c = o[a];
                e[me][c] && t[c] && (t[c] = (n = e[me][c], r = t[c], n.reduce(Tr, r)))
            }
            i = t
        }
        return i
    }

    function Tr(e, t) {
        switch (t.type) {
            case ce:
                return function(e, t) {
                    for (var n = t, r = 0, i = e.cfg; r < i.length; r++) {
                        var a = i[r];
                        n = n.replace(new RegExp(a[0], 'g'), a[1])
                    }
                    return n
                }(t, e);
            case oe:
                return function(e, t) {
                    for (var n = t, r = 0, i = e.cfg; r < i.length; r++) {
                        var a = i[r],
                            o = a[0],
                            c = a[1];
                        if (o >= 0) n = n.slice(0, o) + c + n.slice(o);
                        else if (-1 === o) n = n.slice(o + 1) + c;
                        else {
                            var u = n.slice(0, n.length + o),
                                s = n.slice(o);
                            n = u + c + s
                        }
                    }
                    return n
                }(t, e);
            case ae:
                return function(e, t) {
                    for (var n = t, r = 0, i = e.cfg; r < i.length; r++) {
                        var a = i[r];
                        n = n.slice(a[0], a[1])
                    }
                    return n
                }(t, e);
            default:
                return e
        }
    }

    function Ar(e, n, r) {
        var i = (e || Object.keys(n[le] || {})).reduce((function(e, i) {
                var a, o, c = null === (a = n[le]) || void 0 === a ? void 0 : a[i];
                if (!c) return e;
                switch (c[pe]) {
                    case re:
                        var u = function(e) {
                            function n(t) {
                                return Object.keys(e[me]).reduce((function(t, n) {
                                    if (null == n ? void 0 : n.includes('.')) {
                                        var r = e[me][n],
                                            i = rr(n)(t);
                                        i && (t[r] = i)
                                    } else if (null == t ? void 0 : t[n]) {
                                        if ((r = e[me][n]) === n) return t;
                                        t[r] = t[n], delete t[n]
                                    }
                                    return t
                                }), t)
                            }
                            var r = e[fe];
                            return function(e) {
                                return r.reduce((function(e, t) {
                                    if (e[t]) e[t] = n(e[t]);
                                    else if (t.includes('.')) {
                                        var r = rr(t, null)(e);
                                        Array.isArray(r) && r.forEach((function(e) {
                                            e && n(e)
                                        }))
                                    }
                                    return e
                                }), t({}, e))
                            }
                        }(c);
                        return e = u(r);
                    case ie:
                        u = (o = c, function(e) {
                            for (var t = 0, n = o[fe]; t < n.length; t++) {
                                var r = n[t];
                                if (r.includes('.')) {
                                    var i = br(o, rr(r)(e));
                                    wr(r)(i)
                                } else e[r] = br(o, rr(r)(e))
                            }
                            return e
                        });
                        return e = u(r);
                    default:
                        return e
                }
            }), t({}, r)),
            a = (e || Object.keys(n[le] || {})).reduce((function(e, t) {
                var i, a = null === (i = n[le]) || void 0 === i ? void 0 : i[t];
                if (!a) return e;
                if (a[pe] === ne) {
                    var o = Ir(n, a);
                    return e.transformed = o(r), e
                }
                return e
            }), t({}, i));
        return a
    }

    function Sr(e, n, r) {
        var i;
        if ((null === (i = n.meta) || void 0 === i ? void 0 : i.dataType) === wt) return n.data;
        var a, o = r || {},
            c = function(t) {
                var n = zn(t);
                return Ar(o[le], e, n)
            }((a = {
                trigger: n.data
            }, function(e, n, r, i) {
                var a = (e || Object.keys(n.enr || {})).reduce((function(e, a) {
                    var o, c = null === (o = n[de]) || void 0 === o ? void 0 : o[a];
                    if (!c) return e;
                    var u = c[pe],
                        s = Cr[u];
                    return s && (r[a] = s(c, i)), t(t({}, e), r)
                }), r);
                return a
            }(o[de], e, a, n.meta))),
            u = c.trigger;
        return c.transformed || u
    }
    var Or = 12e4;

    function Lr(e, t) {
        return r(this, void 0, void 0, (function() {
            var n, r, a;
            return i(this, (function(i) {
                switch (i.label) {
                    case 0:
                        return [4, jn((function() {
                            var e;
                            return Boolean(null === (e = window.ShopifyAnalytics) || void 0 === e ? void 0 : e.meta)
                        }), Or).catch((function() {}))];
                    case 1:
                        return i.sent(), 'product' === rr('ShopifyAnalytics.meta.page.pageType')(window) && (n = ht, r = gr(), a = function(r) {
                            return t(En(r, {
                                trigger: {
                                    id: e[ve]
                                },
                                source: Z,
                                dataType: n
                            }))
                        }, r && a(r)), [2]
                }
            }))
        }))
    }

    function Nr(e, t) {
        return '*' === e || (new RegExp(e).test(t || '') || (null == t ? void 0 : t.includes(e)) || !1)
    }
    var Pr = '[0-9]+\\/checkouts\\/\\w+\\/thank_you';

    function Rr(e, t) {
        return r(this, void 0, void 0, (function() {
            var n, r, a;
            return i(this, (function(i) {
                return ('thank_you' === rr('Shopify.Checkout.step')(window) || Nr(Pr, window.location.href)) && (n = _t, r = gr(), a = function(r) {
                    return t(En(r, {
                        trigger: {
                            id: e[ve]
                        },
                        source: Z,
                        dataType: n
                    }))
                }, r && a(r)), [2]
            }))
        }))
    }

    function kr(e, t, n = {}) {
        const {
            leading: r = !1,
            trailing: i = !0,
            maxWait: a
        } = n;
        let o, c, u, s = 0,
            d = 0;

        function l(t) {
            const n = c || [];
            return c = void 0, d = t, u = e(...n), u
        }

        function v(e) {
            const n = e - s;
            return 0 === s || n >= t || n < 0 || void 0 !== a && e - d >= a
        }

        function f() {
            const e = Date.now();
            if (v(e)) return p(e);
            o = setTimeout(f, function(e) {
                const n = e - d,
                    r = t - (e - s);
                return void 0 === a ? r : Math.min(r, a - n)
            }(e))
        }

        function p(e) {
            return o && clearTimeout(o), o = void 0, i && c ? l(e) : (c = void 0, u)
        }

        function g(...e) {
            const n = Date.now(),
                i = v(n);
            return c = e, s = n, i ? o ? (clearTimeout(o), o = setTimeout(f, t), l(s)) : (d = a = s, o = setTimeout(f, t), r ? l(a) : u) : (void 0 === o && (o = setTimeout(f, t)), u);
            var a
        }
        return g.cancel = function() {
            o && clearTimeout(o), s = 0, d = 0, c = void 0, o = void 0
        }, g.flush = function() {
            return o ? p(Date.now()) : u
        }, g
    }

    function Dr(e, t, n) {
        const r = n ? .(e, t);
        if ('boolean' == typeof r) return r;
        if (e === t) return !0;
        if ((void 0 === e || void 0 === t || null === e || null === t) && (e || t)) return !1;
        const i = e ? .constructor.name,
            a = t ? .constructor.name;
        if (i !== a) return !1;
        if ('Array' === i) {
            if (e.length !== t.length) return !1;
            let r = !0;
            for (let i = 0; i < e.length; i++)
                if (!Dr(e[i], t[i], n)) {
                    r = !1;
                    break
                }
            return r
        }
        if ('Object' === i) {
            let r = !0;
            const i = Object.keys(e),
                a = Object.keys(t);
            if (i.length !== a.length) return !1;
            for (let a = 0; a < i.length; a++)
                if (!Dr(e[i[a]], t[i[a]], n)) {
                    r = !1;
                    break
                }
            return r
        }
        return e === t
    }

    function xr(e, t) {
        var n = function(e) {
            var t = Object.entries(e);
            return function(e, n) {
                for (var r = n[0], i = n[1], a = 0, o = t; a < o.length; a++) {
                    var c = o[a],
                        u = c[0],
                        s = c[1];
                    if (s === r) e[u] = Fr(i);
                    else if (Array.isArray(s) && s.includes(r)) {
                        if (Object.keys(e).includes(u) && null != e[u]) return e;
                        e[u] = Fr(i)
                    } else 'string' == typeof s && Br.test(s) && new RegExp(Mr(s)).test(r) && (e[u] = Fr(i))
                }
                return e
            }
        }(e);
        return function(e) {
            return Object.entries(e).reduce(n, t || {})
        }
    }
    var Br = /^\/.*\/$/;

    function Mr(e) {
        return e.substring(1, e.length - 1)
    }
    var Ur = /^\[.*\]$/;

    function Fr(e) {
        if (!Ur.test(e)) return e;
        try {
            return JSON.parse(e)
        } catch (t) {
            return e
        }
    }
    var Hr = function(e) {
        return function(t) {
            return Nr(e, t.name)
        }
    };

    function Vr(e) {
        var t = e.pluginConfig,
            n = t[he],
            r = t[_e],
            i = Object.entries(r).reduce((function(e, t) {
                var n = t[0],
                    r = t[1];
                return r && (e[r] = n), e
            }), {});
        return function(e) {
            var r = fr(decodeURIComponent(e.name)),
                a = r[n],
                o = i[a];
            if (o) {
                var c = function(e, t) {
                    var n = e[ye],
                        r = n[Ee],
                        i = t in n ? n[t] : r,
                        a = e[me],
                        o = null != i ? i[me] : null;
                    return null != o && o in a ? xr(a[o]) : function() {}
                }(t, o)(r);
                if (c) return En(c, {
                    source: t[ge],
                    trigger: {
                        id: t[ve]
                    },
                    dataType: o
                })
            }
            return null
        }
    }

    function jr(e) {
        return {
            type: z,
            parse: Vr({
                pluginConfig: e
            }),
            shouldParse: Hr(e[Ce])
        }
    }
    var Gr = function(e) {
            return Array.isArray(e) ? e : [e]
        },
        qr = function(e) {
            return Object.entries(e).reduce((function(e, t) {
                var n = t[0],
                    r = t[1];
                return r && Gr(r).forEach((function(t) {
                    return e[t.toLowerCase()] = n
                })), e
            }), {})
        },
        Yr = function(e) {
            return Object.entries(e || {}).reduce((function(e, t) {
                var n = t[0],
                    r = t[1];
                return r && Gr(r).forEach((function(t) {
                    return e[t] = n
                })), e
            }), {})
        };
    var $r = function(e, t, n) {
            for (var r = 0, i = n; r < i.length; r++) {
                var a = i[r];
                if (Object.prototype.hasOwnProperty.call(t, a)) {
                    var o = t[a];
                    if (Array.isArray(o) || 'object' == typeof o) return Gr(o)
                }
            }
            for (var c = [JSON.parse(JSON.stringify(e) || '{}')]; c.length > 0;) {
                var u = c.shift();
                if ('object' == typeof u && null !== u) {
                    var s = Object.keys(u).find((function(e) {
                        return n.includes(e)
                    }));
                    if (s) {
                        var d = u[s];
                        if (delete u[s], Array.isArray(d)) return d;
                        if ('object' == typeof d && null !== d) return [d]
                    } else
                        for (var a in u) c.push(u[a])
                }
            }
            return []
        },
        Wr = function(e, t, n) {
            var r = {};
            return t.forEach((function(t) {
                var i = n[t] || t;
                if (null == t ? void 0 : t.includes('.')) {
                    var a = rr(t)(e);
                    a && (r[i] = a)
                } else(null == e ? void 0 : e[t]) && (r[i] = null == e ? void 0 : e[t])
            })), r
        };

    function Jr(e) {
        var n = e.pluginConfig,
            r = {
                category: ['item_category'],
                image: ['imageUrl'],
                name: ['title', 'item_name', 'productName'],
                price: ['variantPrice', 'productPrice'],
                currency: ['variantCurrency', 'productCurrency', 'currencyCode'],
                quantity: ['orderQuantity'],
                productId: ['id', 'item_id', 'product_id'],
                subProductId: ['variantSku', 'variantId', 'variant_id', 'subproduct_id'],
                cartCoupon: ['purchase.actionField.coupon'],
                cartTotal: ['purchase.actionField.subtotal', 'purchase.actionField.subtotalWithShipping'],
                cartCurrency: ['currency'],
                orderId: ['transaction_id', 'order_id']
            },
            i = n[_e],
            a = Gr(n[Te]),
            o = qr(i),
            c = function(e) {
                var t = [];
                t.push.apply(t, Object.keys(e));
                for (var n = 0, r = Object.keys(e); n < r.length; n++) {
                    var i = r[n],
                        a = Gr(e[i]);
                    t.push.apply(t, a)
                }
                return t
            }(n[me] || r),
            u = Yr(n[me] || r),
            s = {};
        return function() {
            var e, r = null;
            return Array.isArray(window.dataLayer) ? (null === (e = window.dataLayer) || void 0 === e || e.forEach((function(e) {
                var i, d, l = null == e ? void 0 : e['gtm.uniqueEventId'];
                if (!l || !Object.prototype.hasOwnProperty.call(s, l)) {
                    s[l] = 'processed';
                    var v = (null == e ? void 0 : e.event) || (null == e ? void 0 : e[1]) || 'cannot process';
                    if ('string' == typeof v) {
                        'ecommerce' === (null == v ? void 0 : v.toLowerCase()) && (v = (null === (i = null == e ? void 0 : e.eventDescription) || void 0 === i ? void 0 : i.toLowerCase()) || (null === (d = null == e ? void 0 : e.eventName) || void 0 === d ? void 0 : d.toLowerCase()) || 'cannot process');
                        var f, p = (null == v ? void 0 : v.toLowerCase()) || '',
                            g = o[p] || o[null == p ? void 0 : p.replace(/ /g, '_')];
                        if (!g) {
                            var m = null == e ? void 0 : e.eventAction;
                            if ('string' == typeof m) {
                                var y = (null == m ? void 0 : m.toLowerCase()) || '';
                                g = o[y] || o[null == y ? void 0 : y.replace(/ /g, '_')]
                            }
                        }
                        if (g) {
                            'event' === (null == e ? void 0 : e[0]) ? f = null == e ? void 0 : e[2]: (null == e ? void 0 : e.ecommerce) ? f = null == e ? void 0 : e.ecommerce : (null == e ? void 0 : e.ecommerceGA4) ? f = null == e ? void 0 : e.ecommerceGA4 : (null == e ? void 0 : e[''.concat(v, 'Data')]) && (f = null == e ? void 0 : e[''.concat(v, 'Data')]);
                            var h = $r(f, e, a);
                            h.length;
                            var _ = Wr(t(t({}, f), e), c, u),
                                E = h.map((function(e) {
                                    return Wr(e, c, u)
                                }));
                            _ = t(g !== _t ? t({}, E[0]) : {
                                items: E
                            }, _), r = En(_, {
                                source: n[ge],
                                trigger: {
                                    id: n[ve]
                                },
                                dataType: g
                            })
                        }
                    }
                }
            })), r || null) : null
        }
    }
    var Kr = {
        category: 'pr\\dca',
        currency: '^cu$',
        name: 'pr\\dnm',
        orderId: '^ti$',
        cartTotal: '^tr$',
        price: 'pr\\dpr',
        quantity: 'pr\\dqt',
        sku: 'pr\\did'
    };

    function Xr(e) {
        var n = e.pluginConfig,
            r = n[he],
            i = n[_e],
            a = Object.entries(i).reduce((function(e, t) {
                var n = t[0],
                    r = t[1];
                return r && (Array.isArray(r) ? r.forEach((function(t) {
                    return e[t.toLowerCase()] = n
                })) : e[r.toLowerCase()] = n), e
            }), {});
        return function(e) {
            var i, o, c, u, s, d, l, v = fr(decodeURIComponent(e.name));
            if ('string' == typeof r) c = null === (i = v[r]) || void 0 === i ? void 0 : i.toLowerCase(), u = a[c];
            else if (Array.isArray(r))
                for (var f = 0, p = r; f < p.length; f++) {
                    var g = p[f];
                    if (v[g] && (c = null === (o = v[g]) || void 0 === o ? void 0 : o.toLowerCase(), u = a[c])) break
                }
            if (u) {
                if (!n[ye][Ee] && !(u in n[ye])) return null;
                var m = Kr;
                n[me] && (m = t(t({}, m), n[me]));
                var y = (s = m, d = v, l = {}, Object.entries(s).forEach((function(e) {
                        var t = e[0],
                            n = e[1];
                        l[t] || (l[t] = []), Object.entries(d).forEach((function(e) {
                            var r = e[0],
                                i = e[1];
                            new RegExp(n, 'i').test(r) && l[t].push(i)
                        }))
                    })), l),
                    h = function(e) {
                        var n = {},
                            r = [];
                        Object.entries(e).forEach((function(e) {
                            var t = e[0],
                                i = e[1];
                            1 === i.length ? n[t] = i[0] : i.forEach((function(e, n) {
                                e && (r[n] || (r[n] = {}), r[n][t] = e)
                            }))
                        })), r.length ? r.forEach((function(e, i) {
                            r[i] = t(t({}, e), n)
                        })) : r.push(t({}, n));
                        return r
                    }(y),
                    _ = void 0;
                if (h && (_ = u === _t ? {
                        items: h
                    } : t({}, h[0])), _) return En(_, {
                    source: n[ge],
                    trigger: {
                        id: n[ve]
                    },
                    dataType: u
                })
            }
            return null
        }
    }

    function zr(e, t) {
        var n, r, i, a;
        void 0 === t && (t = 0);
        var o = 3 & e.length,
            c = e.length - o,
            u = 3432918353,
            s = 461845907;
        for (n = t, a = 0; a < c;) i = 255 & e.charCodeAt(a) | (255 & e.charCodeAt(++a)) << 8 | (255 & e.charCodeAt(++a)) << 16 | (255 & e.charCodeAt(++a)) << 24, ++a, n = 27492 + (65535 & (r = 5 * (65535 & (n = (n ^= i = (65535 & (i = (i = (65535 & i) * u + (((i >>> 16) * u & 65535) << 16) & 4294967295) << 15 | i >>> 17)) * s + (((i >>> 16) * s & 65535) << 16) & 4294967295) << 13 | n >>> 19)) + ((5 * (n >>> 16) & 65535) << 16) & 4294967295)) + ((58964 + (r >>> 16) & 65535) << 16);
        switch (i = 0, o) {
            case 3:
                i ^= (255 & e.charCodeAt(a + 2)) << 16;
            case 2:
                i ^= (255 & e.charCodeAt(a + 1)) << 8;
            case 1:
                n ^= i = (65535 & (i = (i = (65535 & (i ^= 255 & e.charCodeAt(a))) * u + (((i >>> 16) * u & 65535) << 16) & 4294967295) << 15 | i >>> 17)) * s + (((i >>> 16) * s & 65535) << 16) & 4294967295
        }
        return n ^= e.length, n = 2246822507 * (65535 & (n ^= n >>> 16)) + ((2246822507 * (n >>> 16) & 65535) << 16) & 4294967295, n = 3266489909 * (65535 & (n ^= n >>> 13)) + ((3266489909 * (n >>> 16) & 65535) << 16) & 4294967295, (n ^= n >>> 16) >>> 0
    }

    function Zr(e) {
        var t = document.querySelectorAll('button.tocart');

        function n() {
            var n = !1;
            t.forEach((function(e) {
                var t, r;
                n = n || 'Added' === (null === (r = null === (t = null == e ? void 0 : e.attributes) || void 0 === t ? void 0 : t.getNamedItem('title')) || void 0 === r ? void 0 : r.value)
            })), n && e()
        }
        t.forEach((function(e) {
            new MutationObserver(n).observe(e, {
                attributes: !0
            })
        }))
    }

    function Qr(e) {
        try {
            fetch('/attentivemobile/cart/get').then((function(e) {
                return e.json()
            })).then((function(t) {
                var n, r, i, a = t,
                    o = ii(),
                    c = String(zr(JSON.stringify(t)));
                if (a.entity_id && (null === (n = o.get(a.entity_id)) || void 0 === n ? void 0 : n.cartHash) !== c) {
                    for (var u = oi(a.attentive_cart_items), s = null === (r = o.get(a.entity_id)) || void 0 === r ? void 0 : r.cart, d = [], l = [], v = function(n) {
                            var r = function(e) {
                                var t = {};
                                return t.productId = e.product_id, t.quantity = e.qty, t
                            }(n);
                            if (d.push(r), 'configurable' !== n.product_type) {
                                var i = ci(n, a.attentive_cart_items, a, u);
                                i.currency = t.quote_currency_code, i.cartCurrency = i.currency, l.push(i), (!s || (null == s ? void 0 : s.filter((function(e) {
                                    return Dr(e, r)
                                })).length) < 1) && e(In(i, {
                                    dataType: mt,
                                    source: ee
                                }))
                            }
                        }, f = 0, p = null !== (i = a.attentive_cart_items) && void 0 !== i ? i : []; f < p.length; f++) {
                        v(p[f])
                    }
                    var g = {};
                    g.items = l, g.products = g.items, g.uid = String(a.customer_id), g.cartTotal = a.grand_total, g.cartCoupon = a.coupon_code, g.email = a.customer_email, e(In(g, {
                        dataType: gt,
                        source: ee
                    })), o.set(a.entity_id, {
                        cartHash: c,
                        cart: d
                    }), ai(o)
                }
            })).catch((function(e) {
                return Mt($, e)
            }))
        } catch (e) {
            Mt($, e)
        }
    }

    function ei(e, t, n) {
        var r = new Map,
            i = document.querySelectorAll('div.swatch-attribute');

        function a(e) {
            try {
                e.forEach((function() {
                    var e, a;
                    i.forEach((function(e) {
                        var t = e.attributes.getNamedItem('data-attribute-code'),
                            n = e.attributes.getNamedItem('data-option-selected');
                        t && n && r.set(t.value, n.value)
                    }));
                    var o = !0;
                    if (r.forEach((function(e) {
                            o = o && null !== e
                        })), o) {
                        var c = null !== (a = null === (e = null == t ? void 0 : t.attentive_variants) || void 0 === e ? void 0 : e.filter((function(e) {
                            var t = !0;
                            return r.forEach((function(n, r) {
                                t = t && e[r] === n
                            })), t
                        }))) && void 0 !== a ? a : [];
                        if (!(c.length < 1)) {
                            var u = c[0];
                            n(u)
                        }
                    }
                }))
            } catch (e) {
                Mt($, e)
            }
        }
        i.forEach((function(e) {
            try {
                var t = e.attributes.getNamedItem('data-attribute-code');
                t && r.set(t.value, null), new MutationObserver(a).observe(e, {
                    attributes: !0
                })
            } catch (e) {
                Mt($, e)
            }
        }))
    }

    function ti(e, t) {
        return r(this, void 0, void 0, (function() {
            var n, r, a, o, c, u, s, d, l, v, f, p, g;
            return i(this, (function(i) {
                switch (i.label) {
                    case 0:
                        return i.trys.push([0, 3, , 4]), [4, fetch('/attentivemobile/store/get')];
                    case 1:
                        return [4, i.sent().json()];
                    case 2:
                        return n = i.sent(), r = document.getElementById('attnProductInfo'), (a = null === (p = null == r ? void 0 : r.attributes) || void 0 === p ? void 0 : p.getNamedItem('data-product-info')) ? (o = atob(a.value.trim()), 'configurable' !== (c = JSON.parse(o)).type_id ? ((d = {}).productId = c.entity_id, d.subProductId = c.entity_id, d.sku = d.productId, d.name = c.name, l = null == n ? void 0 : n.attentive_secure_base_media_url, v = null == c ? void 0 : c.small_image, l && v && (d.image = l + 'catalog/product' + v), t(En(d, {
                            trigger: {
                                id: e[ve]
                            },
                            dataType: ht,
                            source: ee
                        })), [2]) : (u = null !== (g = null == c ? void 0 : c.attentive_variants) && void 0 !== g ? g : []).length < 1 ? [2] : (s = u[0], (d = {}).productId = c.entity_id, d.subProductId = s.entity_id, d.sku = d.productId, d.name = s.name, l = null == n ? void 0 : n.attentive_secure_base_media_url, v = null == s ? void 0 : s.small_image, l && v && (d.image = l + 'catalog/product' + v), t(En(d, {
                            trigger: {
                                id: e[ve]
                            },
                            dataType: ht,
                            source: ee
                        })), ei(n, c, (function(r) {
                            return i = r, a = n, (o = {}).productId = c.entity_id, o.subProductId = i.entity_id, o.sku = o.productId, o.image = a.attentive_secure_base_media_url + 'catalog/product' + i.small_image, o.name = i.name, void t(En(o, {
                                trigger: {
                                    id: e[ve]
                                },
                                dataType: ht,
                                source: ee
                            }));
                            var i, a, o
                        })), [3, 4])) : [2];
                    case 3:
                        return f = i.sent(), Mt($, f), [3, 4];
                    case 4:
                        return [2]
                }
            }))
        }))
    }

    function ni(e, t) {
        return r(this, void 0, void 0, (function() {
            return i(this, (function(n) {
                try {
                    ! function(e, t) {
                        fetch('/attentivemobile/order/get').then((function(e) {
                            return e.json()
                        })).then((function(n) {
                            return function(e, t, n) {
                                var r, i, a, o;
                                try {
                                    for (var c = [], u = oi(e.attentive_order_items), s = 0, d = null !== (i = null === (r = null == e ? void 0 : e.attentive_order_items) || void 0 === r ? void 0 : r.filter((function(e) {
                                            return 'configurable' !== e.product_type
                                        }))) && void 0 !== i ? i : []; s < d.length; s++) {
                                        var l = d[s],
                                            v = ci(l, e.attentive_order_items, e, u);
                                        v.currency = e.order_currency_code, v.cartCurrency = v.currency, v.orderId = e.entity_id, v.quantity = l.qty_ordered, v.phone = null === (a = null == e ? void 0 : e.attentive_order_billing_address) || void 0 === a ? void 0 : a.telephone, c.push(v)
                                    }
                                    var f = {};
                                    f.items = c, f.email = e.customer_email, f.phone = null === (o = null == e ? void 0 : e.attentive_order_billing_address) || void 0 === o ? void 0 : o.telephone, f.uid = String(e.customer_id), f.cartTotal = e.grand_total, f.cartCoupon = e.coupon_code, n(En(f, {
                                        trigger: {
                                            id: t[ve]
                                        },
                                        dataType: _t,
                                        source: ee
                                    }));
                                    var p = ii();
                                    e.quote_id && p.delete(e.quote_id), ai(p)
                                } catch (e) {
                                    Mt($, e)
                                }
                            }(n, e, t)
                        })).catch((function(e) {
                            return Mt($, e)
                        }))
                    }(e, t)
                } catch (e) {
                    Mt(W, e)
                }
                return [2]
            }))
        }))
    }
    var ri = 'attn_magento_cart';

    function ii() {
        var e, t, n = null !== (e = sessionStorage.getItem(ri)) && void 0 !== e ? e : '{}';
        try {
            t = JSON.parse(n)
        } catch (e) {
            t = {}
        }
        return new Map(Object.entries(t))
    }

    function ai(e) {
        sessionStorage.setItem(ri, JSON.stringify(Object.fromEntries(e.entries())))
    }

    function oi(e) {
        var t, n;
        void 0 === e && (e = []);
        for (var r = new Map, i = 0, a = e; i < a.length; i++) {
            var o = a[i];
            if ('configurable' === (null == o ? void 0 : o.product_type) && (null == o ? void 0 : o.product_id))
                for (var c = 0, u = Object.entries(null !== (n = null === (t = null == o ? void 0 : o.attentive_product) || void 0 === t ? void 0 : t.attentive_configurable_product_links) && void 0 !== n ? n : []); c < u.length; c++) {
                    var s = u[c];
                    s[0];
                    var d = s[1];
                    r.set(d, o.product_id)
                }
        }
        return r
    }

    function ci(e, t, n, r) {
        var i, a;
        void 0 === t && (t = []);
        var o = {},
            c = e.product_id ? r.get(e.product_id) : void 0;
        if (c) {
            o.productId = c;
            var u = t.filter((function(t) {
                return t.product_id === c && t.sku === e.sku
            }));
            u.length > 0 && (o.quantity = u[0].qty, o.price = u[0].price)
        } else o.productId = e.product_id, o.quantity = e.qty;
        var s = null === (i = n.attentive_store) || void 0 === i ? void 0 : i.attentive_secure_base_media_url,
            d = null === (a = e.attentive_product) || void 0 === a ? void 0 : a.small_image;
        return s && d && (o.image = s + 'catalog/product' + d), o.subProductId = e.product_id, o.sku = o.productId, o.name = e.name, o.email = n.customer_email, o.uid = String(n.customer_id), o.cartTotal = n.grand_total, o.cartCoupon = n.coupon_code, o
    }

    function ui() {
        return Boolean(Boolean(window.ShopifyAnalytics) || Boolean(window.Shopify))
    }
    var si, di = 1e3;

    function li(e) {
        return r(this, void 0, void 0, (function() {
            var t, n;
            return i(this, (function(r) {
                switch (r.label) {
                    case 0:
                        return t = Date.now(), si && t - si < 1500 ? [2] : (e === hi && (si = Date.now()), [4, fetch('/cart.json')]);
                    case 1:
                        if (!(n = r.sent()).ok) throw new Error(n.statusText);
                        return [4, n.json()];
                    case 2:
                        return [2, r.sent()]
                }
            }))
        }))
    }
    var vi = 'attn_cart',
        fi = 'attn_cart_items';

    function pi(e) {
        return sessionStorage.getItem(e)
    }

    function gi(e, t) {
        sessionStorage.setItem(e, t)
    }

    function mi(e) {
        return ''.concat(e.id, ':').concat(e.variant_id, ':').concat(e.quantity)
    }

    function yi(e, t) {
        var n = e.items.map(mi);
        gi(vi, t), gi(fi, JSON.stringify(n))
    }
    var hi = 2;

    function _i(e, t, n) {
        return void 0 === t && (t = 'USD'), void 0 === n && (n = !0), {
            category: e.product_type,
            image: e.image,
            name: e.product_title || e.title,
            productId: e.product_id,
            quantity: String(e.quantity),
            price: n ? pr(e.price) : String(e.price),
            subProductId: e.variant_id,
            currency: t
        }
    }

    function Ei(e, t) {
        return void 0 === t && (t = !0), {
            products: e.items.map((function(n) {
                return _i(n, e.currency, t)
            })),
            cartId: e.token,
            cartTotal: t ? pr(e.total_price) : String(e.total_price),
            cartCurrency: e.currency
        }
    }

    function Ci(e, t) {
        return r(this, void 0, void 0, (function() {
            var n, r, a, o, c, u, s, d, l, v, f;
            return i(this, (function(i) {
                switch (i.label) {
                    case 0:
                        return i.trys.push([0, 2, , 3]), [4, li(t)];
                    case 1:
                        if (!(n = i.sent())) return [2];
                        if (0 === n.items.length && t === hi) return function(e) {
                            var t = gr();
                            t && Object.keys(t).length > 0 && e(In(t, {
                                dataType: mt,
                                source: Z
                            }))
                        }(e), [2];
                        if (r = function() {
                                var e;
                                return JSON.parse(null !== (e = pi(fi)) && void 0 !== e ? e : '[]')
                            }(), a = Ei(n, !1), o = JSON.stringify(n.items), c = pi(vi), u = String(zr(o)), s = c !== u, !c) return yi(n, u), [2];
                        if (r && s) {
                            for (yi(n, u), d = 0, l = n.items; d < l.length; d++) v = l[d], r.includes(mi(v)) || e(In(_i(v, n.currency), {
                                dataType: mt,
                                source: Z
                            }));
                            e(In(a, {
                                dataType: gt,
                                source: Z
                            }))
                        }
                        return [3, 3];
                    case 2:
                        return f = i.sent(), Mt(q, f), [3, 3];
                    case 3:
                        return [2]
                }
            }))
        }))
    }

    function Ii(e, t) {
        return document.addEventListener('pointerup', (function(n) {
            var r = n.target,
                i = (e[Ie] || At).some((function(e) {
                    var t, i = null;
                    try {
                        t = document.querySelectorAll(e), i = function(e, t) {
                            var n = function(e) {
                                    return 'function' == typeof e.composedPath ? e.composedPath() : []
                                }(e),
                                r = Array.from(t);
                            return 0 === r.length ? null : r.find((function(e) {
                                return n.includes(e)
                            })) || null
                        }(n, t)
                    } catch (e) {}
                    var a = null == r ? void 0 : r.textContent;
                    if (a && a.length > 1e4) return !1;
                    var o = a ? a.toLowerCase().replace(/\n\t/g, '').trim() : '',
                        c = e.toLowerCase();
                    return !(!i && o !== c)
                }));
            i && setTimeout(Ci, di, t, hi)
        }), !0)
    }
    var wi, bi, Ti = 12e4;

    function Ai(e, t) {
        return r(this, void 0, void 0, (function() {
            return i(this, (function(n) {
                switch (n.label) {
                    case 0:
                        return [4, jn((function() {
                            var e;
                            return Boolean(null === (e = window.ShopifyAnalytics) || void 0 === e ? void 0 : e.meta)
                        }), Ti).catch((function() {}))];
                    case 1:
                        return n.sent(), 'product' === rr('ShopifyAnalytics.meta.page.pageType')(window) ? (wi && clearInterval(wi), wi = window.setInterval((function() {
                            var n, r = function() {
                                var e = document.querySelector('[name=id]');
                                if (e && 'value' in e) return e.value
                            }();
                            r && r !== bi && (bi = r, t(En({}, {
                                trigger: (n = {
                                    id: e[ve]
                                }, n[De] = !0, n),
                                source: Z,
                                dataType: ht
                            })))
                        }), 500), [2]) : [2]
                }
            }))
        }))
    }
    var Si = 'attn_cart',
        Oi = 'attn_cart_items';

    function Li(e) {
        return sessionStorage.getItem(e)
    }

    function Ni(e, t) {
        sessionStorage.setItem(e, t)
    }

    function Pi(e) {
        return {
            image: e.image,
            name: e.name,
            productId: String(e.product_id),
            quantity: String(e.quantity),
            price: e.price,
            subProductId: String(e.variation_id)
        }
    }

    function Ri(e) {
        return r(this, void 0, void 0, (function() {
            var t, n, r, a, o, c, u, s, d, l, v, f;
            return i(this, (function(i) {
                if (!Boolean(rr('woocommerce_params')(window))) return [2];
                try {
                    if (!(t = window.attn_cart)) return [2];
                    if (n = null === (v = window.attn_cart) || void 0 === v ? void 0 : v.products, r = JSON.stringify(n), a = Li(Si), o = String(zr(r)), c = n ? function(e) {
                            return Object.keys(e).map((function(t) {
                                return ''.concat(e[t].product_id, ':').concat(e[t].variation_id, ':').concat(e[t].quantity)
                            }))
                        }(n) : null, o === a) return [2];
                    if (u = JSON.parse(null !== (f = Li(Oi)) && void 0 !== f ? f : '[]'), Ni(Oi, JSON.stringify(c)), Ni(Si, o), t && n) {
                        if (s = function(e) {
                                var t = e.products;
                                return {
                                    products: Object.keys(t).map((function(e) {
                                        return Pi(t[e])
                                    })),
                                    cartTotal: e.cartTotal
                                }
                            }(t), d = void 0, u.length !== Object.keys(n).length)
                            for (l in n) u.includes(''.concat(n[l].product_id, ':').concat(n[l].variation_id, ':').concat(n[l].quantity)) || (d = Pi(n[l]));
                        d && e(In(d, {
                            dataType: mt,
                            source: Q
                        })), e(In(s, {
                            dataType: gt,
                            source: Q
                        }))
                    }
                } catch (e) {
                    Mt(Y, e)
                }
                return [2]
            }))
        }))
    }

    function ki(e) {
        return function(e) {
            return e[pe] === z
        }(e) || function(e) {
            return e[pe] === J
        }(e) || function(e) {
            return e[pe] === K
        }(e) || function(e) {
            return e[pe] === te
        }(e)
    }

    function Di(e, t, n) {
        for (var r = 0, i = e; r < i.length; r++) {
            var a = i[r];
            if (a.shouldParse(t)) {
                var o = a.parse(t);
                o && n(o)
            }
        }
    }
    var xi, Bi, Mi = ['view_item', 'enhanceEcom productView', 'Viewed Product', 'Product Details', 'Product Viewed', 'product detail view', 'Product Details Viewed', 'Product Detail Views', 'Product Details View', 'product detail', 'pdp view', 'Product Page', 'detail', 'detailView', 'dl_view_item', 'triggerProductDetail', 'product-detail-view', 'productDetail', 'productViewed', 'bva_view_item'],
        Ui = ['add_to_cart', 'enhanceEcom addToCart', 'add', 'Added Product', 'Adding To A Shopping Cart', 'Add To Bag', 'add to wishlist', 'add to cart quickview', 'add to cart standard', 'Add To Cart', 'Added Product', 'Cart Item Added', 'Product Add To Cart', 'Ecommerce:Items Added to Cart', 'addToCart', 'dl_add_to_cart', 'product add to cart', 'bva_add_to_cart', 'productAdd', 'product_added'],
        Fi = ['purchase', 'enhanceEcom purchase', 'Completed Order', 'sale', 'transaction', 'checkout order completed', 'ordercomplete', 'onepagecheckout', 'ecommerce: purchase', 'ecommerce:purchase', 'order_completed', 'order_complete', 'purchase_complete', 'bva_purchase', 'dl_purchase'],
        Hi = {
            category: ['item_category'],
            image: ['imageUrl', 'imageURL', 'imageurl'],
            name: ['title', 'item_name', 'productName'],
            price: ['variantPrice', 'productPrice'],
            currency: ['variantCurrency', 'productCurrency', 'currencyCode'],
            quantity: ['orderQuantity'],
            productId: ['id', 'item_id', 'product_id'],
            subProductId: ['shopify_variant_id', 'variantSku', 'variantId', 'variant_id', 'subproduct_id'],
            cartCoupon: ['purchase.actionField.coupon'],
            cartTotal: ['purchase.actionField.subtotal', 'purchase.actionField.subtotalWithShipping'],
            cartCurrency: ['currency'],
            orderId: ['order_id', 'orderNumber', 'order_number', 'transaction_id', 'transactionId', 'purchase.actionField.id']
        },
        Vi = function(e, t) {
            return Gr(e || []).concat(Gr(t || []))
        };

    function ji(e, t) {
        var n, r;
        return t ? e : ((n = {})[ve] = e.id, n[pe] = te, n[me] = Hi, n[ge] = te, n[Te] = ['products', 'items'], n[Ce] = '/collect?', n[he] = 'ea', n[_e] = ((r = {})[ht] = Vi(Mi, e[_e][ht]), r[mt] = Vi(Ui, e[_e][mt]), r[_t] = Vi(Fi, e[_e][_t]), r), n[ye] = function(e) {
            var t, n, r, i, a, o = {};
            e.ev[Ee] && Object.assign(o, (t = {}, t[Ee] = e.ev[Ee], t));
            e.ev[ht] && Object.assign(o, (n = {}, n[ht] = e.ev[ht], n));
            e.ev[mt] && Object.assign(o, ((r = {})[mt] = e.ev[mt], r));
            e.ev[Ct] && Object.assign(o, ((i = {})[Ct] = e.ev[Ct], i));
            e.ev[_t] && Object.assign(o, ((a = {})[_t] = e.ev[_t], a));
            return o
        }(e), n)
    }

    function Gi(e) {
        var t, n, r = ((t = {})[ve] = e.id, t[pe] = K, t[me] = {}, t[ge] = K, t[Ce] = '/collect?', t[he] = ['pa', 'ea'], t[_e] = ((n = {})[ht] = ['Viewed Product', 'Product Details', 'Product Viewed', 'product detail view', 'Product Details Viewed', 'Product Detail Views', 'Product Details View', 'product detail', 'pdp view', 'Product Page', 'view_item', 'detail'], n[mt] = ['add', 'Added Product', 'Adding To A Shopping Cart', 'Add To Bag', 'add to wishlist', 'add to cart quickview', 'add to cart standard', 'Add To Cart', 'Added Product', 'Cart Item Added', 'Product Add To Cart', 'Ecommerce:Items Added to Cart', 'addToCart', 'add_to_cart'], n[_t] = ['purchase', 'Completed Order', 'sale', 'transaction', 'checkout order completed', 'ordercomplete', 'onepagecheckout', 'ecommerce:purchase', 'Order Completed'], n), t[ye] = function(e) {
            var t, n, r, i, a, o = {};
            e.ev[Ee] && Object.assign(o, (t = {}, t[Ee] = e.ev[Ee], t));
            e.ev[ht] && Object.assign(o, (n = {}, n[ht] = e.ev[ht], n));
            e.ev[mt] && Object.assign(o, ((r = {})[mt] = e.ev[mt], r));
            e.ev[Ct] && Object.assign(o, ((i = {})[Ct] = e.ev[Ct], i));
            e.ev[_t] && Object.assign(o, ((a = {})[_t] = e.ev[_t], a));
            return o
        }(e), t);
        return ji(r)
    }
    var qi = ((xi = {})[K] = function(e) {
            return {
                type: K,
                parse: Xr({
                    pluginConfig: e
                }),
                shouldParse: (t = e[Ce], function(e) {
                    return Nr(t, e.name)
                })
            };
            var t
        }, xi[J] = function(e) {
            var n, r, i = jr(t(t({}, e), ((n = {})[pe] = z, n[ge] = J, n[Ce] = '^https://www.facebook.com/tr', n[he] = 'ev', n[_e] = ((r = {})[ht] = 'ViewContent', r[mt] = 'AddToCart', r[_t] = 'Purchase', r), n)));
            return {
                type: J,
                parse: i.parse,
                shouldParse: i.shouldParse
            }
        }, xi[z] = jr, xi[te] = function(e) {
            return {
                type: te,
                parse: Jr({
                    pluginConfig: e
                }),
                shouldParse: (t = e[Ce], function(e) {
                    return Nr(t, e.name)
                })
            };
            var t
        }, xi),
        Yi = ((Bi = {})[Z] = function(e, t) {
            return r(this, void 0, void 0, (function() {
                return i(this, (function(n) {
                    return ui() ? ((null == e ? void 0 : e.eatc) || (Ci(t, 1), function(e) {
                        var t = !1;
                        new PerformanceObserver((function(n) {
                            for (var r = 0, i = n.getEntries(); r < i.length; r++) {
                                var a = i[r];
                                if (t) return;
                                if (a.name.includes('https://www.facebook.com/tr') && 'AddToCart' === (o = fr(decodeURIComponent(a.name))).ev && (t = !0, setTimeout((function() {
                                        return Ci(e, hi)
                                    }), di)), a.name.includes('https://www.google-analytics.com/collect')) {
                                    var o, c = ['add', 'Added Product', 'Adding To A Shopping Cart', 'Add To Bag', 'add to wishlist', 'add to cart quickview', 'add to cart standard', 'Add To Cart', 'Added Product', 'Cart Item Added', 'Product Add To Cart', 'Ecommerce:Items Added to Cart', 'addToCart', 'add_to_cart'];
                                    ('string' == typeof(o = fr(decodeURIComponent(a.name))).ea && c.includes(o.ea) || 'string' == typeof o.pa && c.includes(o.pa)) && (t = !0, setTimeout((function() {
                                        return Ci(e, hi)
                                    }), di))
                                }
                            }
                        })).observe({
                            entryTypes: ['resource']
                        })
                    }(t), Ii(e, t)), Lr(e, t), e[De] && Ai(e, t), Rr(e, t), [2]) : [2]
                }))
            }))
        }, Bi[X] = function(e, t) {
            var n, r = Nr(e[Ce], window.location.href),
                i = e[Ie].length > 0,
                a = function() {
                    return t(En({}, {
                        trigger: {
                            id: e[ve]
                        },
                        source: X,
                        dataType: e.t
                    }))
                };
            r && (i ? (null === (n = e[Ie]) || void 0 === n ? void 0 : n.filter((function(e) {
                return document.querySelector(e)
            })).length) && setTimeout(a, e[be]) : setTimeout(a, e[be]))
        }, Bi.oe = function(e, t) {
            var n = e[Ne],
                r = document;
            document.addEventListener(e.de, (function(i) {
                var a;
                if (Nr(e[Ce], window.location.href)) {
                    var o = i.target;
                    n && (r = null !== (a = o.closest(n)) && void 0 !== a ? a : r), e[Ie].some((function(a) {
                        var c, u, s = null;
                        try {
                            u = r.querySelectorAll(a), s = function(e, t) {
                                var n = function(e) {
                                        return 'function' == typeof e.composedPath ? e.composedPath() : []
                                    }(e),
                                    r = Array.from(t);
                                return 0 === r.length ? null : r.find((function(e) {
                                    return n.includes(e)
                                })) || null
                            }(i, u)
                        } catch (e) {}
                        var d = null == o ? void 0 : o.textContent,
                            l = d ? d.toLowerCase().replace(/\n\t/g, '').trim() : '',
                            v = a.toLowerCase();
                        if (s || l === v) {
                            var f = {
                                    source: 'oe',
                                    trigger: {
                                        id: e[ve]
                                    },
                                    dataType: e.t
                                },
                                p = En({}, f);
                            if (!n) return t(p), !0;
                            var g = i.target.closest(n);
                            if (g && (null === (c = null == p ? void 0 : p.meta) || void 0 === c ? void 0 : c.trigger)) return p.meta.trigger[Ne] = g, t(p), !0
                        }
                        return !1
                    }))
                }
            }), !0)
        }, Bi[Q] = function(e, t) {
            return r(this, void 0, void 0, (function() {
                var n, r, a, o, c, u;
                return i(this, (function(i) {
                    switch (i.label) {
                        case 0:
                            return Ri(t), n = '\\/checkout\\/order-received\\/|\\/order-confirmed\\/', [4, jn((function() {
                                return Boolean(window.attn_product || window.attn_order)
                            }), 12e4).catch((function() {}))];
                        case 1:
                            return i.sent(), r = Nr(n, window.location.href) && Boolean(rr('attn_order')(window)), a = Boolean(rr('attn_product')(window)), (a || r) && (o = a ? ht : _t, c = Er(), u = function(n) {
                                return t(En(n, {
                                    trigger: {
                                        id: e[ve]
                                    },
                                    source: Q,
                                    dataType: o
                                }))
                            }, c && u(c)), [2]
                    }
                }))
            }))
        }, Bi[ee] = function(e, t) {
            return r(this, void 0, void 0, (function() {
                return i(this, (function(n) {
                    return document.getElementById('attentiveMagentoPage') ? (document.getElementById('attnProductInfo') && ti(e, t), document.getElementById('attnOrderInfo') ? ni(e, t) : function(e, t) {
                        r(this, void 0, void 0, (function() {
                            return i(this, (function(e) {
                                try {
                                    Zr((function() {
                                        Qr(t)
                                    })), Qr(t)
                                } catch (e) {
                                    Mt($, e)
                                }
                                return [2]
                            }))
                        }))
                    }(0, t), [2]) : [2]
                }))
            }))
        }, Bi.plt = function(e, t) {
            var n = Date.now(),
                r = window.scrollY + window.innerHeight,
                i = kr((function() {
                    var e = window.scrollY + window.innerHeight;
                    r = Math.max(r, e)
                }), 200);
            window.addEventListener('scroll', i), window.addEventListener('visibilitychange', (function() {
                if ('hidden' !== document.visibilityState) return r = 0, void(n = Date.now());
                var i = Date.now() - n,
                    a = document.documentElement.scrollHeight,
                    o = r / a * 100;
                t(En({
                    scrollDepth: Math.min(o, 100),
                    timeSpent: i
                }, {
                    trigger: {
                        id: e[ve]
                    },
                    source: 'plt',
                    dataType: e.t
                }))
            }))
        }, Bi);

    function $i(e, t, n) {
        var r = [],
            i = e[se] || [],
            a = /iPad|iPhone|iPod/.test(navigator.userAgent);
        i.forEach((function(e) {
                var i = e.pt;
                if (a && i === J) {
                    var o = Gi(e);
                    r.push(qi[o.pt](o))
                } else if (i === K) {
                    var c = ji(e, null == n ? void 0 : n.ua);
                    r.push(qi[c.pt](c))
                } else i in qi && ki(e) ? r.push(qi[i](e)) : i in Yi && Yi[i](e, t)
            })),
            function(e, t) {
                if (0 !== e.length) {
                    var n = 0;
                    if (!performance.getEntries || !performance.setResourceTimingBufferSize) throw new Error(F);
                    performance.setResourceTimingBufferSize(600);
                    try {
                        'PerformanceObserver' in window ? (r(), new PerformanceObserver((function(n) {
                            for (var r = 0, i = n.getEntries(); r < i.length; r++) {
                                var a = i[r];
                                Di(e, a, t)
                            }
                        })).observe({
                            entryTypes: ['resource']
                        })) : window.setInterval((function() {
                            r()
                        }), 250)
                    } catch (e) {
                        Mt(j, e)
                    }
                }

                function r() {
                    for (var r = 0, i = window.performance.getEntries(); r < i.length; r++) {
                        var a = i[r];
                        a.startTime > n && Di(e, a, t), n = a.startTime
                    }
                }
            }(r, t)
    }

    function Wi(e, t) {
        (e[se] || []).forEach((function(e) {
            var n = e.pt;
            n === X && Yi[X](e, t), n === Z && function(e, t) {
                r(this, void 0, void 0, (function() {
                    return i(this, (function(n) {
                        return Lr(e, t), Rr(e, t), [2]
                    }))
                }))
            }(e, t), n === Q && Yi[Q](e, t), n === ee && Yi[ee](e, t)
        }))
    }

    function Ji(e) {
        var n, r, i = [];
        if (function(e) {
                var t;
                return Boolean((null === (t = null == e ? void 0 : e.meta) || void 0 === t ? void 0 : t.dataType) && [yt, _t, mt, ht, bt, gt, wt, Tt].includes(e.meta.dataType))
            }(e)) {
            var a = e.data;
            if (a && Array.isArray(null == a ? void 0 : a.items) ? a.items.forEach((function(n) {
                    var r;
                    delete(r = 'object' == typeof n ? t(t({}, e.data), n) : t({
                        productId: n
                    }, e.data)).items, i.push({
                        type: e.type,
                        data: r,
                        meta: e.meta
                    })
                })) : e && e.type && i.push(e), (null === (n = e.meta) || void 0 === n ? void 0 : n.dataType) === _t) {
                var o = function(e) {
                    for (var t = 0, n = 0, r = e; n < r.length; n++) {
                        var i = r[n].data;
                        if (i.cartTotal && !isNaN(Number(i.cartTotal))) return i.cartTotal;
                        var a = Number(rn(i.price || '0')),
                            o = Number(an(i.quantity || '1') || '1');
                        isNaN(o) || isNaN(a) ? isNaN(a) || (t += a) : t += a * o
                    }
                    return String(t)
                }(i);
                i.forEach((function(e) {
                    return e.data.cartTotal = o
                }));
                var c = i.map((function(e) {
                        return e.data
                    })),
                    u = null === (r = c.find((function(e) {
                        return void 0 !== e.orderId
                    }))) || void 0 === r ? void 0 : r.orderId;
                i.push({
                    type: e.type,
                    data: {
                        uid: a.uid,
                        phone: a.phone,
                        email: a.email,
                        orderId: u,
                        products: c
                    },
                    meta: t(t({}, e.meta), {
                        dataType: It
                    })
                })
            }
        }
        return i
    }

    function Ki(e, t) {
        var n;
        void 0 === t && (t = 'every');
        var r = ((n = {})[Ae] = function(e) {
            if (e.type === Ae) {
                var t = document.querySelector(e[Ae]);
                return e[Oe] ? Boolean(null == t ? void 0 : t.getAttribute(e[Oe] || '')) : Boolean(t)
            }
        }, n[Se] = function(e) {
            if (e.type === Se) return Boolean(rr(e[Se])(window))
        }, n[Ce] = function(e) {
            if (e.type === Ce) return Nr(e[Ce], window.location.href)
        }, n[Re] = function(e) {
            if (e.type === Re) return Boolean(new URLSearchParams(window.location.search).get(e[Re]))
        }, n);
        if (!Array.isArray(e)) return !0;
        return e[t]((function(e) {
            return r[e.type] && r[e.type](e)
        }))
    }
    var Xi = 'attn_oid',
        zi = {};

    function Zi(e) {
        return !! function(e) {
            return function(e) {
                var t;
                try {
                    if ((null === (t = e.meta) || void 0 === t ? void 0 : t.dataType) === _t && e.data.orderId) {
                        var n = localStorage.getItem(Xi);
                        return String(e.data.orderId) === n
                    }
                } catch (e) {
                    return Mt(V, e), !1
                }
            }(e) || function(e) {
                var t = 2e3,
                    n = Qi(e);
                return !!n && (zi[n] ? Date.now() - zi[n].lastSeen : 1 / 0) < t
            }(e)
        }(e) || (function(e) {
            var t;
            if (!e.data) return;
            var n = Qi(e);
            n && (zi[n] = {
                lastSeen: Date.now(),
                event: e
            });
            if ((null === (t = e.meta) || void 0 === t ? void 0 : t.dataType) === _t && e.data.orderId) try {
                localStorage.setItem(Xi, String(e.data.orderId))
            } catch (e) {
                Mt(H, e)
            }
        }(e), !1)
    }

    function Qi(e) {
        var t;
        return null === (t = e.meta) || void 0 === t ? void 0 : t.dataType
    }
    var ea = navigator.userAgent.includes('Safari') && !navigator.userAgent.includes('Chrome');

    function ta(e) {
        var t = 'onpagehide' in window && !ea ? 'pagehide' : 'beforeunload';
        window.addEventListener(t, e)
    }
    var na = function() {
        var e, t, n, a = !0,
            o = ((e = {})[st] = function(e, o, c) {
                var u, s, d, l = c.dispatch;
                t = o.data.clientConfiguration, n = t.ap,
                    function(e) {
                        if (window.edgetag && e[ct]) {
                            var t = {
                                edgeURL: e[ct]
                            };
                            e[et] || (t.disableConsentCheck = !0), window.edgetag('init', t)
                        }
                    }(t), window.edgetag && !(null === (u = t.gen) || void 0 === u ? void 0 : u.dpd) && function(e) {
                        r(this, void 0, void 0, (function() {
                            var t, n;
                            return i(this, (function(r) {
                                switch (r.label) {
                                    case 0:
                                        return void 0 !== Jn ? [2] : void 0 !== (t = O(Kn)) ? (Jn = t, [2]) : [4, Wn(e)];
                                    case 1:
                                        return n = r.sent(), Jn = n, P(Kn, n), [2]
                                }
                            }))
                        }))
                    }('https://cdn.attn.tv/'.concat(t.company, '/dtag.js')), t[et] && (a = Boolean(null === (s = e[tt]) || void 0 === s ? void 0 : s.val)), (null === (d = t.cc) || void 0 === d ? void 0 : d.dap) || function(e) {
                        var t = window.location,
                            n = t.href,
                            r = t.pathname;
                        setInterval((function() {
                            var t = {
                                href: n !== window.location.href,
                                pathname: r !== window.location.pathname
                            };
                            (t.href || t.pathname) && (n = window.location.href, r = window.location.pathname, e(_n(t)))
                        }), 500)
                    }(l), n && $i(n, l, t), a && l(Cn({}, {
                        dataType: yt,
                        source: 'a'
                    }))
            }, e.uc = function(e, t, r) {
                var i, o = r.dispatch;
                n && Wi(n, o), (null === (i = t.data) || void 0 === i ? void 0 : i.pathname) && a && o(Cn({}, {
                    dataType: yt,
                    source: 'a'
                }))
            }, e[vt] = function(e, t) {
                a = !!t.data.on
            }, e.cd = function(e, r, i) {
                var o, c, u, s = i.dispatch;
                if (Un(r) || (null === (o = r.meta) || void 0 === o ? void 0 : o.dataType) === wt) s(Cn(r.data, r.meta));
                else if (n && a) {
                    (null === (c = r.meta) || void 0 === c ? void 0 : c.dataType) === mt && ui() && !t.dase && Ci(s, hi);
                    var d = null === (u = null == r ? void 0 : r.meta) || void 0 === u ? void 0 : u.trigger,
                        l = (n[se] || []).find((function(e) {
                            return e[ve] === (null == d ? void 0 : d.id)
                        })),
                        v = function(e) {
                            var t = function(e, t) {
                                var n, r, i = null;
                                if (ki(e)) {
                                    if (ki(e)) {
                                        var a = e[ye][Ee],
                                            o = e[ye],
                                            c = ((n = {})[ht] = o[ht] || a, n[mt] = o[mt] || a, n[_t] = o[_t] || a, n),
                                            u = null === (r = null == t ? void 0 : t.meta) || void 0 === r ? void 0 : r.dataType;
                                        i = u ? c[u] : null
                                    }
                                } else i = e.pl || {};
                                return i
                            }(e, r);
                            if (t) {
                                var i = function() {
                                        if (n && t) {
                                            var e = Sr(n, r, t);
                                            s(Cn(e, r.meta))
                                        }
                                    },
                                    a = e.wf;
                                if (function(e) {
                                        return null != e && 'object' == typeof e
                                    }(a)) {
                                    var o = null == a ? void 0 : a[be],
                                        c = null == a ? void 0 : a[Pe],
                                        u = c && jn((function() {
                                            return Ki(c)
                                        }), o);
                                    u && (ta(u.cancel), u.then(i).catch((function(e) {
                                        var t = e.reason;
                                        t !== Fn && t !== Hn || i()
                                    })))
                                } else i()
                            } else s(In(r.data, r.meta))
                        };
                    if (l)
                        if (Ki(l[Pe] || [], l.cndt)) v(l);
                        else if (l.asn) {
                        var f = l[Pe],
                            p = f && jn((function() {
                                return Ki(f)
                            }), 2e4);
                        p && (ta(p.cancel), p.then((function() {
                            return v(l)
                        })).catch((function(e) {
                            e.reason
                        })))
                    }
                }
            }, e[ft] = function(e, n, r) {
                var i, o = r.dispatch;
                if (Un(n) || a) {
                    if (Zi(n) && !t.disdedupe) return;
                    if (!0 === t.sactcu && Un(n) && (null === (i = n.meta) || void 0 === i ? void 0 : i.dataType) === mt && li(hi).then((function(e) {
                            if (e) {
                                var t = Ei(e, !1);
                                t && o(In(t, {
                                    dataType: gt,
                                    source: 'a'
                                }))
                            }
                        })), function(e) {
                            var t;
                            return (null === (t = null == e ? void 0 : e.meta) || void 0 === t ? void 0 : t.dataType) === gt
                        }(n)) o(In(n.data, n.meta));
                    else ! function(e, t) {
                        if (e.length > 0)
                            for (; e.length;) {
                                var n = e.shift();
                                n && n.meta && t(n.data, n.meta)
                            }
                    }(Ji(n), (function(e, t) {
                        return o(In(e, t))
                    }))
                }
            }, e);
        return sn(o)
    };
    const ra = '_attnfp';
    async function ia(e) {
        const t = (n = ra, S.getJSON(n));
        var n;
        if (t && 1 === t.maxAge) return t;
        try {
            const t = await
            import ('https://t.tnafpt.com/agent?version=3&apiKey=WThcqME9UwT4oh0caZUE'), n = await t.load(), r = await n.get(function(e) {
                let t;
                return e && (t = {
                    linkedId: e
                }), t
            }(e));
            if (! function(e) {
                    return null !== e && 'object' == typeof e && 'visitorId' in e && 'requestId' in e
                }(r)) return;
            return P(ra, JSON.stringify({ ...r,
                maxAge: 1
            }), {
                expires: 1
            }), r
        } catch (e) {
            return
        }
    }
    const aa = e => e.map((e => 'string' == typeof e ? e : e.sku || e.subProductId || e.productId)),
        oa = e => e.map((e => 'string' == typeof e ? {
            id: e,
            quantity: 1
        } : {
            id: e.sku || e.subProductId || e.productId,
            quantity: e.quantity || 1,
            ...e
        })),
        ca = (e, t) => {
            const n = parseFloat(t || '0');
            return !n || isNaN(n) ? e.reduce(((e, t) => {
                if ('string' == typeof t) return e;
                const n = parseFloat(t.price || '0'),
                    r = isNaN(n) ? 0 : n,
                    i = parseFloat(t.quantity || '1');
                return e + r * (isNaN(i) ? 1 : i)
            }), 0) : n
        },
        ua = (e, t) => {
            const n = (e => {
                const t = e.data.items;
                return t && Array.isArray(t) ? t : []
            })(t);
            switch (e) {
                case 'PageView':
                    return {};
                case 'ViewContent':
                case 'AddToCart':
                    return {
                        content_ids: aa(n),
                        content_type: 'product',
                        contents: oa(n),
                        currency: t.data.currency || t.data.cartCurrency || void 0,
                        value: ca(n, t.data.cartTotal)
                    };
                case 'Purchase':
                    return {
                        content_ids: aa(n),
                        content_type: 'product',
                        contents: oa(n),
                        currency: t.data.currency || t.data.cartCurrency || void 0,
                        num_items: n.length,
                        value: ca(n, t.data.cartTotal)
                    };
                default:
                    return
            }
        },
        sa = {
            [yt]: 'PageView',
            [ht]: 'ViewContent',
            [mt]: 'AddToCart',
            [_t]: 'Purchase',
            i: void 0,
            [wt]: void 0,
            [bt]: void 0,
            [gt]: void 0,
            [It]: void 0,
            [Tt]: void 0
        },
        da = e => {
            (() => {
                const e = function(...t) {
                    e.callMethod ? e.callMethod.apply(null, t) : e.queue.push(t)
                };
                e.push = e, e.queue = [], e.loaded = !1, e.version = '2.0', window.fbq = e, window._fbq = e
            })(), (() => {
                const e = document.createElement('script');
                e.async = !0, e.src = 'https://connect.facebook.net/en_US/fbevents.js', document.head.appendChild(e)
            })(), window.fbq ? .('init', e)
        },
        la = e => {
            const t = {
                phone: en(e.replace(/^1/, ''), !0) || void 0,
                email: tn(e) || void 0
            };
            return t.email && function(e, t) {
                const n = t + ':0';
                try {
                    P('attntv_mstore_' + e, n, {
                        secure: window.location.protocol.includes('https')
                    })
                } catch (e) {
                    Mt(H, e)
                }
            }('email', t.email), t
        };
    const va = ['text', 'email', 'tel'],
        fa = e => {
            const t = new WeakMap,
                n = (e, t = new Set) => {
                    var r;
                    (r = e) instanceof HTMLInputElement && va.includes(r.type) && t.add(e), e.childNodes ? .forEach((e => n(e, t)));
                    const i = e;
                    return i.shadowRoot && i.shadowRoot.childNodes.forEach((e => n(e, t))), Array.from(t)
                };
            return {
                monitorInput: n => {
                    if (t.has(n)) return;
                    const r = kr(e, 750);
                    t.set(n, r), n.value && e({
                        target: n
                    }), n.addEventListener('input', r)
                },
                cleanupInput: e => {
                    if (!t.has(e)) return;
                    const n = t.get(e);
                    n && (n.cancel(), e.removeEventListener('input', n)), t.delete(e)
                },
                findInputElements: n
            }
        };
    let pa = () => {},
        ga = () => {};
    const ma = () => {
        let e, t, n, r = !1,
            i = !1,
            a = !1;
        return sn({
            [st]: async (o, c, {
                dispatch: u
            }) => {
                e = c.data.clientConfiguration, r = e[rt] ? .[St] ? ? !1, i = e[rt] ? .efj ? ? !1, n = e[rt] ? .mpid ? ? void 0, a = e[rt] ? .esx ? ? !1, pa(), ga();
                const s = e.ido ? .idos;
                'off' !== s ? .type && (pa = function(e) {
                    const t = t => {
                        t.target.matches('input:not([type=password]):not([type=submit]):not([autocomplete^="cc-"])') && e(t)
                    };
                    return document.addEventListener('focusout', t), () => {
                        document.removeEventListener('focusout', t)
                    }
                }((e => ((e, t) => {
                    const n = la(e.target.value);
                    (n.phone || n.email) && t(In(n, {
                        dataType: bt,
                        source: 'fs'
                    }))
                })(e, u))));
                const d = void 0 !== window.location.pathname && (window.location.pathname.includes('/checkout') || window.location.pathname.includes('/shipping'));
                a && d && (ga = (e => {
                    const {
                        monitorInput: t,
                        cleanupInput: n,
                        findInputElements: r
                    } = fa(e), i = new MutationObserver((e => {
                        e.forEach((e => {
                            'childList' === e.type && (e.removedNodes.length > 0 && e.removedNodes.forEach((e => r(e).forEach(n))), e.addedNodes.length > 0 && e.addedNodes.forEach((e => r(e).forEach(t))), r(e.target).forEach(t))
                        }))
                    }));
                    return i.observe(document, {
                        childList: !0,
                        subtree: !0
                    }), () => {
                        i.disconnect()
                    }
                })((e => ((e, t) => {
                    if (!(e.target instanceof HTMLInputElement)) return;
                    const n = la(e.target.value);
                    (n.phone || n.email) && t(In(n, {
                        dataType: bt,
                        source: 'fs'
                    }))
                })(e, u)))), ((e, t) => {
                    const n = O('__attentive_id'),
                        r = e ? .[Ye] ? .val;
                    if (n && fn(n) && r && fn(r) && r === n) return;
                    const i = vn();
                    P('__attentive_id', i, {
                        expires: 21900
                    }), t(yn({
                        id: i,
                        maxAge: 21900
                    }))
                })(o, u), r ? (((e, t) => {
                    const n = O('_fbc'),
                        r = O('_fbp');
                    if (e[$e] && e[We] && n === e[$e] && r === e[We]) return;
                    t(hn({
                        [Ke]: !0,
                        [$e]: n,
                        [We]: r
                    }))
                })(o, u), n && u(wn({
                    pixelId: n
                }))) : u(hn({
                    [$e]: void 0,
                    [We]: void 0,
                    [Ke]: void 0
                })), i && (t = await ia(o[Ye] ? .val))
            },
            [pt]: (e, a) => {
                if (r) {
                    const t = (e => {
                        if (!e.meta) return;
                        const t = vn();
                        return e.meta.metaEventId = t, t
                    })(a);
                    t && e[Ke] && n && ((e, t) => {
                        if (!e.meta) return;
                        const n = sa[e.meta.dataType];
                        if (!n) return;
                        const r = ua(n, e);
                        r && 'function' == typeof window.fbq && window.fbq('track', n, r, {
                            eventID: t
                        })
                    })(a, t)
                }
                i && t && ((e, t) => {
                    t.meta && (t.meta.fingerprintRequestId = e.requestId, t.meta.fingerprintVisitorId = e.visitorId, t.meta.fingerprintConfidenceScore = e.confidence.score)
                })(t, a)
            },
            imp: (e, t) => {
                r && e[Ke] && t.data.pixelId && da(t.data.pixelId)
            }
        })
    };
    var ya, ha = (e => (e.ActionButton = 'ActionButton', e.AgeGating = 'AgeGating', e.Background = 'Background', e.BubbleStyles = 'BubbleStyles', e.CheckoutProduct = 'CheckoutProduct', e.CloseIcon = 'CloseIcon', e.CompleteYourSignupSVG = 'CompleteYourSignupSVG', e.Countdown = 'Countdown', e.DismissButton = 'DismissButton', e.OptionalEmailButton = 'OptionalEmailButton', e.Image = 'Image', e.Input = 'Input', e.LegalText = 'LegalText', e.Logo = 'Logo', e.SuccessPhoneSVG = 'SuccessPhoneSVG', e.TextHeader = 'TextHeader', e.MobileExperience = 'MobileExperience', e.OfferWheel = 'OfferWheel', e.BubbleIcon = 'BubbleIcon', e.PrimaryCTA = 'PrimaryCTA', e.SMSPrefilledText = 'SMSPrefilledText', e.CustomCSS = 'CustomCSS', e.AttributeInputs = 'AttributeInputs', e.PageTimeout = 'PageTimeout', e.FeatureFlagCondition = 'FeatureFlagCondition', e.CustomAlreadySubscribedError = 'CustomAlreadySubscribedError', e.LandingPageURL = 'LandingPageURL', e.PageTimeoutRedirectButton = 'PageTimeoutRedirectButton', e.PreEngagementConsentButton = 'PreEngagementConsentButton', e.PreEngagementDenyButton = 'PreEngagementDenyButton', e.ProductHighlight = 'ProductHighlight', e))(ha || {}),
        _a = (e => (e.INFO = 'INFO', e.WARNING = 'WARNING', e))(_a || {}),
        Ea = (e => (e.PLAIN = 'PLAIN', e.BLOCK = 'BLOCK', e.BOLD = 'BOLD', e))(Ea || {}),
        Ca = (e => (e.EST = 'America/New_York', e.CST = 'America/Chicago', e.MST = 'America/Denver', e.PST = 'America/Los_Angeles', e.GMT = 'Europe/London', e.NST = 'America/St_Johns', e.AST = 'America/Halifax', e.AWT = 'Australia/Perth', e.ACWT = 'Australia/Eucla', e.ACT = 'Australia/Darwin', e.AETB = 'Australia/Brisbane', e.AET = 'Australia/Sydney', e.LHT = 'Australia/Lord_Howe', e.CEST = 'Europe/Paris', e.AZOST = 'Atlantic/Azores', e.ACT1 = 'America/Rio_Branco', e.AMT = 'America/Manaus', e.BRT = 'America/Sao_Paulo', e.FNT = 'America/Noronha', e.PT = 'America/Tijuana', e.MT = 'America/Hermosillo', e.CT = 'America/Mexico_City', e.ET = 'America/Cancun', e.NZDT = 'Pacific/Auckland', e))(Ca || {}),
        Ia = (e => (e.enUS = 'en-US', e.enCA = 'en-CA', e.enGB = 'en-GB', e.enAU = 'en-AU', e.enNZ = 'en-NZ', e.enFR = 'en-FR', e.enBE = 'en-BE', e.enBR = 'en-BR', e.enCH = 'en-CH', e.enDE = 'en-DE', e.enDK = 'en-DK', e.enES = 'en-ES', e.enIT = 'en-IT', e.enMX = 'en-MX', e.enNL = 'en-NL', e.enNO = 'en-NO', e.enPL = 'en-PL', e.enPT = 'en-PT', e.enSE = 'en-SE', e.frFR = 'fr-FR', e.frBE = 'fr-BE', e.frCA = 'fr-CA', e.frCH = 'fr-CH', e.enIE = 'en-IE', e.itIT = 'it-IT', e.nlNL = 'nl-NL', e.ptPT = 'pt-PT', e.ptBR = 'pt-BR', e.esES = 'es-ES', e.esMX = 'es-MX', e.svSE = 'sv-SE', e.deDE = 'de-DE', e.nlBE = 'nl-BE', e.deCH = 'de-CH', e.plPL = 'pl-PL', e.noNO = 'no-NO', e.daDK = 'da-DK', e))(Ia || {});

    function wa(e) {
        if (null === e || !0 === e || !1 === e) return NaN;
        var t = Number(e);
        return isNaN(t) ? t : t < 0 ? Math.ceil(t) : Math.floor(t)
    }

    function ba(e, t) {
        if (t.length < e) throw new TypeError(e + ' argument' + (e > 1 ? 's' : '') + ' required, but only ' + t.length + ' present')
    }

    function Ta(t) {
        ba(1, arguments);
        var n = Object.prototype.toString.call(t);
        return t instanceof Date || 'object' === e(t) && '[object Date]' === n ? new Date(t.getTime()) : 'number' == typeof t || '[object Number]' === n ? new Date(t) : new Date(NaN)
    }

    function Aa(t, n) {
        if (ba(2, arguments), !n || 'object' !== e(n)) return new Date(NaN);
        var r = n.years ? wa(n.years) : 0,
            i = n.months ? wa(n.months) : 0,
            a = n.weeks ? wa(n.weeks) : 0,
            o = n.days ? wa(n.days) : 0,
            c = n.hours ? wa(n.hours) : 0,
            u = n.minutes ? wa(n.minutes) : 0,
            s = n.seconds ? wa(n.seconds) : 0,
            d = Ta(t),
            l = i || r ? function(e, t) {
                ba(2, arguments);
                var n = Ta(e),
                    r = wa(t);
                if (isNaN(r)) return new Date(NaN);
                if (!r) return n;
                var i = n.getDate(),
                    a = new Date(n.getTime());
                return a.setMonth(n.getMonth() + r + 1, 0), i >= a.getDate() ? a : (n.setFullYear(a.getFullYear(), a.getMonth(), i), n)
            }(d, i + 12 * r) : d,
            v = o || a ? function(e, t) {
                ba(2, arguments);
                var n = Ta(e),
                    r = wa(t);
                return isNaN(r) ? new Date(NaN) : r ? (n.setDate(n.getDate() + r), n) : n
            }(l, o + 7 * a) : l,
            f = 1e3 * (s + 60 * (u + 60 * c));
        return new Date(v.getTime() + f)
    }
    var Sa = (e => (e.SMS = 'sms', e.EMAIL = 'email', e.AGE_GATE = 'age_gate', e.METADATA_TEXT = 'metadata_text', e))(Sa || {}),
        Oa = (e => (e.PARTIAL = 'partial', e.FULLSCREEN = 'fullscreen', e))(Oa || {});
    Ia.enGB, Ia.enFR, Ia.enBE, Ia.enCH, Ia.enDE, Ia.enDK, Ia.enES, Ia.enIT, Ia.enNL, Ia.enNO, Ia.enPL, Ia.enPT, Ia.enSE, Ia.frFR, Ia.frBE, Ia.frCA, Ia.frCH, Ia.enIE, Ia.itIT, Ia.nlNL, Ia.ptPT, Ia.ptBR, Ia.esES, Ia.svSE, Ia.deDE, Ia.nlBE, Ia.deCH, Ia.plPL, Ia.noNO, Ia.daDK;
    const La = {
            backgroundColor: '#000000',
            backgroundColorInverted: '#FFFFFF',
            inputBorderColor: '#979797',
            bubbleBackgroundColor: '#000000',
            buttonColor: '#E91220',
            fontColor: '#FFFFFF',
            fontColorInverted: '#000000',
            inactive: 'rgba(0,0,0,0.3)',
            placeholderColor: '#767676',
            transparent: 'transparent'
        },
        Na = {
            xs: '1rem',
            sm: '1.25rem',
            md: '1.5rem',
            lg: '4.5rem',
            bubble: '1.12rem',
            countdownDisplay: '4rem',
            countdownSeperator: '2rem',
            countdownLabel: '1rem',
            legal: '0.625rem',
            input: '0.75rem',
            success: '2.5rem',
            successMobilePartial: '1.75rem',
            successMobileFullscreen: '2rem',
            smsCtaSubheader: '0.9375rem',
            emailSmsCtaSubheader: '0.8125rem',
            wheel: '0.5rem'
        },
        Pa = e => `%{translationOverride:${e}}`;
    var Ra = (e => (e.visitor = 'RELATIVE', e.global = 'ABSOLUTE', e))(Ra || {}),
        ka = (e => (e.DAYS = 'DAYS', e.HOURS = 'HOURS', e.MINUTES = 'MINUTES', e.SECONDS = 'SECONDS', e))(ka || {});
    Ca.EST;
    La.fontColorInverted, La.fontColor, Na.md, La.backgroundColor;
    La.fontColorInverted, La.fontColor, Na.md, La.backgroundColor;
    La.fontColor, La.backgroundColor, La.fontColorInverted, La.fontColor, Na.md, La.backgroundColor;
    La.fontColor, La.backgroundColor, Na.bubble, La.backgroundColor;
    La.fontColorInverted, La.backgroundColor, Na.countdownLabel;
    La.fontColorInverted, Na.countdownSeperator, La.fontColorInverted, Na.countdownSeperator;
    var Da = (e => (e.DESKTOP = 'DESKTOP', e.ON_SITE = 'ON_SITE', e.LANDING_PAGE = 'LANDING_PAGE', e.LEGAL = 'LEGAL', e.INTEGRATION = 'INTEGRATION', e.TEXT_TO_JOIN = 'TEXT_TO_JOIN', e.MANUAL_UPLOAD = 'MANUAL_UPLOAD', e))(Da || {}),
        xa = (e => (e.DYNAMIC = 'DYNAMIC', e.CONVERSATIONAL = 'CONVERSATIONAL', e.PRIVACY = 'PRIVACY', e.TERMS = 'TERMS', e.COUPON_DISPLAY_SCREEN = 'COUPON_DISPLAY_SCREEN', e.NO_SHOW = 'NO_SHOW', e.SHOPIFY_CHECKOUT = 'SHOPIFY_CHECKOUT', e.SHOPIFY_CHECKOUT_TRANSACTIONAL = 'SHOPIFY_CHECKOUT_TRANSACTIONAL', e.SHOPIFY_CHECKOUT_EMAIL = 'SHOPIFY_CHECKOUT_EMAIL', e.UNSUBSCRIBE = 'UNSUBSCRIBE', e.RECHARGE_CHECKOUT = 'RECHARGE_CHECKOUT', e.RECHARGE_CHECKOUT_TRANSACTIONAL = 'RECHARGE_CHECKOUT_TRANSACTIONAL', e.AFFILIATE_ENDPOINT = 'AFFILIATE_ENDPOINT', e.OFFER_DISPLAY = 'OFFER_DISPLAY', e.CODE = 'CODE', e.LANDING_PAGE = 'LANDING_PAGE', e.FULL_SCREEN = 'FULL_SCREEN', e.EMAIL_FULL_SCREEN = 'EMAIL_FULL_SCREEN', e.BUBBLE_FULL_SCREEN = 'BUBBLE_FULL_SCREEN', e.EMAIL_BUBBLE_FULL_SCREEN = 'EMAIL_BUBBLE_FULL_SCREEN', e.PARTIAL = 'PARTIAL', e.EMAIL_PARTIAL = 'EMAIL_PARTIAL', e.BUBBLE_PARTIAL = 'BUBBLE_PARTIAL', e.EMAIL_BUBBLE_PARTIAL = 'EMAIL_BUBBLE_PARTIAL', e.BUBBLE = 'BUBBLE', e.LIGHTBOX = 'LIGHTBOX', e.LIGHTBOX_BUBBLE = 'LIGHTBOX_BUBBLE', e.EMAIL_LIGHTBOX = 'EMAIL_LIGHTBOX', e.EMAIL_WIZARD = 'EMAIL_WIZARD', e.MANUAL_ENTRY = 'MANUAL_ENTRY', e.PRODUCT_DISPLAY = 'PRODUCT_DISPLAY', e))(xa || {}),
        Ba = (e => (e.LEFT = 'left', e.CENTER = 'center', e.RIGHT = 'right', e.JUSTIFY = 'justify', e))(Ba || {});
    Pa('defaultTextValues.headers.mobilePartialHeader1'), Na.sm, La.fontColor, Pa('defaultTextValues.headers.mobilePartialHeader2'), Na.xs, La.fontColor, Pa('defaultTextValues.headers.desktopPartialHeader1'), Na.sm, La.fontColor, Pa('defaultTextValues.headers.desktopSmsPartialHeader2'), Na.xs, La.fontColor;
    Ea.BLOCK, _a.WARNING, Pa('defaultTextValues.headers.cdsHeader'), Na.md, La.fontColor, Pa('defaultTextValues.headers.cdsPrefHeader'), Na.md, La.fontColor, Pa('defaultTextValues.headers.cdsEmailGateHeader'), Na.md, La.fontColor, Pa('defaultTextValues.headers.cdsSubHeader'), Na.xs, La.fontColor, Na.xs, La.fontColor, Pa('defaultTextValues.headers.cdsEmailGateSubHeader'), Na.xs, La.fontColor;
    var Ma = (e => (e.OPEN = 'OPEN', e.IMPRESSION = 'IMPRESSION', e.LEAD = 'LEAD', e.EMAIL_LEAD = 'EMAIL_LEAD', e.CLOSE = 'CLOSE', e.EXPAND = 'EXPAND', e.SHRINK = 'SHRINK', e.DETECT_EXIT_INTENT = 'DETECT_EXIT_INTENT', e.SET_COOKIE = 'SET_COOKIE', e.RESIZE_FRAME = 'RESIZE_FRAME', e.CREATIVE_PAGE_VIEW = 'CREATIVE_PAGE_VIEW', e.ADD_TO_CART = 'ADD_TO_CART', e))(Ma || {}),
        Ua = (e => (e.GOOGLE_ANALYTICS_4 = 'GOOGLE_ANALYTICS_4', e.GOOGLE_ANALYTICS = 'GOOGLE_ANALYTICS', e.FACEBOOK_PIXEL = 'FACEBOOK_PIXEL', e.NORTHBEAM_PIXEL = 'NORTHBEAM_PIXEL', e.DATALAYER_PUSH = 'DATALAYER_PUSH', e))(Ua || {});
    Ua.GOOGLE_ANALYTICS_4, Ua.GOOGLE_ANALYTICS, Ua.FACEBOOK_PIXEL, Ua.NORTHBEAM_PIXEL, Ua.DATALAYER_PUSH, Ua.GOOGLE_ANALYTICS_4, Ua.GOOGLE_ANALYTICS, Ua.FACEBOOK_PIXEL, Ua.NORTHBEAM_PIXEL, Ua.DATALAYER_PUSH;
    const Fa = {
        [Ua.GOOGLE_ANALYTICS_4]: {
            [Ma.IMPRESSION]: {
                name: 'impression',
                reportPageType: !1
            },
            [Ma.EMAIL_LEAD]: {
                name: 'submitEmail',
                reportEmail: !1,
                reportPageType: !1
            },
            [Ma.LEAD]: {
                name: 'submitSMS',
                reportPageType: !1
            },
            [Ma.CLOSE]: {
                name: 'close',
                reportPageType: !1
            },
            [Ma.EXPAND]: {
                name: 'expand',
                reportPageType: !1
            }
        },
        [Ua.GOOGLE_ANALYTICS]: {
            [Ma.IMPRESSION]: {
                name: 'impression'
            },
            [Ma.EMAIL_LEAD]: {
                name: 'submitEmail',
                reportEmail: !1
            },
            [Ma.LEAD]: {
                name: 'submitSMS'
            },
            [Ma.CLOSE]: {
                name: 'close'
            },
            [Ma.EXPAND]: {
                name: 'expand'
            }
        },
        [Ua.FACEBOOK_PIXEL]: {
            [Ma.IMPRESSION]: {
                name: 'ViewContent'
            },
            [Ma.EMAIL_LEAD]: {
                name: 'Contact',
                reportEmail: !1
            },
            [Ma.LEAD]: {
                name: 'Lead'
            },
            [Ma.CLOSE]: {
                name: 'Close'
            },
            [Ma.EXPAND]: {
                name: 'Expand'
            }
        },
        [Ua.NORTHBEAM_PIXEL]: {
            [Ma.EMAIL_LEAD]: {
                name: 'submitEmail',
                reportEmail: !0
            },
            [Ma.LEAD]: {
                name: 'submitSMS',
                reportPhone: !0
            }
        },
        [Ua.DATALAYER_PUSH]: {
            [Ma.IMPRESSION]: {
                name: 'impression'
            },
            [Ma.EMAIL_LEAD]: {
                name: 'submitEmail',
                reportEmail: !1
            },
            [Ma.LEAD]: {
                name: 'submitSMS'
            },
            [Ma.CLOSE]: {
                name: 'close'
            },
            [Ma.EXPAND]: {
                name: 'expand'
            }
        }
    };

    function Ha(e) {
        const t = {
            enabled: !1,
            id: '',
            reportCreative: !0,
            eventOptions: Fa[e]
        };
        if (e === Ua.GOOGLE_ANALYTICS) t.eventCategory = 'Attentive';
        return t
    }
    for (const e in Ua) Ha(e);
    var Va = (e => (e.BUBBLE = 'bubble', e.FIELD_CAPTURE = 'field_capture', e.SUCCESS = 'success', e.COUPON = 'coupon', e.EMAIL_GATE = 'email_gate', e.SPIN_TO_WIN = 'spin_to_win', e.OFFER_WHEEL = 'offer_wheel', e.EXISTING_SUBSCRIBER = 'existing_subscriber', e.LIVE_SMS = 'live_sms', e.PREVIEW_TOOLTIP = 'preview_tooltip', e.UNSUBSCRIBE = 'unsubscribe', e.PRE_ENGAGEMENT = 'pre_engagement', e.MYSTERY_OFFER = 'mystery_offer', e.EXISTING_SUBSCRIBER_EXPERIMENT = 'existing_subscriber_experiment', e.SCRATCH_OFF = 'scratch_off', e))(Va || {});
    var ja = (e => (e.LEFT = 'left', e.RIGHT = 'right', e))(ja || {}),
        Ga = (e => (e.TOP = 'top', e.BOTTOM = 'bottom', e))(Ga || {});
    ha.BubbleStyles;
    const qa = {
        color: La.fontColor,
        backgroundColor: La.backgroundColor,
        backgroundOpacity: '100%',
        transparentBackground: !1,
        size: Na.legal,
        font: 0,
        alignment: Ba.JUSTIFY
    };
    ((e, t) => {
        const n = [];
        if (void 0 === e.active || e.active) {
            const r = {
                v: 2,
                styles: {
                    color: e.textConfig ? .color,
                    backgroundColor: e.textConfig ? .backgroundColor,
                    backgroundOpacity: e.textConfig ? .backgroundOpacity,
                    transparentBackground: e.textConfig ? .transparentBackground,
                    fontSize: e.textConfig ? .size,
                    font: e.textConfig ? .font,
                    textAlign: e.textConfig ? .alignment ? ? Ba.JUSTIFY,
                    marginTop: e ? .marginTop,
                    marginBottom: e ? .marginBottom
                },
                content: {
                    customContent: e.content ? .customContent,
                    optionalLink: e.content ? .optionalLink
                },
                placement: Boolean(!e.displayBelowInputs) || t ? 'below-headers' : 'below-inputs'
            };
            e.checkbox ? .active && (r.checkbox = {
                border: e.checkbox ? .border,
                checkColor: e.checkbox ? .checkColor,
                icon: e.checkbox ? .icon,
                active: !0
            }), n.push(r)
        }
        if (e.content ? .additionalLegalText) {
            const t = {
                v: 2,
                styles: {
                    color: e.additionalLegalTextConfig ? .color || e.textConfig ? .color,
                    backgroundColor: e.additionalLegalTextConfig ? .backgroundColor || e.textConfig ? .backgroundColor,
                    backgroundOpacity: e.additionalLegalTextConfig ? .backgroundOpacity || e.textConfig ? .backgroundOpacity,
                    transparentBackground: e.additionalLegalTextConfig ? .transparentBackground ? ? e.textConfig ? .transparentBackground,
                    fontSize: e.additionalLegalTextConfig ? .size || e.textConfig ? .size,
                    font: e.additionalLegalTextConfig ? .font || e.textConfig ? .font,
                    textAlign: (e.additionalLegalTextConfig ? .alignment || e.textConfig ? .alignment) ? ? Ba.JUSTIFY
                },
                placement: 'below-buttons',
                content: {
                    customContent: e.content ? .additionalLegalText
                }
            };
            n.push(t)
        }
        return n
    })({
        textConfig: qa,
        content: {},
        additionalLegalTextConfig: qa
    }, !0)[0];
    const Ya = {
        previewTooltipActive: !0,
        previewTooltipPageRule: {
            delay: {
                value: 5,
                enabled: !0
            }
        },
        previewTooltipTargeting: 1,
        tooltipText: 'Need help?',
        displayPageRule: {
            delay: {
                value: 3,
                enabled: !0
            }
        },
        displayPageTargeting: 2,
        welcomeMessage: 'Have a question for our experts? We\'re here to help.',
        submitButtonText: 'TEXT US FOR HELP',
        secondarySubmitButtonText: 'and to sign up for texts',
        legalText: {
            textConfig: { ...qa,
                color: '#3C3C3C',
                backgroundColor: '#FFFFFF'
            },
            content: {}
        }
    };
    var $a;
    Va.LIVE_SMS, (e => {
        const t = { ...Ya
        };
        e && (t.phoneInput = 'Your phone number', t.submitButtonText = 'GET HELP', t.secondarySubmitButtonText = 'and sign me up for texts')
    })($a), Sa.SMS;
    const Wa = e => e.subType === xa.CONVERSATIONAL && (e.type === Da.ON_SITE || e.type === Da.DESKTOP),
        Ja = ['overlay', 'support', 'embedded'],
        Ka = ['immediately', 'delay', 'scroll', 'exitIntent', 'backInStock', 'pdpPrice', 'addToCart'],
        Xa = e => !!e && e.includes('TEXT');
    var za = (e => (e.SOURCE = 'source', e.CAMPAIGN = 'campaign', e.CONTENT = 'content', e.MEDIUM = 'medium', e.TERM = 'term', e))(za || {});

    function Za(e) {
        return 'ct' in e && 'canvas' === e.ct
    }
    const Qa = '__attentive_email_creativeFilter';
    var eo = (e => (e.OVERLAY_DATA = 'OVERLAY_DATA', e.EXIT_INTENT = 'EXIT_INTENT', e))(eo || {});
    const to = e => {
            const t = new Date;
            return t.setTime(t.getTime() + 1e3 * e), t
        },
        no = () => to(1800),
        ro = window;
    class io {
        MAX_AGE;
        MAX_AGE_DAYS;
        userId;
        __attentive_domain;
        constructor() {
            const e = ro.__attentive_cfg && ro.__attentive_cfg.gdpr;
            this.MAX_AGE = e ? 33696e3 : 189216e4, this.MAX_AGE_DAYS = Math.round(this.MAX_AGE / 86400), this.userId = null, this.__attentive_domain = ro.__attentive_domain
        }
        getId() {
            return this.userId || this.setId(), this.userId
        }
        rotateId() {
            this.userId = null, R('__attentive_id'), R('__attentive_cco'), this.setId()
        }
        getCookie = e => document.cookie.replace(new RegExp(`(?:(?:^|.*;\\s*)${e}\\s*=\\s*([^;]*).*$)|^.*$`), '$1');
        createImg = e => {
            new Image(1, 1).src = `https://${this.__attentive_domain}${e}`
        };
        setId = () => {
            const e = '__attentive_cco',
                {
                    getQueryParam: t,
                    getCookie: n,
                    createImg: r
                } = this,
                i = n('__attentive_id'),
                a = n(e),
                o = t('attn-vid') || t('visitorId'),
                c = t('attn-sid') || t('subscriberId'),
                u = t('attn-eid') || t('externalId'),
                s = t('altid'),
                d = Boolean(i),
                l = this.userId;
            let v = !1;
            if (a) try {
                const e = new Date(Number(a) + 1e3 * this.MAX_AGE),
                    t = new Date;
                e.valueOf() - t.valueOf() < 2592e6 && (v = !0)
            } catch (e) {}
            d || null == o ? i && o ? (this.userId = i, o !== i && r(`/sv?qid=${o}&cid=${i}`)) : ln && null !== localStorage.getItem('__attentive_id') ? (this.userId = localStorage.getItem('__attentive_id'), localStorage.removeItem('__attentive_id')) : this.userId = !i && !o || v ? vn() : i : this.userId = o, c ? r(`/sv?sid=${c}&cid=${this.userId}`) : s ? r(u ? `/sv?altid=${s}&seid=${u}&cid=${this.userId}` : `/sv?altid=${s}&cid=${this.userId}`) : u ? r(`/sv?seid=${u}&cid=${this.userId}`) : i && v && r(`/sv?qid=${i}&cid=${this.userId}`), l !== this.userId && this.userId && P('__attentive_id', this.userId, {
                expires: this.MAX_AGE_DAYS
            }), a && !v || P(e, String(Date.now()), {
                expires: this.MAX_AGE_DAYS
            })
        };
        getQueryParam = e => {
            const {
                queryParams: t
            } = this;
            return t(ro.location.search, e) || t(ro.location.hash, e)
        };
        queryParams(e, t) {
            let n = null;
            return e.substring(1).split('&').forEach((e => {
                const r = e.split('=');
                r[0] === t && (n = r[1])
            })), n
        }
    }
    const ao = {
            klaviyo: () => window._learnq && window._learnq.isIdentified,
            bouncex: () => window.bouncex && window.bouncex.var
        },
        oo = {
            klaviyo: () => window._learnq && window._learnq.isIdentified && window._learnq.isIdentified instanceof Function && window._learnq.isIdentified(),
            bouncex: () => Boolean(window.bouncex && window.bouncex.vars) && window.bouncex.vars.email_submitted_attentive
        };

    function co(e) {
        for (const t in e) void 0 === e[t] && delete e[t];
        return e
    }
    const uo = ro.__attentive_cfg && ro.__attentive_cfg.esms && ro.__attentive_cfg.esms in ao,
        so = uo && ao[ro.__attentive_cfg.esms],
        lo = uo && oo[ro.__attentive_cfg.esms],
        vo = uo && so instanceof Function && lo instanceof Function,
        fo = async () => {
            if (vo) {
                const e = async () => await new Promise((e => {
                    const t = setInterval((() => {
                        if (so()) {
                            clearInterval(t);
                            const n = Qa,
                                r = !!lo();
                            P(n, JSON.stringify(r), {
                                expires: no()
                            }), e()
                        }
                    }), 200);
                    setTimeout((() => {
                        clearInterval(t), e()
                    }), 3e3)
                }));
                await e()
            }
        },
        po = e => -1 !== document.cookie.indexOf(e),
        go = e => {
            return (e => {
                if (!e) {
                    if (O('__attentive_iss')) return !0;
                    if (window.location.search.includes('externalId=')) return P('__attentive_iss', 'true', {
                        expires: no()
                    }), !0
                }
                return !1
            })(e.ENABLE_SUBSCRIBER_CREATIVES) || !(!(n = e.REQUIRED_COOKIE) || n.every(po)) || (e => {
                if (e) {
                    const {
                        key: t,
                        value: n
                    } = e, r = O(t);
                    return void 0 !== n ? r === n : void 0 !== r
                }
                return !1
            })(e.DISALLOWED_COOKIES) || !!(t = e.DISALLOWED_PROPERTIES) && t() || !!e.SHOULD_BLOCK_PWA_DISPLAY_MODE && window.matchMedia('(display-mode: standalone)').matches || ((e, t) => {
                if (window.innerWidth >= 760 ? Boolean(e) : Boolean(t)) return 0 === document.cookie.replace(/(?:(?:^|.*;\s*)__attentive_id\s*=\s*([^;]*).*$)|^.*$/, '$1').length;
                return !1
            })(e.BOUNCE_X_DESKTOP_CUSTOMER, e.BOUNCE_X_CUSTOMER);
            var t, n
        },
        mo = e => new Promise((t => setTimeout(t, e))),
        yo = async e => {
            if (e) {
                const {
                    thirdPartyVariable: t,
                    timeout: n
                } = e, r = n || 1e3;
                await (async (e, t) => {
                    for (; !e();) await mo(t)
                })(t, r)
            }
        };
    var ho = (e => (e[e.SHOW = 0] = 'SHOW', e[e.DO_NOT_SHOW = 1] = 'DO_NOT_SHOW', e[e.HIDE_INITIAL = 2] = 'HIDE_INITIAL', e))(ho || {});
    const _o = (e, t, n) => !1 !== e && t !== Va.BUBBLE && n !== Oa.PARTIAL,
        Eo = 'aria-hidden',
        Co = new Map;
    let Io = !1;

    function wo(e) {
        if ('attentive_overlay' === e.id) return !0;
        const t = e.tagName.toUpperCase();
        return 'META' === t || ('SCRIPT' === t || ('STYLE' === t || 'INPUT' === t && 'hidden' === e.type))
    }

    function bo() {
        for (const [e, t] of Array.from(Co.entries())) wo(e) || t.processed || (t.processed = !0, e.setAttribute(Eo, 'true'))
    }

    function To() {
        for (const [e, t] of Array.from(Co.entries())) wo(e) || t.processed && (t.processed = !1, t.ariaHidden ? e.setAttribute(Eo, t.ariaHidden) : e.removeAttribute(Eo))
    }
    const Ao = () => {
        Io = !1, To()
    };
    const So = new MutationObserver((e => {
        for (const t of e)
            if ('attributes' === t.type) {
                if (!Io) continue;
                const e = t.target;
                if ('true' === e.getAttribute(Eo)) continue;
                Co.delete(e)
            }
        const t = Array.from(document ? .body ? .children ? ? []);
        ! function(e) {
            for (const t of e) Co.has(t) || Co.set(t, {
                ariaHidden: t.getAttribute(Eo),
                processed: !1
            });
            Io ? bo() : To()
        }(t),
        function(e) {
            for (const t of e) So.observe(t, {
                attributeFilter: [Eo]
            })
        }(t)
    }));
    try {
        document && So.observe(document.body, {
            childList: !0
        })
    } catch (e) {}
    const Oo = () => /Safari/.test(navigator.userAgent),
        Lo = (e, t) => e.slice(0, t.length) === t,
        No = () => {
            const e = {};
            return document.cookie.split('; ').forEach((t => {
                if (Lo(t, '__attentive')) {
                    const [n, ...r] = t.split('=');
                    e[n] = r.join('')
                }
            })), e
        },
        Po = (e, t) => {
            if (t.innerHeight >= t.documentHeight) return !0;
            const n = (e => Math.abs(e.top) / (e.documentHeight - e.innerHeight) * 100)(t),
                r = e.value;
            return r && n + 1 >= r
        },
        Ro = e => !!e ? .exitIntent ? .enabled,
        ko = (e, t, n) => {
            const r = (e => e.find((e => 'type' in e && e.type === Va.BUBBLE)))(e);
            if (void 0 === r) return !1;
            const i = t && parseInt(t),
                a = 'fields' in r ? r ? .fields : void 0,
                o = parseInt(a ? .showBubblePV || '');
            if (void 0 === a ? .showBubblePV || !i || !n) return !0;
            const c = i && n && Math.abs(i - parseInt(n)) + 1;
            return Boolean(c && c >= o)
        },
        Do = e => {
            if (!e ? .length) return !1;
            const t = e && e.find((e => e.type === Va.BUBBLE)),
                n = t && t.fields;
            return !!(n && n.countdownSection && n.countdownSection.active)
        },
        xo = (e, t) => {
            let n = new Date;
            switch (e) {
                case ka.DAYS:
                    n = Aa(n, {
                        days: Number(t)
                    });
                    break;
                case ka.HOURS:
                    n = Aa(n, {
                        hours: Number(t)
                    });
                    break;
                case ka.MINUTES:
                    n = Aa(n, {
                        minutes: Number(t)
                    });
                    break;
                case ka.SECONDS:
                    n = Aa(n, {
                        seconds: Number(t)
                    })
            }
            return n.toISOString()
        },
        Bo = e => {
            const t = '__attentive_timer';
            if (!O(t) && e ? .enabled && e ? .type === Ra.visitor && e ? .durationUnit && e ? .durationValue) {
                P(t, xo(e.durationUnit, e.durationValue))
            }
        },
        Mo = () => /iPhone|iPad|iPod/.test(navigator.userAgent),
        Uo = window.matchMedia('(max-width: 480px)'),
        Fo = /(android|bb\d+|meego).+mobile|avantgo|bada\/|blackberry|blazer|compal|elaine|fennec|hiptop|iemobile|ip(hone|od)|iris|kindle|lge |maemo|midp|mmp|mobile.+firefox|netfront|opera m(ob|in)i|palm( os)?|phone|p(ixi|re)\/|plucker|pocket|psp|series(4|6)0|symbian|treo|up\.(browser|link)|vodafone|wap|windows ce|xda|xiino/i,
        Ho = /1207|6310|6590|3gso|4thp|50[1-6]i|770s|802s|a wa|abac|ac(er|oo|s-)|ai(ko|rn)|al(av|ca|co)|amoi|an(ex|ny|yw)|aptu|ar(ch|go)|as(te|us)|attw|au(di|-m|r |s )|avan|be(ck|ll|nq)|bi(lb|rd)|bl(ac|az)|br(e|v)w|bumb|bw-(n|u)|c55\/|capi|ccwa|cdm-|cell|chtm|cldc|cmd-|co(mp|nd)|craw|da(it|ll|ng)|dbte|dc-s|devi|dica|dmob|do(c|p)o|ds(12|-d)|el(49|ai)|em(l2|ul)|er(ic|k0)|esl8|ez([4-7]0|os|wa|ze)|fetc|fly(-|_)|g1 u|g560|gene|gf-5|g-mo|go(\.w|od)|gr(ad|un)|haie|hcit|hd-(m|p|t)|hei-|hi(pt|ta)|hp( i|ip)|hs-c|ht(c(-| |_|a|g|p|s|t)|tp)|hu(aw|tc)|i-(20|go|ma)|i230|iac( |-|\/)|ibro|idea|ig01|ikom|im1k|inno|ipaq|iris|ja(t|v)a|jbro|jemu|jigs|kddi|keji|kgt( |\/)|klon|kpt |kwc-|kyo(c|k)|le(no|xi)|lg( g|\/(k|l|u)|50|54|-[a-w])|libw|lynx|m1-w|m3ga|m50\/|ma(te|ui|xo)|mc(01|21|ca)|m-cr|me(rc|ri)|mi(o8|oa|ts)|mmef|mo(01|02|bi|de|do|t(-| |o|v)|zz)|mt(50|p1|v )|mwbp|mywa|n10[0-2]|n20[2-3]|n30(0|2)|n50(0|2|5)|n7(0(0|1)|10)|ne((c|m)-|on|tf|wf|wg|wt)|nok(6|i)|nzph|o2im|op(ti|wv)|oran|owg1|p800|pan(a|d|t)|pdxg|pg(13|-([1-8]|c))|phil|pire|pl(ay|uc)|pn-2|po(ck|rt|se)|prox|psio|pt-g|qa-a|qc(07|12|21|32|60|-[2-7]|i-)|qtek|r380|r600|raks|rim9|ro(ve|zo)|s55\/|sa(ge|ma|mm|ms|ny|va)|sc(01|h-|oo|p-)|sdk\/|se(c(-|0|1)|47|mc|nd|ri)|sgh-|shar|sie(-|m)|sk-0|sl(45|id)|sm(al|ar|b3|it|t5)|so(ft|ny)|sp(01|h-|v-|v )|sy(01|mb)|t2(18|50)|t6(00|10|18)|ta(gt|lk)|tcl-|tdg-|tel(i|m)|tim-|t-mo|to(pl|sh)|ts(70|m-|m3|m5)|tx-9|up(\.b|g1|si)|utst|v400|v750|veri|vi(rg|te)|vk(40|5[0-3]|-v)|vm40|voda|vulc|vx(52|53|60|61|70|80|81|83|85|98)|w3c(-| )|webc|whit|wi(g |nc|nw)|wmlb|wonu|x700|yas-|your|zeto|zte-/i,
        Vo = /android|ipad|playbook|silk/i,
        jo = {
            nokia: /nokia|lumia/
        },
        Go = {
            genericTab: /tablet/
        };
    const qo = window,
        Yo = () => {
            const e = qo ? .attn_d0x0b_cfg;
            if (e) {
                const t = atob(e);
                return JSON.parse(t).bctu
            }
        },
        $o = (e = 'default') => {
            const t = {
                default: ro.__attentive_cfg && ro.__attentive_cfg.zi,
                disable: ro.__attentive_cfg && ro.__attentive_cfg.zd,
                enable: ro.__attentive_cfg && ro.__attentive_cfg.ze
            };
            return ro.__attentive_cfg && t[e]
        },
        Wo = (e, t) => {
            const n = document.createElement('div');
            return n.style.position = 'fixed', n.style.left = '0', n.style.bottom = '0', n.style.width = '100vw', n.style.height = '0', n.style.setProperty('z-index', (e => {
                if (e && e.shouldApplyZIndex && e.zIndex) return String(e.zIndex);
                return $o('default') || '9223372036854775807'
            })(t.CONDITIONAL_Z_INDEX_MAP) || null), n.style.setProperty('color-scheme', 'none'), n.id = e, n
        },
        Jo = e => !!(e.offsetWidth || e.offsetHeight || e.getClientRects().length) && 'hidden' !== ro.getComputedStyle(e).visibility,
        Ko = e => {
            const t = e || document.documentElement;
            return {
                top: t.scrollTop || document.body.scrollTop || window.pageYOffset,
                documentHeight: t.scrollHeight || document.body.scrollHeight,
                innerHeight: window.innerHeight
            }
        },
        Xo = '__attn_exit_intent_triggered',
        zo = () => void 0 !== O(Xo),
        Zo = () => {
            const e = new Date(Date.now() + 36e5);
            P(Xo, 'true', {
                expires: e
            })
        },
        Qo = (e, t) => {
            const n = r => {
                    r.clientY > 50 || (t(), e.removeEventListener('mousemove', n))
                },
                r = setTimeout((() => {
                    e.addEventListener('mousemove', n)
                }), 3e3);
            return () => {
                e.removeEventListener('mousemove', n), clearTimeout(r)
            }
        },
        ec = (e, t, n) => Math.abs(e) / (t - n) * 100,
        tc = (e, t, n) => {
            let r, i = 0;
            n && (r = e.querySelector(n) ? ? void 0);
            const a = kr((() => {
                const {
                    top: n,
                    documentHeight: o,
                    innerHeight: c
                } = Ko(r);
                ec(n, o, c) > 50 && (0 === n && (i = 0), n > i ? i = n : ec(n - i, o, c) > 3 && (t(), e.removeEventListener('touchmove', a)))
            }), o = 120, {
                leading: !0,
                trailing: !0,
                maxWait: o,
                ...c
            });
            var o, c;
            return e.addEventListener('touchmove', a), () => e.removeEventListener('touchmove', a)
        },
        nc = () => {
            const e = (() => {
                    const e = performance.getEntriesByType('resource').filter((e => 'script' === e.initiatorType && e.name.includes('dtag.js'))).sort(((e, t) => e.startTime - t.startTime));
                    if (e.length > 0) {
                        const t = e[0];
                        return {
                            start: t.fetchStart,
                            end: t.responseEnd
                        }
                    }
                })(),
                t = (() => {
                    const e = performance.getEntriesByType('mark');
                    return {
                        tagLoaded: e.find((e => e.name === w.TagCoreLoaded)),
                        tagCreativesLoaded: e.find((e => e.name === w.TagCreativesLoaded))
                    }
                })(),
                n = {
                    dtagStart: e ? .start,
                    dtagEnd: e ? .end,
                    tagLoaded: t.tagLoaded ? .startTime,
                    tagCreativesLoaded: t.tagCreativesLoaded ? .startTime
                };
            if (!(() => {
                    const e = ro.__attentive_cfg && ro.__attentive_cfg.lt && ('1' === ro.__attentive_cfg.lt || '2' === ro.__attentive_cfg.lt);
                    return Boolean(e || vo)
                })()) {
                const e = performance.getEntriesByName(w.FetchCreativesStart, 'mark'),
                    t = performance.getEntriesByName(w.FetchCreativesEnd, 'mark');
                if (e.length > 1 || t.length > 1) return {};
                e.length > 0 && (n.fetchCreativesStart = e[0].startTime), t.length > 0 && (n.fetchCreativesEnd = t[0].startTime)
            }
            return n
        },
        rc = () => {
            const e = ro.__attentive_domain;
            if (ln && e) {
                const t = ro.localStorage.getItem('attn_pdp');
                if (t) {
                    const n = JSON.parse(atob(t));
                    if (n[e]) return !0 === Array.isArray(n[e]) ? n[e] : [n[e]]
                }
            }
        },
        ic = function(e) {
            e.preventDefault(), e.stopPropagation()
        },
        {
            toggleScrollLock: ac,
            getCurrentValue: oc
        } = (() => {
            let e, t = !1;
            return {
                toggleScrollLock: n => {
                    if (t = n, n) {
                        if (!e) {
                            e = window.pageYOffset;
                            try {
                                const t = parseInt(getComputedStyle(document.body).height, 10) - (e + window.visualViewport.height);
                                t < 0 && window.scrollBy({
                                    top: t
                                })
                            } catch {}
                        }
                        document.body.style.overflow = 'hidden', document.body.style.position = 'absolute', document.body.style.top = -e + 'px', document.body.style.left = '0', document.body.style.right = '0', document.body.style.bottom = '0', document.body.style.height = 'unset', document.documentElement.style.overflow = 'hidden', document.documentElement.style.position = 'absolute', document.documentElement.style.top = '0', document.documentElement.style.left = '0', document.documentElement.style.right = '0', document.documentElement.style.bottom = '0'
                    } else document.body.style.removeProperty('overflow'), document.body.style.removeProperty('position'), document.body.style.removeProperty('top'), document.body.style.removeProperty('left'), document.body.style.removeProperty('right'), document.body.style.removeProperty('bottom'), document.body.style.removeProperty('height'), document.documentElement.style.removeProperty('overflow'), document.documentElement.style.removeProperty('position'), document.documentElement.style.removeProperty('top'), document.documentElement.style.removeProperty('left'), document.documentElement.style.removeProperty('right'), document.documentElement.style.removeProperty('bottom'), void 0 !== e && e >= 0 && (window.scrollTo({
                        top: e,
                        behavior: 'instant'
                    }), e = void 0)
                },
                getCurrentValue: () => t
            }
        })();

    function cc(e, t) {
        e.ENABLE_SCROLLING_NO_STYLING || (e.ENABLE_SCROLLING_CUSTOM_STYLING_NO_SCROLL_LOCK ? e.ENABLE_SCROLLING_CUSTOM_STYLING_NO_SCROLL_LOCK() : oc() && (ac(!1), t.style.setProperty('z-index', $o('enable') || '9223372036854775807', 'important'), e.ENABLE_SCROLLING_CUSTOM_STYLING_WITH_SCROLL_LOCK && e.ENABLE_SCROLLING_CUSTOM_STYLING_WITH_SCROLL_LOCK())), document.body.removeEventListener('touchmove', ic)
    }
    const uc = async (e, t) => {
        if (window.Shopify ? .routes ? .root) {
            const n = {
                items: [{
                    id: e,
                    quantity: t
                }]
            };
            try {
                if ((await fetch(`${window.Shopify?.routes?.root||'/'}cart/add.js`, {
                        method: 'POST',
                        headers: {
                            'Content-Type': 'application/json'
                        },
                        body: JSON.stringify(n)
                    })).ok) return 'success'
            } catch (e) {}
        }
    };

    function sc(e, t, n) {
        const {
            action: r,
            thirdPartyAnalytics: i
        } = e, a = i && i[t];
        if (!a || !a.enabled) return;
        const o = a.eventOptions ? .[r],
            c = o ? .name || Fa[t] ? .[Ma[r]] ? .name;
        if (void 0 === c) return;
        const u = a.reportCreative && 'creativeId' in e ? e.creativeId : void 0,
            s = o && 'reportEmail' in o && o.reportEmail && 'email' in e ? e.email : void 0,
            d = 'email' in e ? e.email : void 0,
            l = 'phone' in e ? e.phone : void 0,
            v = 'closeType' in e ? e.closeType : void 0,
            f = 'eventCategory' in a ? a.eventCategory : void 0,
            p = o && 'reportPageType' in o && o.reportPageType,
            g = r === Ma.IMPRESSION && p && 'pageType' in e ? e.pageType : p && 'impressionPageType' in e ? e.impressionPageType : void 0;
        if (t === Ua.GOOGLE_ANALYTICS_4) {
            const e = {
                source: 'Attentive',
                creative_id: u,
                creative_type: g,
                email: s
            };
            if (ro.gtag) {
                const t = n.GA4_CUSTOM_EVENT_FORMATTING;
                ro.gtag('event', c, co(t ? t(e) : e))
            } else ro.dataLayer && ro.dataLayer.push(co({ ...e,
                event: c
            }))
        }
        t === Ua.GOOGLE_ANALYTICS && (ro.ga ? ro.ga((() => {
            const e = ro.ga ? .getAll();
            e && e.length && e[0].send('event', f || 'Attentive', c, co({
                eventLabel: u,
                dimension1: s,
                dimension2: v,
                nonInteraction: r === Ma.IMPRESSION
            }))
        })) : ro.gtag && ro.gtag('event', c, co({
            event_category: f,
            event_label: u,
            dimension1: s,
            dimension2: v,
            non_interaction: r === Ma.IMPRESSION
        }))), t === Ua.FACEBOOK_PIXEL && ro.fbq && ro.fbq('track', c, co({
            creativeId: u,
            email: s,
            closeType: v
        })), t === Ua.NORTHBEAM_PIXEL && ro.Northbeam && (r === Ma.EMAIL_LEAD && d ? ro.Northbeam.fireEmailCaptureEvent(d, 'Attentive') : r === Ma.LEAD && l && ro.Northbeam.fireCustomGoal(`phone_capture: ${l}`, {})), t === Ua.DATALAYER_PUSH && (ro.dataLayer = ro.dataLayer || [], ro.dataLayer.push(co({
            event: c,
            source: 'Attentive',
            creative_id: u,
            email: s
        })))
    }
    const dc = '__attentive_vf';

    function lc() {
        return O(dc)
    }
    const vc = {
        marketing: {
            overlayElementID: 'attentive_overlay',
            creativeContainerID: 'attentive_creative',
            creativeContainerTitle: 'Sign Up via Text for Offers',
            useCustomEventHandling: !0
        },
        'live-sms': {
            overlayElementID: 'attentive_live_sms_overlay',
            creativeContainerID: 'attentive_live_sms_creative',
            creativeContainerTitle: 'Get real-time support via SMS',
            useCustomEventHandling: !1
        },
        backInStock: {
            overlayElementID: 'attentive_overlay',
            creativeContainerID: 'attentive_creative',
            creativeContainerTitle: 'Sign Up via Text for Offers',
            useCustomEventHandling: !0
        },
        topBar: {
            overlayElementID: 'attentive_top_bar_overlay',
            creativeContainerID: 'attentive_top_bar_creative',
            creativeContainerTitle: 'Sign Up via Text for Offers',
            useCustomEventHandling: !0
        },
        pdpPrice: {
            overlayElementID: 'attentive_pdp_price_overlay',
            creativeContainerID: 'attentive_pdp_price_creative',
            creativeContainerTitle: 'Sign Up via Text for Offers',
            useCustomEventHandling: !0
        }
    };
    class fc {
        clientConfig;
        userId;
        lastElementInFocus = null;
        email = null;
        creativeContainer;
        overlayElement;
        loaded = !1;
        shouldResetIFrame;
        initialBottom = 0;
        requireRepaintOnOpen = !1;
        shouldDisableScroll = !1;
        attentiveConfig;#
        e;
        useCustomEventHandling = !1;
        windowEvent;
        onLoadFunction;
        constructor(e, t, n, r, i, a) {
            this.clientConfig = e, this.useCustomEventHandling = a, this.userId = t;
            const o = Wo(n, e),
                c = ((e, t, n) => {
                    const r = document.createElement('iframe');
                    r.style.width = '100%', r.style.height = '0', r.style.position = 'absolute', r.style.bottom = '0', r.style.opacity = '0', r.style.transition = 'opacity 500ms', r.style.border = '0', r.style.overflow = 'hidden', r.style.visibility = 'hidden', r.allowTransparency = 'true', r.referrerPolicy = 'origin', r.id = e, r.allow = 'clipboard-write';
                    const i = n.IFRAME_CLASS;
                    i && i(r);
                    const a = ro ? .__attentive_cfg ? .iframeTitle;
                    return r.title = a || t, r
                })(r, i, e);
            var u;
            o.appendChild(c), this.creativeContainer = c, this.overlayElement = o, this.shouldResetIFrame = Mo() && Oo() && !!document.querySelector('meta[name=apple-itunes-app]'), this.shouldResetIFrame && (this.creativeContainer.style.transition = 'opacity 500ms, bottom 150ms ease-in-out', this.handleIFramePlacement()), this.show = this.show.bind(this), this.hide = this.hide.bind(this), this.orientationChangeHandler = this.orientationChangeHandler.bind(this), this.refocusEventListener = this.refocusEventListener.bind(this), this.windowEvent = (u = this.clientConfig ? .CUSTOM_WINDOW_EVENTS, u && document.querySelector(u) || ro)
        }
        creativeEventHandler = async e => {
            if (e.data && Object.prototype.hasOwnProperty.call(e.data, '__attentive')) {
                const t = e.data.__attentive;
                if (t.creativeId !== this.attentiveConfig ? .trackingParams ? .creativeId) return;
                const n = e.ports;
                ! function(e, t) {
                    const n = e.thirdPartyAnalytics;
                    for (const r in n) {
                        const i = n[r];
                        i ? .enabled && sc(e, r, t)
                    }
                }(t, this.clientConfig);
                let r = !1;
                const i = this.attentiveConfig ? .trackingParams.creativeId,
                    a = this.attentiveConfig ? .trackingParams ? .countdownTimerFilter,
                    o = d(),
                    c = _();
                switch (t.action) {
                    case Ma.OPEN:
                        r = _o(this.clientConfig.ada, t.pageType, t.layout), r && (Io = !0, bo()), this.useCustomEventHandling && this.clientConfig.CUSTOM_OPEN_EVENTS && this.clientConfig.CUSTOM_OPEN_EVENTS(t), this.openCreative(t);
                        break;
                    case Ma.CLOSE:
                        this.creativeContainer.style.opacity = '0', r = _o(this.clientConfig.ada), setTimeout((() => {
                            this.hide(i), this.resetFocusOnCreativeClose()
                        }), 500), r && Ao(), this.useCustomEventHandling && this.clientConfig.CUSTOM_CLOSE_EVENTS && this.clientConfig.CUSTOM_CLOSE_EVENTS(t), t.shouldSetViewFatigueCookie && (lc() || P(dc, 'true', {
                            expires: to(86400)
                        }));
                        break;
                    case Ma.LEAD:
                        o && (o.setAttribute('data-signup-complete', 'true'), v(o)), c && (c.setAttribute('data-signup-complete', 'true'), I(c)), this.useCustomEventHandling && await (async (e, t) => {
                            e.CUSTOM_LEAD_EVENTS && await e.CUSTOM_LEAD_EVENTS(t)
                        })(this.clientConfig, t), ro.__attentive_cfg && '1' === ro.__attentive_cfg.sdj && function({
                            phone: e,
                            creativeId: t
                        }) {
                            try {
                                window.sd && (window.sd.identify('', {
                                    phone_number: e
                                }), window.sd.track('registration', {
                                    phone_number: e,
                                    properties: {
                                        creativeId: t
                                    }
                                }))
                            } catch (e) {}
                        }(t), n ? .length && n[0] && n[0].postMessage('custom logic completed'), (({
                            phone: e
                        }) => {
                            qo ? .edgetag && Yo() && e && qo.edgetag('user', 'phone', e)
                        })(t);
                        break;
                    case Ma.ADD_TO_CART:
                        n ? .length && n[0] && n[0].postMessage({
                            message: 'success' === await uc(t.variantId, t.quantity) ? 'success' : 'failure',
                            variantId: t.variantId
                        });
                        break;
                    case Ma.IMPRESSION:
                        this.useCustomEventHandling && this.clientConfig.CUSTOM_IMPRESSION_EVENTS && this.clientConfig.CUSTOM_IMPRESSION_EVENTS(t), this.forwardEmail(t);
                        break;
                    case Ma.EMAIL_LEAD:
                        this.useCustomEventHandling && this.clientConfig.CUSTOM_EMAIL_LEAD_EVENTS && this.clientConfig.CUSTOM_EMAIL_LEAD_EVENTS(t), ro.__attentive_cfg && '1' === ro.__attentive_cfg.klv && (({
                            email: e
                        }) => {
                            window._learnq && window._learnq.push(['identify', {
                                $email: e
                            }])
                        })(t), ro.__attentive_cfg && '1' === ro.__attentive_cfg.wpm && function({
                            email: e
                        }) {
                            window.postMessage({
                                func: 'wrPush',
                                message: e
                            }, '*')
                        }(t), ro.__attentive_cfg && '1' === ro.__attentive_cfg.ges && window.geq && window.geq.suppress(), ro.__attentive_cfg && '1' === ro.__attentive_cfg.oma && (({
                            email: e
                        }) => {
                            window.ometria && window.ometria.identify && window.ometria.identify(e)
                        })(t), ro.__attentive_cfg && '1' === ro.__attentive_cfg.lcses && function({
                            email: e
                        }) {
                            try {
                                window.localStorage.setItem('_attn_', JSON.stringify({
                                    email: e
                                }))
                            } catch (e) {}
                        }(t), ro.__attentive_cfg && '1' === ro.__attentive_cfg.sdes && function({
                            email: e,
                            creativeId: t
                        }) {
                            try {
                                window.sd && (window.sd.identify('', {
                                    email: e
                                }), window.sd.track('registration', {
                                    email: e,
                                    properties: {
                                        creativeId: t
                                    }
                                }))
                            } catch (e) {}
                        }(t), (({
                            email: e
                        }) => {
                            qo ? .edgetag && Yo() && e && qo.edgetag('user', 'email', e)
                        })(t);
                        break;
                    case Ma.EXPAND:
                        this.useCustomEventHandling && this.clientConfig.CUSTOM_EXPAND_EVENTS && this.clientConfig.CUSTOM_EXPAND_EVENTS(t), a && (Bo(a), this.sendMessageToCreative(eo.OVERLAY_DATA, {
                            overlayData: this.getOverlayData()
                        }));
                        break;
                    case Ma.SHRINK:
                        r = _o(this.clientConfig.ada), r && Ao(), this.useCustomEventHandling && this.clientConfig.CUSTOM_SHRINK_EVENTS && this.clientConfig.CUSTOM_SHRINK_EVENTS(t);
                        break;
                    case Ma.DETECT_EXIT_INTENT:
                        Mo() && Oo() && (this.requireRepaintOnOpen = !0), this.detectExitIntent(t, a);
                        break;
                    case Ma.SET_COOKIE:
                        (({
                            cookieName: e,
                            cookieValue: t,
                            cookieAttributes: n = []
                        }) => {
                            const r = [`${Lo(e,'__attentive')?'':'__attentive'}${e}=${t}`, 'path=/', ...n].join('; ');
                            document.cookie = r
                        })(t);
                        break;
                    case Ma.RESIZE_FRAME:
                        this.applyStylesToIFrame(t.style), this.resetIFrame(t.style ? .bottom ? ? '0');
                        break;
                    case Ma.CREATIVE_PAGE_VIEW:
                        this.useCustomEventHandling && this.clientConfig.CUSTOM_CREATIVE_PAGE_VIEW_EVENTS && this.clientConfig.CUSTOM_CREATIVE_PAGE_VIEW_EVENTS(t)
                }
            }
        };
        orientationChangeHandler(e) {
            e.matches || this.hide()
        }
        focus() {
            this.clientConfig.CUSTOM_SKIP_FOCUS || this.creativeContainer.focus()
        }
        refocusEventListener() {
            this.attentiveConfig ? .creativeConfig ? .type === Da.DESKTOP && this.shouldDisableScroll && ro.setTimeout((() => {
                this.focus()
            }))
        }
        openCreative = e => {
            var t, n, r;
            this.clientConfig.CUSTOM_DISABLE_OPEN_CREATIVE && this.clientConfig.CUSTOM_DISABLE_OPEN_CREATIVE() || (!this.loaded && function() {
                const {
                    userAgent: e
                } = window.navigator, {
                    width: t
                } = window.screen, n = new RegExp(jo.nokia), r = new RegExp(Go.genericTab), i = new RegExp(Fo), a = new RegExp(Ho), o = new RegExp(Vo);
                return !r.test(e) && !(!n.test(e) && (i.test(e) || a.test(e.substr(0, 4)) ? t > 480 : (o.test(e), 1)))
            }() && Uo.addListener(this.orientationChangeHandler), this.shouldDisableScroll = e.pageType !== Va.BUBBLE && e.layout !== Oa.PARTIAL, ro.removeEventListener('focus', this.refocusEventListener), ro.addEventListener('focus', this.refocusEventListener), this.applyStylesToIFrame(e.style), this.creativeContainer.style.opacity = '1', this.creativeContainer.style.visibility = 'visible', this.shouldDisableScroll ? (t = this.clientConfig, n = this.overlayElement, t.DISABLE_SCROLLING_NO_STYLING || (t.DISABLE_SCROLLING_CUSTOM_STYLING_NO_SCROLL_LOCK ? t.DISABLE_SCROLLING_CUSTOM_STYLING_NO_SCROLL_LOCK() : (ac(!0), n.style.setProperty('z-index', $o('disable') || '9223372036854775807', 'important'), t.DISABLE_SCROLLING_CUSTOM_STYLING_WITH_SCROLL_LOCK && t.DISABLE_SCROLLING_CUSTOM_STYLING_WITH_SCROLL_LOCK())), document.body.addEventListener('touchmove', ic)) : cc(this.clientConfig, this.overlayElement), this.requireRepaintOnOpen && (r = this.overlayElement, setTimeout((() => {
                'fixed' === r.style.position && (r.style.position = 'relative', r.offsetHeight, r.style.position = 'fixed')
            }), 100)), this.resetIFrame(e.style ? .bottom ? ? '0'), e.pageType !== Va.BUBBLE && this.focus())
        };
        applyStylesToIFrame = e => {
            const t = this.clientConfig.IFRAME_CLASS;
            !t ? .(this.creativeContainer) && e && Object.assign(this.creativeContainer.style, e)
        };
        resetIFrame = e => {
            this.shouldResetIFrame && (this.initialBottom = parseInt(e, 10) || 0, ro.addEventListener('resize', this.handleIFramePlacement), this.windowEvent.addEventListener('scroll', this.handleIFramePlacement), this.handleIFramePlacement())
        };
        handleIFramePlacement = () => {
            ro.innerHeight < document.documentElement.clientHeight || (this.creativeContainer.style.bottom = `${this.initialBottom}`), this.postFrameHandler()
        };
        handleADACompliance = () => {
            this.clientConfig.ADA_COMPLIANT && (ro.addEventListener('keydown', (e => 27 === e.keyCode && this.hide()), !1), this.lastElementInFocus = document.activeElement)
        };
        resetFocusOnCreativeClose = () => {
            if (this.clientConfig.ADA_COMPLIANT)
                if (this.lastElementInFocus && 'body' !== this.lastElementInFocus.nodeName.toLowerCase() && Jo(this.lastElementInFocus)) this.lastElementInFocus.focus();
                else {
                    const e = document.querySelectorAll('a[href]:not([disabled]), button:not([disabled]), textarea:not([disabled]), input[type="text"]:not([disabled]), input[type="radio"]:not([disabled]), input[type="checkbox"]:not([disabled]), select:not([disabled])');
                    for (const t of e)
                        if (Jo(t)) {
                            t.focus();
                            break
                        }
                }
        };
        postFrameHandler = kr((() => {
            const e = Math.floor(this.creativeContainer.getBoundingClientRect().bottom) - ro.innerHeight;
            this.creativeContainer.clientHeight >= document.body.clientHeight ? this.creativeContainer.style.bottom = '0' : e > 0 && (this.creativeContainer.style.bottom = `${e+this.initialBottom}px`)
        }), 250);
        setEmail(e) {
            this.email = e
        }
        load(e) {
            ro.attnOverlayLoaded = !0;
            const t = this.clientConfig.TOP_BAR_CONTAINER_TARGET && this.clientConfig.TOP_BAR_CONTAINER_TARGET(e.attentiveConfig.trackingParams.creativeId),
                n = this.clientConfig.CONTAINER_TARGET_OVERLAY && this.clientConfig.CONTAINER_TARGET_OVERLAY(e.attentiveConfig.trackingParams.creativeId);
            t ? t.appendChild(this.creativeContainer) : n ? n.appendChild(this.overlayElement) : document ? .body ? .appendChild(this.overlayElement), this.loaded = !0
        }
        show(e) {
            this.handleADACompliance(), this.loaded || this.load(e), this.populateIframeContent(e), ro.addEventListener('resize', this.sendOverlayDataToCreative)
        }
        generateOnLoadFunction = e => () => {
            const {
                attentiveConfig: t
            } = e;
            this.#e = new MessageChannel, this.creativeContainer.contentWindow ? .postMessage('__attentiveInit', '*', [this.#e.port2]), this.sendAttentiveConfigToCreative(t)
        };
        populateIframeContent = async e => {
            const {
                creativeRendererIndexURL: t,
                attentiveConfig: n
            } = e;
            this.creativeContainer.src = t, this.iframeLoaded(), this.attentiveConfig = n, this.onLoadFunction && this.creativeContainer.removeEventListener('load', this.onLoadFunction), this.onLoadFunction = this.generateOnLoadFunction(e), this.creativeContainer.addEventListener('load', this.onLoadFunction, {
                once: !0
            })
        };
        getOverlayData = () => ({
            vendorIDs: $t([Ut, Ft, Ht, Vt, jt]),
            clientWidth: document.documentElement.clientWidth,
            performanceMetrics: nc(),
            attentiveCookies: No(),
            productViewData: rc()
        });
        sendMessageToCreative = (e, t) => {
            this.creativeContainer && this.creativeContainer.contentWindow && this.creativeContainer.contentWindow.postMessage({
                __attentive: {
                    type: e,
                    data: t
                }
            }, '*')
        };
        sendOverlayDataToCreative = kr((() => {
            this.sendMessageToCreative(eo.OVERLAY_DATA, {
                overlayData: this.getOverlayData()
            })
        }), 250);
        sendAttentiveConfigToCreative = e => {
            if (!this.#e) return;
            const t = {
                __attentiveConfig: { ...e,
                    overlayData: this.getOverlayData()
                }
            };
            this.#e.port1.postMessage(t)
        };
        sendTriggeredExitIntentToCreative = e => {
            zo() || (e && (Bo(e), this.sendMessageToCreative(eo.OVERLAY_DATA, {
                overlayData: this.getOverlayData()
            })), Zo(), this.sendMessageToCreative(eo.EXIT_INTENT, {
                hasTriggeredExitIntent: !0
            }))
        };
        detectExitIntent = (e, t) => {
            const {
                creativeType: n,
                isBubbleCreative: r
            } = e;
            r && (zo() || (n === Da.DESKTOP ? Qo(document, (() => this.sendTriggeredExitIntentToCreative(t))) : n === Da.ON_SITE && tc(document, (() => this.sendTriggeredExitIntentToCreative(t)), this.clientConfig.CUSTOM_EXIT_INTENT_SCROLL_ELEMENT_SELECTOR || '')))
        };
        iframeLoaded() {
            (e => {
                if (e.ANNOUNCE_ADA_POPUP && -1 !== document.cookie.indexOf('attn_ada_test')) {
                    const e = document.querySelector('.attentiveButton');
                    e && e.click()
                }
            })(this.clientConfig), ro && ro.getComputedStyle && 'center' === ro.getComputedStyle(this.overlayElement).textAlign && (this.overlayElement.style.textAlign = 'left')
        }
        hide(e) {
            if (e && this.attentiveConfig ? .trackingParams.creativeId && e !== this.attentiveConfig ? .trackingParams.creativeId) return;
            const t = this.clientConfig.TOP_BAR_CONTAINER_TARGET && e && this.clientConfig.TOP_BAR_CONTAINER_TARGET(e);
            t ? t.removeChild(this.creativeContainer) : this.overlayElement.parentNode && this.overlayElement.parentNode.removeChild(this.overlayElement), this.creativeContainer.src = '', this.creativeContainer.style.visibility = 'hidden', this.clientConfig.ENABLE_SCROLL_BLACKLIST_SITE || cc(this.clientConfig, this.overlayElement), Uo.removeListener(this.orientationChangeHandler), ro.removeEventListener('resize', this.sendOverlayDataToCreative), ro.removeEventListener('focus', this.refocusEventListener), this.loaded = !1
        }
        forwardEmail(e) {
            this.email && (async e => {
                const {
                    domain: t = window.__attentive_domain,
                    creativeId: n,
                    email: r,
                    visitorId: i,
                    impressionPageType: a
                } = e, o = `https://${t}/track`, c = new URLSearchParams;
                c.append('s', '1'), c.append('a', 'CLICK'), c.append('id', i), c.append('e', r), a && c.append('pt', a), n && c.append('c', n);
                const u = O('_attn_bopd_');
                u && c.append('abs', u);
                const s = $t([Ut, Ft, Ht, Vt, jt]);
                s && c.append('cui', JSON.stringify(s)), fetch(`${o}?${c}`, {
                    method: 'GET',
                    mode: 'no-cors'
                })
            })({
                email: this.email,
                creativeId: e.creativeId,
                visitorId: `${this.userId}`,
                impressionPageType: e.pageType
            })
        }
    }
    const pc = '__attn_atc_triggered',
        gc = ({
            pageView: e,
            pageviewRuleLowerBound: t,
            bubbleMultiPage: n,
            bubbleCanvasPage: r
        }) => {
            const i = parseInt(e);
            let a = 0;
            if (n) {
                const e = n.fields;
                a = parseInt(e.showBubblePV || '')
            }
            r && (a = parseInt(r.showBubblePV || ''));
            return Math.abs(i - parseInt(t)) + 1 >= a
        },
        mc = e => {
            const {
                firstPageDisplayed: t,
                pageview: n,
                pageviewRuleLowerBound: r
            } = e.trackingParams;
            let i = e.creativeConfig,
                a = !1;
            if (e.creativeConfig ? .subType === xa.DYNAMIC)
                if (Za(e.creativeConfig)) {
                    const o = Object.values(e.creativeConfig.pages).find((e => 'type' in e && e.type === Va.BUBBLE));
                    if (o)
                        if (t) {
                            if (!('BUBBLE' === t) && o.nextPage) {
                                const t = e.creativeConfig,
                                    n = o.id,
                                    r = o.nextPage;
                                delete t.pages[n], t.firstPageId = r, a = !0, i = t
                            }
                        } else {
                            if (!!!lc() && n && r) {
                                const {
                                    configWithSkippedBubblePage: t,
                                    hasSkippedBubblePage: c
                                } = (({
                                    pageView: e,
                                    pageviewRuleLowerBound: t,
                                    creativeConfig: n,
                                    bubblePage: r
                                }) => {
                                    const i = n,
                                        a = gc({
                                            pageView: e,
                                            pageviewRuleLowerBound: t,
                                            bubbleCanvasPage: r
                                        });
                                    if (!a && r.nextPage) {
                                        const e = r.id,
                                            t = r.nextPage;
                                        delete i.pages[e], i.firstPageId = t
                                    }
                                    return {
                                        configWithSkippedBubblePage: i,
                                        hasSkippedBubblePage: !a
                                    }
                                })({
                                    pageView: n,
                                    pageviewRuleLowerBound: r,
                                    creativeConfig: e.creativeConfig,
                                    bubblePage: o
                                });
                                a = c, i = t
                            }
                        }
                } else {
                    const o = e.creativeConfig.pages.find((e => e.type === Va.BUBBLE));
                    if (o)
                        if (t) {
                            if (!('BUBBLE' === t)) {
                                const t = e.creativeConfig;
                                t.pages = t.pages.filter((e => e.type !== Va.BUBBLE)), a = !0, i = t
                            }
                        } else {
                            if (!!!lc() && n && r) {
                                const {
                                    configWithSkippedBubblePage: t,
                                    hasSkippedBubblePage: c
                                } = (({
                                    pageView: e,
                                    pageviewRuleLowerBound: t,
                                    creativeConfig: n,
                                    bubblePage: r
                                }) => {
                                    const i = n,
                                        a = gc({
                                            pageView: e,
                                            pageviewRuleLowerBound: t,
                                            bubbleMultiPage: r
                                        });
                                    return a || (i.pages = i.pages.filter((e => e.type !== Va.BUBBLE))), {
                                        configWithSkippedBubblePage: i,
                                        hasSkippedBubblePage: !a
                                    }
                                })({
                                    pageView: n,
                                    pageviewRuleLowerBound: r,
                                    creativeConfig: e.creativeConfig,
                                    bubblePage: o
                                });
                                a = c, i = t
                            }
                        }
                }
            return {
                filteredCreativePagesConfig: i,
                skippedBubblePage: a
            }
        },
        yc = (e, t, n, r) => {
            const {
                overlayElementID: i,
                creativeContainerID: a,
                creativeContainerTitle: o,
                useCustomEventHandling: c
            } = vc[r];
            let u, d = -1,
                p = [];
            const y = new fc(e, t.getId(), i, a, o, c),
                _ = e => {
                    const t = parseInt(e.attentiveConfig.trackingParams.creativeId, 10);
                    n.registerCreativeMessageHandler(t, y.creativeEventHandler), y.show(e)
                },
                C = e => {
                    const t = parseInt(e.attentiveConfig.trackingParams.creativeId, 10);
                    n.registerCreativeMessageHandler(t, y.creativeEventHandler), y.load(e), d = t
                },
                w = (r, i = {}) => {
                    const a = (o = r, JSON.parse(JSON.stringify(o)));
                    var o;
                    const {
                        email: c,
                        hideInitialView: w,
                        skipLoadingRestrictions: b,
                        previouslyLoaded: T,
                        trigger: A = 'immediately',
                        initiator: S
                    } = i, L = parseInt(a.attentiveConfig.trackingParams.creativeId, 10);
                    (() => {
                        const e = y.attentiveConfig ? .trackingParams ? .creativeId;
                        e && n.unregisterCreativeMessageHandler(parseInt(e, 10))
                    })();
                    const {
                        attentiveConfig: N
                    } = a, {
                        filteredCreativePagesConfig: P,
                        skippedBubblePage: R
                    } = mc(N);
                    if (N.creativeConfig = P, N.creativeParams.skippedBubblePage = R, N.creativeParams.displayTrigger = A, N.creativeParams.initiator = S, N.creativeParams.adblockerStatus = O('_attn_bopd_'), void 0 !== c && y.setEmail(c), b) return T ? void _(a) : (C(a), void(d === L && _(a)));
                    const k = async () => {
                            const t = await (async e => (await Promise.all([fo(), yo(e.SHOULD_DELAY_OVERLAY_THIRDPARTY)]), ro.__attentive_cfg && '1' === ro.__attentive_cfg.lt ? 1 : ro.__attentive_cfg && '2' === ro.__attentive_cfg.lt ? ro.attnOverlayHidden ? 1 : 2 : go(e) ? 1 : 0))(e);
                            t !== ho.DO_NOT_SHOW && (C(a), d !== L || w || _(a))
                        },
                        D = () => {
                            const n = a.attentiveConfig.displayRules,
                                r = {
                                    immediately: () => {
                                        k()
                                    },
                                    delay: () => {
                                        const e = (e => {
                                                if (e ? .delay ? .enabled && Number(e.delay.value)) return e ? .delay
                                            })(n),
                                            t = setTimeout(k, 1e3 * (e ? .value ? ? 0));
                                        p.push((() => clearTimeout(t)))
                                    },
                                    scroll: () => {
                                        const t = (e => {
                                            if (e ? .scroll ? .enabled && Number(e.scroll.value) > -1) return e ? .scroll
                                        })(n);
                                        if (Number(t ? .value) > -1) {
                                            const n = () => {
                                                const r = e ? .CUSTOM_WINDOW_EVENTS && document.querySelector(e.CUSTOM_WINDOW_EVENTS) || void 0,
                                                    i = Ko(r);
                                                (0 === t ? .value || t && i && Po(t, i)) && (k(), ro.removeEventListener('scroll', n))
                                            };
                                            ro.addEventListener('scroll', n), n(), p.push((() => ro.removeEventListener('scroll', n)))
                                        }
                                    },
                                    exitIntent: () => {
                                        const t = Ro(n),
                                            r = a.attentiveConfig.trackingParams.countdownTimerFilter;
                                        if (t) {
                                            const t = a.attentiveConfig.creativeConfig,
                                                {
                                                    pageview: n,
                                                    pageviewRuleLowerBound: i
                                                } = a.attentiveConfig.trackingParams,
                                                {
                                                    type: o
                                                } = t;
                                            let c = !1,
                                                u = !1;
                                            if (Za(t)) {
                                                const e = Object.values(t.pages).find((e => 'type' in e && e.type === Va.BUBBLE));
                                                e && (c = ((e, t, n) => {
                                                    const r = t && parseInt(t),
                                                        i = parseInt(e.showBubblePV);
                                                    if (!r || !n) return !0;
                                                    const a = r && n && Math.abs(r - parseInt(n)) + 1;
                                                    return Boolean(a && a >= i)
                                                })(e, n, i))
                                            } else c = ko(t.pages, n, i), u = Do(t.pages);
                                            const s = () => {
                                                if (Zo(), r ? .enabled && r.type === Ra.visitor) return Bo(r), void k();
                                                k()
                                            };
                                            if (c) u && r && r ? .enabled && r ? .type === Ra.visitor && Bo(r), k();
                                            else {
                                                if (zo()) return;
                                                if (o === Da.DESKTOP) {
                                                    const e = Qo(document, s);
                                                    p.push(e)
                                                }
                                                if (o === Da.ON_SITE) {
                                                    const t = tc(document, s, e.CUSTOM_EXIT_INTENT_SCROLL_ELEMENT_SELECTOR || '');
                                                    p.push(t)
                                                }
                                            }
                                        }
                                    },
                                    backInStock: () => {
                                        const e = a.attentiveConfig.creativeConfig;
                                        if ('customTrigger' in e && 'backInStock' === e.customTrigger ? .type) {
                                            const n = document.getElementById('attn-waitlist-trigger');
                                            if (n) {
                                                const r = Xa(a.attentiveConfig.trackingParams.subscriberChannels),
                                                    i = l(e.customTrigger, r);
                                                i.onclick = async () => {
                                                    const e = n.getAttribute('data-product-id'),
                                                        o = n.getAttribute('data-variant-id');
                                                    if (e && o) {
                                                        const n = new URLSearchParams;
                                                        n.append('c', a.attentiveConfig.trackingParams.creativeId), n.append('id', t.getId() ? ? ''), await fetch(`https://${ro.__attentive_domain}/user-input-collection?${n.toString()}`, {
                                                                method: 'POST',
                                                                body: JSON.stringify({
                                                                    waitlistEnrollment: {
                                                                        productId: e,
                                                                        variantId: o
                                                                    }
                                                                })
                                                            }),
                                                            function({
                                                                productId: e,
                                                                variantId: t
                                                            }) {
                                                                const n = f();
                                                                if (n && e && t) {
                                                                    const r = g({
                                                                            productId: e,
                                                                            variantId: t
                                                                        }),
                                                                        i = m();
                                                                    i.includes(r) || i.push(r), n.setAttribute(s, i.join(','))
                                                                }
                                                            }({
                                                                productId: e,
                                                                variantId: o
                                                            });
                                                        const c = 'true' === i.getAttribute('data-signup-complete');
                                                        r || c ? v(i) : (C(a), _(a))
                                                    }
                                                }, n.appendChild(i)
                                            }
                                        }
                                    },
                                    pdpPrice: () => {
                                        const e = a.attentiveConfig.creativeConfig;
                                        if ('customTrigger' in e && 'pdpPrice' === e.customTrigger ? .type) {
                                            const t = document.getElementById(h);
                                            if (t) {
                                                const n = E(e.customTrigger);
                                                n.onclick = async () => {
                                                    Xa(a.attentiveConfig.trackingParams.subscriberChannels) || 'true' === n.getAttribute('data-signup-complete') ? I(n) : (C(a), _(a))
                                                }, t.appendChild(n)
                                            }
                                        }
                                    },
                                    addToCart: () => {
                                        u = a
                                    }
                                };
                            a.attentiveConfig.creativeConfig && !Za(a.attentiveConfig.creativeConfig) && ((e, t, n) => {
                                const r = Ro(t),
                                    i = e.attentiveConfig.trackingParams.countdownTimerFilter,
                                    a = Do(n);
                                if (!r && i ? .enabled && i ? .type === Ra.visitor) {
                                    const {
                                        pageview: t,
                                        pageviewRuleLowerBound: r
                                    } = e.attentiveConfig.trackingParams;
                                    n && t && r && ko(n, t, r) ? a && Bo(i) : Bo(i)
                                }
                            })(a, n, a.attentiveConfig.creativeConfig.pages);
                            return r[A](), {
                                triggerAddToCartCreative: r.addToCart
                            }
                        },
                        x = e.SHOULD_DELAY_OVERLAY_CUSTOM;
                    if (x) return void x(D);
                    const {
                        triggerAddToCartCreative: B
                    } = D();
                    return {
                        triggerAddToCartCreative: B
                    }
                };
            return {
                showCreative: w,
                showCreatives: (e, t) => {
                    Ka.forEach((n => {
                        const r = e[n];
                        r && w(r, { ...t,
                            trigger: n
                        })
                    }))
                },
                hideCreatives: () => {
                    y.hide(), p.forEach((e => e())), p = []
                },
                triggerAddToCartCreative: () => {
                    const e = u;
                    if (!e) return;
                    let t = 'page',
                        n = 0;
                    const r = e.attentiveConfig.displayRules ? .addToCart,
                        {
                            trackingParams: i
                        } = e.attentiveConfig;
                    if (r ? .enabled && r.config && r.config.firstPage && r.config.frequency ? (t = r.config.frequency, n = parseInt(r.config.firstPage, 10)) : i.aiCreativeRules && (t = 'session', n = 8), 'session' === t && void 0 !== O(pc)) return;
                    if (i.pageview && parseInt(i.pageview, 10) < n) return;
                    e.attentiveConfig.trackingParams.firstPageDisplayed = 'FIELD_CAPTURE';
                    const {
                        attentiveConfig: a
                    } = e, {
                        filteredCreativePagesConfig: o,
                        skippedBubblePage: c
                    } = mc(a);
                    a.creativeConfig = o, a.creativeParams.skippedBubblePage = c, C(e), _(e), u = void 0, (() => {
                        const e = new Date(Date.now() + 18e5);
                        P(pc, 'true', {
                            expires: e
                        })
                    })()
                }
            }
        },
        hc = () => {
            const e = new Map,
                t = t => {
                    if (!(n = t).data || !Object.prototype.hasOwnProperty.call(n.data, '__attentive')) return;
                    var n;
                    const {
                        data: {
                            __attentive: {
                                creativeId: r
                            }
                        }
                    } = t, i = e.get(parseInt(r, 10));
                    i && i(t)
                };
            window.removeEventListener('message', t), window.addEventListener('message', t);
            return {
                registerCreativeMessageHandler: (t, n) => {
                    e.set(t, n)
                },
                unregisterCreativeMessageHandler: t => {
                    e.delete(t)
                },
                removeEventListener: () => {
                    window.removeEventListener('message', t)
                }
            }
        },
        _c = async e => {
            if (e) {
                const {
                    interval: t,
                    conditionCheck: n,
                    maxTime: r
                } = e;
                await (async (e, t, n) => {
                    const r = n ? xo(ka.SECONDS, n) : null;
                    for (;
                        (!r || (new Date).toISOString() <= r) && !e();) await mo(t)
                })(n, t, r)
            }
        };
    let Ec = e => new Promise((t => {
        setTimeout((() => {
            const n = document.createElement('script');
            n.type = 'text/javascript', n.src = `https://cdn.attn.tv/growth-tag-assets/client-configs/${e}.js`, n.setAttribute('async', 'true'), n.onload = () => {
                const e = ro.__attentive_client_cfg;
                return t(e || null)
            }, n.onerror = () => t(null);
            ((document.getElementsByTagName('head') || [null])[0] || document.getElementsByTagName('script')[0].parentNode).appendChild(n)
        }))
    }));
    ({}).VITE_LOCAL_CLIENT_CONFIG && (require(`../client-configs/${{}.VITE_LOCAL_CLIENT_CONFIG}`), Ec = async e => ro.__attentive_client_cfg ? ? {});
    const Cc = async () => {
            const e = (() => {
                const e = {},
                    t = ro ? .attn_d0x0b_cfg;
                if (t) {
                    const n = atob(t),
                        r = JSON.parse(n);
                    e.creativesConfig = r.cc, e.externalCompanyId = r.ceid
                }
                return e
            })();
            return { ...e.externalCompanyId ? await (async e => await Ec(e) || {})(e.externalCompanyId) : {},
                ...e.creativesConfig
            }
        },
        Ic = '__attentive_ss_referrer',
        wc = 'ORGANIC',
        bc = () => {
            const e = O(Ic) ? ? null;
            if (e) return e;
            const t = document.referrer || wc;
            return P(Ic, t, {
                expires: no()
            }), t
        };

    function Tc(e) {
        if (!e.includes('?')) return {};
        return e.slice(e.indexOf('?') + 1).split('&').reduce(((e, t) => {
            const [n, r] = t.split('=');
            return e[n] = r, e
        }), {})
    }

    function Ac(e) {
        const t = Tc(location.search);
        return t[e] ? t[e] : null
    }
    const Sc = 'utm_',
        Oc = '__attentive_utm_param_',
        Lc = () => {
            const e = {};
            for (const t of Object.values(za)) {
                const n = O(`${Oc}${t}`);
                n && (e[t] = n)
            }
            return e
        },
        Nc = (e, t) => {
            const n = {};
            Array.isArray(e.cook) && e.cook.forEach((e => {
                const t = O(e);
                void 0 !== t && (n[e] = t)
            }));
            return {
                cookies: n,
                utmParams: Lc(),
                productIds: (() => {
                    const e = localStorage.getItem('attn_pdp');
                    if (e) try {
                        const t = JSON.parse(atob(e)),
                            n = Object.values(t)[0];
                        return n.map((e => parseInt(e.sku))).filter((e => !isNaN(e)))
                    } catch (e) {}
                })(),
                pd: (() => {
                    const e = {
                        adblocked: 1,
                        browser: 2,
                        unknown: 3
                    }[O('_attn_bopd_')];
                    if (e) return e
                })(),
                ...t !== wc && {
                    referrer: t
                }
            }
        },
        Pc = '__attentive_pv';

    function Rc() {
        const e = parseInt(O(Pc) ? ? '', 10);
        return e || 0
    }
    const kc = e => {
            let t;
            e && (t = e());
            const n = (() => {
                if (uo) {
                    const e = O(Qa);
                    return !!e && 'false' !== e
                }
            })();
            return n && (t = n), Boolean(t)
        },
        Dc = e => {
            try {
                if (e) return e()
            } catch {
                return
            }
        },
        xc = e => {
            let t;
            if (e.app) t = (() => {
                try {
                    return new URLSearchParams(window.location.search).get('debug')
                } catch (e) {
                    return null
                }
            })();
            else if (e.DEBUG_PASSWORD) return t
        },
        Bc = e => {
            const {
                customFilterParam: t,
                anonymousId: n,
                creativeID: r,
                clientConfig: i,
                userId: a,
                targets: o,
                triggers: c
            } = e, u = new URLSearchParams;
            u.append('v', '4.39.19'), u.append('r', window.top.document.referrer), u.append('id', `${a}`), u.append('pv', `${Rc()}`), u.append('l', window.top.document.location.href);
            const {
                deviceWidth: s,
                deviceHeight: d
            } = (e => {
                let t = window.innerWidth,
                    n = window.innerHeight;
                if (e) {
                    const {
                        width: r,
                        height: i
                    } = e();
                    t = r, n = i
                }
                return {
                    deviceWidth: t,
                    deviceHeight: n
                }
            })(i.CUSTOM_DEVICE_SIZE);
            u.append('w', `${s}`), u.append('h', `${d}`);
            const l = bc();
            l && u.append('ss_ref', `${l}`);
            const v = ((e, t) => {
                let n;
                return t && (n = t()), n = e || n, n
            })(n, i.ANON_ID_PARAMS);
            v && u.append('a', v);
            const f = ((e, t) => {
                let n;
                return t && (n = t()), n = e || n, n && 'string' == typeof n && (n = n.replace(/"/g, '')), n
            })(t, i.GET_CREATIVE_FILTER_PARAM);
            f && u.append('s', `${f}`);
            const p = kc(i.GET_EMAIL_CREATIVE_FILTER_PARAM);
            p && u.append('hasEmail', `${p}`), r && u.append('force_show_creative', `${r}`);
            const g = Ac('ignore_filters');
            g && u.append('ignore_filters', g);
            const m = (() => {
                const e = O('__attentive_timer');
                if (e && new Date > new Date(e)) return !0;
                return !1
            })();
            m && u.append('rct_exp', `${m}`), o && o.forEach((e => {
                u.append('ta', e)
            })), c && c.forEach((e => {
                u.append('tr', e)
            }));
            const y = Ac('attn-eid') || Ac('externalId');
            y && u.append('seid', y);
            const h = Ac('altid');
            h && u.append('altid', h);
            const _ = xc(i);
            return _ && u.append('debug', _), u.append('f', '2'), u
        },
        Mc = e => decodeURIComponent((e || '').replace(/\+/g, ' ')),
        Uc = (e, t) => {
            const n = {},
                r = ro.__attentive_domain || '',
                i = e => {
                    const i = ((e, t, n) => ({
                            creativeConfig: e.creativeConfig && JSON.parse(e.creativeConfig),
                            companyMetadata: {
                                companyName: Mc(e.companyName),
                                displayName: Mc(e.displayName),
                                companyUrl: e.companyUrl,
                                customerPrivacyLink: e.privacyLink,
                                customerTermsLink: e.customerTermsLink,
                                attentivePrivacyLink: e.attentivePrivacyLink,
                                attentiveTermsLink: e.termsLink,
                                allAttentiveTermsLinks: e.allAttentiveTermsLinks || {},
                                emailAddress: e.emailAddress,
                                companyAddress: e.companyAddress,
                                country: e.country,
                                language: e.language,
                                companyPhone: e.companyPhone
                            },
                            displayRules: e.displayRules,
                            creativeParams: {
                                showEmail: e.showEmail ? 'true' : 'false'
                            },
                            trackingParams: {
                                attnDomain: t,
                                attentiveAPI: e.attentiveAPI,
                                impressionId: e.impressionId,
                                creativeId: e.creativeId,
                                creativeName: e.creativeConfig && JSON.parse(e.creativeConfig) ? .base ? .fields ? .creativeName,
                                userId: e.userId,
                                isSubscriber: e.isSubscriber,
                                hasEmail: kc(n.GET_EMAIL_CREATIVE_FILTER_PARAM),
                                userEmail: Dc(n.GET_EMAIL_CREATIVE_PARAM),
                                subscriberChannels: e.subscriberChannels,
                                companyExternalId: e.encodedCompanyExternalId,
                                sourceUrl: e.sourceUrl,
                                environment: e.environment,
                                anonymousId: e.anonymousId,
                                encodedSubscriberExternalId: e.encodedSubscriberExternalId,
                                templateId: 'string' == typeof e.templateId ? parseInt(e.templateId, 10) : void 0,
                                pageview: 'null' === e.pageview ? void 0 : e.pageview,
                                pageviewRuleLowerBound: 'null' === e.pageviewRuleLowerBound ? void 0 : e.pageviewRuleLowerBound,
                                countdownTimerFilter: e.countdownTimerFilter,
                                productVariants: e.productVariants,
                                firstPageDisplayed: e.firstPageDisplayed,
                                aiCreativeRules: e.aiCreativeRules
                            },
                            deciders: e.deciders || {},
                            overrides: {}
                        }))(e.renderingFields, r, t),
                        a = Ka.filter((e => i.displayRules && i.displayRules[e] ? .enabled));
                    a.length || a.push('immediately');
                    const o = (e => Wa(e.creativeConfig) ? 'support' : ['63206', '441976'].includes(e.trackingParams.creativeId) ? 'embedded' : 'overlay')(i),
                        c = n[o] ? ? {};
                    a.forEach((t => {
                        c[t] = {
                            attentiveConfig: i,
                            creativeRendererIndexURL: e.contentUrl
                        }
                    })), n[o] = c
                };
            if ((e => 'renderingFields' in e)(e)) i(e);
            else if ((e => 'creatives' in e)(e)) {
                const {
                    creatives: {
                        marketing: t,
                        'live-sms': n,
                        topBar: r
                    }
                } = e;
                t && t.length > 0 && i(t[0]), n && n.length > 0 && i(n[0]), r && r.length > 0 && i(r[0])
            } else Ja.forEach((t => {
                const n = e.targets[t];
                n && Ka.forEach((e => {
                    const t = n[e];
                    t && i(t)
                }))
            }));
            return n
        },
        Fc = (e, t) => {
            const n = JSON.parse(JSON.stringify(e)),
                r = Object.values(n.pages).find((e => 'type' in e && e.type === Va.BUBBLE));
            if (r) {
                const e = r.styles;
                void 0 === e.bottom && void 0 !== e.top || ((e, t) => {
                    switch (t) {
                        case ja.LEFT:
                            e.left && (e.right = '5px', e.left = void 0);
                            break;
                        case ja.RIGHT:
                            e.right && (e.left = '5px', e.right = void 0)
                    }
                })(e, t)
            }
            return n
        },
        Hc = (e, t) => {
            const n = JSON.parse(JSON.stringify(e)),
                r = n.pages.find((e => 'type' in e && e.type === Va.BUBBLE));
            if (r) {
                const e = r.fields.position,
                    n = r.fields.verticalPosition;
                void 0 !== n && n !== Ga.BOTTOM || e !== t || (r.fields.position = e === ja.LEFT ? ja.RIGHT : ja.LEFT)
            }
            return n
        },
        Vc = e => {
            const t = e.support,
                n = e.overlay,
                r = e.embedded;
            if (!t || !n) return e;
            const i = (e => Ka.map((t => {
                const n = e[t] ? .attentiveConfig ? .creativeConfig;
                return n && Wa(n) ? n.base.fields.position : null
            })).find((e => null !== e)))(t);
            return i ? (Ka.forEach((e => {
                const t = n[e];
                if (!t) return;
                const {
                    creativeConfig: r
                } = t.attentiveConfig;
                r && !Wa(r) && (Za(r) ? t.attentiveConfig.creativeConfig = Fc(r, i) : t.attentiveConfig.creativeConfig = Hc(r, i), n[e] = t)
            })), {
                support: t,
                overlay: n,
                embedded: r
            }) : e
        },
        jc = async (e, t) => {
            try {
                const n = bc(),
                    r = await fetch(e, {
                        method: 'POST',
                        body: JSON.stringify({ ...Nc(t, n)
                        })
                    });
                if ('https://creatives.attn.tv' === window.location.origin && (t.app ? await (async e => {
                        try {
                            const t = await e.json(),
                                n = {
                                    status: e.status,
                                    body: t
                                };
                            window.postMessage(n, 'https://creatives.attn.tv')
                        } catch (e) {}
                    })(r.clone()) : t.ON_FETCH_CREATIVES && await t.ON_FETCH_CREATIVES(r.clone())), 200 !== r.status) return {};
                return ((e, t) => {
                    const n = Uc(e, t);
                    return Vc(n)
                })(await r.json(), t)
            } catch {
                return {}
            }
        },
        Gc = async (e, t = {}) => {
            const n = (r = {
                clientConfig: e,
                creativeID: t.creativeID ? ? null,
                customFilterParam: t.customFilterParam ? ? null,
                userId: t.userID ? ? null,
                anonymousId: t.anonymousID ? ? null,
                triggers: t.triggers,
                targets: t.targets
            }, `https://${ro.__attentive_domain}/unrenderedCreative?${Bc(r).toString()}`);
            var r;
            return jc(n, e)
        },
        qc = '__attentive_dv';

    function Yc(e) {
        const t = new Date;
        t.setTime(t.getTime() + 60 * e * 60 * 1e3), P(qc, '1', {
            expires: t
        })
    }

    function $c(e) {
        try {
            void 0 === O(qc) && async function(e) {
                return fetch(`https://${ro.__attentive_domain}/d/?attn_vid=${e.getId()}`).then((e => e.text()))
            }(e).then((t => {
                t.includes('true') && e.rotateId(), Yc(24)
            })).catch((() => {
                Yc(2)
            }))
        } catch (e) {
            Yc(2)
        }
    }
    const Wc = async () => {
        performance.mark(w.TagCreativesLoaded);
        const e = new io;
        $c(e), (e => {
            const t = Tc(e),
                n = Object.values(za);
            for (const e of Object.keys(t)) {
                const r = e.toLocaleLowerCase(),
                    i = r.substring(4);
                Lo(r, Sc) && n.includes(i) && P(`${Oc}${i}`, t[e], {
                    expires: new Date(Date.now() + 18e5)
                })
            }
        })(ro.location.search);
        const t = await Cc();
        (e => {
            if (e) {
                const {
                    cookieKey: t,
                    cookiePersistTimeInSeconds: n,
                    getCookieValue: r
                } = e, i = r();
                void 0 !== i && P(t, i, {
                    expires: to(n)
                })
            }
        })(t.SET_GENERIC_COOKIE), ((e, t) => {
            if (e && t) {
                const {
                    key: e,
                    value: n
                } = t;
                P(e, n ? ? 'true', {
                    expires: no()
                })
            }
        })(t.SHOULD_BLOCK_WITH_COOKIES, t.DISALLOWED_COOKIES), (e => {
            if (e) {
                const t = e.cookieKey || '__attentive_creativeFilter',
                    n = e.getCookieValue();
                void 0 !== n && P(t, n, {
                    expires: no()
                })
            }
        })(t.SET_CREATIVE_FILTER_SESSION_COOKIE), (e => {
            if (e) {
                const t = e();
                t && P('__attentive_client_user_id', t)
            }
        })(t.ATTENTIVE_CLIENT_USER_ID);
        let n = {};
        var r;
        r = t.ON_TAG_INITIALIZATION, r ? .();
        const i = hc(),
            a = yc(t, e, i, 'marketing'),
            o = yc(t, e, i, 'live-sms'),
            c = yc(t, e, i, 'topBar'),
            u = async (e = {}, r = {}) => {
                performance.mark(w.FetchCreativesStart);
                const i = await Gc(t, e);
                performance.mark(w.FetchCreativesEnd);
                const {
                    overlay: u,
                    support: s,
                    embedded: d
                } = i;
                u ? a.showCreatives(u, r) : '2' === ro.__attentive_cfg ? .lt && n.overlay && a.showCreatives(n.overlay, r), s && o.showCreatives(s, {
                    skipLoadingRestrictions: !0
                }), d && c.showCreatives(d, {
                    skipLoadingRestrictions: !0
                }), n = i
            },
            s = () => {
                a.hideCreatives()
            },
            d = async () => {
                ! function() {
                    const e = Rc();
                    P(Pc, `${e+1}`, {
                        expires: no()
                    })
                }(), s();
                const n = (e => {
                        const t = {
                            userID: e.getId()
                        };
                        if (location.href.includes('attn_creative_id=')) {
                            const {
                                attn_creative_id: e
                            } = Tc(location.href);
                            t.creativeID = parseInt(e, 10)
                        }
                        return t.targets = [], t.triggers = [], t
                    })(e),
                    r = {
                        email: null,
                        initiator: 'attn',
                        skipLoadingRestrictions: Boolean(n.creativeID) || ro.attn_mobile_app,
                        hideInitialView: '2' === ro.__attentive_cfg ? .lt
                    };
                await _c(t.SHOULD_DELAY_CREATIVES_FETCH), u(n, r)
            };
        ((e = {}) => {
            ro.__attentive ? ro.__attentive = { ...ro.__attentive,
                ...e
            } : ro.__attentive = e
        })({
            show: d,
            hide: s,
            trigger: async (t, r, i, a, o) => {
                const c = {
                        customFilterParam: t,
                        anonymousID: r,
                        creativeID: a,
                        userID: e.getId(),
                        targets: ['overlay'],
                        triggers: ['standard']
                    },
                    s = {
                        email: i,
                        hideInitialView: Boolean(o),
                        skipLoadingRestrictions: !0,
                        previouslyLoaded: '2' === ro.__attentive_cfg ? .lt && !!n,
                        initiator: 'sdk'
                    };
                u(c, s)
            }
        }), d();
        return {
            triggerAddToCartCreative: () => {
                a.triggerAddToCartCreative()
            }
        }
    };
    var Jc = {
            evaluateEligibility: function(e) {
                try {
                    var t = e.variantId,
                        n = function() {
                            var e;
                            try {
                                var t = null === (e = p()) || void 0 === e ? void 0 : e.innerHTML;
                                return JSON.parse(t || '')
                            } catch (e) {
                                return
                            }
                        }();
                    return !!(null == n ? void 0 : n[t])
                } catch (e) {
                    return !1
                }
            }
        },
        Kc = {
            shopify: Jc,
            base: {
                evaluateEligibility: function(e) {
                    try {
                        return null !== document.querySelector('.'.concat('attn-oos'))
                    } catch (e) {
                        return !1
                    }
                }
            }
        },
        Xc = function() {
            var e, t, n = !1,
                a = !1,
                o = function() {
                    return r(void 0, void 0, void 0, (function() {
                        var e;
                        return i(this, (function(r) {
                            switch (r.label) {
                                case 0:
                                    return n ? [3, 2] : (n = !0, [4, Wc()]);
                                case 1:
                                    e = r.sent().triggerAddToCartCreative, t = e, r.label = 2;
                                case 2:
                                    return [2]
                            }
                        }))
                    }))
                };
            return sn(((e = {})[st] = function(e, t) {
                var n, r = t.data.clientConfiguration;
                a = !0 === (null === (n = r.cc) || void 0 === n ? void 0 : n.pcve), !e || e && !e[Ye] || o()
            }, e[dt] = function() {
                o()
            }, e[ft] = function(e, t) {
                var n, r = t.data,
                    i = t.meta,
                    o = (n = r.items && Array.isArray(r.items) && r.items.length > 0 && 'object' == typeof r.items[0] ? r.items[0] : r).sku,
                    c = n.subProductId,
                    u = n.price,
                    s = n.cartCurrency,
                    l = n.image,
                    y = n.name,
                    h = n.productId;
                if (a && ln && (null == i ? void 0 : i.dataType) === ht && y && u && l && (o || h)) {
                    var E = {
                            name: y,
                            image: l,
                            price: u,
                            sku: o || h,
                            cartCurrency: s,
                            variantId: c,
                            location: window.location.href
                        },
                        I = window.__attentive_domain,
                        w = window.localStorage.getItem('attn_pdp'),
                        b = {};
                    if (w) b = JSON.parse(atob(w));
                    if (I) {
                        var T = (!0 === Array.isArray(b[I]) ? b[I] : []).filter((function(e) {
                            return e.sku !== E.sku
                        }));
                        T.unshift(E), T.length > 3 && (T = T.slice(0, 3)), b[I] = T, window.localStorage.setItem('attn_pdp', btoa(JSON.stringify(b)))
                    }
                }
                var A, S = f();
                if (S && (null == i ? void 0 : i.dataType) === ht && (o || h) && c)
                    if ((0, Kc[p() ? 'shopify' : 'base'].evaluateEligibility)({
                            variantId: ''.concat(c)
                        })) {
                        var O = d(),
                            L = (A = {
                                productId: ''.concat(o || h),
                                variantId: ''.concat(c)
                            }, 'true' === d() ? .getAttribute('data-signup-complete') && m().includes(g(A)));
                        !O || S.getAttribute('data-product-id') === ''.concat(o || h) && S.getAttribute('data-variant-id') === ''.concat(c) || !0 !== O.disabled || L ? O && L && v(O) : function(e) {
                                const t = e.getAttribute('data-enabled-text');
                                t && (e.disabled = !1, e.innerText = t)
                            }(O),
                            function(e, t, n) {
                                e.setAttribute('data-product-id', t), e.setAttribute('data-variant-id', n), e.style.display = 'block'
                            }(S, ''.concat(o || h), ''.concat(c))
                    } else ! function(e) {
                        e.removeAttribute('data-product-id'), e.removeAttribute('data-variant-id'), e.style.display = 'none'
                    }(S);
                var N = C();
                N && (! function(e, t) {
                    e.setAttribute('data-product-price', t), e.style.display = 'block'
                }(N, ''.concat(u)), (O = _()) && !0 === O.disabled && function(e) {
                    const t = e.getAttribute('data-enabled-text');
                    t && (e.disabled = !1, e.innerText = t)
                }(O))
            }, e[pt] = function(e, n) {
                var r = n.meta;
                (null == r ? void 0 : r.dataType) === mt && 'function' == typeof t && t()
            }, e))
        },
        zc = function() {
            var e;
            return sn(((e = {})[st] = function(e, t, n) {
                var r;
                n.dispatch;
                var i = O('__attentive_session_id');
                P('__attentive_session_id', i ? String(i) : i = vn(), {
                    expires: 1 / 48
                }), e && ut in e && (e[ut] = ((r = {
                    val: i
                })[Pt] = Date.now(), r[Nt] = Date.now(), r[Rt] = 1 / 48, r))
            }, e))
        };

    function Zc(e, t) {
        var n, r;
        return null != (null === (n = t.meta) || void 0 === n ? void 0 : n.dataType) && null != e[at] && e[at][null === (r = t.meta) || void 0 === r ? void 0 : r.dataType]
    }

    function Qc(e, t) {
        Array.isArray(t) && (t = t.join(','));
        var n = {
            phone: en,
            price: rn,
            quantity: an,
            email: nn,
            cartTotal: rn,
            orderId: cn,
            image: un
        };
        return n[e] && (t = n[e](t)), 'string' == typeof t && (t = on(t)), t
    }

    function eu(e) {
        var t = Object.keys(e.data).reduce((function(t, n) {
            var r = e.data[n];
            if ('' !== r && ('number' == typeof r || 'string' == typeof r)) {
                var i = Qc(n, r);
                t[n] = i
            }
            return t
        }), {});
        for (var n in e.data)
            if ('products' !== n && 'items' !== n || !Array.isArray(e.data[n])) t[n] = tu(n, e.data[n]);
            else {
                var r = Object(e.data)[n].map((function(e) {
                    var t = {};
                    for (var n in e) {
                        var r = tu(n, e[n]);
                        null != r && (t[n] = r)
                    }
                    return nu(t), t
                }));
                t[n] = JSON.stringify(r)
            }
        return nu(t),
            function(e, t) {
                var n, r;
                (null === (n = e.meta) || void 0 === n ? void 0 : n.dataType) !== _t && (null === (r = e.meta) || void 0 === r ? void 0 : r.dataType) !== gt || t.cartCurrency || t.currency && (t.cartCurrency = t.currency)
            }(e, t), t
    }

    function tu(e, t) {
        if ('' !== t && ('number' == typeof t || 'string' == typeof t)) return Qc(e, t)
    }

    function nu(e) {
        e.sku ? e.productId = e.sku : e.productId && (e.sku = e.productId)
    }

    function ru(e, r, i) {
        var a, o, c = eu(r);
        if (!(null === (o = r.meta) || void 0 === o ? void 0 : o.dataType)) return null;
        var u = JSON.stringify(t({
                source: r.meta.source
            }, c)),
            s = x + '_' + M,
            d = function(e, t) {
                var n, r, i = x + '_' + M;
                return zr((null === (n = e[Ye]) || void 0 === n ? void 0 : n.val) + t.meta.dataType + i + document.referrer + e[Be] + `${(r=new Date).getUTCFullYear()}-${r.getUTCMonth()+1}-${r.getUTCDate()}-${r.getUTCHours()}-${r.getUTCMinutes()}`)
            }(e, r),
            l = e,
            v = ot;
        l[v];
        var f = ct;
        l[f];
        var p = n(l, [v + '', f + '']),
            g = {};
        r.meta && r.meta.fingerprintRequestId && r.meta.fingerprintVisitorId && (g[Xe] = r.meta.fingerprintRequestId, g[ze] = r.meta.fingerprintVisitorId, g[Ze] = r.meta.fingerprintConfidenceScore);
        var m = {};
        r.meta && r.meta.metaEventId && (m[Je] = r.meta.metaEventId);
        var y = t(t(t(t({}, p), g), m), ((a = {})[Qe] = 'modern', a[xe] = d, a[qe] = s, a[He] = r.meta.dataType, a[Ge] = document.referrer, a[je] = i ? function(e) {
            return e.split('?')[0]
        }(window.location.href) : window.location.href, a[Ue] = u, a[Fe] = (new Date).getTime(), a[nt] = $t([Ut, Ft, Ht, Vt, jt, Gt, qt]), a));
        return '?'.concat(xt(y))
    }

    function iu(e) {
        return function(t, n) {
            var r;
            if (!Un(n) && Zc(e, n)) return '';
            var i = ru(t, n, null == e ? void 0 : e.sqp),
                a = !1;
            if (i) {
                var o = B + i;
                if (D && window.opener) try {
                    var c = JSON.stringify({
                        url: o,
                        state: t,
                        event: n,
                        clientConfig: e
                    });
                    window.opener.postMessage({
                        type: 'SERVER_EVENT',
                        payload: c
                    }, '*')
                } catch (e) {}
                if ('function' == typeof(null === (r = null === window || void 0 === window ? void 0 : window.navigator) || void 0 === r ? void 0 : r.sendBeacon)) try {
                    return a = navigator.sendBeacon(o), o
                } catch (e) {}
                return a || (new Image(1, 1).src = o), o
            }
            return ''
        }
    }
    var au = function(e, t) {
            var n, r, i, a, o, c;
            return e.push({
                id: (null === (n = t.productId) || void 0 === n ? void 0 : n.toString()) || (null === (r = t.sku) || void 0 === r ? void 0 : r.toString()),
                quantity: t.quantity ? parseInt(t.quantity) : void 0,
                item_price: t.price ? parseFloat(t.price) : void 0,
                variantId: null === (i = t.subProductId) || void 0 === i ? void 0 : i.toString(),
                title: null === (a = t.name) || void 0 === a ? void 0 : a.toString(),
                category: null === (o = t.category) || void 0 === o ? void 0 : o.toString(),
                image: null === (c = t.image) || void 0 === c ? void 0 : c.toString(),
                type: 'product'
            }), e
        },
        ou = function(e) {
            return {
                cartId: e.cartId || void 0,
                cartCoupon: e.cartCoupon || void 0,
                cartCurrency: e.cartCurrency || void 0,
                cartDiscount: e.cartDiscount || void 0
            }
        },
        cu = function(e) {
            return Array.isArray(e) ? e.reduce(au, []) : 'object' == typeof e ? Object.values(e).reduce(au, []) : void 0
        };

    function uu(e) {
        var r, i, a = null === (r = e[rt]) || void 0 === r ? void 0 : r[St],
            o = {},
            c = null === (i = e[rt]) || void 0 === i ? void 0 : i.efj,
            u = function(n, r, i, o) {
                var u, s, d;
                if (window.edgetag && o) {
                    var l = {};
                    a && (l = t(t({}, l), ((u = {})[Je] = null === (d = i.meta) || void 0 === d ? void 0 : d.metaEventId, u[Ke] = r[Ke], u[$e] = r[$e], u[We] = r[We], u))), c && i.meta && (l = t(t({}, l), ((s = {})[Xe] = i.meta.fingerprintRequestId, s[ze] = i.meta.fingerprintVisitorId, s[Ze] = i.meta.fingerprintConfidenceScore, s))), Object.keys(l).length > 0 && (o.customJson = JSON.stringify(l)), o && r[ut] && (o.sessionId = r[ut].val), window.edgetag('tag', n, o, {}, {
                        destination: e[ct]
                    })
                }
            };
        return function(r, i) {
            var a;
            if (window.edgetag && (Un(i) || !Zc(e, i)) && (i.data.blotoutExternalIds = function(e) {
                    if (null !== e) {
                        var t = null == e ? void 0 : e.filter((function(e) {
                            return e.name !== Yt
                        }));
                        if (t && t.length > 0) {
                            var n = {};
                            return null == t || t.forEach((function(e) {
                                e.vendor === Ht ? n.clientUserId = e.id || '' : e.vendor === Vt ? n[e.name || 'customId'] = e.id || '' : n[e.vendor] = e.id || ''
                            })), n
                        }
                    }
                }($t([Ut, Ft, Ht, Vt, jt, Gt, qt])), null === (a = i.meta) || void 0 === a ? void 0 : a.dataType)) {
                if (i.meta.dataType !== bt) {
                    var c = i.data,
                        s = c.email,
                        d = c.phone;
                    if (s) {
                        var l = tn(s);
                        l && window.edgetag('user', 'email', l)
                    }
                    if (d) {
                        var v = en(d.replace(/^1/, ''), !0);
                        v && window.edgetag('user', 'phone', v)
                    }
                }
                switch (i.meta.dataType) {
                    case mt:
                        return void u('AddToCart', r, i, function(e) {
                            return {
                                currency: e.data.currency || e.data.cartCurrency || void 0,
                                contents: au([], t(t({}, e.data), {
                                    quantity: '1'
                                })),
                                customIdentifiers: e.data.blotoutExternalIds
                            }
                        }(i));
                    case yt:
                        return void u('PageView', r, i, function(e) {
                            var t = {
                                customIdentifiers: e.data.blotoutExternalIds
                            };
                            return t.customIdentifiers ? t : {}
                        }(i));
                    case ht:
                        return void u('ViewContent', r, i, function(e) {
                            return {
                                currency: e.data.currency || e.data.cartCurrency || void 0,
                                contents: au([], t(t({}, e.data), {
                                    quantity: '1'
                                })),
                                customIdentifiers: e.data.blotoutExternalIds
                            }
                        }(i));
                    case _t:
                        return void u('Purchase', r, i, function(e) {
                            if (e.data.orderId) return {
                                currency: e.data.currency || e.data.cartCurrency || void 0,
                                contents: au([], t(t({}, e.data), {
                                    quantity: '1'
                                })),
                                value: e.data.cartTotal ? parseFloat(e.data.cartTotal) : void 0,
                                orderId: e.data.orderId,
                                eventId: e.data.orderId,
                                cart: ou(e.data),
                                customIdentifiers: e.data.blotoutExternalIds
                            }
                        }(i));
                    case gt:
                        return void u('CartUpdated', r, i, function(e) {
                            var t;
                            if (e.data.products) {
                                var n = cu(e.data.products),
                                    r = ou(e.data),
                                    i = Array.isArray(e.data.products) ? null === (t = e.data.products.find((function(e) {
                                        return e.currency
                                    }))) || void 0 === t ? void 0 : t.currency : void 0;
                                if (n) return {
                                    currency: e.data.currency || e.data.cartCurrency || i || void 0,
                                    contents: n,
                                    cart: r,
                                    customIdentifiers: e.data.blotoutExternalIds
                                }
                            }
                        }(i));
                    case It:
                        return void u('OrderConfirmed', r, i, function(e) {
                            if (e.data.products && e.data.orderId) {
                                var t = cu(e.data.products);
                                if (t) return {
                                    currency: e.data.currency || e.data.cartCurrency || void 0,
                                    contents: t,
                                    orderId: e.data.orderId,
                                    eventId: e.data.orderId,
                                    cart: ou(e.data),
                                    customIdentifiers: e.data.blotoutExternalIds
                                }
                            }
                        }(i));
                    case wt:
                        return void u('PageLeave', r, i, function(e) {
                            return {
                                customIdentifiers: e.data.blotoutExternalIds,
                                scrollDepth: Number(e.data.scrollDepth),
                                timeSpent: Number(e.data.timeSpent)
                            }
                        }(i));
                    case 'i':
                    case bt:
                        var f = i.data,
                            p = (d = f.phone, s = f.email, n(f, ['phone', 'email']));
                        return d && window.edgetag('user', 'phone', d), s && window.edgetag('user', 'email', s), void(o = t(t({}, o), p));
                    default:
                        return
                }
            }
        }
    }
    var su = [
            ['2', '3', '4', '5'],
            ['C0002', 'C0003', 'C0004', 'C0005']
        ],
        du = function() {
            var e = function() {
                var e = O('OptanonConsent');
                if (!e) return {};
                var t = new URLSearchParams(e),
                    n = Object.fromEntries(t);
                if (!n.groups) return {};
                var r = n.groups.split(',').reduce((function(e, t) {
                    var n = t.split(':'),
                        r = n[0],
                        i = n[1];
                    return e[r] = i, e
                }), {});
                return r
            }();
            return {
                getMetaConsent: function() {
                    return function(e) {
                        return 0 === Object.keys(e).length || su.every((function(t) {
                            return t.every((function(t) {
                                return !(t in e) || '0' !== e[t]
                            }))
                        }))
                    }(e)
                }
            }
        },
        lu = function(e, t) {
            var n, r = du(),
                i = ((n = {})[Ke] = function(e, t) {
                    var n;
                    if (null === (n = t[rt]) || void 0 === n ? void 0 : n[St]) return e.getMetaConsent()
                }(r, e), n);
            Object.values(i).every((function(e) {
                return void 0 === e
            })) || t(hn(i))
        },
        vu = function() {
            var e, t;
            return sn(((e = {})[st] = function(e, n, r) {
                var i = r.dispatch;
                t = n.data.clientConfiguration, lu(t, i)
            }, e[vt] = function(e, n) {
                n.data.on && function(e, t) {
                    t.data.on && window.edgetag && e[ct] && window.edgetag('consent', {
                        all: !0
                    })
                }(t, n)
            }, e))
        },
        fu = function(e) {
            var t = localStorage.getItem('attn_load_collect');
            null === t && (t = (Math.random() < e).toString());
            if (localStorage.setItem('attn_load_collect', t), 'true' === t) {
                var n = document.createElement('script'),
                    r = ''.concat('https://cdn.attn.tv/tag', '/').concat(x, '/collector.js');
                n.src = r, n.async = !0, document.body.appendChild(n)
            }
        };

    function pu() {
        var e;
        if (null != window.attn_d0x0b_evt && window.attn_d0x0b_evt.length > 0) {
            var t = null === (e = window.attentive) || void 0 === e ? void 0 : e.analytics;
            if (!t) return;
            for (var n = 0, r = window.attn_d0x0b_evt; n < r.length; n++) {
                var i = r[n],
                    a = i.func,
                    o = i.args;
                'object' == typeof t && 'function' == typeof t[a] && t[a].apply(null, o)
            }
        }
    }
    var gu = function() {
        !0 !== window.attn_tag_initialized && function(e) {
            r(this, void 0, void 0, (function() {
                var t, n, r;
                return i(this, (function(i) {
                    switch (i.label) {
                        case 0:
                            document.removeEventListener('DOMContentLoaded', gu), performance.mark(w.TagCoreLoaded), window.attn_tag_initialized = !0, i.label = 1;
                        case 1:
                            return i.trys.push([1, 3, , 4]), [4, mu(t = JSON.parse(atob(e)))];
                        case 2:
                            return i.sent() && (n = [], D && n.push((function(e, t) {
                                var n;
                                if (D) {
                                    var r = function() {};
                                    try {
                                        t.type === st && (ya = e, D && (jn((function() {
                                            return Boolean(rr('gtag')(window))
                                        })).then((function() {})).catch(r), jn((function() {
                                            return Boolean(rr('fbq')(window))
                                        })).then((function() {})).catch(r), jn((function() {
                                            return Boolean(rr('Shopify')(window))
                                        })).then((function() {})).catch(r), document.querySelectorAll('meta').forEach((function(e) {})), document.querySelectorAll('script[type="application/ld+json"]').forEach((function(e) {})))), null === (n = t.meta) || void 0 === n || n.dataType, ya !== e && (ya = e)
                                    } catch (e) {}
                                }
                            })), n.push(ma()), n.push(na()), n.push(function() {
                                var e, t, n, r;
                                return sn(((e = {})[st] = function(e, i) {
                                    t = i.data.clientConfiguration, n = uu(t), r = iu(t)
                                }, e[pt] = function(e, i) {
                                    window.edgetag && t[ct] ? n(e, i) : r(e, i)
                                }, e))
                            }()), n.push(vu()), n.push(function() {
                                var e, t;
                                return sn(((e = {})[st] = function(e, n) {
                                    var r, i = null === (r = null == (t = n.data.clientConfiguration) ? void 0 : t.tac) || void 0 === r ? void 0 : r.p;
                                    i && i > 0 && fu(i)
                                }, e))
                            }()), n.push(zc()), n.push(Xc()), window.attentive = Mn({
                                clientConfiguration: t,
                                services: n
                            }), queueMicrotask(pu)), [3, 4];
                        case 3:
                            return r = i.sent(), Mt(G, r), [3, 4];
                        case 4:
                            return [2]
                    }
                }))
            }))
        }(window.attn_d0x0b_cfg)
    };

    function mu(e) {
        return new Promise((function(t, n) {
            if (e[it] && e[et]) {
                if (yu('enable')) return void t(!0);
                var r = function() {
                    yu('enable') && (window.removeEventListener('attn_queued_sdk_event', r), t(!0))
                };
                window.addEventListener('attn_queued_sdk_event', r)
            } else t(!0)
        }))
    }

    function yu(e) {
        var t;
        return null === (t = null === window || void 0 === window ? void 0 : window.attn_d0x0b_evt) || void 0 === t ? void 0 : t.find((function(t) {
            return t.func === e
        }))
    }
    window.attn_d0x0b_cfg && ('loading' === document.readyState ? document.addEventListener('DOMContentLoaded', gu) : gu())
}();