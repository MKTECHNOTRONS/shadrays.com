/** 
 * onetrust-banner-sdk
 * v202502.1.0
 * by OneTrust LLC
 * Copyright 2025 
 */
(() => {
    var B = function(e, t) {
        return (B = Object.setPrototypeOf || ({
                __proto__: []
            }
            instanceof Array ? function(e, t) {
                e.__proto__ = t
            } : function(e, t) {
                for (var o in t) Object.prototype.hasOwnProperty.call(t, o) && (e[o] = t[o])
            }))(e, t)
    };

    function x(e, t) {
        if ("function" != typeof t && null !== t) throw new TypeError("Class extends value " + String(t) + " is not a constructor or null");

        function o() {
            this.constructor = e
        }
        B(e, t), e.prototype = null === t ? Object.create(t) : (o.prototype = t.prototype, new o)
    }
    var H, R = function() {
        return (R = Object.assign || function(e) {
            for (var t, o = 1, n = arguments.length; o < n; o++)
                for (var r in t = arguments[o]) Object.prototype.hasOwnProperty.call(t, r) && (e[r] = t[r]);
            return e
        }).apply(this, arguments)
    };

    function F(e, s, a, l) {
        return new(a = a || Promise)(function(o, t) {
            function n(e) {
                try {
                    i(l.next(e))
                } catch (e) {
                    t(e)
                }
            }

            function r(e) {
                try {
                    i(l.throw(e))
                } catch (e) {
                    t(e)
                }
            }

            function i(e) {
                var t;
                e.done ? o(e.value) : ((t = e.value) instanceof a ? t : new a(function(e) {
                    e(t)
                })).then(n, r)
            }
            i((l = l.apply(e, s || [])).next())
        })
    }

    function M(n, r) {
        var i, s, a, l = {
                label: 0,
                sent: function() {
                    if (1 & a[0]) throw a[1];
                    return a[1]
                },
                trys: [],
                ops: []
            },
            c = Object.create(("function" == typeof Iterator ? Iterator : Object).prototype);
        return c.next = e(0), c.throw = e(1), c.return = e(2), "function" == typeof Symbol && (c[Symbol.iterator] = function() {
            return this
        }), c;

        function e(o) {
            return function(e) {
                var t = [o, e];
                if (i) throw new TypeError("Generator is already executing.");
                for (; l = c && t[c = 0] ? 0 : l;) try {
                    if (i = 1, s && (a = 2 & t[0] ? s.return : t[0] ? s.throw || ((a = s.return) && a.call(s), 0) : s.next) && !(a = a.call(s, t[1])).done) return a;
                    switch (s = 0, (t = a ? [2 & t[0], a.value] : t)[0]) {
                        case 0:
                        case 1:
                            a = t;
                            break;
                        case 4:
                            return l.label++, {
                                value: t[1],
                                done: !1
                            };
                        case 5:
                            l.label++, s = t[1], t = [0];
                            continue;
                        case 7:
                            t = l.ops.pop(), l.trys.pop();
                            continue;
                        default:
                            if (!(a = 0 < (a = l.trys).length && a[a.length - 1]) && (6 === t[0] || 2 === t[0])) {
                                l = 0;
                                continue
                            }
                            if (3 === t[0] && (!a || t[1] > a[0] && t[1] < a[3])) l.label = t[1];
                            else if (6 === t[0] && l.label < a[1]) l.label = a[1], a = t;
                            else {
                                if (!(a && l.label < a[2])) {
                                    a[2] && l.ops.pop(), l.trys.pop();
                                    continue
                                }
                                l.label = a[2], l.ops.push(t)
                            }
                    }
                    t = r.call(n, l)
                } catch (e) {
                    t = [6, e], s = 0
                } finally {
                    i = a = 0
                }
                if (5 & t[0]) throw t[1];
                return {
                    value: t[0] ? t[1] : void 0,
                    done: !0
                }
            }
        }
    }

    function U() {
        for (var e = 0, t = 0, o = arguments.length; t < o; t++) e += arguments[t].length;
        for (var n = Array(e), r = 0, t = 0; t < o; t++)
            for (var i = arguments[t], s = 0, a = i.length; s < a; s++, r++) n[r] = i[s];
        return n
    }(e = H = H || {})[e.ACTIVE = 0] = "ACTIVE", e[e.ALWAYS_ACTIVE = 1] = "ALWAYS_ACTIVE", e[e.EXPIRED = 2] = "EXPIRED", e[e.NO_CONSENT = 3] = "NO_CONSENT", e[e.OPT_OUT = 4] = "OPT_OUT", e[e.PENDING = 5] = "PENDING", e[e.WITHDRAWN = 6] = "WITHDRAWN";
    var q = setTimeout;

    function j(e) {
        return Boolean(e && void 0 !== e.length)
    }

    function K() {}

    function z(e) {
        if (!(this instanceof z)) throw new TypeError("Promises must be constructed via new");
        if ("function" != typeof e) throw new TypeError("not a function");
        this._state = 0, this._handled = !1, this._value = void 0, this._deferreds = [], Z(e, this)
    }

    function W(o, n) {
        for (; 3 === o._state;) o = o._value;
        0 === o._state ? o._deferreds.push(n) : (o._handled = !0, z._immediateFn(function() {
            var e, t = 1 === o._state ? n.onFulfilled : n.onRejected;
            if (null === t)(1 === o._state ? Y : J)(n.promise, o._value);
            else {
                try {
                    e = t(o._value)
                } catch (e) {
                    return void J(n.promise, e)
                }
                Y(n.promise, e)
            }
        }))
    }

    function Y(t, e) {
        try {
            if (e === t) throw new TypeError("A promise cannot be resolved with itself.");
            if (e && ("object" == typeof e || "function" == typeof e)) {
                var o = e.then;
                if (e instanceof z) return t._state = 3, t._value = e, void X(t);
                if ("function" == typeof o) return void Z((n = o, r = e, function() {
                    n.apply(r, arguments)
                }), t)
            }
            t._state = 1, t._value = e, X(t)
        } catch (e) {
            J(t, e)
        }
        var n, r
    }

    function J(e, t) {
        e._state = 2, e._value = t, X(e)
    }

    function X(e) {
        2 === e._state && 0 === e._deferreds.length && z._immediateFn(function() {
            e._handled || z._unhandledRejectionFn(e._value)
        });
        for (var t = 0, o = e._deferreds.length; t < o; t++) W(e, e._deferreds[t]);
        e._deferreds = null
    }

    function Q(e, t, o) {
        this.onFulfilled = "function" == typeof e ? e : null, this.onRejected = "function" == typeof t ? t : null, this.promise = o
    }

    function Z(e, t) {
        var o = !1;
        try {
            e(function(e) {
                o || (o = !0, Y(t, e))
            }, function(e) {
                o || (o = !0, J(t, e))
            })
        } catch (e) {
            o || (o = !0, J(t, e))
        }
    }

    function $() {}
    z.prototype.catch = function(e) {
        return this.then(null, e)
    }, z.prototype.then = function(e, t) {
        var o = new this.constructor(K);
        return W(this, new Q(e, t, o)), o
    }, z.prototype.finally = function(t) {
        var o = this.constructor;
        return this.then(function(e) {
            return o.resolve(t()).then(function() {
                return e
            })
        }, function(e) {
            return o.resolve(t()).then(function() {
                return o.reject(e)
            })
        })
    }, z.all = function(t) {
        return new z(function(r, i) {
            if (!j(t)) return i(new TypeError("Promise.all accepts an array"));
            var s = Array.prototype.slice.call(t);
            if (0 === s.length) return r([]);
            var a = s.length;
            for (var e = 0; e < s.length; e++) ! function t(o, e) {
                try {
                    if (e && ("object" == typeof e || "function" == typeof e)) {
                        var n = e.then;
                        if ("function" == typeof n) return void n.call(e, function(e) {
                            t(o, e)
                        }, i)
                    }
                    s[o] = e, 0 == --a && r(s)
                } catch (e) {
                    i(e)
                }
            }(e, s[e])
        })
    }, z.resolve = function(t) {
        return t && "object" == typeof t && t.constructor === z ? t : new z(function(e) {
            e(t)
        })
    }, z.reject = function(o) {
        return new z(function(e, t) {
            t(o)
        })
    }, z.race = function(r) {
        return new z(function(e, t) {
            if (!j(r)) return t(new TypeError("Promise.race accepts an array"));
            for (var o = 0, n = r.length; o < n; o++) z.resolve(r[o]).then(e, t)
        })
    }, z._immediateFn = "function" == typeof setImmediate ? function(e) {
        setImmediate(e)
    } : function(e) {
        q(e, 0)
    }, z._unhandledRejectionFn = function(e) {
        "undefined" != typeof console && console && console.warn("Possible Unhandled Promise Rejection:", e)
    }, $.prototype.initPolyfill = function() {
        this.initArrayIncludesPolyfill(), this.initObjectAssignPolyfill(), this.initArrayFillPolyfill(), this.initClosestPolyfill(), this.initIncludesPolyfill(), this.initEndsWithPoly(), this.initCustomEventPolyfill(), this.promisesPolyfil()
    }, $.prototype.initArrayIncludesPolyfill = function() {
        Array.prototype.includes || Object.defineProperty(Array.prototype, "includes", {
            value: function(e) {
                for (var t = [], o = 1; o < arguments.length; o++) t[o - 1] = arguments[o];
                if (null == this) throw new TypeError("Array.prototype.includes called on null or undefined");
                var n = Object(this),
                    r = parseInt(n.length, 10) || 0;
                if (0 !== r) {
                    var i, s, a = t[1] || 0;
                    for (0 <= a ? i = a : (i = r + a) < 0 && (i = 0); i < r;) {
                        if (e === (s = n[i]) || e != e && s != s) return !0;
                        i++
                    }
                }
                return !1
            },
            writable: !0,
            configurable: !0
        })
    }, $.prototype.initEndsWithPoly = function() {
        String.prototype.endsWith || Object.defineProperty(String.prototype, "endsWith", {
            value: function(e, t) {
                return (void 0 === t || t > this.length) && (t = this.length), this.substring(t - e.length, t) === e
            },
            writable: !0,
            configurable: !0
        })
    }, $.prototype.initClosestPolyfill = function() {
        Element.prototype.matches || (Element.prototype.matches = Element.prototype.msMatchesSelector || Element.prototype.webkitMatchesSelector), Element.prototype.closest || Object.defineProperty(Element.prototype, "closest", {
            value: function(e) {
                var t = this;
                do {
                    if (t.matches(e)) return t
                } while (null !== (t = t.parentElement || t.parentNode) && 1 === t.nodeType);
                return null
            },
            writable: !0,
            configurable: !0
        })
    }, $.prototype.initIncludesPolyfill = function() {
        String.prototype.includes || Object.defineProperty(String.prototype, "includes", {
            value: function(e, t) {
                return !((t = "number" != typeof t ? 0 : t) + e.length > this.length) && -1 !== this.indexOf(e, t)
            },
            writable: !0,
            configurable: !0
        })
    }, $.prototype.initObjectAssignPolyfill = function() {
        "function" != typeof Object.assign && Object.defineProperty(Object, "assign", {
            value: function(e, t) {
                if (null == e) throw new TypeError("Cannot convert undefined or null to object");
                for (var o = Object(e), n = 1; n < arguments.length; n++) {
                    var r = arguments[n];
                    if (null != r)
                        for (var i in r) Object.prototype.hasOwnProperty.call(r, i) && (o[i] = r[i])
                }
                return o
            },
            writable: !0,
            configurable: !0
        })
    }, $.prototype.initArrayFillPolyfill = function() {
        Array.prototype.fill || Object.defineProperty(Array.prototype, "fill", {
            value: function(e) {
                if (null == this) throw new TypeError("this is null or not defined");
                for (var t = Object(this), o = t.length >>> 0, n = arguments[1] >> 0, r = n < 0 ? Math.max(o + n, 0) : Math.min(n, o), n = arguments[2], n = void 0 === n ? o : n >> 0, i = n < 0 ? Math.max(o + n, 0) : Math.min(n, o); r < i;) t[r] = e, r++;
                return t
            }
        })
    }, $.prototype.initCustomEventPolyfill = function() {
        if ("function" == typeof window.CustomEvent) return !1;

        function e(e, t) {
            t = t || {
                bubbles: !1,
                cancelable: !1,
                detail: void 0
            };
            var o = document.createEvent("CustomEvent");
            return o.initCustomEvent(e, t.bubbles, t.cancelable, t.detail), o
        }
        e.prototype = window.Event.prototype, window.CustomEvent = e
    }, $.prototype.insertViewPortTag = function() {
        var e = document.querySelector('meta[name="viewport"]'),
            t = document.createElement("meta");
        t.name = "viewport", t.content = "width=device-width, initial-scale=1", e || document.head.appendChild(t)
    }, $.prototype.promisesPolyfil = function() {
        "undefined" == typeof Promise && (window.Promise = z)
    };
    var ee, te, oe, ne, re, ie, se, ae, le, ce, de, ue, pe, Ce, ge, he, ye, fe, Se, me, ve, Te, Pe, ke, be, Ae, Ie, Le, _e, o, Ee, Oe, Ve, De, Ne, we, Ge = new $,
        Be = ((e = ee = ee || {})[e.Unknown = 0] = "Unknown", e[e.BannerCloseButton = 1] = "BannerCloseButton", e[e.ConfirmChoiceButton = 2] = "ConfirmChoiceButton", e[e.AcceptAll = 3] = "AcceptAll", e[e.RejectAll = 4] = "RejectAll", e[e.BannerSaveSettings = 5] = "BannerSaveSettings", e[e.ContinueWithoutAcceptingButton = 6] = "ContinueWithoutAcceptingButton", (e = te = te || {})[e.Banner = 1] = "Banner", e[e.PC = 2] = "PC", e[e.API = 3] = "API", (e = oe = oe || {}).AcceptAll = "AcceptAll", e.RejectAll = "RejectAll", e.UpdateConsent = "UpdateConsent", (e = ne = ne || {})[e.Purpose = 1] = "Purpose", e[e.SpecialFeature = 2] = "SpecialFeature", (e = re = re || {}).Legal = "legal", e.UserFriendly = "user_friendly", (e = ie = ie || {}).Top = "top", e.Bottom = "bottom", (e = se = se || {})[e.Banner = 0] = "Banner", e[e.PrefCenterHome = 1] = "PrefCenterHome", e[e.VendorList = 2] = "VendorList", e[e.CookieList = 3] = "CookieList", e[e.IabIllustrations = 4] = "IabIllustrations", (e = ae = ae || {})[e.RightArrow = 39] = "RightArrow", e[e.LeftArrow = 37] = "LeftArrow", e[e.UpArrow = 38] = "UpArrow", e[e.DownArrow = 40] = "DownArrow", (e = le = le || {}).AfterTitle = "AfterTitle", e.AfterDescription = "AfterDescription", e.AfterDPD = "AfterDPD", (e = ce = ce || {}).PlusMinus = "Plusminus", e.Caret = "Caret", e.NoAccordion = "NoAccordion", (e = de = de || {}).Consent = "Consent", e.LI = "LI", e.AddtlConsent = "AddtlConsent", (e = ue = ue || {}).Iab1Pub = "eupubconsent", e.Iab2Pub = "eupubconsent-v2", e.Iab1Eu = "euconsent", e.Iab2Eu = "euconsent-v2", (e = pe = pe || {})[e.Disabled = 0] = "Disabled", e[e.Consent = 1] = "Consent", e[e.LegInt = 2] = "LegInt", (e = Ce = Ce || {})[e["Banner - Allow All"] = 1] = "Banner - Allow All", e[e["Banner - Reject All"] = 2] = "Banner - Reject All", e[e["Banner - Close"] = 3] = "Banner - Close", e[e["Preference Center - Allow All"] = 4] = "Preference Center - Allow All", e[e["Preference Center - Reject All"] = 5] = "Preference Center - Reject All", e[e["Preference Center - Confirm"] = 6] = "Preference Center - Confirm", e[e["GPC value changed"] = 7] = "GPC value changed", (e = ge = ge || {}).Active = "1", e.InActive = "0", (e = he = he || {}).Host = "Host", e.GenVendor = "GenVen", (e = ye = ye || {})[e.Host = 1] = "Host", e[e.GenVen = 2] = "GenVen", e[e.HostAndGenVen = 3] = "HostAndGenVen", (e = fe = fe || {})[e.minDays = 1] = "minDays", e[e.maxDays = 30] = "maxDays", e[e.maxYear = 31536e3] = "maxYear", e[e.maxSecToDays = 86400] = "maxSecToDays", (e = Se = Se || {})[e.RTL = 0] = "RTL", e[e.LTR = 1] = "LTR", (e = me = me || {})[e.GoogleVendor = 1] = "GoogleVendor", e[e.GeneralVendor = 2] = "GeneralVendor", (e = Et = Et || {})[e.Days = 1] = "Days", e[e.Weeks = 7] = "Weeks", e[e.Months = 30] = "Months", e[e.Years = 365] = "Years", (e = ve = ve || {}).Checkbox = "Checkbox", e.Toggle = "Toggle", (e = Te = Te || {}).SlideIn = "Slide_In", e.FadeIn = "Fade_In", e.RemoveAnimation = "Remove_Animation", (e = Pe = Pe || {}).Link = "Link", e.Icon = "Icon", (e = ke = ke || {}).consent = "consent", e.set = "set", (e = be = be || {}).update = "update", e.default = "default", e.ads_data_redaction = "ads_data_redaction", (e = Ae = Ae || {}).analytics_storage = "analytics_storage", e.ad_storage = "ad_storage", e.functionality_storage = "functionality_storage", e.personalization_storage = "personalization_storage", e.security_storage = "security_storage", e.ad_user_data = "ad_user_data", e.ad_personalization = "ad_personalization", e.region = "region", e.wait_for_update = "wait_for_update", (e = Ie = Ie || {}).granted = "granted", e.denied = "denied", 0, (e = Le = Le || {}).OBJECT_TO_LI = "ObjectToLI", e.LI_ACTIVE_IF_LEGAL_BASIS = "LIActiveIfLegalBasis", (e = _e = _e || {}).cookies = "cookies", e.vendors = "vendors", (e = o = o || {}).GDPR = "GDPR", e.CCPA = "CCPA", e.IAB2 = "IAB2", e.IAB2V2 = "IAB2V2", e.GENERIC = "GENERIC", e.LGPD = "LGPD", e.GENERIC_PROMPT = "GENERIC_PROMPT", e.CPRA = "CPRA", e.CDPA = "CDPA", e.DELAWARE = "DELAWARE", e.IOWA = "IOWA", e.NEBRASKA = "NEBRASKA", e.USNATIONAL = "USNATIONAL", e.CUSTOM = "CUSTOM", e.FLORIDA = "FLORIDA", e.COLORADO = "COLORADO", e.CONNECTICUT = "CTDPA", e.MONTANA = "MONTANA", e.TEXAS = "TEXAS", e.OREGON = "OREGON", e.TENNESSEE = "TENNESSEE", e.NEWJERSEY = "NEWJERSEY", e.NEWHAMPSHIRE = "NEWHAMPSHIRE", e.UCPA = "UCPA", {
            ca: o.CPRA,
            va: o.CDPA,
            co: o.COLORADO,
            or: o.OREGON,
            ct: o.CONNECTICUT,
            fl: o.FLORIDA,
            mt: o.MONTANA,
            tx: o.TEXAS,
            de: o.DELAWARE,
            ia: o.IOWA,
            ne: o.NEBRASKA,
            tn: o.TENNESSEE,
            nj: o.NEWJERSEY,
            nh: o.NEWHAMPSHIRE,
            ut: o.UCPA
        }),
        u = ((e = Ee = Ee || {}).Name = "OTGPPConsent", e[e.ChunkSize = 4e3] = "ChunkSize", e.ChunkCountParam = "GPPCookiesCount", (e = Oe = Oe || {}).MspaCoveredTransaction = "IsMSPAEnabled", e.MspaOptOutOptionMode = "Opt-Out", e.MspaServiceProviderMode = "Service Provider", 0, (e = Ve = Ve || {}).GpcSegmentType = "GpcSegmentType", e.Gpc = "Gpc", (e = De = De || {}).SensitiveDataProcessing = "SensitiveDataProcessing", e.KnownChildSensitiveDataConsents = "KnownChildSensitiveDataConsents", (e = Ne = Ne || {}).CPRA = "usca", e.CCPA = "usca", e.CDPA = "usva", e.OREGON = "usor", e.USNATIONAL = "usnat", e.COLORADO = "usco", e.FLORIDA = "usfl", e.CTDPA = "usct", e.MONTANA = "usmt", e.TEXAS = "ustx", e.DELAWARE = "usde", e.IOWA = "usia", e.NEBRASKA = "usne", e.TENNESSEE = "ustn", e.NEWJERSEY = "usnj", e.NEWHAMPSHIRE = "usnh", e.UCPA = "usut", e.IAB2V2 = "tcfeuv2", (e = we = we || {})[e.CPRA = 8] = "CPRA", e[e.CCPA = 8] = "CCPA", e[e.CDPA = 9] = "CDPA", e[e.OREGON = 15] = "OREGON", e[e.USNATIONAL = 7] = "USNATIONAL", e[e.COLORADO = 10] = "COLORADO", e[e.FLORIDA = 13] = "FLORIDA", e[e.MONTANA = 14] = "MONTANA", e[e.TEXAS = 16] = "TEXAS", e[e.DELAWARE = 17] = "DELAWARE", e[e.IOWA = 18] = "IOWA", e[e.NEBRASKA = 19] = "NEBRASKA", e[e.NEWHAMPSHIRE = 20] = "NEWHAMPSHIRE", e[e.NEWJERSEY = 21] = "NEWJERSEY", e[e.TENNESSEE = 22] = "TENNESSEE", e[e.UCPA = 11] = "UCPA", e[e.CTDPA = 12] = "CTDPA", e[e.IAB2V2 = 2] = "IAB2V2", 0, 0, 0, 0, 0, {
            AWAITING_RE_CONSENT: "AwaitingReconsent",
            CONSENT_ID: "consentId",
            GEO_LOCATION: "geolocation",
            INTERACTION_COUNT: "interactionCount",
            IS_IAB_GLOBAL: "isIABGlobal",
            NOT_LANDING_PAGE: "NotLandingPage",
            GEO: "geo",
            GPC_ENABLED: "isGpcEnabled",
            GPC_Browser_Flag: "browserGpcFlag",
            IS_ANONYMOUS_CONSENT: "isAnonUser",
            IDENTIFIER_TYPE: "identifierType",
            PREV_USER_CONSENT: "iType",
            INTERACTION_TYPE: "intType",
            GROUPS: "groups",
            HEALTH_SIGNATURE_AUTHORIZATION: "healthAuth"
        }),
        C = {
            ADDITIONAL_CONSENT_STRING: "OTAdditionalConsentString",
            ALERT_BOX_CLOSED: "OptanonAlertBoxClosed",
            OPTANON_CONSENT: "OptanonConsent",
            EU_PUB_CONSENT: "eupubconsent-v2",
            EU_CONSENT: "euconsent-v2",
            SELECTED_VARIANT: "OTVariant",
            OT_PREVIEW: "otpreview",
            GPP_CONSENT: Ee.Name
        },
        xe = "CONFIRMED",
        He = "OPT_OUT",
        Re = "NO_CHOICE",
        Fe = "NOTGIVEN",
        Me = "NO_OPT_OUT",
        S = {
            ALWAYS_INACTIVE: "always inactive",
            ALWAYS_ACTIVE: "always active",
            ACTIVE: "active",
            INACTIVE_LANDING_PAGE: "inactive landingpage",
            INACTIVE: "inactive",
            IMPLIED_CONSENT: "implied consent",
            GPC: "gpc",
            DNT: "dnt"
        },
        Ue = {
            LOCAL: "LOCAL",
            TEST: "TEST",
            LOCAL_TEST: "LOCAL_TEST",
            PRODUCTION: "PRODUCTION"
        },
        qe = "data-document-language",
        je = "data-language",
        Ke = "otCookieSettingsButton.json",
        ze = "otCookieSettingsButtonRtl.json",
        We = "otCenterRounded",
        Ye = "otFlat",
        Je = "otFloatingRoundedCorner",
        Xe = "otFloatingFlat",
        Qe = "otFloatingRoundedIcon",
        Ze = "otFloatingRounded",
        $e = "otChoicesBanner",
        et = "otNoBanner",
        tt = "otPcCenter",
        ot = "otPcList",
        nt = "otPcPanel",
        rt = "otPcPopup",
        it = "otPcTab",
        st = "hidebanner",
        at = ((e = {})[Et.Days] = "PCenterVendorListLifespanDay", e[Et.Weeks] = "LfSpnWk", e[Et.Months] = "PCenterVendorListLifespanMonth", e[Et.Years] = "LfSpnYr", e),
        lt = "DNAC",
        ct = "Category",
        dt = "Host",
        ut = "General Vendor",
        pt = "VendorService",
        Ct = "aria-label",
        gt = "aria-hidden",
        ht = "BRANCH",
        yt = "COOKIE",
        ft = "IAB2V2_SPL_PURPOSE",
        St = "IAB2V2_FEATURE",
        mt = "IAB2V2_SPL_FEATURE",
        vt = ["IAB2_PURPOSE", "IAB2_STACK", "IAB2_FEATURE", "IAB2_SPL_PURPOSE", "IAB2_SPL_FEATURE", "IAB2V2_PURPOSE", "IAB2V2_SPL_PURPOSE", "IAB2V2_FEATURE", "IAB2V2_SPL_FEATURE", "IAB2V2_STACK"],
        Tt = ["COOKIE", "BRANCH", "IAB2_STACK", "IAB2V2_STACK"],
        Pt = ["IAB2_PURPOSE", "IAB2_SPL_FEATURE", "IAB2V2_PURPOSE", "IAB2V2_SPL_FEATURE"],
        kt = ["IAB2_FEATURE", "IAB2_SPL_PURPOSE", "IAB2V2_FEATURE", "IAB2V2_SPL_PURPOSE"],
        bt = ["IAB2_PURPOSE", "IAB2_SPL_PURPOSE", "IAB2_FEATURE", "IAB2_SPL_FEATURE"],
        At = {
            IAB2V2: "pur",
            IFE2V2: "ft",
            ISP2V2: "spl_pur",
            ISF2V2: "spl_ft"
        },
        It = {
            pur: "purposes",
            ft: "features",
            spl_pur: "specialPurposes",
            spl_ft: "specialFeatures"
        },
        m = new function() {};

    function d(e, t, o) {
        void 0 === o && (o = !1);

        function n(e) {
            return e ? (";" !== (e = e.trim()).charAt(e.length - 1) && (e += ";"), e.trim()) : null
        }
        var i = n(e.getAttribute("style")),
            s = n(t),
            t = "",
            t = o && i ? (() => {
                for (var e = i.split(";").concat(s.split(";")).filter(function(e) {
                        return 0 !== e.length
                    }), t = "", o = "", n = e.length - 1; 0 <= n; n--) {
                    var r = e[n].substring(0, e[n].indexOf(":") + 1).trim();
                    t.indexOf(r) < 0 && (t += r, o += e[n] + ";")
                }
                return o
            })() : s;
        e.setAttribute("style", t)
    }
    a.insertAfter = function(e, t) {
        t.parentNode.insertBefore(e, t.nextSibling)
    }, a.insertBefore = function(e, t) {
        t.parentNode.insertBefore(e, t)
    }, a.inArray = function(e, t) {
        return t.indexOf(e)
    }, a.ajax = function(e) {
        var t = null,
            o = new XMLHttpRequest,
            n = e.type,
            r = e.contentType,
            i = e.data,
            s = e.success,
            a = e.token,
            t = e.error;
        o.open(n, e.url, !e.sync), o.setRequestHeader("Content-Type", r), a && o.setRequestHeader("Authorization", a), o.withCredentials = !1, o.onload = function() {
            var e;
            200 <= this.status && this.status < 400 ? (e = JSON.parse(this.responseText), s(e)) : t({
                message: "Error Loading Data",
                statusCode: this.status
            })
        }, o.onerror = function(e) {
            t(e)
        }, "post" === n.toLowerCase() || "put" === n.toLowerCase() ? o.send(i) : o.send()
    }, a.prevNextHelper = function(o, e, n) {
        var r = [];

        function i(e, t, o) {
            t[e] && o ? o.includes(".") ? (t[e].classList[0] || t[e].classList.value && t[e].classList.value.includes(o.split(".")[1])) && r.push(t[e]) : o.includes("#") ? t[e].id === o.split("#")[1] && r.push(t[e]) : t[e].tagName === document.createElement(o.trim()).tagName && r.push(t[e]) : t[e] && r.push(t[e])
        }
        return "string" == typeof e ? Array.prototype.forEach.call(document.querySelectorAll(e), function(e, t) {
            i(o, e, n)
        }) : i(o, e, n), r
    }, a.browser = function() {
        var e, t, o;
        return navigator.sayswho = (o = (t = navigator.userAgent).match(/(opera|chrome|safari|firefox|msie|trident(?=\/))\/?\s*(\d+)/i) || [], /trident/i.test(o[1]) ? "IE " + ((e = /\brv[ :]+(\d+)/g.exec(t) || [])[1] || "") : "Chrome" === o[1] && null != (e = t.match(/\b(OPR|Edge)\/(\d+)/)) ? e.slice(1).join(" ").replace("OPR", "Opera") : (o = o[2] ? [o[1], o[2]] : [navigator.appName, navigator.appVersion, "-?"], null != (e = t.match(/version\/(\d+)/i)) && o.splice(1, 1, e[1]), o.join(" "))), {
            version: parseInt(navigator.sayswho.split(" ")[1]),
            type: navigator.sayswho.split(" ")[0],
            userAgent: navigator.userAgent
        }
    }, a.isNodeList = function(e) {
        e = Object.prototype.toString.call(e);
        return "[object NodeList]" === e || "[object Array]" === e
    }, a.getInnerHtmlContent = function(e) {
        return a.isCspTrustedType() ? window.OtTrustedType.TrustedTypePolicy.createHTML(e) : e
    }, a.getScriptUrl = function(e) {
        return a.isCspTrustedType() ? window.OtTrustedType.TrustedTypePolicy.createScriptURL(e) : e
    }, a.isCspTrustedType = function() {
        var e;
        return (null == (e = window.OtTrustedType) ? void 0 : e.isCspTrustedTypeEnabled) && (null == (e = window.OtTrustedType) ? void 0 : e.TrustedTypePolicy)
    }, a.prototype.fadeOut = function(e) {
        var t = this;
        if (void 0 === e && (e = 60), 1 <= this.el.length)
            for (var o = 0; o < this.el.length; o++) d(this.el[o], "\n                    visibility: hidden;\n                    opacity: 0;\n                    transition: visibility 0s " + e + "ms, opacity " + e + "ms linear;\n                ", !0);
        var n = setInterval(function() {
            if (1 <= t.el.length)
                for (var e = 0; e < t.el.length; e++) t.el[e].style.opacity <= 0 && (d(t.el[e], "display: none;", !0), clearInterval(n), "optanon-popup-bg" === t.el[e].id) && t.el[e].removeAttribute("style")
        }, e);
        return this
    }, a.prototype.hide = function() {
        if (1 <= this.el.length)
            for (var e = 0; e < this.el.length; e++) d(this.el[e], "display: none;", !0), this.el[e].setAttribute(gt, !0);
        else a.isNodeList(this.el) || (d(this.el, "display: none;", !0), this.el.setAttribute(gt, !0));
        return this
    }, a.prototype.show = function(e) {
        if (void 0 === e && (e = "block"), 1 <= this.el.length)
            for (var t = 0; t < this.el.length; t++) d(this.el[t], "display: " + e + ";", !0), this.el[t].removeAttribute(gt);
        else a.isNodeList(this.el) || (d(this.el, "display: " + e + ";", !0), this.el.removeAttribute(gt));
        return this
    }, a.prototype.remove = function() {
        if (1 <= this.el.length)
            for (var e = 0; e < this.el.length; e++) this.el[e].parentNode.removeChild(this.el[e]);
        else this.el.parentNode.removeChild(this.el);
        return this
    }, a.prototype.css = function(e) {
        if (e)
            if (1 <= this.el.length) {
                if (!e.includes(":")) return this.el[0].style[e];
                for (var t = 0; t < this.el.length; t++) d(this.el[t], e)
            } else {
                if (!e.includes(":")) return this.el.style[e];
                d(this.el, e)
            }
        return this
    }, a.prototype.removeClass = function(e) {
        if (1 <= this.el.length)
            for (var t = 0; t < this.el.length; t++) this.el[t].classList ? this.el[t].classList.remove(e) : this.el[t].className = this.el[t].className.replace(new RegExp("(^|\\b)" + e.split(" ").join("|") + "(\\b|$)", "gi"), " ");
        else this.el.classList ? this.el.classList.remove(e) : this.el.className = this.el.className.replace(new RegExp("(^|\\b)" + e.split(" ").join("|") + "(\\b|$)", "gi"), " ");
        return this
    }, a.prototype.addClass = function(e) {
        if (1 <= this.el.length)
            for (var t = 0; t < this.el.length; t++) this.el[t].classList ? this.el[t].classList.add(e) : this.el[t].className += " " + e;
        else this.el.classList ? this.el.classList.add(e) : this.el.className += " " + e;
        return this
    }, a.prototype.on = function(r, i, s) {
        var e = this;
        if ("string" != typeof i)
            if (this.el && "HTML" === this.el.nodeName && "load" === r || "resize" === r || "scroll" === r) switch (r) {
                    case "load":
                        window.onload = i;
                        break;
                    case "resize":
                        window.onresize = i;
                        break;
                    case "scroll":
                        window.onscroll = i
                } else if (this.el && 1 <= this.el.length)
                    for (var t = 0; t < this.el.length; t++) this.el[t].addEventListener(r, i);
                else this.el && this.el instanceof Element && this.el.addEventListener(r, i);
        else if (this.el && "HTML" === this.el.nodeName && "load" === r || "resize" === r || "scroll" === r) switch (r) {
            case "load":
                window.onload = s;
                break;
            case "resize":
                window.onresize = s;
                break;
            case "scroll":
                window.onscroll = s
        } else {
            var a = function(o) {
                var n = o.target;
                e.el.eventExecuted = !0, Array.prototype.forEach.call(document.querySelectorAll(i), function(e, t) {
                    Lt["" + r + i] && delete Lt["" + r + i], e.addEventListener(r, s), e === n && s && s.call(e, o)
                }), e.el && e.el[0] ? e.el[0].removeEventListener(r, a) : e.el && e.el instanceof Element && e.el.removeEventListener(r, a)
            };
            if (this.el && 1 <= this.el.length)
                for (t = 0; t < this.el.length; t++) this.el[t].eventExecuted = !1, this.el[t].eventExecuted || this.el[t].addEventListener(r, a);
            else this.el && (this.el.eventExecuted = !1, !this.el.eventExecuted) && this.el instanceof Element && (Lt["" + r + i] || (Lt["" + r + i] = !0, this.el.addEventListener(r, a)))
        }
        return this
    }, a.prototype.off = function(e, t) {
        if (1 <= this.el.length)
            for (var o = 0; o < this.el.length; o++) this.el[o].removeEventListener(e, t);
        else this.el.removeEventListener(e, t);
        return this
    }, a.prototype.one = function(t, o) {
        var n = this;
        if (1 <= this.el.length)
            for (var e = 0; e < this.el.length; e++) this.el[e].addEventListener(t, function(e) {
                e.stopPropagation(), e.currentTarget.dataset.triggered || (o(), e.currentTarget.dataset.triggered = !0)
            });
        else {
            var r = function(e) {
                e.stopPropagation(), o(), n.off(t, r)
            };
            this.el.addEventListener(t, r)
        }
        return this
    }, a.prototype.trigger = function(e) {
        e = new CustomEvent(e, {
            customEvent: "yes"
        });
        return this.el.dispatchEvent(e), this
    }, a.prototype.focus = function() {
        return (1 <= this.el.length ? this.el[0] : this.el).focus(), this
    }, a.prototype.attr = function(e, t) {
        return this.el && 1 <= this.el.length ? t ? ("class" === e ? this.addClass(t) : this.el[0].setAttribute(e, t), this) : this.el[0].getAttribute(e) : t && this.el ? ("class" === e ? this.addClass(t) : this.el.setAttribute(e, t), this) : this.el && this.el.getAttribute(e)
    }, a.prototype.html = function(e) {
        if (null == e) return (1 <= this.el.length ? this.el[0] : this.el).innerHTML;
        var t = a.getInnerHtmlContent(e);
        if (1 <= this.el.length)
            for (var o = 0; o < this.el.length; o++) this.el[o].innerHTML = t;
        else this.el.innerHTML = t;
        return this
    }, a.prototype.append = function(e) {
        if ("string" != typeof e || e.includes("<") || e.includes(">"))
            if (Array.isArray(e)) {
                var o = this;
                Array.prototype.forEach.call(e, function(e, t) {
                    document.querySelector(o.selector).appendChild(new a(e, "ce").el)
                })
            } else {
                if ("string" == typeof e || Array.isArray(e)) return this.appendHtmlElement(e);
                if ("string" == typeof this.selector) document.querySelector(this.selector).appendChild(e);
                else if (1 <= e.length)
                    for (var t = 0; t < e.length; t++) this.selector.appendChild(e[t]);
                else this.selector.appendChild(e)
            }
        else this.el.insertAdjacentText("beforeend", e);
        return this
    }, a.prototype.text = function(o) {
        if (this.el) {
            if (1 <= this.el.length) {
                if (!o) return this.el[0].textContent;
                Array.prototype.forEach.call(this.el, function(e, t) {
                    e.textContent = o
                })
            } else {
                if (!o) return this.el.textContent;
                this.el.textContent = o
            }
            return this
        }
    }, a.prototype.data = function(o, n) {
        if (!(this.el.length < 1)) {
            if (!(1 <= this.el.length)) return r(this.el, n);
            Array.prototype.forEach.call(this.el, function(e, t) {
                r(e, n)
            })
        }
        return this;

        function r(e, t) {
            if (!t) return JSON.parse(e.getAttribute("data-" + o));
            "object" == typeof t ? e.setAttribute("data-" + o, JSON.stringify(t)) : e.setAttribute("data-" + o, t)
        }
    }, a.prototype.height = function(e) {
        this.el.length && (this.el = this.el[0]);
        for (var t = parseInt(window.getComputedStyle(this.el, null).getPropertyValue("padding-top").split("px")[0]), o = parseInt(window.getComputedStyle(this.el, null).getPropertyValue("padding-bottom").split("px")[0]), n = parseInt(window.getComputedStyle(this.el, null).getPropertyValue("margin-top").split("px")[0]), r = parseInt(window.getComputedStyle(this.el, null).getPropertyValue("margin-bottom").split("px")[0]), i = parseInt(window.getComputedStyle(this.el, null).getPropertyValue("height").split("px")[0]), s = [t, o, n, r], a = 0, l = 0; l < s.length; l++) 0 < s[l] && (a += s[l]);
        return e ? (t = e.toString().split(parseInt(e))[1] ? e.toString().split(parseInt(e))[1] : "px", o = "number" == typeof e ? e : parseInt(e.toString().split(t)[0]), (t && "px" === t || "%" === t || "em" === t || "rem" === t) && (0 < o ? d(this.el, "height: " + (a + o + t) + ";", !0) : "auto" === e && d(this.el, "height: " + e + ";", !0)), this) : this.selector === document ? i : this.el.clientHeight - a
    }, a.prototype.each = function(e) {
        var t = !1;
        return void 0 === this.el.length && (this.el = [this.el], t = !0), Array.prototype.forEach.call(this.el, e), t && (this.el = this.el[0]), this
    }, a.prototype.is = function(e) {
        return this.el.length ? (this.el[0].matches || this.el[0].matchesSelector || this.el[0].msMatchesSelector || this.el[0].mozMatchesSelector || this.el[0].webkitMatchesSelector || this.el[0].oMatchesSelector).call(this.el[0], e) : (this.el.matches || this.el.matchesSelector || this.el.msMatchesSelector || this.el.mozMatchesSelector || this.el.webkitMatchesSelector || this.el.oMatchesSelector).call(this.el, e)
    }, a.prototype.filter = function(e) {
        return this.el = Array.prototype.filter.call(document.querySelectorAll(this.selector), e), this
    }, a.prototype.animate = function(e, t) {
        var o, n, r, i, s = this;
        this.el = document.querySelector(this.selector);
        for (o in e) n = o, i = r = void 0, r = parseInt(e[n]), i = e[n].split(parseInt(e[n]))[1] ? e[n].split(parseInt(e[n]))[1] : "px", r = s.createKeyFrameAnimation(n, s.el, r, i), (i = document.head.querySelector("#onetrust-style")) ? i.innerHTML = a.getInnerHtmlContent(i.innerHTML + r) : ((i = document.createElement("style")).id = "onetrust-legacy-style", i.type = "text/css", i.innerHTML = a.getInnerHtmlContent(r), document.head.appendChild(i)), s.addWebKitAnimation(n, t);
        return this
    }, a.prototype.scrollTop = function() {
        return this.el.scrollTop
    }, a.prototype.appendHtmlElement = function(o) {
        var n, r, e;
        return "string" == typeof this.selector ? document.querySelector(this.selector).appendChild(new a(o, "ce").el) : this.useEl ? (n = document.createDocumentFragment(), (r = !(!o.includes("<th") && !o.includes("<td"))) && (e = o.split(" ")[0].split("<")[1], n.appendChild(document.createElement(e)), n.firstChild.innerHTML = a.getInnerHtmlContent(o)), Array.prototype.forEach.call(this.el, function(e, t) {
            r ? e.appendChild(n.firstChild) : e.appendChild(new a(o, "ce").el)
        })) : this.selector.appendChild(new a(o, "ce").el), this
    }, a.prototype.createKeyFrameAnimation = function(e, t, o, n) {
        return "\n        @keyframes slide-" + ("top" === e ? "up" : "down") + "-custom {\n            0% {\n                " + ("top" === e ? "top" : "bottom") + ": " + ("top" === e ? t.getBoundingClientRect().top : window.innerHeight) + "px !important;\n            }\n            100% {\n                " + ("top" === e ? "top" : "bottom") + ": " + (o + n) + ";\n            }\n        }\n        @-webkit-keyframes slide-" + ("top" === e ? "up" : "down") + "-custom {\n            0% {\n                " + ("top" === e ? "top" : "bottom") + ": " + ("top" === e ? t.getBoundingClientRect().top : window.innerHeight) + "px !important;\n            }\n            100% {\n                " + ("top" === e ? "top" : "bottom") + ": " + (o + n) + ";\n            }\n        }\n        @-moz-keyframes slide-" + ("top" === e ? "up" : "down") + "-custom {\n            0% {\n                " + ("top" === e ? "top" : "bottom") + ": " + ("top" === e ? t.getBoundingClientRect().top : window.innerHeight) + "px !important;\n            }\n            100% {\n                " + ("top" === e ? "top" : "bottom") + ": " + (o + n) + ";\n            }\n        }\n        "
    }, a.prototype.addWebKitAnimation = function(e, t) {
        (a.browser().type = a.browser().version <= 8) ? d(this.el, "top" === e ? "-webkit-animation: slide-up-custom " : "-webkit-animation: slide-down-custom " + t + "ms ease-out forwards;"): d(this.el, "\n                animation-name: " + ("top" === e ? "slide-up-custom" : "slide-down-custom") + ";\n                animation-duration: " + t + "ms;\n                animation-fill-mode: forwards;\n                animation-timing-function: ease-out;\n            ", !0)
    };
    var v = a;

    function a(e, t) {
        switch (void 0 === t && (t = ""), this.selector = e, this.useEl = !1, t) {
            case "ce":
                var o = a.browser().type.toLowerCase(),
                    n = a.browser().version;
                n < 10 && "safari" === o || "chrome" === o && n <= 44 || n <= 40 && "firefox" === o ? ((n = document.implementation.createHTMLDocument()).body.innerHTML = a.getInnerHtmlContent(e), this.el = n.body.children[0]) : (o = document.createRange().createContextualFragment(a.getInnerHtmlContent(e)), this.el = o.firstChild), this.length = 1;
                break;
            case "":
                this.el = e === document || e === window ? document.documentElement : "string" != typeof e ? e : document.querySelectorAll(e), this.length = e === document || e === window || "string" != typeof e ? 1 : this.el.length;
                break;
            default:
                this.length = 0
        }
    }

    function T(e, t) {
        return new v(e, t = void 0 === t ? "" : t)
    }
    var Lt = {};

    function _t() {}
    _t.prototype.convertKeyValueLowerCase = function(e) {
        for (var t in e) e[t.toLowerCase()] ? e[t.toLowerCase()] = e[t].toLowerCase() : (e[t] && (e[t.toLowerCase()] = e[t].toLowerCase()), delete e[t]);
        return e
    }, _t.prototype.arrToStr = function(e) {
        return e.toString()
    }, _t.prototype.strToArr = function(e) {
        return e ? e.split(",") : []
    }, _t.prototype.strToMap = function(e) {
        if (!e) return new Map;
        for (var t = new Map, o = 0, n = this.strToArr(e); o < n.length; o++) {
            var r = n[o].split(":");
            t.set(r[0], "1" === r[1])
        }
        return t
    }, _t.prototype.empty = function(e) {
        var t = document.getElementById(e);
        if (t)
            for (; t.hasChildNodes();) t.removeChild(t.lastChild)
    }, _t.prototype.show = function(e) {
        e = document.getElementById(e);
        e && d(e, "display: block;", !0)
    }, _t.prototype.remove = function(e) {
        e = document.getElementById(e);
        e && e.parentNode && e.parentNode.removeChild(e)
    }, _t.prototype.appendTo = function(e, t) {
        var o, e = document.getElementById(e);
        e && ((o = document.createElement("div")).innerHTML = v.getInnerHtmlContent(t), e.appendChild(o))
    }, _t.prototype.contains = function(e, t) {
        for (var o = 0; o < e.length; o += 1)
            if (e[o].toString().toLowerCase() === t.toString().toLowerCase()) return !0;
        return !1
    }, _t.prototype.indexOf = function(e, t) {
        for (var o = 0; o < e.length; o += 1)
            if (e[o] === t) return o;
        return -1
    }, _t.prototype.endsWith = function(e, t) {
        return -1 !== e.indexOf(t, e.length - t.length)
    }, _t.prototype.generateUUID = function() {
        var o = (new Date).getTime();
        return "undefined" != typeof performance && "function" == typeof performance.now && (o += performance.now()), "xxxxxxxx-xxxx-4xxx-yxxx-xxxxxxxxxxxx".replace(/[xy]/g, function(e) {
            var t = (o + 16 * Math.random()) % 16 | 0;
            return o = Math.floor(o / 16), ("x" === e ? t : 3 & t | 8).toString(16)
        })
    }, _t.prototype.getActiveIdArray = function(e) {
        return e.filter(function(e) {
            return "true" === e.split(":")[1]
        }).map(function(e) {
            return parseInt(e.split(":")[0])
        })
    }, _t.prototype.distinctArray = function(e) {
        var t = new Array;
        return e.forEach(function(e) {
            t.indexOf(e) < 0 && t.push(e)
        }), t
    }, _t.prototype.findIndex = function(e, t) {
        for (var o = -1, n = 0; n < e.length; n++)
            if (void 0 !== e[n] && t(e[n], n)) {
                o = n;
                break
            }
        return o
    }, _t.prototype.getURL = function(e) {
        var t = document.createElement("a");
        return t.href = e, t
    }, _t.prototype.removeURLPrefixes = function(e) {
        return e.toLowerCase().replace(/(^\w+:|^)\/\//, "").replace("www.", "")
    }, _t.prototype.removeChild = function(e) {
        if (e)
            if (e instanceof NodeList || e instanceof Array)
                for (var t = 0; t < e.length; t++) e[t].parentElement.removeChild(e[t]);
            else e.parentElement.removeChild(e)
    }, _t.prototype.getRelativeURL = function(e, t, o) {
        return void 0 === o && (o = !1), t ? (t = "./" + e.replace(/^(http|https):\/\//, "").split("/").slice(1).join("/").replace(".json", ""), o ? t : t + ".js") : e
    }, _t.prototype.setCheckedAttribute = function(e, t, o) {
        (t = e ? document.querySelector(e) : t) && (o ? t.setAttribute("checked", "") : t.removeAttribute("checked"), t.checked = o)
    }, _t.prototype.setAriaCheckedAttribute = function(e, t, o) {
        (t = e ? document.querySelector(e) : t) && t.setAttribute("aria-checked", o)
    }, _t.prototype.setDisabledAttribute = function(e, t, o) {
        (t = e ? document.querySelector(e) : t) && (o ? t.setAttribute("disabled", o.toString()) : t.removeAttribute("disabled"))
    }, _t.prototype.setHtmlAttributes = function(e, t) {
        for (var o in t) e.setAttribute(o, t[o]), e[o] = t[o]
    }, _t.prototype.calculateCookieLifespan = function(e) {
        return e < 0 ? I.LifespanTypeText : (e = Math.floor(e / fe.maxSecToDays)) < fe.minDays ? "< 1 " + I.PCenterVendorListLifespanDay : e < fe.maxDays ? e + " " + I.PCenterVendorListLifespanDays : 1 === (e = Math.floor(e / fe.maxDays)) ? e + " " + I.PCenterVendorListLifespanMonth : e + " " + I.PCenterVendorListLifespanMonths
    }, _t.prototype.insertElement = function(e, t, o) {
        e && t && e.insertAdjacentElement(o, t)
    }, _t.prototype.customQuerySelector = function(t) {
        return function(e) {
            return t.querySelector(e)
        }
    }, _t.prototype.customQuerySelectorAll = function(t) {
        return function(e) {
            return t.querySelectorAll(e)
        }
    };
    var g, P = new _t,
        Et = (Ot.prototype.removeAlertBox = function() {
            null !== this.getCookie(C.ALERT_BOX_CLOSED) && this.setCookie(C.ALERT_BOX_CLOSED, "", 0, !0)
        }, Ot.prototype.removeIab1 = function() {
            null !== this.getCookie(ue.Iab1Pub) && this.setCookie(ue.Iab1Pub, "", 0, !0)
        }, Ot.prototype.removeIab2 = function() {
            null !== this.getCookie(ue.Iab2Pub) && this.setCookie(ue.Iab2Pub, "", 0, !0)
        }, Ot.prototype.removeAddtlStr = function() {
            null !== this.getCookie(C.ADDITIONAL_CONSENT_STRING) && this.setCookie(C.ADDITIONAL_CONSENT_STRING, "", 0, !0)
        }, Ot.prototype.removeVariant = function() {
            null !== this.getCookie(C.SELECTED_VARIANT) && this.setCookie(C.SELECTED_VARIANT, "", 0, !0)
        }, Ot.prototype.removeOptanon = function() {
            null !== this.getCookie(C.OPTANON_CONSENT) && this.setCookie(C.OPTANON_CONSENT, "", 0, !0)
        }, Ot.prototype.removePreview = function() {
            null !== this.getCookie(C.OT_PREVIEW) && this.setCookie(C.OT_PREVIEW, "", 0, !0)
        }, Ot.prototype.removeAllCookies = function() {
            this.removeIab1(), this.removeIab2(), this.removePreview(), this.removeOptanon(), this.removeVariant(), this.removeAlertBox(), this.removeAddtlStr(), this.removeAmpStorage()
        }, Ot.prototype.writeCookieParam = function(e, t, o, n) {
            var r, i, s, a = {},
                l = this.getCookie(e);
            if (l)
                for (i = l.split("&"), r = 0; r < i.length; r += 1) s = i[r].split("="), a[decodeURIComponent(s[0])] = s[0] === t && n ? decodeURIComponent(s[1]) : decodeURIComponent(s[1]).replace(/\+/g, " ");
            a[t] = o;
            l = m.moduleInitializer.TenantFeatures;
            l && l.CookieV2CookieDateTimeInISO ? a.datestamp = (new Date).toISOString() : a.datestamp = (new Date).toString(), a.version = L.otSDKVersion, o = this.param(a), this.setCookie(e, o, I.ReconsentFrequencyDays)
        }, Ot.prototype.readCookieParam = function(e, t, o) {
            var n, r, i, s, e = this.getCookie(e);
            if (e) {
                for (r = {}, i = e.split("&"), n = 0; n < i.length; n += 1) s = i[n].split("="), r[decodeURIComponent(s[0])] = o ? decodeURIComponent(s[1]) : decodeURIComponent(s[1]).replace(/\+/g, " ");
                return t && r[t] ? r[t] : t && !r[t] ? "" : r
            }
            return ""
        }, Ot.prototype.getCookie = function(e) {
            if (m && m.moduleInitializer && m.moduleInitializer.MobileSDK) {
                var t = this.getCookieDataObj(e);
                if (t) return t.value
            }
            if (L.isAMP && (L.ampData = JSON.parse(localStorage.getItem(L.dataDomainId)) || {}, L.ampData)) return L.ampData[e] || null;
            for (var o, n = e + "=", r = document.cookie.split(";"), i = 0; i < r.length; i += 1) {
                for (o = r[i];
                    " " === o.charAt(0);) o = o.substring(1, o.length);
                if (0 === o.indexOf(n)) return o.substring(n.length, o.length)
            }
            return null
        }, Ot.prototype.setAmpStorage = function() {
            window.localStorage.setItem(L.dataDomainId, JSON.stringify(L.ampData))
        }, Ot.prototype.removeAmpStorage = function() {
            window.localStorage.removeItem(L.dataDomainId)
        }, Ot.prototype.handleAmp = function(e, t) {
            "" !== t ? L.ampData[e] = t : delete L.ampData[e], 0 === Object.keys(L.ampData).length ? this.removeAmpStorage() : this.setAmpStorage()
        }, Ot.prototype.getExpiryValue = function(e, t, o) {
            return void 0 === t && (t = !1), void 0 === o && (o = new Date), e ? (o.setTime(o.getTime() + 24 * e * 60 * 60 * 1e3), "; expires=" + o.toUTCString()) : t ? "; expires=" + new Date(0).toUTCString() : ""
        }, Ot.prototype.getDomainUrl = function() {
            var e, t = m.moduleInitializer;
            return t && t.RootDomainConsentEnabled ? e = t.RootDomainUrl : t && t.Domain && (e = t.Domain), e
        }, Ot.prototype.setCookie = function(e, t, o, n, r) {
            var i, s, a, l, c, d;
            void 0 === n && (n = !1), void 0 === r && (r = new Date), L.isAMP ? this.handleAmp(e, t) : (o = this.getExpiryValue(o, n, r), n = m.moduleInitializer, s = "", (i = (i = this.getDomainUrl()) ? i.split("/") : []).length <= 1 ? i[1] = "" : s = i.slice(1).join("/"), a = "Samesite=Lax", n.CookieSameSiteNoneEnabled && (a = "Samesite=None; Secure"), l = m.moduleInitializer.TenantFeatures, c = n.ScriptType === Ue.TEST || n.ScriptType === Ue.LOCAL_TEST, L.isPreview || !c && !n.MobileSDK ? (d = t + o + "; path=/" + s + "; domain=." + i[0] + "; " + a, l && l.CookieV2CookiePriority && (d += ";Priority=High;"), document.cookie = e + "=" + d) : (d = t + o + "; path=/; " + a, l && l.CookieV2CookiePriority && (d += ";Priority=High;"), n.MobileSDK ? this.setCookieDataObj({
                name: e,
                value: t,
                expires: o,
                date: r,
                domainAndPath: i
            }) : document.cookie = e + "=" + d))
        }, Ot.prototype.setCookieDataObj = function(t) {
            var e;
            t && (L.otCookieData || (window.OneTrust && window.OneTrust.otCookieData ? L.otCookieData = window.OneTrust.otCookieData : L.otCookieData = []), -1 < (e = P.findIndex(L.otCookieData, function(e) {
                return e.name === t.name
            })) ? L.otCookieData[e] = t : L.otCookieData.push(t))
        }, Ot.prototype.getCookieDataObj = function(t) {
            L.otCookieData && 0 !== L.otCookieData.length || (window.OneTrust && window.OneTrust.otCookieData ? L.otCookieData = window.OneTrust.otCookieData : L.otCookieData = []);
            var e = P.findIndex(L.otCookieData, function(e) {
                return e.name === t
            });
            if (0 <= e) {
                var o = L.otCookieData[e];
                if (o.date) return new Date(o.date) < new Date ? (L.otCookieData.splice(e, 1), null) : o
            }
            return null
        }, Ot.prototype.param = function(e) {
            var t, o = "";
            for (t in e) e.hasOwnProperty(t) && ("" !== o && (o += "&"), o += t + "=" + encodeURIComponent(e[t]).replace(/%20/g, "+"));
            return o
        }, Ot);

    function Ot() {}
    var k, b, Vt = {
            P_Content: "#ot-pc-content",
            P_Logo: ".ot-pc-logo",
            P_Title: "#ot-pc-title",
            P_Policy_Txt: "#ot-pc-desc",
            P_Vendor_Title_Elm: "#ot-lst-title",
            P_Vendor_Title: "#ot-lst-title h3",
            P_Manage_Cookies_Txt: "#ot-category-title",
            P_Label_Txt: ".ot-label-txt",
            P_Category_Header: ".ot-cat-header",
            P_Category_Grp: ".ot-cat-grp",
            P_Category_Item: ".ot-cat-item",
            P_Vendor_List: "#ot-pc-lst",
            P_Vendor_Content: "#ot-lst-cnt",
            P_Vendor_Container: "#ot-ven-lst",
            P_Ven_Bx: "ot-ven-box",
            P_Ven_Name: ".ot-ven-name",
            P_Ven_Link: ".ot-ven-link",
            P_Ven_Leg_Claim: ".ot-ven-legclaim-link",
            P_Ven_Ctgl: "ot-ven-ctgl",
            P_Ven_Ltgl: "ot-ven-litgl",
            P_Ven_Ltgl_Only: "ot-ven-litgl-only",
            P_Ven_Opts: ".ot-ven-opts",
            P_Triangle: "#ot-anchor",
            P_Fltr_Modal: "#ot-fltr-modal",
            P_Fltr_Options: ".ot-fltr-opts",
            P_Fltr_Option: ".ot-fltr-opt",
            P_Select_Cntr: "#ot-sel-blk",
            P_Host_Cntr: "#ot-host-lst",
            P_Host_Hdr: ".ot-host-hdr",
            P_Host_Desc: ".ot-host-desc",
            P_Li_Hdr: ".ot-pli-hdr",
            P_Li_Title: ".ot-li-title",
            P_Sel_All_Vendor_Consent_Handler: "#select-all-vendor-leg-handler",
            P_Sel_All_Vendor_Leg_Handler: "#select-all-vendor-groups-handler",
            P_Sel_All_Host_Handler: "#select-all-hosts-groups-handler",
            P_Host_Title: ".ot-host-name",
            P_Leg_Select_All: ".ot-sel-all-hdr",
            P_Leg_Header: ".ot-li-hdr",
            P_Acc_Header: ".ot-acc-hdr",
            P_Cnsnt_Header: ".ot-consent-hdr",
            P_Tgl_Cntr: ".ot-tgl-cntr",
            P_CBx_Cntr: ".ot-chkbox",
            P_Sel_All_Host_El: "ot-selall-hostcntr",
            P_Sel_All_Vendor_Consent_El: "ot-selall-vencntr",
            P_Sel_All_Vendor_Leg_El: "ot-selall-licntr",
            P_c_Name: "ot-c-name",
            P_c_Host: "ot-c-host",
            P_c_Duration: "ot-c-duration",
            P_c_Type: "ot-c-type",
            P_c_Category: "ot-c-category",
            P_c_Desc: "ot-c-description",
            P_Host_View_Cookies: ".ot-host-expand",
            P_Host_Opt: ".ot-host-opt",
            P_Host_Info: ".ot-host-info",
            P_Arrw_Cntr: ".ot-arw-cntr",
            P_Acc_Txt: ".ot-acc-txt",
            P_Vendor_CheckBx: "ot-ven-chkbox",
            P_Vendor_LegCheckBx: "ot-ven-leg-chkbox",
            P_Host_UI: "ot-hosts-ui",
            P_Host_Cnt: "ot-host-cnt",
            P_Host_Bx: "ot-host-box",
            P_Ven_Dets: ".ot-ven-dets",
            P_Ven_Disc: ".ot-ven-disc",
            P_Gven_List: "#ot-gn-venlst",
            P_Close_Btn: ".ot-close-icon",
            P_Ven_Lst_Cntr: ".ot-vlst-cntr",
            P_Host_Lst_cntr: ".ot-hlst-cntr",
            P_Sub_Grp_Cntr: ".ot-subgrp-cntr",
            P_Subgrp_Desc: ".ot-subgrp-desc",
            P_Subgp_ul: ".ot-subgrps",
            P_Subgrp_li: ".ot-subgrp",
            P_Subgrp_Tgl_Cntr: ".ot-subgrp-tgl",
            P_Grp_Container: ".ot-grps-cntr",
            P_Privacy_Txt: "#ot-pvcy-txt",
            P_Privacy_Hdr: "#ot-pvcy-hdr",
            P_Active_Menu: "ot-active-menu",
            P_Desc_Container: ".ot-desc-cntr",
            P_Tab_Grp_Hdr: "ot-grp-hdr1",
            P_Search_Cntr: "#ot-search-cntr",
            P_Clr_Fltr_Txt: "#clear-filters-handler",
            P_Acc_Grp_Desc: ".ot-acc-grpdesc",
            P_Acc_Container: ".ot-acc-grpcntr",
            P_Line_Through: "line-through",
            P_Vendor_Search_Input: "#vendor-search-handler"
        },
        Dt = {
            P_Grp_Container: ".groups-container",
            P_Content: "#ot-content",
            P_Category_Header: ".category-header",
            P_Desc_Container: ".description-container",
            P_Label_Txt: ".label-text",
            P_Acc_Grp_Desc: ".ot-accordion-group-pc-container",
            P_Leg_Int_Hdr: ".leg-int-header",
            P_Not_Always_Active: "p:not(.ot-always-active)",
            P_Category_Grp: ".category-group",
            P_Category_Item: ".category-item",
            P_Sub_Grp_Cntr: ".cookie-subgroups-container",
            P_Acc_Container: ".ot-accordion-pc-container",
            P_Close_Btn: ".pc-close-button",
            P_Logo: ".pc-logo",
            P_Title: "#pc-title",
            P_Privacy_Txt: "#privacy-text",
            P_Privacy_Hdr: "#pc-privacy-header",
            P_Policy_Txt: "#pc-policy-text",
            P_Manage_Cookies_Txt: "#manage-cookies-text",
            P_Vendor_Title: "#vendors-list-title",
            P_Vendor_Title_Elm: "#vendors-list-title",
            P_Vendor_List: "#vendors-list",
            P_Vendor_Content: "#vendor-list-content",
            P_Vendor_Container: "#vendors-list-container",
            P_Ven_Bx: "vendor-box",
            P_Ven_Name: ".vendor-title",
            P_Ven_Link: ".vendor-privacy-notice",
            P_Ven_Leg_Claim: ".vendor-legclaim-link",
            P_Ven_Ctgl: "ot-vendor-consent-tgl",
            P_Ven_Ltgl: "ot-leg-int-tgl",
            P_Ven_Ltgl_Only: "ot-leg-int-tgl-only",
            P_Ven_Opts: ".vendor-options",
            P_Triangle: "#ot-triangle",
            P_Fltr_Modal: "#ot-filter-modal",
            P_Fltr_Options: ".ot-group-options",
            P_Fltr_Option: ".ot-group-option",
            P_Select_Cntr: "#select-all-container",
            P_Host_Cntr: "#hosts-list-container",
            P_Host_Hdr: ".host-info",
            P_Host_Desc: ".host-description",
            P_Host_Opt: ".host-option-group",
            P_Host_Info: ".vendor-host",
            P_Ven_Dets: ".vendor-purpose-groups",
            P_Ven_Disc: ".ot-ven-disc",
            P_Gven_List: "#ot-gn-venlst",
            P_Arrw_Cntr: ".ot-arrow-container",
            P_Li_Hdr: ".leg-int-header",
            P_Li_Title: ".leg-int-title",
            P_Acc_Txt: ".accordion-text",
            P_Tgl_Cntr: ".ot-toggle-group",
            P_CBx_Cntr: ".ot-chkbox-container",
            P_Host_Title: ".host-title",
            P_Leg_Select_All: ".leg-int-sel-all-hdr",
            P_Leg_Header: ".leg-int-hdr",
            P_Cnsnt_Header: ".consent-hdr",
            P_Acc_Header: ".accordion-header",
            P_Sel_All_Vendor_Consent_Handler: "#select-all-vendor-leg-handler",
            P_Sel_All_Vendor_Leg_Handler: "#select-all-vendor-groups-handler",
            P_Sel_All_Host_Handler: "#select-all-hosts-groups-handler",
            P_Sel_All_Host_El: "select-all-hosts-input-container",
            P_Sel_All_Vendor_Consent_El: "select-all-vendors-input-container",
            P_Sel_All_Vendor_Leg_El: "select-all-vendors-leg-input-container",
            P_c_Name: "cookie-name-container",
            P_c_Host: "cookie-host-container",
            P_c_Duration: "cookie-duration-container",
            P_c_Type: "cookie-type-container",
            P_c_Category: "cookie-category-container",
            P_c_Desc: "cookie-description-container",
            P_Host_View_Cookies: ".host-view-cookies",
            P_Vendor_CheckBx: "vendor-chkbox",
            P_Vendor_LegCheckBx: "vendor-leg-chkbox",
            P_Host_UI: "hosts-list",
            P_Host_Cnt: "host-list-content",
            P_Host_Bx: "host-box",
            P_Ven_Lst_Cntr: ".category-vendors-list-container",
            P_Host_Lst_cntr: ".category-host-list-container",
            P_Subgrp_Desc: ".cookie-subgroups-description-legal",
            P_Subgp_ul: ".cookie-subgroups",
            P_Subgrp_li: ".cookie-subgroup",
            P_Subgrp_Tgl_Cntr: ".cookie-subgroup-toggle",
            P_Active_Menu: "active-group",
            P_Tab_Grp_Hdr: "group-toggle",
            P_Search_Cntr: "#search-container",
            P_Clr_Fltr_Txt: "#clear-filters-handler p",
            P_Vendor_Search_Input: "#vendor-search-handler"
        },
        Nt = {
            GroupTypes: {
                Cookie: "COOKIE",
                Bundle: "BRANCH",
                Ft: "IAB2_FEATURE",
                Pur: "IAB2_PURPOSE",
                Spl_Ft: "IAB2_SPL_FEATURE",
                Spl_Pur: "IAB2_SPL_PURPOSE",
                Stack: "IAB2_STACK"
            },
            IdPatterns: {
                Pur: "IABV2_",
                Ft: "IFEV2_",
                Spl_Pur: "ISPV2_",
                Spl_Ft: "ISFV2_"
            }
        },
        wt = {
            GroupTypes: {
                Cookie: "COOKIE",
                Bundle: "BRANCH",
                Ft: "IAB2V2_FEATURE",
                Pur: "IAB2V2_PURPOSE",
                Spl_Ft: "IAB2V2_SPL_FEATURE",
                Spl_Pur: "IAB2V2_SPL_PURPOSE",
                Stack: "IAB2V2_STACK"
            },
            IdPatterns: {
                Pur: "IAB2V2_",
                Ft: "IFE2V2_",
                Spl_Pur: "ISP2V2_",
                Spl_Ft: "ISF2V2_"
            }
        };
    Bt.prototype.getDataLanguageCulture = function() {
        var e = h.getStubAttr(je);
        return e ? this.checkAndTansformLangCodeWithUnderdscore(e.toLowerCase()) : this.detectDocumentOrBrowserLanguage().toLowerCase()
    }, Bt.prototype.checkAndTansformLangCodeWithUnderdscore = function(e) {
        return e.replace(/\_/, "-")
    }, Bt.prototype.detectDocumentOrBrowserLanguage = function() {
        var e = "";
        if (A.langSwitcherPldr) {
            var t = P.convertKeyValueLowerCase(A.langSwitcherPldr),
                o = this.getUserLanguage().toLowerCase();
            if (!(e = t[o] || t[o + "-" + o] || (t.default === o ? t.default : null)))
                if (2 === o.length)
                    for (var n = 0; n < Object.keys(t).length; n += 1) {
                        var r = Object.keys(t)[n];
                        if (r.substr(0, 2) === o) {
                            e = t[r];
                            break
                        }
                    } else 2 < o.length && (e = t[o.substr(0, 2)]);
            e = e || t.default
        }
        return e
    }, Bt.prototype.getUserLanguage = function() {
        return A.useDocumentLanguage ? this.checkAndTansformLangCodeWithUnderdscore(document.documentElement.lang) : navigator.languages && navigator.languages.length ? navigator.languages[0] : navigator.language || navigator.userLanguage
    }, Bt.prototype.isValidLanguage = function(e, t) {
        var o = P.convertKeyValueLowerCase(A.langSwitcherPldr);
        return !(!o || !o[t] && !o[t + "-" + t] && o.default !== t)
    }, Bt.prototype.getLangJsonUrl = function(e) {
        void 0 === e && (e = null);
        var t, o = A.getRegionRule();
        if (e) {
            if (e = e.toLowerCase(), !this.isValidLanguage(o, e)) return null
        } else e = this.getDataLanguageCulture();
        return L.lang = e, L.consentLanguage = e.substr(0, 2), t = A.canUseConditionalLogic ? A.bannerDataParentURL + "/" + o.Id + "/" + A.Condition.Id + "/" + e : A.bannerDataParentURL + "/" + o.Id + "/" + e, t = A.multiVariantTestingEnabled ? A.bannerDataParentURL + "/" + o.Id + "/variants/" + A.selectedVariant.Id + "/" + e : t
    }, Bt.prototype.populateLangSwitcherPlhdr = function() {
        var e, t, o, n = A.getRegionRule();
        n && (e = n.Variants, A.multiVariantTestingEnabled && e ? (o = void 0, (t = g.getCookie(C.SELECTED_VARIANT)) && (o = e[P.findIndex(e, function(e) {
            return e.Id === t
        })]), t && o || (o = e[Math.floor(Math.random() * e.length)]), A.langSwitcherPldr = o.LanguageSwitcherPlaceholder, A.selectedVariant = o) : A.canUseConditionalLogic ? A.langSwitcherPldr = A.Condition.LanguageSwitcherPlaceholder : A.langSwitcherPldr = n.LanguageSwitcherPlaceholder)
    };
    var Gt, e = Bt;

    function Bt() {}
    Rt.prototype.getLangJson = function(e) {
        var t;
        return void 0 === e && (e = null), A.previewMode ? (t = JSON.parse(window.sessionStorage.getItem("otPreviewData")), Promise.resolve(t.langJson)) : (t = Gt.getLangJsonUrl(e)) ? xt.otFetch(t + ".json") : Promise.resolve(null)
    }, Rt.prototype.getPersistentCookieSvg = function(e) {
        e = e || I.cookiePersistentLogo;
        return e ? xt.otFetch(e, !0) : Promise.resolve(null)
    }, Rt.prototype.fetchGvlObj = function() {
        var e = m.moduleInitializer.IabV2Data.globalVendorListUrl;
        return "IAB2V2" === A.getRegionRuleType() && (e = m.moduleInitializer.Iab2V2Data.globalVendorListUrl), this.otFetch(e)
    }, Rt.prototype.fetchGoogleVendors = function() {
        var e = h.updateCorrectIABUrl(m.moduleInitializer.GoogleData.googleVendorListUrl);
        return h.checkMobileOfflineRequest(h.getBannerVersionUrl()) ? h.otFetchOfflineFile(P.getRelativeURL(e, !0)) : (A.mobileOnlineURL.push(e), this.otFetch(e))
    }, Rt.prototype.getStorageDisclosure = function(t) {
        return F(this, void 0, void 0, function() {
            return M(this, function(e) {
                return [2, this.otFetch(t, !1, !0)]
            })
        })
    }, Rt.prototype.loadCMP = function() {
        var o = this;
        return new Promise(function(e) {
            var t = o.checkIfRequiresPollyfill() ? "otTCF-ie" : "otTCF";
            h.jsonp(h.getBannerVersionUrl() + "/" + t + ".js", e, e)
        })
    }, Rt.prototype.loadGPP = function() {
        return new Promise(function(e) {
            h.jsonp(h.getBannerVersionUrl() + "/otGPP.js", e, e)
        })
    }, Rt.prototype.getCSBtnContent = function() {
        return F(this, void 0, void 0, function() {
            var t, o, n, r;
            return M(this, function(e) {
                switch (e.label) {
                    case 0:
                        return (t = I.useRTL ? Se.RTL : Se.LTR, L.csBtnAsset[t]) ? [3, 2] : (o = h.getBannerSDKAssestsUrl() + "/" + (I.useRTL ? ze : Ke), n = L.csBtnAsset, r = t, [4, this.otFetch(o)]);
                    case 1:
                        n[r] = e.sent(), e.label = 2;
                    case 2:
                        return [2, L.csBtnAsset[t]]
                }
            })
        })
    }, Rt.prototype.getPcContent = function(i) {
        return void 0 === i && (i = !1), F(this, void 0, void 0, function() {
            var t, o, n, r;
            return M(this, function(e) {
                switch (e.label) {
                    case 0:
                        return (t = I.useRTL ? Se.RTL : Se.LTR, L.pcAsset[t] && !i) ? [3, 2] : (o = h.getBannerSDKAssestsUrl(), I.PCTemplateUpgrade && (o += "/v2"), o = o + "/" + A.pcName + (I.useRTL ? "Rtl" : "") + ".json", n = L.pcAsset, r = t, [4, this.otFetch(o)]);
                    case 1:
                        n[r] = e.sent(), e.label = 2;
                    case 2:
                        return [2, L.pcAsset[t]]
                }
            })
        })
    }, Rt.prototype.getBannerContent = function(s, a) {
        return void 0 === s && (s = !1), void 0 === a && (a = null), F(this, void 0, void 0, function() {
            var t, o, n, r, i;
            return M(this, function(e) {
                switch (e.label) {
                    case 0:
                        if (t = I.useRTL ? Se.RTL : Se.LTR, o = a || Gt.getDataLanguageCulture(), L.bAsset[t] && !s) return [3, 2];
                        if (i = A.getRegionRule(), n = void 0, m.fp.CookieV2SSR) {
                            if (A.previewMode) return r = JSON.parse(window.sessionStorage.getItem("otPreviewData")), [2, Promise.resolve(r.bLayout)];
                            n = A.bannerDataParentURL + "/" + i.Id, A.canUseConditionalLogic && (n += "/" + A.Condition.Id), n += "/bLayout-" + o + ".json"
                        } else n = h.getBannerSDKAssestsUrl() + ("/" + A.bannerName + (I.useRTL ? "Rtl" : "")) + ".json";
                        return r = L.bAsset, i = t, [4, this.otFetch(n)];
                    case 1:
                        r[i] = e.sent(), e.label = 2;
                    case 2:
                        return [2, L.bAsset[t]]
                }
            })
        })
    }, Rt.prototype.getCommonStyles = function(i) {
        return void 0 === i && (i = !1), F(this, void 0, void 0, function() {
            var t, o, n, r;
            return M(this, function(e) {
                switch (e.label) {
                    case 0:
                        return (t = I.useRTL ? Se.RTL : Se.LTR, L.cStyles[t] && !i) ? [3, 2] : (o = h.getBannerSDKAssestsUrl() + "/otCommonStyles" + (I.useRTL ? "Rtl" : "") + ".css", n = L.cStyles, r = t, [4, this.otFetch(o, !0)]);
                    case 1:
                        n[r] = e.sent(), e.label = 2;
                    case 2:
                        return [2, L.cStyles[t]]
                }
            })
        })
    }, Rt.prototype.getSyncNtfyContent = function() {
        return F(this, void 0, void 0, function() {
            var t, o, n, r;
            return M(this, function(e) {
                switch (e.label) {
                    case 0:
                        return (t = I.useRTL ? Se.RTL : Se.LTR, L.syncNtfyContent[t]) ? [3, 2] : (o = h.getBannerSDKAssestsUrl() + "/otSyncNotification" + (I.useRTL ? "Rtl" : "") + ".json", n = L.syncNtfyContent, r = t, [4, this.otFetch(o)]);
                    case 1:
                        n[r] = e.sent(), e.label = 2;
                    case 2:
                        return [2, L.syncNtfyContent[t]]
                }
            })
        })
    }, Rt.prototype.getConsentProfile = function(e, t) {
        var o = this,
            n = {
                Identifier: e,
                TenantId: L.tenantId,
                Authorization: t
            };
        return new Promise(function(e) {
            o.getJSON(L.consentApi, n, e, e)
        })
    }, Rt.prototype.checkIfRequiresPollyfill = function() {
        var e = window.navigator.userAgent;
        return 0 < e.indexOf("MSIE ") || 0 < e.indexOf("Trident/") || "undefined" == typeof Set
    }, Rt.prototype.otFetch = function(r, i, s) {
        return void 0 === i && (i = !1), void 0 === s && (s = !1), F(this, void 0, void 0, function() {
            var t, o, n = this;
            return M(this, function(e) {
                switch (e.label) {
                    case 0:
                        return h.checkMobileOfflineRequest(r) ? [4, h.otFetchOfflineFile(r)] : [3, 2];
                    case 1:
                        return [2, e.sent()];
                    case 2:
                        return e.trys.push([2, 9, , 10]), A.mobileOnlineURL.push(r), "undefined" != typeof fetch ? [3, 3] : [2, new Promise(function(e) {
                            n.getJSON(r, null, e, e, i)
                        })];
                    case 3:
                        return [4, fetch(r)];
                    case 4:
                        return (t = e.sent(), s && t.headers.get("Access-Control-Allow-Credentials")) ? [2, Promise.resolve()] : i ? [4, t.text()] : [3, 6];
                    case 5:
                        return [2, e.sent()];
                    case 6:
                        return [4, t.json()];
                    case 7:
                        return [2, e.sent()];
                    case 8:
                        return [3, 10];
                    case 9:
                        return o = e.sent(), console.log("Error in fetch URL : " + r + " Exception :" + o), [3, 10];
                    case 10:
                        return [2]
                }
            })
        })
    }, Rt.prototype.getJSON = function(e, t, o, n, r) {
        void 0 === t && (t = null), void 0 === r && (r = !1);
        var i = new XMLHttpRequest;
        if (i.open("GET", e, !0), i.withCredentials = !1, t)
            for (var s in t) i.setRequestHeader(s, t[s]);
        i.onload = function() {
            var e;
            200 <= this.status && this.status < 400 && this.responseText ? (e = void 0, e = r ? this.responseText : JSON.parse(this.responseText), o(e)) : n({
                message: "Error Loading Data",
                statusCode: this.status
            })
        }, i.onerror = function(e) {
            n(e)
        }, i.send()
    };
    var xt, Ht = Rt;

    function Rt() {}
    Mt.prototype.addLogoUrls = function() {
        h.checkMobileOfflineRequest(h.getBannerVersionUrl()) || (A.mobileOnlineURL.push(h.updateCorrectUrl(I.optanonLogo)), A.mobileOnlineURL.push(h.updateCorrectUrl(I.oneTrustFtrLogo)))
    }, Mt.prototype.getCookieLabel = function(e, t, o) {
        var n;
        return void 0 === o && (o = !0), e ? (n = e.Name, t ? '\n                <a  class="cookie-label"\n                    href="' + (o ? "http://cookiepedia.co.uk/cookies/" : "http://cookiepedia.co.uk/host/") + e.Name + '"\n                    rel="noopener"\n                    target="_blank"\n                >\n                    ' + e.Name + '&nbsp;<span class="ot-scrn-rdr">' + I.NewWinTxt + "</span>\n                </a>\n            " : n) : ""
    }, Mt.prototype.getBannerSDKAssestsUrl = function() {
        return this.getBannerVersionUrl() + "/assets"
    }, Mt.prototype.getBannerVersionUrl = function() {
        var e = A.bannerScriptElement.getAttribute("src");
        return "" + (-1 !== e.indexOf("/consent/") ? e.split("consent/")[0] + "scripttemplates/" : e.split("otSDKStub")[0]) + m.moduleInitializer.Version
    }, Mt.prototype.checkMobileOfflineRequest = function(e) {
        return m.moduleInitializer.MobileSDK && new RegExp("^file://", "i").test(e)
    }, Mt.prototype.updateCorrectIABUrl = function(e) {
        var t, o = m.moduleInitializer.ScriptType;
        return o !== Ue.LOCAL && o !== Ue.LOCAL_TEST || (o = P.getURL(e), (t = (t = A.bannerScriptElement) && t.getAttribute("src") ? P.getURL(t.getAttribute("src")) : null) && o && t.hostname !== o.hostname && (e = (e = (t = "" + A.bannerDataParentURL) + o.pathname.split("/").pop().replace(/(^\/?)/, "/")).replace(o.hostname, t.hostname))), e
    }, Mt.prototype.updateCorrectUrl = function(e, t) {
        if ((void 0 === t && (t = !1), A.previewMode) && new RegExp("^data:image/").test(e)) return e;
        var o = P.getURL(e),
            n = A.bannerScriptElement,
            n = n && n.getAttribute("src") ? P.getURL(n.getAttribute("src")) : null;
        if (n && o && n.hostname !== o.hostname) {
            var r = m.moduleInitializer.ScriptType;
            if (r === Ue.LOCAL || r === Ue.LOCAL_TEST) {
                if (t) return e;
                n = A.bannerDataParentURL + "/" + A.getRegionRule().Id, A.canUseConditionalLogic && (n += "/" + A.Condition.Id), e = n + (null == (r = null == (r = e) ? void 0 : r.replace(null == (t = m.moduleInitializer) ? void 0 : t.CDNLocation, "")) ? void 0 : r.replace(/(^\/?)/, "/"))
            } else e = null == (t = e) ? void 0 : t.replace(o.hostname, n.hostname)
        }
        return e
    }, Mt.prototype.isBundleOrStackActive = function(n, r) {
        void 0 === r && (r = null);
        for (var i = L.oneTrustIABConsent, s = !0, a = (r = r || L.groupsConsent, 0);
            (() => {
                var e, t, o = n.SubGroups[a];
                o.Status !== S.ALWAYS_ACTIVE && (o.Type === yt ? (-1 < (t = P.findIndex(r, function(e) {
                    return e.split(":")[0] === o.CustomGroupId
                })) && "0" === r[t].split(":")[1] || !r.length) && (s = !1) : (e = o.Type === b.GroupTypes.Spl_Ft ? i.specialFeatures : i.purpose, (-1 < (t = P.findIndex(e, function(e) {
                    return e.split(":")[0] === o.IabGrpId
                })) && "false" === e[t].split(":")[1] || !e.length) && (s = !1))), a++
            })(), s && a < n.SubGroups.length;);
        return s
    }, Mt.prototype.otFetchOfflineFile = function(n) {
        return F(this, void 0, void 0, function() {
            var t, o;
            return M(this, function(e) {
                switch (e.label) {
                    case 0:
                        return n = n.replace(".json", ".js"), t = n.split("/"), t = t[t.length - 1], o = t.split(".js")[0], [4, new Promise(function(e) {
                            function t() {
                                e(window[o])
                            }
                            h.jsonp(n, t, t)
                        })];
                    case 1:
                        return [2, e.sent()]
                }
            })
        })
    }, Mt.prototype.jsonp = function(e, t, o) {
        h.checkMobileOfflineRequest(e) || A.mobileOnlineURL.push(e);
        var n = document.createElement("script"),
            r = document.getElementsByTagName("head")[0];

        function i() {
            t()
        }
        n.onreadystatechange = function() {
            "loaded" !== this.readyState && "complete" !== this.readyState || i()
        }, n.onload = i, n.onerror = function() {
            o()
        }, n.type = "text/javascript", n.async = !0, n.src = v.getScriptUrl(e), L.crossOrigin && n.setAttribute("crossorigin", L.crossOrigin), r.appendChild(n)
    }, Mt.prototype.isCookiePolicyPage = function(e) {
        for (var t = !1, o = P.removeURLPrefixes(window.location.href), n = T("<div></div>", "ce").el, r = (T(n).html(e), n.querySelectorAll("a")), i = 0; i < r.length; i++)
            if (P.removeURLPrefixes(r[i].href) === o) {
                t = !0;
                break
            }
        return t
    }, Mt.prototype.isBannerVisible = function() {
        var e = !1,
            t = document.getElementById("onetrust-banner-sdk");
        return e = t && t.getAttribute("style") ? -1 === t.getAttribute("style").replace(/\s/g, "").indexOf("display:none") : e
    }, Mt.prototype.hideBanner = function() {
        var e = this;
        L.bnrAnimationInProg ? setTimeout(function() {
            return e.hideBanner()
        }, 100) : T("#onetrust-banner-sdk").fadeOut(400)
    }, Mt.prototype.resetFocusToBody = function() {
        document.activeElement && document.activeElement.blur()
    }, Mt.prototype.getDuration = function(e) {
        var t, o = e.Length,
            e = e.DurationType;
        return o && 0 !== parseInt(o) ? (o = parseInt(o), e ? (t = 1 < (o = this.round_to_precision(o / e, .5)) ? at[e] + "s" : at[e], I.LifespanDurationText && 1 === e && (t = "LifespanDurationText"), o + " " + I[t]) : this.getDurationText(o)) : I.LfSpanSecs
    }, Mt.prototype.isDateCurrent = function(e) {
        var e = e.split("/"),
            t = parseInt(e[1]),
            o = parseInt(e[0]),
            e = parseInt(e[2]),
            n = new Date,
            r = n.getDate(),
            i = n.getFullYear(),
            n = n.getMonth() + 1;
        return i < e || e === i && n < o || e === i && o === n && r <= t
    }, Mt.prototype.insertFooterLogo = function(e) {
        var t = T(e).el;
        if (t.length && I.oneTrustFtrLogo) {
            var o = h.updateCorrectUrl(I.oneTrustFtrLogo);
            h.checkMobileOfflineRequest(h.getBannerVersionUrl()) && (o = P.getRelativeURL(o, !0, !0));
            for (var n = 0; n < t.length; n++) {
                var r = t[n].querySelector("img"),
                    i = "Powered by OneTrust " + I.NewWinTxt;
                T(t[n]).attr("href", I.pCFooterLogoUrl), r.setAttribute("src", o), r.setAttribute("title", i), T(t[n]).attr("aria-label", i)
            }
        }
    }, Mt.prototype.getUTCFormattedDate = function(e) {
        e = new Date(e);
        return e.getUTCFullYear() + "-" + (e.getUTCMonth() + 1).toString().padStart(2, "0") + "-" + e.getUTCDate().toString().toString().padStart(2, "0") + " " + e.getUTCHours() + ":" + e.getUTCMinutes().toString().toString().padStart(2, "0") + ":" + e.getUTCSeconds().toString().toString().padStart(2, "0")
    }, Mt.prototype.getDurationText = function(e) {
        return 365 <= e ? (e = this.round_to_precision(e /= 365, .5)) + " " + (1 < e ? I.LfSpnYrs : I.LfSpnYr) : I.LifespanDurationText ? e + " " + I.LifespanDurationText : e + " " + (1 < e ? I.PCenterVendorListLifespanDays : I.PCenterVendorListLifespanDay)
    }, Mt.prototype.round_to_precision = function(e, t) {
        e = +e + (void 0 === t ? .5 : t / 2);
        return e - e % (void 0 === t ? 1 : +t)
    }, Mt.prototype.isOptOutEnabled = function() {
        return I.PCTemplateUpgrade ? L.genVenOptOutEnabled : I.allowHostOptOut
    }, Mt.prototype.findUserType = function(e) {
        L.isKeyboardUser = !(!e || 0 !== e.detail)
    }, Mt.prototype.getCSSPropsFromString = function(e) {
        var t, o;
        return e ? (t = e.length, o = {}, (e = e.endsWith(";") ? e.substring(0, t - 1) : e).trim().split(";").forEach(function(e) {
            e = e.trim().toString().split(":"), e = JSON.parse('{ "' + e[0].trim() + '" : "' + e[1].trim() + '" }');
            o = Object.assign(o, e)
        }), o) : {}
    }, Mt.prototype.setCloseIcon = function(e) {
        var t = h.updateCorrectUrl(I.OTCloseBtnLogo),
            e = T(e);
        e.length && d(e.el, 'background-image: url("' + t + '")', !0)
    }, Mt.prototype.createOptOutSignalElement = function(e, t) {
        var e = e(t ? "#ot-pc-content" : "#onetrust-policy"),
            o = document.createElement("div"),
            n = (o.classList.add("ot-optout-signal"), document.createElement("div")),
            r = (n.classList.add("ot-optout-icon"), document.createElement("span"));
        return r.innerText = t ? I.PCOptOutSignalText : I.BOptOutSignalText, o.append(n), o.append(r), null != (t = e) && t.prepend(o), this.applyGuardLogo(), o
    }, Mt.prototype.applyGuardLogo = function() {
        return F(this, void 0, void 0, function() {
            var t, o, n;
            return M(this, function(e) {
                switch (e.label) {
                    case 0:
                        return (t = I.cookiePersistentLogo).includes("ot_guard_logo.svg") || (o = I.OTCloseBtnLogo, n = o.indexOf("static/"), t = o.replace(o.slice(n + 7), "ot_guard_logo.svg")), (o = m.moduleInitializer.ScriptType) !== Ue.LOCAL && o !== Ue.LOCAL_TEST || (t = h.updateCorrectUrl(t)), [4, xt.getPersistentCookieSvg(t)];
                    case 1:
                        return n = e.sent(), T(".ot-optout-icon").html(n), [2]
                }
            })
        })
    }, Mt.prototype.updateTCString = function() {
        var e = p.iabStringSDK().tcString().encode(L.tcModel);
        L.cmpApi.update(e, !1)
    }, Mt.prototype.replaceTextFromString = function(e, t, o) {
        return t.split(e).join(o)
    }, Mt.prototype.getStubQueryParam = function(e) {
        var t = A.stubUrl || window.otStubData && window.otStubData.stubUrl;
        return !t || (t = t.split("?")).length < 2 ? null : new URLSearchParams(t[1]).get(e)
    }, Mt.prototype.getStubAttr = function(e) {
        var t = A.bannerScriptElement,
            t = t && t.getAttribute(e);
        return t || h.getStubQueryParam(e)
    };
    var h, Ft = Mt;

    function Mt() {}
    t.prototype.getPurposeOneGrpId = function() {
        return b.IdPatterns.Pur + "1"
    }, t.prototype.setRegionRule = function(e) {
        this.rule = e
    }, t.prototype.getRegionRule = function() {
        return this.rule
    }, t.prototype.getRegionRuleType = function() {
        return this.multiVariantTestingEnabled && this.selectedVariant ? this.selectedVariant.TemplateType : this.conditionalLogicEnabled && !this.allConditionsFailed ? this.Condition.TemplateType : this.rule.Type
    }, t.prototype.getTemplateName = function() {
        return this.multiVariantTestingEnabled && this.selectedVariant ? this.selectedVariant.Name : (this.canUseConditionalLogic ? this.Condition : this.rule).TemplateName
    }, t.prototype.isGroupExistInImpliedConsentableGroup = function(t) {
        return A.consentableImpliedConsentGroup.some(function(e) {
            return e.CustomGroupId === t.CustomGroupId
        })
    }, t.prototype.removeGroupFromImpliedConsentableGroup = function(t) {
        this.consentableImpliedConsentGroup = this.consentableImpliedConsentGroup.filter(function(e) {
            return e.CustomGroupId !== t.CustomGroupId
        })
    }, t.prototype.initConsentableImpliedConsentGroup = function(e) {
        var t = this;
        e.forEach(function(e) {
            e.Status === S.INACTIVE_LANDING_PAGE && t.consentableImpliedConsentGroup.push(e)
        })
    }, t.prototype.resetImpliedConsentableGroups = function() {
        this.consentableImpliedConsentGroup = this.consentableGrps.filter(function(e) {
            return e.Status === S.INACTIVE_LANDING_PAGE
        })
    }, t.prototype.canUseGoogleVendors = function(e) {
        return !!e && (this.conditionalLogicEnabled && !this.allConditionsFailed ? this.Condition : this.rule).UseGoogleVendors
    }, t.prototype.initVariables = function() {
        this.consentableGrps = [], this.consentableImpliedConsentGroup = [], this.consentableIabGrps = [], this.iabGrps = [], this.iabGrpIdMap = {}, this.domainGrps = {}, this.iabGroups = {
            purposes: {},
            legIntPurposes: {},
            specialPurposes: {},
            features: {},
            specialFeatures: {}
        }
    }, t.prototype.init = function(e) {
        this.getGPCSignal(), this.initVariables();
        var t = e.DomainData;
        this.setPublicDomainData(JSON.parse(JSON.stringify(t))), this.domainDataMapper(t), this.commonDataMapper(e.CommonData), I.NtfyConfig = e.NtfyConfig || {}, this.setBannerName(), this.setPcName(), this.populateGPCSignal(), this.populateGPCBrowserSignal(), I.GoogleConsent.GCEnable && this.initGCM()
    }, t.prototype.getGPCSignal = function() {
        navigator.globalPrivacyControl ? this.gpcEnabled = !0 : this.gpcEnabled = !1
    }, t.prototype.isValidConsentNoticeGroup = function(e, t) {
        var o, n, r, i, s;
        return !!e.ShowInPopup && (o = this.isGroupHasCookies(e), i = r = n = !1, null != (s = e) && s.Parent || (e.SubGroups.length && (n = e.SubGroups.some(function(e) {
            return e.GroupName && e.ShowInPopup && e.FirstPartyCookies.length
        }), r = e.SubGroups.some(function(e) {
            return e.GroupName && e.ShowInPopup && (e.Hosts.length || e.GeneralVendorsIds && e.GeneralVendorsIds.length)
        }), !t || e.FirstPartyCookies.length && e.Hosts.length || (i = !e.SubGroups.some(function(e) {
            return -1 === vt.indexOf(e.Type)
        }))), s = e.SubGroups.some(function(e) {
            return -1 < vt.indexOf(e.Type)
        }), (-1 < vt.indexOf(e.Type) || s) && (e.ShowVendorList = !0), (e.Hosts.length || r || n) && (e.ShowHostList = !0)), this.isValidGroup(o, e, n, r, i))
    }, t.prototype.isValidGroup = function(e, t, o, n, r) {
        var i = L.showVendorService && t.VendorServices && t.VendorServices.length;
        return e || -1 < vt.indexOf(t.Type) || o || n || r || i
    }, t.prototype.isGroupHasCookies = function(e) {
        return e.FirstPartyCookies.length || e.Hosts.length || e.GeneralVendorsIds && e.GeneralVendorsIds.length || e.VendorServices && e.VendorServices.length
    }, t.prototype.extractGroupIdForIabGroup = function(e) {
        return -1 < e.indexOf(b.IdPatterns.Spl_Pur) ? e = e.replace(b.IdPatterns.Spl_Pur, "") : -1 < e.indexOf(b.IdPatterns.Pur) ? e = e.replace(b.IdPatterns.Pur, "") : -1 < e.indexOf(b.IdPatterns.Ft) ? e = e.replace(b.IdPatterns.Ft, "") : -1 < e.indexOf(b.IdPatterns.Spl_Ft) && (e = e.replace(b.IdPatterns.Spl_Ft, "")), e
    }, t.prototype.isIabGrpAndNonConsentable = function(e) {
        var t = b.GroupTypes;
        return !this.isIab2orv2Template && -1 < vt.indexOf(e.Type) || this.isIab2orv2Template && (e.Type === t.Pur || e.Type === t.Stack) && !e.HasConsentOptOut && !e.HasLegIntOptOut || e.Type === t.Spl_Ft && !e.HasConsentOptOut
    }, t.prototype.setTcfPurposeParentMapForGrp = function(e) {
        var t = b.GroupTypes;
        if (this.isTcfV2Template && e.Parent) switch (e.Type) {
            case t.Pur:
                this.tcfParentMap.pur.set(parseInt(e.IabGrpId), e.Parent);
                break;
            case t.Spl_Pur:
                this.tcfParentMap.spl_pur.set(parseInt(e.IabGrpId), e.Parent);
                break;
            case t.Ft:
                this.tcfParentMap.ft.set(parseInt(e.IabGrpId), e.Parent);
                break;
            case t.Spl_Ft:
                this.tcfParentMap.spl_ft.set(parseInt(e.IabGrpId), e.Parent)
        }
    }, t.prototype.populateGroups = function(e, r) {
        var i = this,
            s = {},
            a = [],
            l = b.GroupTypes,
            t = (e.forEach(function(e) {
                var t = e.CustomGroupId;
                if (i.setHealthSignatureDataIntoGroup(r, e), void 0 !== e.HasConsentOptOut && e.IsIabPurpose || (e.HasConsentOptOut = !0), !i.isIabGrpAndNonConsentable(e)) {
                    if (t !== A.getPurposeOneGrpId() || e.ShowInPopup || (i.purposeOneTreatment = !0), i.grpContainLegalOptOut = e.HasLegIntOptOut || i.grpContainLegalOptOut, e.SubGroups = [], e.Parent ? a.push(e) : s[t] = e, i.isIab2orv2Template && -1 < vt.indexOf(e.Type)) {
                        var o = i.extractGroupIdForIabGroup(t),
                            n = (i.iabGrpIdMap[t] = o, e.IabGrpId = o, {
                                description: e.GroupDescription,
                                descriptionLegal: e.DescriptionLegal,
                                id: Number(o),
                                name: e.GroupName
                            });
                        switch (e.Type) {
                            case l.Pur:
                                i.iabGroups.purposes[o] = n;
                                break;
                            case l.Spl_Pur:
                                i.iabGroups.specialPurposes[o] = n;
                                break;
                            case l.Ft:
                                i.iabGroups.features[o] = n;
                                break;
                            case l.Spl_Ft:
                                i.iabGroups.specialFeatures[o] = n
                        }
                    }
                    i.setTcfPurposeParentMapForGrp(e)
                }
            }), a.forEach(function(e) {
                s[e.Parent] && e.ShowInPopup && (e.FirstPartyCookies.length || e.Hosts.length || e.GeneralVendorsIds && e.GeneralVendorsIds.length || -1 < vt.indexOf(e.Type)) && s[e.Parent].SubGroups.push(e)
            }), []);
        return Object.keys(s).forEach(function(e) {
            i.isValidConsentNoticeGroup(s[e], r.IsIabEnabled) && (s[e].SubGroups.sort(function(e, t) {
                return e.Order - t.Order
            }), t.push(s[e]))
        }), this.initGrpVar(t), t.sort(function(e, t) {
            return e.Order - t.Order
        })
    }, t.prototype.setHealthSignatureDataIntoGroup = function(e, t) {
        this.requireSignatureEnabled && e.RequireSignatureCID === t.CustomGroupId && (t.needsHealthSignature = !0, "1" === g.readCookieParam(C.OPTANON_CONSENT, u.HEALTH_SIGNATURE_AUTHORIZATION)) && (t.healthSignatureId = g.readCookieParam(C.OPTANON_CONSENT, u.CONSENT_ID))
    }, t.prototype.isGrpConsentable = function(e) {
        var t = b.GroupTypes;
        return e.Type === t.Cookie || e.Type === t.Pur || e.Type === t.Spl_Ft
    }, t.prototype.initGrpVar = function(e) {
        var o = this,
            n = !0,
            r = !0;
        e.forEach(function(e) {
            U([e], e.SubGroups).forEach(function(e) {
                var t;
                o.isGrpConsentable(e) && (o.domainGrps[e.PurposeId.toLowerCase()] = e.CustomGroupId), -1 < Tt.indexOf(e.Type) && o.consentableGrps.push(e), -1 < Pt.indexOf(e.Type) && o.consentableIabGrps.push(e), -1 === Tt.indexOf(e.Type) && o.iabGrps.push(e), o.gpcEnabled && e.IsGpcEnabled && (e.Status = S.INACTIVE), (t = o.DNTEnabled && e.IsDntEnabled ? S.DNT : e.Status.toLowerCase()) !== S.ACTIVE && t !== S.INACTIVE_LANDING_PAGE && t !== S.DNT || (n = !1), t !== S.INACTIVE_LANDING_PAGE && t !== S.ALWAYS_ACTIVE && (r = !1), o.gpcForAGrpEnabled || (o.gpcForAGrpEnabled = e.IsGpcEnabled)
            })
        }), this.isOptInMode = n, this.isSoftOptInMode = r
    }, t.prototype.domainDataMapper = function(e) {
        this.requireSignatureEnabled = (null == (t = m.fp) ? void 0 : t.CookieV2SubmitPurpose) && e.IsRequireSignatureEnabled && e.PCTemplateUpgrade;
        var t = {
            AriaClosePreferences: e.AriaClosePreferences,
            AriaOpenPreferences: e.AriaOpenPreferences,
            AriaPrivacy: e.AriaPrivacy,
            CenterRounded: e.CenterRounded,
            Flat: e.Flat,
            FloatingFlat: e.FloatingFlat,
            FloatingRounded: e.FloatingRounded,
            FloatingRoundedCorner: e.FloatingRoundedCorner,
            FloatingRoundedIcon: e.FloatingRoundedIcon,
            VendorLevelOptOut: e.IsIabEnabled,
            AboutCookiesText: e.AboutCookiesText,
            AboutLink: e.AboutLink,
            AboutText: e.AboutText,
            ActiveText: e.ActiveText,
            AddLinksToCookiepedia: e.AddLinksToCookiepedia,
            AlertAllowCookiesText: e.AlertAllowCookiesText,
            AlertCloseText: e.AlertCloseText,
            AlertLayout: e.AlertLayout,
            AlertMoreInfoText: e.AlertMoreInfoText,
            AlertNoticeText: e.AlertNoticeText,
            AllowAllText: e.PreferenceCenterConfirmText,
            AlwaysActiveText: e.AlwaysActiveText,
            AlwaysInactiveText: e.AlwaysInactiveText,
            BannerAdditionalDescPlacement: e.BannerAdditionalDescPlacement,
            BannerAdditionalDescription: e.BannerAdditionalDescription,
            BannerCloseButtonText: e.BannerCloseButtonText,
            BannerFeatureDescription: e.BannerFeatureDescription,
            BannerFeatureTitle: e.BannerFeatureTitle,
            BannerIABPartnersLink: e.BannerIABPartnersLink,
            BannerInformationDescription: e.BannerInformationDescription,
            BannerInformationTitle: e.BannerInformationTitle,
            BannerNonIABVendorListText: e.BannerNonIABVendorListText,
            BannerPosition: e.BannerPosition,
            BannerPurposeDescription: e.BannerPurposeDescription,
            BannerPurposeTitle: e.BannerPurposeTitle,
            BannerRejectAllButtonText: e.BannerRejectAllButtonText,
            BannerRelativeFontSizesToggle: e.BannerRelativeFontSizesToggle,
            BannerSettingsButtonDisplayLink: e.BannerSettingsButtonDisplayLink,
            BannerShowRejectAllButton: e.BannerShowRejectAllButton,
            BShowOptOutSignal: e.BShowOptOutSignal,
            BOptOutSignalText: e.BOptOutSignalText,
            BRegionAriaLabel: e.BRegionAriaLabel,
            BannerTitle: e.BannerTitle,
            BCloseButtonType: e.BCloseButtonType,
            BContinueText: e.BContinueText,
            BCookiePolicyLinkScreenReader: e.BCookiePolicyLinkScreenReader,
            BnrLogoAria: e.BnrLogoAria,
            BImprintLinkScreenReader: e.BImprintLinkScreenReader,
            BInitialFocus: e.BInitialFocus,
            BInitialFocusLinkAndButton: e.BInitialFocusLinkAndButton,
            BRejectConsentType: e.BRejectConsentType,
            BSaveBtnTxt: e.BSaveBtnText,
            BShowImprintLink: e.BShowImprintLink,
            BShowPolicyLink: e.BShowPolicyLink,
            BShowSaveBtn: e.BShowSaveBtn,
            cctId: e.cctId,
            ChoicesBanner: e.ChoicesBanner,
            CloseShouldAcceptAllCookies: e.CloseShouldAcceptAllCookies,
            CloseText: e.CloseText,
            ConfirmText: e.ConfirmText,
            ConsentModel: {
                Name: e.ConsentModel
            },
            CookieListDescription: e.CookieListDescription,
            CookieListTitle: e.CookieListTitle,
            CookieSettingButtonText: e.CookieSettingButtonText,
            CookiesUsedText: e.CookiesUsedText,
            CustomJs: e.CustomJs,
            firstPartyTxt: e.CookieFirstPartyText,
            FooterDescriptionText: e.FooterDescriptionText,
            ForceConsent: e.ForceConsent,
            GeneralVendors: e.GeneralVendors,
            GeneralVendorsEnabled: e.PCenterUseGeneralVendorsToggle,
            GenVenOptOut: e.PCenterAllowVendorOptout,
            GlobalRestrictionEnabled: e.GlobalRestrictionEnabled,
            GlobalRestrictions: e.GlobalRestrictions,
            GoogleConsent: {
                GCAdStorage: e.GCAdStorage,
                GCAnalyticsStorage: e.GCAnalyticsStorage,
                GCEnable: e.GCEnable,
                GCFunctionalityStorage: e.GCFunctionalityStorage,
                GCPersonalizationStorage: e.GCPersonalizationStorage,
                GCRedactEnable: e.GCRedactEnable,
                GCSecurityStorage: e.GCSecurityStorage,
                GCWaitTime: e.GCWaitTime,
                GCAdUserData: e.GCAdUserData,
                GCAdPersonalization: e.GCAdPersonalization
            },
            MCMData: e.MCMData,
            GroupGenVenListLabel: e.PCenterGeneralVendorThirdPartyCookiesText,
            Groups: this.populateGroups(e.Groups, e),
            HideToolbarCookieList: e.HideToolbarCookieList,
            IabType: e.IabType,
            InactiveText: e.InactiveText,
            IsConsentLoggingEnabled: e.IsConsentLoggingEnabled,
            IsIabEnabled: e.IsIabEnabled,
            IsIabThirdPartyCookieEnabled: e.IsIabThirdPartyCookieEnabled,
            IsLifespanEnabled: e.IsLifespanEnabled,
            Language: e.Language,
            LastReconsentDate: e.LastReconsentDate,
            LfSpanSecs: e.PCLifeSpanSecs,
            LfSpnWk: e.PCLifeSpanWk,
            LfSpnWks: e.PCLifeSpanWks,
            LfSpnYr: e.PCLifeSpanYr,
            LfSpnYrs: e.PCLifeSpanYrs,
            LifespanDurationText: e.LifespanDurationText,
            MainInfoText: e.MainInfoText,
            MainText: e.MainText,
            ManagePreferenceText: e.PreferenceCenterManagePreferencesText,
            NewVendorsInactiveEnabled: e.NewVendorsInactiveEnabled,
            NewWinTxt: e.PreferenceCenterMoreInfoScreenReader,
            NextPageAcceptAllCookies: e.NextPageAcceptAllCookies,
            NextPageCloseBanner: e.NextPageCloseBanner,
            NoBanner: e.NoBanner,
            OnClickAcceptAllCookies: e.OnClickAcceptAllCookies,
            OnClickCloseBanner: e.OnClickCloseBanner,
            OverriddenVendors: null != (t = e.OverriddenVendors) ? t : {},
            OverridenGoogleVendors: null != (t = e.OverridenGoogleVendors) ? t : {},
            Publisher: e.publisher,
            PublisherCC: e.PublisherCC,
            ReconsentFrequencyDays: e.ReconsentFrequencyDays,
            ScrollAcceptAllCookies: e.ScrollAcceptAllCookies,
            ScrollCloseBanner: e.ScrollCloseBanner,
            ShowAlertNotice: e.ShowAlertNotice,
            showBannerCloseButton: e.showBannerCloseButton,
            ShowPreferenceCenterCloseButton: e.ShowPreferenceCenterCloseButton,
            ThirdPartyCookieListText: e.ThirdPartyCookieListText,
            thirdPartyTxt: e.CookieThirdPartyText,
            UseGoogleVendors: this.canUseGoogleVendors(e.PCTemplateUpgrade),
            VendorConsentModel: e.VendorConsentModel,
            VendorListText: e.VendorListText,
            Vendors: e.Vendors,
            PCCategoryStyle: e.PCCategoryStyle || ve.Checkbox,
            PCShowAlwaysActiveToggle: e.PCShowAlwaysActiveToggle,
            PCenterImprintLinkScreenReader: e.PCenterImprintLinkScreenReader,
            PCenterImprintLinkText: e.PCenterImprintLinkText,
            PCenterImprintLinkUrl: e.PCenterImprintLinkUrl,
            PCShowOptOutSignal: e.PCShowOptOutSignal,
            PCOptOutSignalText: e.PCOptOutSignalText,
            PCRegionAriaLabel: e.PCRegionAriaLabel,
            PCHostNotFound: e.PCHostNotFound,
            PCVendorNotFound: e.PCVendorNotFound,
            PCTechNotFound: e.PCTechNotFound,
            UseNonStandardStacks: e.UseNonStandardStacks,
            RequireSignatureCID: e.RequireSignatureCID,
            IsRequireSignatureEnabled: e.IsRequireSignatureEnabled,
            PCRequireSignatureHelpText: e.PCRequireSignatureHelpText,
            PCRequireSignatureFieldLabel: e.PCRequireSignatureFieldLabel,
            PCRequireSignatureHeaderText: e.PCRequireSignatureHeaderText,
            PCRequireSignatureHeaderDesc: e.PCRequireSignatureHeaderDesc,
            PCRequireSignatureRejectBtnText: e.PCRequireSignatureRejectBtnText,
            PCRequireSignatureConfirmBtnText: e.PCRequireSignatureConfirmBtnText
        };
        this.setPCDomainData(t, e), this.setAdditionalTechnologies(t, e), this.setVendorServiceConfigData(t, e), this.setDomainCommonDataDefaults(t, e), this.setDomainPCDataDefaults(t, e), this.setGppData(t, e), e.PCTemplateUpgrade && (e.Center || e.Panel) && (t.PCAccordionStyle = e.PCAccordionStyle), t.PCenterEnableAccordion = e.PCAccordionStyle !== ce.NoAccordion, this.legIntSettings = e.LegIntSettings || {}, void 0 === this.legIntSettings.PAllowLI && (this.legIntSettings.PAllowLI = !0), m.moduleInitializer.MobileSDK || (this.pagePushedDown = e.BannerPushesDownPage), I = R(R({}, I), t)
    }, t.prototype.setGppData = function(e, t) {
        e.GPPPurposes = R({}, t.GPPPurposes), e.IsGPPDataProcessingApplicable = t.IsGPPDataProcessingApplicable, e.IsGPPEnabled = t.IsGPPEnabled, e.IsGPPKnownChildApplicable = t.IsGPPKnownChildApplicable, e.IsMSPAEnabled = t.IsMSPAEnabled, e.MSPAOptionMode = t.MSPAOptionMode, e.UseGPPUSNational = t.UseGPPUSNational
    }, t.prototype.setPCDomainData = function(e, t) {
        e.PCAccordionStyle = ce.Caret, e.PCActiveText = t.PCActiveText, e.PCCloseButtonType = t.PCCloseButtonType, e.PCContinueText = t.PCContinueText, e.PCCookiePolicyLinkScreenReader = t.PCCookiePolicyLinkScreenReader, e.PCCookiePolicyText = t.PCCookiePolicyText, e.PCenterAllowAllConsentText = t.PCenterAllowAllConsentText, e.PCenterApplyFiltersText = t.PCenterApplyFiltersText, e.PCenterBackText = t.PCenterBackText, e.PCenterCancelFiltersText = t.PCenterCancelFiltersText, e.PCenterClearFiltersText = t.PCenterClearFiltersText, e.PCenterCookiesListText = t.PCenterCookiesListText, e.PCenterEnableAccordion = t.PCenterEnableAccordion, e.PCenterFilterText = t.PCenterFilterText, e.PCenterGeneralVendorsText = t.PCenterGeneralVendorsText, e.PCenterRejectAllButtonText = t.PCenterRejectAllButtonText, e.PCenterSelectAllVendorsText = t.PCenterSelectAllVendorsText, e.PCenterShowRejectAllButton = t.PCenterShowRejectAllButton, e.PCenterUserIdDescriptionText = t.PCenterUserIdDescriptionText, e.PCenterUserIdNotYetConsentedText = t.PCenterUserIdNotYetConsentedText, e.PCenterUserIdTimestampTitleText = t.PCenterUserIdTimestampTitleText, e.PCenterUserIdTitleText = t.PCenterUserIdTitleText, e.PCenterVendorListDescText = t.PCenterVendorListDescText, e.PCenterVendorListDisclosure = t.PCenterVendorListDisclosure, e.PCenterVendorListLifespan = t.PCenterVendorListLifespan, e.PCenterVendorListLifespanDay = t.PCenterVendorListLifespanDay, e.PCenterVendorListLifespanDays = t.PCenterVendorListLifespanDays, e.PCenterVendorListLifespanMonth = t.PCenterVendorListLifespanMonth, e.PCenterVendorListLifespanMonths = t.PCenterVendorListLifespanMonths, e.PCenterVendorListNonCookieUsage = t.PCenterVendorListNonCookieUsage, e.PCenterVendorListStorageDomain = t.PCenterVendorListStorageDomain, e.PCVLSDomainsUsed = t.PCVLSDomainsUsed, e.PCVLSUse = t.PCVLSUse, e.PCenterVendorListStorageIdentifier = t.PCenterVendorListStorageIdentifier, e.PCenterVendorListStoragePurposes = t.PCenterVendorListStoragePurposes, e.PCenterVendorListStorageType = t.PCenterVendorListStorageType, e.PCenterVendorsListText = t.PCenterVendorsListText, e.PCenterViewPrivacyPolicyText = t.PCenterViewPrivacyPolicyText, e.PCGoogleVendorsText = t.PCGoogleVendorsText, e.PCGrpDescLinkPosition = t.PCGrpDescLinkPosition, e.PCGrpDescType = t.PCGrpDescType, e.PCGVenPolicyTxt = t.PCGeneralVendorsPolicyText, e.PCIABVendorsText = t.PCIABVendorsText, e.PCIABVendorLegIntClaimText = t.PCIABVendorLegIntClaimText, e.PCVListDataDeclarationText = t.PCVListDataDeclarationText, e.PCVListDataRetentionText = t.PCVListDataRetentionText, e.PCVListStdRetentionText = t.PCVListStdRetentionText, e.IABDataCategories = t.IABDataCategories, e.PCInactiveText = t.PCInactiveText, e.PCIllusText = t.PCIllusText, e.PCLogoAria = t.PCLogoScreenReader, e.PCOpensCookiesDetailsAlert = t.PCOpensCookiesDetailsAlert, e.PCenterVendorListScreenReader = t.PCenterVendorListScreenReader, e.PCOpensVendorDetailsAlert = t.PCOpensVendorDetailsAlert, e.PCenterDynamicRenderingEnable = t.PCenterDynamicRenderingEnable, e.PCTemplateUpgrade = t.PCTemplateUpgrade, e.PCVendorFullLegalText = t.PCVendorFullLegalText, e.PCViewCookiesText = t.PCViewCookiesText, e.PCLayout = {
            Center: t.Center,
            List: t.List,
            Panel: t.Panel,
            Popup: t.Popup,
            Tab: t.Tab
        }, e.PCenterVendorListLinkText = t.PCenterVendorListLinkText, e.PCenterVendorListLinkAriaLabel = t.PCenterVendorListLinkAriaLabel, e.PreferenceCenterPosition = t.PreferenceCenterPosition, e.PCVendorsCountText = t.PCVendorsCountText, e.PCVendorsCountFeatureText = t.PCVendorsCountFeatureText, e.PCVendorsCountSpcFeatureText = t.PCVendorsCountSpcFeatureText, e.PCVendorsCountSpcPurposeText = t.PCVendorsCountSpcPurposeText
    }, t.prototype.setVendorServiceConfigData = function(e, t) {
        e.VendorServiceConfig = {
            PCVSOptOut: t.PCVSOptOut,
            PCVSEnable: t.PCVSEnable,
            PCVSExpandCategory: t.PCVSExpandCategory,
            PCVSExpandGroup: t.PCVSExpandGroup,
            PCVSCategoryView: t.PCVSCategoryView,
            PCVSNameText: t.PCVSNameText,
            PCVSAllowAllText: t.PCVSAllowAllText,
            PCVSListTitle: t.PCVSListTitle,
            PCVSParentCompanyText: t.PCVSParentCompanyText,
            PCVSAddressText: t.PCVSAddressText,
            PCVSDefaultCategoryText: t.PCVSDefaultCategoryText,
            PCVSDefaultDescriptionText: t.PCVSDefaultDescriptionText,
            PCVSDPOEmailText: t.PCVSDPOEmailText,
            PCVSDPOLinkText: t.PCVSDPOLinkText,
            PCVSPrivacyPolicyLinkText: t.PCVSPrivacyPolicyLinkText,
            PCVSCookiePolicyLinkText: t.PCVSCookiePolicyLinkText,
            PCVSOptOutLinkText: t.PCVSOptOutLinkText,
            PCVSLegalBasisText: t.PCVSLegalBasisText
        }
    }, t.prototype.setAdditionalTechnologies = function(e, t) {
        e.AdditionalTechnologiesConfig = {
            PCShowTrackingTech: t.PCShowTrackingTech,
            PCCookiesLabel: t.PCCookiesLabel,
            PCTechDetailsText: t.PCTechDetailsText,
            PCTrackingTechTitle: t.PCTrackingTechTitle,
            PCLocalStorageLabel: t.PCLocalStorageLabel,
            PCSessionStorageLabel: t.PCSessionStorageLabel,
            PCTechDetailsAriaLabel: t.PCTechDetailsAriaLabel,
            PCLocalStorageDurationText: t.PCLocalStorageDurationText,
            PCSessionStorageDurationText: t.PCSessionStorageDurationText
        }
    }, t.prototype.setDomainCommonDataDefaults = function(e, t) {
        e.AdvancedAnalyticsCategory = t.AdvancedAnalyticsCategory || "", e.BannerDPDDescription = t.BannerDPDDescription || [], e.BannerDPDDescriptionFormat = t.BannerDPDDescriptionFormat || "", e.BannerDPDTitle = t.BannerDPDTitle || "", e.CategoriesText = t.CategoriesText || "Categories", e.CookiesText = t.CookiesText || "Cookies", e.CookiesDescText = t.CookiesDescText || "Description", e.LifespanText = t.LifespanText || "Lifespan", e.LifespanTypeText = t.LifespanTypeText || "Session", e.PCenterConsentText = t.PCenterConsentText || "Consent"
    }, t.prototype.setDomainPCDataDefaults = function(e, t) {
        e.PCenterCookieListFilterAria = t.PCenterCookieListFilterAria || "Filter", e.PCenterCookieListSearch = t.PCenterCookieListSearch || "Search", e.PCenterCookieSearchAriaLabel = t.PCenterCookieSearchAriaLabel || "Cookie list search", e.PCenterFilterAppliedAria = t.PCenterFilterAppliedAria || "Applied", e.PCenterFilterClearedAria = t.PCenterFilterClearedAria || "Filters Cleared", e.PCenterLegIntColumnHeader = t.PCenterLegIntColumnHeader || "Legitimate Interest", e.PCenterLegitInterestText = t.PCenterLegitInterestText || "Legitimate Interest", e.PCenterVendorListFilterAria = t.PCenterVendorListFilterAria || "Filter", e.PCenterVendorListSearch = t.PCenterVendorListSearch || "Search", e.PCenterVendorSearchAriaLabel = t.PCenterVendorSearchAriaLabel || "Vendor list search", e.PCFirstPartyCookieListText = t.PCFirstPartyCookieListText || "First Party Cookies", e.PCShowConsentLabels = !!t.PCTemplateUpgrade && t.PCShowConsentLabels, e.PCShowPersistentCookiesHoverButton = t.PCShowPersistentCookiesHoverButton || !1
    }, t.prototype.commonDataMapper = function(e) {
        var t = {
            iabThirdPartyConsentUrl: e.IabThirdPartyCookieUrl,
            optanonHideAcceptButton: e.OptanonHideAcceptButton,
            optanonHideCookieSettingButton: e.OptanonHideCookieSettingButton,
            optanonStyle: e.OptanonStyle,
            optanonStaticContentLocation: e.OptanonStaticContentLocation,
            bannerCustomCSS: e.BannerCustomCSS.replace(/\\n/g, ""),
            pcCustomCSS: e.PCCustomCSS.replace(/\\n/g, ""),
            textColor: e.TextColor,
            buttonColor: e.ButtonColor,
            buttonTextColor: e.ButtonTextColor,
            bannerMPButtonColor: e.BannerMPButtonColor,
            bannerMPButtonTextColor: e.BannerMPButtonTextColor,
            backgroundColor: e.BackgroundColor,
            bannerAccordionBackgroundColor: e.BannerAccordionBackgroundColor,
            BContinueColor: e.BContinueColor,
            PCContinueColor: e.PCContinueColor,
            pcTextColor: e.PcTextColor,
            pcButtonColor: e.PcButtonColor,
            pcButtonTextColor: e.PcButtonTextColor,
            pcAccordionBackgroundColor: e.PcAccordionBackgroundColor,
            pcLinksTextColor: e.PcLinksTextColor,
            bannerLinksTextColor: e.BannerLinksTextColor,
            pcEnableToggles: e.PcEnableToggles,
            pcBackgroundColor: e.PcBackgroundColor,
            pcMenuColor: e.PcMenuColor,
            pcMenuHighLightColor: e.PcMenuHighLightColor,
            legacyBannerLayout: e.LegacyBannerLayout,
            optanonLogo: e.OptanonLogo,
            oneTrustFtrLogo: e.OneTrustFooterLogo,
            optanonCookieDomain: e.OptanonCookieDomain,
            cookiePersistentLogo: e.CookiePersistentLogo,
            optanonGroupIdPerformanceCookies: e.OptanonGroupIdPerformanceCookies,
            optanonGroupIdFunctionalityCookies: e.OptanonGroupIdFunctionalityCookies,
            optanonGroupIdTargetingCookies: e.OptanonGroupIdTargetingCookies,
            optanonGroupIdSocialCookies: e.OptanonGroupIdSocialCookies,
            optanonShowSubGroupCookies: e.ShowSubGroupCookies,
            useRTL: e.UseRTL,
            showBannerCookieSettings: e.ShowBannerCookieSettings,
            showBannerAcceptButton: e.ShowBannerAcceptButton,
            showCookieList: e.ShowCookieList,
            allowHostOptOut: e.AllowHostOptOut,
            CookiesV2NewCookiePolicy: e.CookiesV2NewCookiePolicy,
            cookieListTitleColor: e.CookieListTitleColor,
            cookieListGroupNameColor: e.CookieListGroupNameColor,
            cookieListTableHeaderColor: e.CookieListTableHeaderColor,
            CookieListTableHeaderBackgroundColor: e.CookieListTableHeaderBackgroundColor,
            cookieListPrimaryColor: e.CookieListPrimaryColor,
            cookieListCustomCss: e.CookieListCustomCss,
            pcShowCookieHost: e.PCShowCookieHost,
            pcShowCookieDuration: e.PCShowCookieDuration,
            pcShowCookieType: e.PCShowCookieType,
            pcShowCookieCategory: e.PCShowCookieCategory,
            pcShowCookieDescription: e.PCShowCookieDescription,
            ConsentIntegration: e.ConsentIntegration,
            ConsentPurposesText: e.BConsentPurposesText || "Consent Purposes",
            FeaturesText: e.BFeaturesText || "Features",
            LegitimateInterestPurposesText: e.BLegitimateInterestPurposesText || "Legitimate Interest Purposes",
            ConsentText: e.BConsentText || "Consent",
            LegitInterestText: e.BLegitInterestText || "Legit. Interest",
            pcDialogClose: e.PCDialogClose || "dialog closed",
            pCFooterLogoUrl: e.PCFooterLogoUrl,
            SpecialFeaturesText: e.BSpecialFeaturesText || "Special Features",
            SpecialPurposesText: e.BSpecialPurposesText || "Special Purposes",
            pcCListName: e.PCCListName || "Name",
            pcCListHost: e.PCCListHost || "Host",
            pcCListDuration: e.PCCListDuration || "Duration",
            pcCListType: e.PCCListType || "Type",
            pcCListCategory: e.PCCListCategory || "Category",
            pcCListDescription: e.PCCListDescription || "Description",
            IabLegalTextUrl: e.IabLegalTextUrl,
            pcLegIntButtonColor: e.PcLegIntButtonColor,
            pcLegIntButtonTextColor: e.PcLegIntButtonTextColor,
            PCenterExpandToViewText: e.PCenterExpandToViewText,
            BCategoryContainerColor: e.BCategoryContainerColor,
            BCategoryStyleColor: e.BCategoryStyleColor,
            BLineBreakColor: e.BLineBreakColor,
            BSaveBtnColor: e.BSaveBtnColor,
            BCategoryStyle: e.BCategoryStyle,
            BAnimation: e.BAnimation,
            BFocusBorderColor: e.BFocusBorderColor,
            PCFocusBorderColor: e.PCFocusBorderColor,
            BnrLogo: e.BnrLogo,
            OTCloseBtnLogo: e.OTCloseBtnLogo,
            OTExternalLinkLogo: e.OTExternalLinkLogo
        };
        this.cookieListMapper(t, e), I = R(R({}, I), t), this.pubDomainData.CookiesV2NewCookiePolicy = e.CookiesV2NewCookiePolicy
    }, t.prototype.cookieListMapper = function(e, t) {
        e.TTLGroupByTech = t.TTLGroupByTech, e.TTLShowTechDesc = t.TTLShowTechDesc
    }, t.prototype.setPublicDomainData = function(n) {
        this.pubDomainData = {
            AboutCookiesText: n.AboutCookiesText,
            AboutLink: n.AboutLink,
            AboutText: n.AboutText,
            ActiveText: n.ActiveText,
            AddLinksToCookiepedia: n.AddLinksToCookiepedia,
            AlertAllowCookiesText: n.AlertAllowCookiesText,
            AlertCloseText: n.AlertCloseText,
            AlertLayout: n.AlertLayout,
            AlertMoreInfoText: n.AlertMoreInfoText,
            AlertNoticeText: n.AlertNoticeText,
            AllowAllText: n.PreferenceCenterConfirmText,
            AlwaysActiveText: n.AlwaysActiveText,
            AlwaysInactiveText: n.AlwaysInactiveText,
            BAnimation: n.BAnimation,
            BannerCloseButtonText: n.BannerCloseButtonText,
            BannerDPDDescription: n.BannerDPDDescription || [],
            BannerDPDDescriptionFormat: n.BannerDPDDescriptionFormat || "",
            BannerDPDTitle: n.BannerDPDTitle || "",
            BannerFeatureDescription: n.BannerFeatureDescription,
            BannerFeatureTitle: n.BannerFeatureTitle,
            BannerIABPartnersLink: n.BannerIABPartnersLink,
            BannerInformationDescription: n.BannerInformationDescription,
            BannerInformationTitle: n.BannerInformationTitle,
            BannerPosition: n.BannerPosition,
            BannerPurposeDescription: n.BannerPurposeDescription,
            BannerPurposeTitle: n.BannerPurposeTitle,
            BannerRejectAllButtonText: n.BannerRejectAllButtonText,
            BannerRelativeFontSizesToggle: n.BannerRelativeFontSizesToggle,
            BannerSettingsButtonDisplayLink: n.BannerSettingsButtonDisplayLink,
            BannerShowRejectAllButton: n.BannerShowRejectAllButton,
            BannerTitle: n.BannerTitle,
            BCategoryContainerColor: n.BCategoryContainerColor,
            BCategoryStyle: n.BCategoryStyle,
            BCategoryStyleColor: n.BCategoryStyleColor,
            BCloseButtonType: n.BCloseButtonType,
            BContinueText: n.BContinueText,
            BInitialFocus: n.BInitialFocus,
            BInitialFocusLinkAndButton: n.BInitialFocusLinkAndButton,
            BLineBreakColor: n.BLineBreakColor,
            BRejectConsentType: n.BRejectConsentType,
            BSaveBtnColor: n.BSaveBtnColor,
            BSaveBtnTxt: n.BSaveBtnText,
            BShowSaveBtn: n.BShowSaveBtn,
            CategoriesText: n.CategoriesText,
            cctId: n.cctId,
            ChoicesBanner: n.ChoicesBanner,
            CloseShouldAcceptAllCookies: n.CloseShouldAcceptAllCookies,
            CloseText: n.CloseText,
            ConfirmText: n.ConfirmText,
            ConsentIntegrationData: null,
            ConsentModel: {
                Name: n.ConsentModel
            },
            CookieListDescription: n.CookieListDescription,
            CookieListTitle: n.CookieListTitle,
            CookieSettingButtonText: n.CookieSettingButtonText,
            CookiesText: n.CookiesText,
            CookiesDescText: n.CookiesDescText,
            CookiesUsedText: n.CookiesUsedText,
            CustomJs: n.CustomJs,
            Domain: m.moduleInitializer.Domain,
            FooterDescriptionText: n.FooterDescriptionText,
            ForceConsent: n.ForceConsent,
            GeneralVendors: n.GeneralVendors,
            GoogleConsent: {
                GCAdStorage: n.GCAdStorage,
                GCAnalyticsStorage: n.GCAnalyticsStorage,
                GCEnable: n.GCEnable,
                GCFunctionalityStorage: n.GCFunctionalityStorage,
                GCPersonalizationStorage: n.GCPersonalizationStorage,
                GCRedactEnable: n.GCRedactEnable,
                GCSecurityStorage: n.GCSecurityStorage,
                GCWaitTime: n.GCWaitTime,
                GCAdUserData: n.GCAdUserData,
                GCAdPersonalization: n.GCAdPersonalization
            },
            MCMData: n.MCMData,
            Groups: null,
            HideToolbarCookieList: n.HideToolbarCookieList,
            IabType: n.IabType,
            InactiveText: n.InactiveText,
            IsBannerLoaded: !1,
            IsConsentLoggingEnabled: n.IsConsentLoggingEnabled,
            IsIABEnabled: n.IsIabEnabled,
            IsIabThirdPartyCookieEnabled: n.IsIabThirdPartyCookieEnabled,
            IsLifespanEnabled: n.IsLifespanEnabled,
            Language: n.Language,
            LastReconsentDate: n.LastReconsentDate,
            LifespanDurationText: n.LifespanDurationText,
            LifespanText: n.LifespanText,
            LifespanTypeText: n.LifespanTypeText,
            MainInfoText: n.MainInfoText,
            MainText: n.MainText,
            ManagePreferenceText: n.PreferenceCenterManagePreferencesText,
            NextPageAcceptAllCookies: n.NextPageAcceptAllCookies,
            NextPageCloseBanner: n.NextPageCloseBanner,
            NoBanner: n.NoBanner,
            OnClickAcceptAllCookies: n.OnClickAcceptAllCookies,
            OnClickCloseBanner: n.OnClickCloseBanner,
            OverridenGoogleVendors: n.OverridenGoogleVendors,
            PCAccordionStyle: ce.Caret,
            PCCloseButtonType: n.PCCloseButtonType,
            PCContinueText: n.PCContinueText,
            PCenterAllowAllConsentText: n.PCenterAllowAllConsentText,
            PCenterApplyFiltersText: n.PCenterApplyFiltersText,
            PCenterBackText: n.PCenterBackText,
            PCenterCancelFiltersText: n.PCenterCancelFiltersText,
            PCenterClearFiltersText: n.PCenterClearFiltersText,
            PCenterCookieSearchAriaLabel: n.PCenterCookieSearchAriaLabel || "Cookie list search",
            PCenterCookiesListText: n.PCenterCookiesListText,
            PCenterEnableAccordion: n.PCenterEnableAccordion,
            PCenterExpandToViewText: n.PCenterExpandToViewText,
            PCenterFilterAppliedAria: n.PCenterFilterAppliedAria || "Applied",
            PCenterFilterClearedAria: n.PCenterFilterClearedAria || "Filters Cleared",
            PCenterFilterText: n.PCenterFilterText,
            PCenterRejectAllButtonText: n.PCenterRejectAllButtonText,
            PCenterSelectAllVendorsText: n.PCenterSelectAllVendorsText,
            PCenterShowRejectAllButton: n.PCenterShowRejectAllButton,
            PCenterUserIdDescriptionText: n.PCenterUserIdDescriptionText,
            PCenterUserIdNotYetConsentedText: n.PCenterUserIdNotYetConsentedText,
            PCenterUserIdTimestampTitleText: n.PCenterUserIdTimestampTitleText,
            PCenterUserIdTitleText: n.PCenterUserIdTitleText,
            PCenterVendorListDescText: n.PCenterVendorListDescText,
            PCenterVendorSearchAriaLabel: n.PCenterVendorSearchAriaLabel || "Vendor list search",
            PCenterVendorsListText: n.PCenterVendorsListText,
            PCenterViewPrivacyPolicyText: n.PCenterViewPrivacyPolicyText,
            PCFirstPartyCookieListText: n.PCFirstPartyCookieListText,
            PCGoogleVendorsText: n.PCGoogleVendorsText,
            PCGrpDescLinkPosition: n.PCGrpDescLinkPosition,
            PCGrpDescType: n.PCGrpDescType,
            PCIABVendorsText: n.PCIABVendorsText,
            PCIABVendorLegIntClaimText: n.PCIABVendorLegIntClaimText,
            PCVListDataDeclarationText: n.PCVListDataDeclarationText,
            PCVListDataRetentionText: n.PCVListDataRetentionText,
            PCVListStdRetentionText: n.PCVListStdRetentionText,
            IABDataCategories: n.IABDataCategories,
            PCLogoAria: n.PCLogoScreenReader,
            PCOpensCookiesDetailsAlert: n.PCOpensCookiesDetailsAlert,
            PCenterVendorListScreenReader: n.PCenterVendorListScreenReader,
            PCOpensVendorDetailsAlert: n.PCOpensVendorDetailsAlert,
            PCShowPersistentCookiesHoverButton: n.PCShowPersistentCookiesHoverButton,
            PCenterDynamicRenderingEnable: n.PCenterDynamicRenderingEnable,
            PCTemplateUpgrade: n.PCTemplateUpgrade,
            PCVendorFullLegalText: n.PCVendorFullLegalText,
            PCViewCookiesText: n.PCViewCookiesText,
            PCLayout: {
                Center: n.Center,
                List: n.List,
                Panel: n.Panel,
                Popup: n.Popup,
                Tab: n.Tab
            },
            PCenterVendorListLinkText: n.PCenterVendorListLinkText,
            PCenterVendorListLinkAriaLabel: n.PCenterVendorListLinkAriaLabel,
            PCenterImprintLinkScreenReader: n.PCenterImprintLinkScreenReader,
            PCenterImprintLinkText: n.PCenterImprintLinkText,
            PCenterImprintLinkUrl: n.PCenterImprintLinkUrl,
            PreferenceCenterPosition: n.PreferenceCenterPosition,
            ScrollAcceptAllCookies: n.ScrollAcceptAllCookies,
            ScrollCloseBanner: n.ScrollCloseBanner,
            ShowAlertNotice: n.ShowAlertNotice,
            showBannerCloseButton: n.showBannerCloseButton,
            ShowPreferenceCenterCloseButton: n.ShowPreferenceCenterCloseButton,
            ThirdPartyCookieListText: n.ThirdPartyCookieListText,
            UseGoogleVendors: this.canUseGoogleVendors(n.PCTemplateUpgrade),
            VendorConsentModel: n.VendorConsentModel,
            VendorLevelOptOut: n.IsIabEnabled,
            VendorListText: n.VendorListText,
            CookiesV2NewCookiePolicy: !1
        }, n.PCTemplateUpgrade && (n.Center || n.Panel) && n.PCAccordionStyle !== ce.NoAccordion && (this.pubDomainData.PCAccordionStyle = n.PCAccordionStyle), this.pubDomainData.PCenterEnableAccordion = n.PCAccordionStyle !== ce.NoAccordion;
        var r = [];
        n.Groups.forEach(function(e) {
            var t, o;
            !n.IsIabEnabled && e.IsIabPurpose || (e.Cookies = JSON.parse(JSON.stringify(e.FirstPartyCookies)), o = null == (o = e.Hosts) ? void 0 : o.reduce(function(e, t) {
                return e.concat(JSON.parse(JSON.stringify(t.Cookies)))
            }, []), (t = e.Cookies).push.apply(t, o), r.push(e))
        }), this.pubDomainData.Groups = r
    }, t.prototype.setBannerScriptElement = function(e) {
        this.bannerScriptElement = e, this.setDomainElementAttributes()
    }, t.prototype.setGCMcallback = function() {
        window.otEventListeners && window.otEventListeners.length && window.otEventListeners.forEach(function(e) {
            e && "consent.changed" === e.event && (A.gcmUpdateCallback = e.listener)
        })
    }, t.prototype.setDomainElementAttributes = function() {
        var e;
        this.bannerScriptElement && ((e = h.getStubAttr(qe)) && this.setUseDocumentLanguage("true" === e), this.bannerScriptElement.hasAttribute("data-ignore-ga") && (this.ignoreGoogleAnlyticsCall = "true" === this.bannerScriptElement.getAttribute("data-ignore-ga")), this.bannerScriptElement.hasAttribute("data-ignore-html")) && (this.ignoreInjectingHtmlCss = "true" === this.bannerScriptElement.getAttribute("data-ignore-html"))
    }, t.prototype.setUseDocumentLanguage = function(e) {
        this.useDocumentLanguage = e
    }, t.prototype.setPcName = function() {
        var e = I.PCLayout;
        e.Center ? this.pcName = tt : e.Panel ? this.pcName = nt : e.Popup ? this.pcName = rt : e.List ? this.pcName = ot : e.Tab && (this.pcName = it)
    }, t.prototype.setBannerName = function() {
        I.Flat ? this.bannerName = Ye : I.FloatingRoundedCorner ? this.bannerName = Je : I.FloatingFlat ? this.bannerName = Xe : I.FloatingRounded ? this.bannerName = Ze : I.FloatingRoundedIcon ? this.bannerName = Qe : I.CenterRounded ? this.bannerName = We : I.ChoicesBanner ? this.bannerName = $e : I.NoBanner && (this.bannerName = et)
    }, t.prototype.populateGPCSignal = function() {
        var e = g.readCookieParam(C.OPTANON_CONSENT, u.GPC_ENABLED),
            t = this.gpcForAGrpEnabled && this.gpcEnabled ? "1" : "0";
        this.gpcValueChanged = e ? e != t : this.gpcForAGrpEnabled, g.writeCookieParam(C.OPTANON_CONSENT, u.GPC_ENABLED, t)
    }, t.prototype.populateGPCBrowserSignal = function() {
        var e = g.readCookieParam(C.OPTANON_CONSENT, u.GPC_Browser_Flag),
            t = this.gpcEnabled ? "1" : "0";
        this.gpcBrowserValueChanged = e !== t, g.writeCookieParam(C.OPTANON_CONSENT, u.GPC_Browser_Flag, t)
    }, t.prototype.initGCM = function() {
        var o = [],
            e = (Object.keys(this.rule.States).forEach(function(t) {
                A.rule.States[t].forEach(function(e) {
                    o.push((t + "-" + e).toUpperCase())
                })
            }), A.rule.Countries.map(function(e) {
                return e.toUpperCase()
            }));
        A.gcmCountries = e.concat(o)
    }, t.prototype.getRegionDetailsOnRuleSet = function(e, t) {
        var o, n;
        t && 1 < t.length && (o = ["co", "va", "ut"], 1 <= (n = t.filter(function(e) {
            return !o.includes(e)
        })).length) && n.length < t.length && (e.KnownChildSensitiveDataConsents = 2)
    };
    var Ut = t;

    function t() {
        var t = this;
        this.DNTEnabled = "yes" === navigator.doNotTrack || "1" === navigator.doNotTrack, this.gpcEnabled = !1, this.gpcForAGrpEnabled = !1, this.pagePushedDown = !1, this.iabGroups = {
            purposes: {},
            legIntPurposes: {},
            specialPurposes: {},
            features: {},
            specialFeatures: {}
        }, this.iabType = null, this.grpContainLegalOptOut = !1, this.purposeOneTreatment = !1, this.ignoreInjectingHtmlCss = !1, this.ignoreGoogleAnlyticsCall = !1, this.mobileOnlineURL = [], this.iabGrpIdMap = {}, this.iabGrps = [], this.consentableGrps = [], this.consentableImpliedConsentGroup = [], this.consentableIabGrps = [], this.domainGrps = {}, this.thirdPartyiFrameLoaded = !1, this.thirdPartyiFrameResolve = null, this.thirdPartyiFramePromise = new Promise(function(e) {
            t.thirdPartyiFrameResolve = e
        }), this.isOptInMode = !1, this.isSoftOptInMode = !1, this.gpcValueChanged = !1, this.gpcBrowserValueChanged = !1, this.conditionalLogicEnabled = !1, this.allConditionsFailed = !1, this.canUseConditionalLogic = !1, this.gtmUpdatedinStub = !1, this.gcmDevIdSet = !1, this.tcf2ActiveVendors = {
            all: 0,
            pur: new Map,
            ft: new Map,
            spl_pur: new Map,
            spl_ft: new Map,
            stack: new Map
        }, this.tcfParentMap = {
            pur: new Map,
            ft: new Map,
            spl_pur: new Map,
            spl_ft: new Map
        }
    }
    var A, I = {};

    function qt() {
        this.otSDKVersion = "202502.1.0", this.isAMP = !1, this.ampData = {}, this.otCookieData = window.OneTrust && window.OneTrust.otCookieData || [], this.syncRequired = !1, this.isIabSynced = !1, this.isGacSynced = !1, this.grpsSynced = [], this.syncedValidGrp = !1, this.groupsConsent = [], this.initialGroupsConsent = [], this.hostsConsent = [], this.initialHostConsent = [], this.genVendorsConsent = {}, this.vsConsent = new Map, this.initialGenVendorsConsent = {}, this.vendors = {
            list: [],
            searchParam: "",
            vendorTemplate: null,
            selectedVendors: [],
            selectedPurpose: [],
            selectedLegInt: [],
            selectedLegIntVendors: [],
            selectedSpecialFeatures: []
        }, this.initialVendors = {
            list: [],
            searchParam: "",
            vendorTemplate: null,
            selectedVendors: [],
            selectedPurpose: [],
            selectedLegInt: [],
            selectedLegIntVendors: [],
            selectedSpecialFeatures: []
        }, this.oneTrustIABConsent = {
            purpose: [],
            legimateInterest: [],
            features: [],
            specialFeatures: [],
            specialPurposes: [],
            vendors: [],
            legIntVendors: [],
            vendorList: null,
            IABCookieValue: ""
        }, this.initialOneTrustIABConsent = {
            purpose: [],
            legimateInterest: [],
            features: [],
            specialFeatures: [],
            specialPurposes: [],
            vendors: [],
            legIntVendors: [],
            vendorList: null,
            IABCookieValue: ""
        }, this.addtlVendors = {
            vendorConsent: [],
            vendorSelected: {}
        }, this.initialAddtlVendors = {
            vendorConsent: [],
            vendorSelected: {}
        }, this.addtlConsentVersion = "1~", this.deletedGoogleVendors = {}, this.initialAddtlVendorsList = {}, this.isAddtlConsent = !1, this.currentGlobalFilteredList = [], this.filterByIABCategories = [], this.filterByCategories = [], this.hosts = {
            hostTemplate: null,
            hostCookieTemplate: null
        }, this.generalVendors = {
            gvTemplate: null,
            gvCookieTemplate: null
        }, this.oneTrustAlwaysActiveHosts = [], this.alwaysActiveGenVendors = [], this.softOptInGenVendors = [], this.optInGenVendors = [], this.optanonHostList = [], this.srcExecGrps = [], this.htmlExecGrps = [], this.srcExecGrpsTemp = [], this.htmlExecGrpsTemp = [], this.isPCVisible = !1, this.dataGroupState = [], this.userLocation = {
            country: "",
            state: "",
            stateName: ""
        }, this.vendorsSetting = {}, this.dsParams = {}, this.isV2Stub = !1, this.fireOnetrustGrp = !1, this.showVendorService = !1, this.showGeneralVendors = !1, this.genVenOptOutEnabled = !1, this.gpcConsentTxn = !1, this.vsIsActiveAndOptOut = !1, this.bAsset = {}, this.pcAsset = {}, this.csBtnAsset = {}, this.cStyles = {}, this.vendorDomInit = !1, this.genVendorDomInit = !1, this.syncNtfyContent = {}, this.ntfyRequired = !1, this.skipAddingHTML = !1, this.bnrAnimationInProg = !1, this.isPreview = !1, this.geoFromUrl = "", this.hideBanner = !1, this.setAttributePolyfillIsActive = !1, this.storageBaseURL = "", this.isKeyboardUser = !1, this.customerStyles = new Map, this.showTrackingTech = !1, this.currentTrackingTech = {}
    }
    qt.prototype.getVendorsInDomain = function() {
        var e, t;
        return L._vendorsInDomain || (e = new Map, t = null != (t = I.Groups) ? t : [], L.setVendorServicesMap(t, e), L._vendorsInDomain = e), L._vendorsInDomain
    }, qt.prototype.setVendorServicesMap = function(e, t) {
        for (var o, n = 0, r = e; n < r.length; n++) {
            var i = r[n];
            i.SubGroups && 0 < i.SubGroups.length && L.setVendorServicesMap(i.SubGroups, t);
            for (var s = 0, a = null != (o = i.VendorServices) ? o : []; s < a.length; s++) {
                var l = a[s],
                    c = Object.assign({}, i);
                delete c.VendorServices, l.groupRef = c, t.set(l.CustomVendorServiceId, l)
            }
        }
    }, qt.prototype.clearVendorsInDomain = function() {
        L._vendorsInDomain = null
    }, qt.prototype.checkVendorConsent = function(e) {
        return L.vendorsSetting[e] && L.vendorsSetting[e].consent
    };
    var L = new qt;

    function n() {
        this.IABTCF_DEFAULT_LANGUAGE = "EN", this.IABTCF_DEFAULT_SERBIAN = "SR-CYRL", this.IABTCF_DEFAULT_PORTUGUESE = "PT-PT", this.IABTCF_SUPPORTED_LANGUAGES = new Set(["AR", "BG", "BS", "CA", "CS", "CY", "DA", "DE", "EL", "EN", "ES", "ET", "EU", "FI", "FR", "GL", "HE", "HR", "HU", "ID", "IT", "JA", "KA", "KO", "LT", "LV", "MK", "MS", "MT", "NL", "NO", "PL", "PT-BR", "PT-PT", "RO", "RU", "SK", "SL", "SQ", "SR-LATN", "SR-CYRL", "SV", "SW", "TH", "TL", "TR", "UK", "VI", "ZH"])
    }
    n.prototype.initializeBannerVariables = function(e) {
        var t = e.DomainData;
        A.iabType = t.IabType, k = t.PCTemplateUpgrade ? Vt : Dt, b = "IAB2" === A.iabType ? Nt : wt, A.init(e), L.showGeneralVendors = I.GeneralVendorsEnabled && I.PCTemplateUpgrade, L.showVendorService = m.fp.CookieV2VendorServiceScript && I.VendorServiceConfig.PCVSEnable && !A.isIab2orv2Template && I.PCTemplateUpgrade, L.vsIsActiveAndOptOut = L.showVendorService && I.VendorServiceConfig.PCVSOptOut, L.showTrackingTech = m.fp.CookieV2TrackingTechPrefCenter && I.AdditionalTechnologiesConfig.PCShowTrackingTech, L.genVenOptOutEnabled = L.showGeneralVendors && I.GenVenOptOut, h.addLogoUrls(), this.setGeolocationInCookies(), this.setOrUpdate3rdPartyIABConsentFlag()
    }, n.prototype.initializeVendorInOverriddenVendors = function(e, t) {
        I.OverriddenVendors[e] = {
            disabledCP: [],
            disabledLIP: [],
            active: t,
            legInt: !1,
            consent: !1
        }
    }, n.prototype.applyGlobalRestrictionsonNewVendor = function(e, t, o, n) {
        var r = I.GlobalRestrictions,
            i = I.OverriddenVendors;
        switch (I.Publisher.restrictions[o] || (I.Publisher.restrictions[o] = {}), i[t] || this.initializeVendorInOverriddenVendors(t, !0), i[t].disabledCP || (i[t].disabledCP = []), i[t].disabledLIP || (i[t].disabledLIP = []), r[o]) {
            case pe.Disabled:
                (n ? i[t].disabledCP : i[t].disabledLIP).push(o), I.Publisher.restrictions[o][t] = pe.Disabled;
                break;
            case pe.Consent:
                n ? (i[t].consent = !0, I.Publisher.restrictions[o][t] = pe.Consent) : (i[t].disabledLIP.push(o), this.checkFlexiblePurpose(e, t, o, !1));
                break;
            case pe.LegInt:
                n ? (i[t].disabledCP.push(o), this.checkFlexiblePurpose(e, t, o, !0)) : (i[t].legInt = !0, I.Publisher.restrictions[o][t] = pe.LegInt);
                break;
            case void 0:
                n ? i[t].consent = !0 : i[t].legInt = !0
        }
    }, n.prototype.checkFlexiblePurpose = function(e, t, o, n) {
        e.flexiblePurposes.includes(o) ? (n ? I.OverriddenVendors[t].legInt = !0 : I.OverriddenVendors[t].consent = !0, I.Publisher.restrictions[o][t] = n ? pe.LegInt : pe.Consent) : I.Publisher.restrictions[o][t] = pe.Disabled
    }, n.prototype.getActivePurposesForVendor = function(e, t) {
        var o = I.OverriddenVendors[t] && I.OverriddenVendors[t].disabledCP,
            n = I.OverriddenVendors[t] && I.OverriddenVendors[t].disabledLIP,
            o = o ? this.removeElementsFromArray(e.purposes, I.OverriddenVendors[t].disabledCP) || [] : e.purposes || [],
            n = n ? this.removeElementsFromArray(e.legIntPurposes, I.OverriddenVendors[t].disabledLIP) || [] : e.legIntPurposes || [],
            t = U(o, n, e.flexiblePurposes || []);
        return new Set(t)
    }, n.prototype.canInferGCMSettingsFromTCString = function() {
        return A.isTcfV2Template && I.GoogleConsent.GCEnable
    }, n.prototype.shouldOverrideTCData = function() {
        var e = this.canInferGCMSettingsFromTCString();
        return I.UseGoogleVendors || e
    }, n.prototype.setActiveVendorCount = function(o, e) {
        var n, r, i, s = this,
            a = [];
        "IAB2V2" === A.getRegionRuleType() && (n = new Set, r = A.tcf2ActiveVendors, (i = this.getActivePurposesForVendor(o, e)).forEach(function(e) {
            var t = r.pur.get(e) || 0;
            r.pur.set(e, t + 1), A.tcfParentMap.pur.get(e) && n.add(A.tcfParentMap.pur.get(e))
        }), o.specialPurposes && o.specialPurposes.forEach(function(e) {
            var t = r.spl_pur.get(e) || 0;
            r.spl_pur.set(e, t + 1), A.tcfParentMap.spl_pur.get(e) && (n.add(A.tcfParentMap.spl_pur.get(e)), t = A.tcfParentMap.spl_pur.get(e), s.updateParentCountByType(t, r, o, a, i))
        }), o.features && o.features.forEach(function(e) {
            var t = r.ft.get(e) || 0;
            r.ft.set(e, t + 1), A.tcfParentMap.ft.get(e) && (n.add(A.tcfParentMap.ft.get(e)), t = A.tcfParentMap.ft.get(e), s.updateParentCountByType(t, r, o, a, i))
        }), o.specialFeatures && o.specialFeatures.forEach(function(e) {
            var t = r.spl_ft.get(e) || 0;
            r.spl_ft.set(e, t + 1), A.tcfParentMap.spl_ft.get(e) && (n.add(A.tcfParentMap.spl_ft.get(e)), t = A.tcfParentMap.spl_ft.get(e), s.updateParentCountByType(t, r, o, a, i))
        }), n.forEach(function(e) {
            var t = r.stack.get(e) || 0;
            r.stack.set(e, t + 1)
        }))
    }, n.prototype.updateParentCountByType = function(e, t, o, n, r) {
        var i, s, a, l;
        e && !n.includes(e) && (i = !1, a = e.split("_"), s = ["IAB2V2", "IFE2V2", "ISP2V2", "ISF2V2"].includes(a[0]), 1 < a.length) && s && (s = this.readProp(At, a[0]), a = parseInt(a[1]), l = void 0, (s === At.IAB2V2 && !r.has(a) || s !== At.IAB2V2 && (l = o[this.readProp(It, s)]) && !l.includes(a)) && (i = !0), s) && i && ((r = t[s].get(a)) ? t[s].set(a, r + 1) : (t[s].set(a, 1), n.push(e)))
    }, n.prototype.readProp = function(e, t) {
        var o, n = "";
        for (o in e)
            if (t === o) {
                n = e[o];
                break
            }
        return n
    }, n.prototype.isVendorInvalid = function(e, t) {
        var o = !1,
            n = !e.purposes.length && !e.flexiblePurposes.length,
            r = (I.OverriddenVendors[t] && !I.OverriddenVendors[t].consent && (n = !0), !0);
        return A.legIntSettings.PAllowLI && e.legIntPurposes.length && (!I.OverriddenVendors[t] || I.OverriddenVendors[t].legInt) && (r = !1), o = !n || !r || e.specialPurposes.length || e.features.length || e.specialFeatures.length ? o : !0
    }, n.prototype.removeInActiveVendorsForTcf = function(r) {
        var i = this,
            s = L.iabData.vendorListVersion,
            e = I.Publisher,
            a = I.GlobalRestrictionEnabled;
        0 !== Object.keys(e).length && e && Object.keys(e.restrictions).length;
        Object.keys(r.vendors).forEach(function(t) {
            var o = r.vendors[t],
                e = !1,
                n = i.getVendorGVLVersion(o),
                n = (s < n && (I.NewVendorsInactiveEnabled ? (i.initializeVendorInOverriddenVendors(t, !1), e = !0) : a && (o.purposes.forEach(function(e) {
                    i.applyGlobalRestrictionsonNewVendor(o, t, e, !0)
                }), o.legIntPurposes.forEach(function(e) {
                    i.applyGlobalRestrictionsonNewVendor(o, t, e, !1)
                }))), I.OverriddenVendors[t] && !I.OverriddenVendors[t].active && (e = !0), -1 < I.Vendors.indexOf(Number(t)) && (e = !0), i.isVendorInvalid(o, t));
            (e = e || n) && delete r.vendors[t], e || i.setActiveVendorCount(o, t)
        })
    }, n.prototype.getVendorGVLVersion = function(e) {
        return A.isTcfV2Template ? e.iab2V2GVLVersion : e.iab2GVLVersion
    }, n.prototype.removeElementsFromArray = function(e, t) {
        return e.filter(function(e) {
            return !t.includes(e)
        })
    }, n.prototype.setPublisherRestrictions = function() {
        var i, t, s, a, e = I.Publisher;
        e && e.restrictions && (i = this.iabStringSDK(), t = e.restrictions, s = L.iabData, a = L.oneTrustIABConsent.vendorList.vendors, Object.keys(t).forEach(function(o) {
            var n, r = t[o],
                e = A.iabGroups.purposes[o];
            e && (n = {
                description: e.description,
                purposeId: e.id,
                purposeName: e.name
            }), Object.keys(r).forEach(function(e) {
                var t;
                L.vendorsSetting[e] && (t = L.vendorsSetting[e].arrIndex, 1 === r[e] && -1 === a[e].purposes.indexOf(Number(o)) ? s.vendors[t].purposes.push(n) : 2 === r[e] && -1 === a[e].legIntPurposes.indexOf(Number(o)) && s.vendors[t].legIntPurposes.push(n), t = i.purposeRestriction(Number(o), r[e]), L.tcModel.publisherRestrictions.add(Number(e), t))
            })
        }))
    }, n.prototype.populateVendorListTCF = function() {
        return F(this, void 0, void 0, function() {
            var t, o, n, r, i, s, a, l, c, d;
            return M(this, function(e) {
                switch (e.label) {
                    case 0:
                        return (t = this.iabStringSDK(), o = L.iabData, n = h.updateCorrectIABUrl(o.globalVendorListUrl), r = !this.isIABCrossConsentEnabled(), s = this.getConsentLanguage(), h.checkMobileOfflineRequest(h.getBannerVersionUrl())) ? [3, 1] : (A.mobileOnlineURL.push(n), i = t.gvl(s, n, L.gvlObj), [3, 3]);
                    case 1:
                        return l = (a = t).gvl, c = [s, null], [4, h.otFetchOfflineFile(P.getRelativeURL(n, !0))];
                    case 2:
                        i = l.apply(a, c.concat([e.sent()])), e.label = 3;
                    case 3:
                        return this.removeInActiveVendorsForTcf(i), A.tcf2ActiveVendors.all = Object.keys(i.vendors).length, L.oneTrustIABConsent.vendorList = i, this.assignIABDataWithGlobalVendorList(i), d = L, [4, t.tcModel(i)];
                    case 4:
                        d.tcModel = e.sent(), r && this.setPublisherRestrictions(), L.tcModel.cmpId = parseInt(o.cmpId), A.isTcfV2Template && (L.tcModel.useNonStandardTexts = I.UseNonStandardStacks), L.tcModel.cmpVersion = parseInt(o.cmpVersion);
                        try {
                            L.tcModel.consentLanguage = L.consentLanguage
                        } catch (e) {
                            L.tcModel.consentLanguage = "EN"
                        }
                        return L.tcModel.consentScreen = parseInt(o.consentScreen), L.tcModel.isServiceSpecific = r, L.tcModel.purposeOneTreatment = A.purposeOneTreatment, I.PublisherCC ? L.tcModel.publisherCountryCode = I.PublisherCC : L.userLocation.country && (L.tcModel.publisherCountryCode = L.userLocation.country), L.cmpApi = t.cmpApi(L.tcModel.cmpId, L.tcModel.cmpVersion, r, this.shouldOverrideTCData() ? {
                            getTCData: this.overrideTCData,
                            getInAppTCData: this.overrideTCData
                        } : void 0), null !== this.alertBoxCloseDate() && !this.needReconsent() || this.resetTCModel(), [2]
                }
            })
        })
    }, n.prototype.resetTCModel = function() {
        var e, t, o = this.iabStringSDK(),
            n = L.tcModel.clone();
        n.unsetAll(), A.legIntSettings.PAllowLI && (e = A.consentableIabGrps.filter(function(e) {
            return e.HasLegIntOptOut && e.Type === b.GroupTypes.Pur
        }).map(function(e) {
            return parseInt(A.iabGrpIdMap[e.CustomGroupId])
        }), t = Object.keys(L.vendorsSetting).filter(function(e) {
            return L.vendorsSetting[e].legInt
        }).map(function(e) {
            return parseInt(e)
        }), n.purposeLegitimateInterests.set(e), n.vendorLegitimateInterests.set(t), n.isServiceSpecific) && n.publisherLegitimateInterests.set(e), L.cmpApi.update(o.tcString().encode(n), !0)
    }, n.prototype.overrideTCData = function(e, t, o) {
        var n = p.canInferGCMSettingsFromTCString();
        t && t.tcString && (I.UseGoogleVendors && (t.addtlConsent = "" + L.addtlConsentVersion + (L.isAddtlConsent ? L.addtlVendors.vendorConsent.join(".") : "")), n) && (t.enableAdvertiserConsentMode = !0), "function" == typeof e ? e(t, o) : console.error("__tcfapi received invalid parameters.")
    }, n.prototype.setIabData = function() {
        L.iabData = A.isTcfV2Template ? m.moduleInitializer.Iab2V2Data : m.moduleInitializer.IabV2Data, L.iabData.consentLanguage = L.consentLanguage
    }, n.prototype.assignIABDataWithGlobalVendorList = function(o) {
        var r = this,
            i = I.OverriddenVendors,
            s = (L.iabData.vendorListVersion = o.vendorListVersion, L.iabData.vendors = [], I.IABDataCategories);
        Object.keys(o.vendors).forEach(function(n) {
            L.vendorsSetting[n] = {
                consent: !0,
                legInt: !0,
                arrIndex: 0,
                specialPurposesOnly: !1
            };
            var e = {},
                t = o.vendors[n];
            e.vendorId = n, e.vendorName = t.name, e.policyUrl = t.policyUrl, r.setIAB2VendorData(t, e), e.cookieMaxAge = t.cookieMaxAgeSeconds ? P.calculateCookieLifespan(t.cookieMaxAgeSeconds) : null, e.usesNonCookieAccess = t.usesNonCookieAccess, e.deviceStorageDisclosureUrl = t.deviceStorageDisclosureUrl || null, A.legIntSettings.PAllowLI && !r.shouldHaveVendorLIUnset(i, t, n) || (L.vendorsSetting[n].legInt = !1), A.legIntSettings.PAllowLI && r.vendorHasNoLIAndPurConsent(i, t, n) && t.specialPurposes.length && (L.vendorsSetting[n].specialPurposesOnly = !0, L.anyVendorHasOnlySplPur = !0), (!i[n] || i[n].consent) && (i[n] || t.purposes.length || t.flexiblePurposes.length) && (t.purposes.length || t.flexiblePurposes.length) || (L.vendorsSetting[n].consent = !1), e.features = t.features.reduce(function(e, t) {
                t = A.iabGroups.features[t];
                return t && e.push({
                    description: t.description,
                    featureId: t.id,
                    featureName: t.name
                }), e
            }, []), e.specialFeatures = o.vendors[n].specialFeatures.reduce(function(e, t) {
                t = A.iabGroups.specialFeatures[t];
                return t && e.push({
                    description: t.description,
                    featureId: t.id,
                    featureName: t.name
                }), e
            }, []), r.mapDataDeclarationForVendor(o.vendors[n], e, s), r.mapDataRetentionForVendor(o.vendors[n], e), e.purposes = o.vendors[n].purposes.reduce(function(e, t) {
                var o = A.iabGroups.purposes[t];
                return !o || i[n] && i[n].disabledCP && -1 !== i[n].disabledCP.indexOf(t) || e.push({
                    description: o.description,
                    purposeId: o.id,
                    purposeName: o.name
                }), e
            }, []), e.legIntPurposes = o.vendors[n].legIntPurposes.reduce(function(e, t) {
                var o = A.iabGroups.purposes[t];
                return !o || i[n] && i[n].disabledLIP && -1 !== i[n].disabledLIP.indexOf(t) || e.push({
                    description: o.description,
                    purposeId: o.id,
                    purposeName: o.name
                }), e
            }, []), e.specialPurposes = t.specialPurposes.reduce(function(e, t) {
                t = A.iabGroups.specialPurposes[t];
                return t && e.push({
                    description: t.description,
                    purposeId: t.id,
                    purposeName: t.name
                }), e
            }, []), L.iabData.vendors.push(e), L.vendorsSetting[n].arrIndex = L.iabData.vendors.length - 1
        })
    }, n.prototype.vendorHasNoLIAndPurConsent = function(e, t, o) {
        return e[o] && !e[o].legInt && !e[o].consent || !e[o] && !t.legIntPurposes.length && !t.purposes.length
    }, n.prototype.shouldHaveVendorLIUnset = function(e, t, o) {
        var n = !1,
            r = !1,
            i = t.specialPurposes.length;
        return (e[o] && !e[o].legInt || !e[o] && !t.legIntPurposes.length) && (n = !0), (e[o] && !e[o].consent || !e[o] && !t.purposes.length) && (r = !0), !(!n || r === Boolean(i) && (r || i))
    }, n.prototype.mapDataDeclarationForVendor = function(e, t, n) {
        var o;
        A.isTcfV2Template && null != (o = e.dataDeclaration) && o.length && (t.dataDeclaration = e.dataDeclaration.reduce(function(e, t) {
            var o = n.find(function(e) {
                return e.Id === t
            });
            return o && e.push({
                Description: o.Description,
                Id: o.Id,
                Name: o.Name
            }), e
        }, []))
    }, n.prototype.mapDataRetentionForVendor = function(o, n) {
        var e;
        n.dataRetention = {}, A.isTcfV2Template && o.dataRetention && (null !== (null == (e = o.dataRetention) ? void 0 : e.stdRetention) && void 0 !== (null == (e = o.dataRetention) ? void 0 : e.stdRetention) && (n.dataRetention = {
            stdRetention: o.dataRetention.stdRetention
        }), Object.keys(null == (e = o.dataRetention) ? void 0 : e.purposes).length && (n.dataRetention.purposes = JSON.parse(JSON.stringify(o.dataRetention.purposes)), Object.keys(o.dataRetention.purposes).forEach(function(e) {
            var t = A.iabGroups.purposes[e];
            t && (n.dataRetention.purposes[e] = {
                name: t.name,
                id: t.id,
                retention: o.dataRetention.purposes[e]
            })
        })), Object.keys(null == (e = o.dataRetention) ? void 0 : e.specialPurposes).length) && (n.dataRetention.specialPurposes = JSON.parse(JSON.stringify(o.dataRetention.specialPurposes)), Object.keys(o.dataRetention.specialPurposes).forEach(function(e) {
            var t = A.iabGroups.specialPurposes[e];
            t && (n.dataRetention.specialPurposes[e] = {
                name: t.name,
                id: t.id,
                retention: o.dataRetention.specialPurposes[e]
            })
        }))
    }, n.prototype.setIAB2VendorData = function(e, t) {
        var o, n, r;
        A.isTcfV2Template && (n = L.lang, r = (r = e.urls.find(function(e) {
            return e.langId === n
        })) || e.urls[0], t.vendorPrivacyUrl = (null == (o = r) ? void 0 : o.privacy) || "", t.legIntClaim = (null == (o = r) ? void 0 : o.legIntClaim) || "", null != (r = e.dataDeclaration) && r.length && (t.dataDeclaration = e.dataDeclaration), e.DataRetention) && (t.DataRetention = e.DataRetention)
    }, n.prototype.populateIABCookies = function() {
        return F(this, void 0, void 0, function() {
            return M(this, function(e) {
                switch (e.label) {
                    case 0:
                        if (!this.isIABCrossConsentEnabled()) return [3, 5];
                        e.label = 1;
                    case 1:
                        return e.trys.push([1, 3, , 4]), [4, this.setIAB3rdPartyCookie(C.EU_CONSENT, "", 0, !0)];
                    case 2:
                        return e.sent(), [3, 4];
                    case 3:
                        return e.sent(), this.setIABCookieData(), this.updateCrossConsentCookie(!1), [3, 4];
                    case 4:
                        return [3, 6];
                    case 5:
                        p.needReconsent() || this.setIABCookieData(), e.label = 6;
                    case 6:
                        return [2]
                }
            })
        })
    }, n.prototype.setIAB3rdPartyCookie = function(e, t, o, n) {
        var r = I.iabThirdPartyConsentUrl;
        try {
            if (r && document.body) return this.updateThirdPartyConsent(r, e, t, o, n);
            throw new ReferenceError
        } catch (e) {
            throw e
        }
    }, n.prototype.setIABCookieData = function() {
        L.oneTrustIABConsent.IABCookieValue = g.getCookie(C.EU_PUB_CONSENT)
    }, n.prototype.updateThirdPartyConsent = function(n, r, i, s, a) {
        return F(this, void 0, void 0, function() {
            var t, o;
            return M(this, function(e) {
                return t = window.location.protocol + "//" + n + "/?name=" + r + "&value=" + i + "&expire=" + s + "&isFirstRequest=" + a, document.getElementById("onetrustIabCookie") ? (document.getElementById("onetrustIabCookie").contentWindow.location.replace(t), [2]) : (d(o = document.createElement("iframe"), "display: none;", !0), o.id = "onetrustIabCookie", o.setAttribute("title", "OneTrust IAB Cookie"), o.src = t, document.body.appendChild(o), [2, new Promise(function(e) {
                    o.onload = function() {
                        A.thirdPartyiFrameResolve(), A.thirdPartyiFrameLoaded = !0, e()
                    }, o.onerror = function() {
                        throw A.thirdPartyiFrameResolve(), A.thirdPartyiFrameLoaded = !0, e(), new URIError
                    }
                })])
            })
        })
    }, n.prototype.setIABVendor = function(n, r, i) {
        var t, s = this;
        void 0 === n && (n = !0), void 0 === r && (r = !1), void 0 === i && (i = !1), L.iabData.vendors.forEach(function(e) {
            var t, o, e = e.vendorId;
            A.legIntSettings.PAllowLI ? (o = void 0, r ? o = n : (t = L.vendorsSetting[e], i && t.legInt && !t.specialPurposesOnly ? s.updateVendorPurposeOrLI(!0, e, !1) : (o = !!L.vendorsSetting[e].consent && n, s.updateVendorPurposeOrLI(!0, e, L.vendorsSetting[e].legInt))), s.updateVendorPurposeOrLI(!1, e, o)) : (L.oneTrustIABConsent.legIntVendors = [], s.updateVendorPurposeOrLI(!1, e, n))
        }), I.UseGoogleVendors && (t = L.addtlVendors, Object.keys(L.addtlVendorsList).forEach(function(e) {
            n ? (t.vendorSelected["" + e.toString()] = !0, t.vendorConsent.push("" + e.toString())) : r && (t.vendorSelected["" + e.toString()] = !1, e = t.vendorConsent.indexOf("" + e.toString()), t.vendorConsent.splice(e, 1))
        }))
    }, n.prototype.updateVendorPurposeOrLI = function(e, t, o) {
        void 0 === o && (o = !1), (e = void 0 === e ? !1 : e) ? -1 < (e = L.oneTrustIABConsent.legIntVendors.findIndex(function(e) {
            return e.includes(t.toString() + ":true") || e.includes(t.toString() + ":false")
        })) ? L.oneTrustIABConsent.legIntVendors[e] = t.toString() + ":" + o : L.oneTrustIABConsent.legIntVendors.push(t.toString() + ":" + o) : -1 < (e = L.oneTrustIABConsent.vendors.findIndex(function(e) {
            return e.includes(t.toString() + ":true") || e.includes(t.toString() + ":false")
        })) ? L.oneTrustIABConsent.vendors[e] = t.toString() + ":" + o : L.oneTrustIABConsent.vendors.push(t.toString() + ":" + o)
    }, n.prototype.setOrUpdate3rdPartyIABConsentFlag = function() {
        var e = this.getIABCrossConsentflagData();
        I.IsIabEnabled ? e && !this.needReconsent() || this.updateCrossConsentCookie(I.IsIabThirdPartyCookieEnabled) : e && !this.reconsentRequired() && "true" !== e || this.updateCrossConsentCookie(!1)
    }, n.prototype.isIABCrossConsentEnabled = function() {
        return "true" === this.getIABCrossConsentflagData()
    }, n.prototype.getIABCrossConsentflagData = function() {
        return g.readCookieParam(C.OPTANON_CONSENT, u.IS_IAB_GLOBAL)
    }, n.prototype.setGeolocationInCookies = function() {
        var e, t = g.readCookieParam(C.OPTANON_CONSENT, u.GEO_LOCATION);
        L.userLocation && !t && this.isAlertBoxClosedAndValid() ? (e = L.userLocation.country + ";" + L.userLocation.state, this.setUpdateGeolocationCookiesData(e)) : this.reconsentRequired() && t && this.setUpdateGeolocationCookiesData("")
    }, n.prototype.iabStringSDK = function() {
        var e = m.moduleInitializer.otIABModuleData;
        if (I.IsIabEnabled && e) return {
            gvl: e.tcfSdkRef.gvl,
            tcModel: e.tcfSdkRef.tcModel,
            tcString: e.tcfSdkRef.tcString,
            cmpApi: e.tcfSdkRef.cmpApi,
            purposeRestriction: e.tcfSdkRef.purposeRestriction
        }
    }, n.prototype.setUpdateGeolocationCookiesData = function(e) {
        g.writeCookieParam(C.OPTANON_CONSENT, u.GEO_LOCATION, e)
    }, n.prototype.calculateDaysFromDateToToday = function(e) {
        var e = new Date(e),
            t = new Date,
            t = (e.setUTCHours(0, 0, 0, 0), t.setUTCHours(0, 0, 0, 0), Math.abs(t.getTime() - e.getTime()));
        return Math.ceil(t / 864e5)
    }, n.prototype.reconsentRequired = function() {
        return (m.moduleInitializer.MobileSDK || this.awaitingReconsent()) && this.needReconsent()
    }, n.prototype.awaitingReconsent = function() {
        return "true" === g.readCookieParam(C.OPTANON_CONSENT, u.AWAITING_RE_CONSENT)
    }, n.prototype.needReconsent = function() {
        var e = this.alertBoxCloseDate(),
            t = I.LastReconsentDate;
        return !!(e && t && new Date(t) > new Date(e)) || (L.isAMP && e ? this.calculateDaysFromDateToToday(e) >= I.ReconsentFrequencyDays : void 0)
    }, n.prototype.updateCrossConsentCookie = function(e) {
        g.writeCookieParam(C.OPTANON_CONSENT, u.IS_IAB_GLOBAL, e)
    }, n.prototype.alertBoxCloseDate = function() {
        return g.getCookie(C.ALERT_BOX_CLOSED)
    }, n.prototype.isAlertBoxClosedAndValid = function() {
        return null !== this.alertBoxCloseDate() && !this.reconsentRequired()
    }, n.prototype.generateLegIntButtonElements = function(e, t, o) {
        return v.getInnerHtmlContent('<div class="ot-leg-btn-container" data-group-id="' + t + '" data-el-id="' + t + '-leg-out" is-vendor="' + (o = void 0 === o ? !1 : o) + '">\n                    <button class="ot-obj-leg-btn-handler ' + (e ? "ot-leg-int-enabled ot-inactive-leg-btn" : "ot-active-leg-btn") + '">\n                        <svg xmlns="http://www.w3.org/2000/svg" xmlns:xlink="http://www.w3.org/1999/xlink" x="0px" y="0px" viewBox="0 0 512 512">\n                            <path fill="' + I.pcButtonTextColor + '" d="M173.898 439.404l-166.4-166.4c-9.997-9.997-9.997-26.206 0-36.204l36.203-36.204c9.997-9.998 26.207-9.998 36.204 0L192 312.69 432.095 72.596c9.997-9.997 26.207-9.997 36.204 0l36.203 36.204c9.997 9.997 9.997 26.206 0 36.204l-294.4 294.401c-9.998 9.997-26.207 9.997-36.204-.001z"/>\n                        </svg>\n                        <span>' + (e ? A.legIntSettings.PObjectLegIntText : A.legIntSettings.PObjectionAppliedText) + '\n                        </span>\n                    </button>\n                    <button\n                        class="ot-remove-objection-handler"\n                            data-style="color:' + I.pcButtonColor + "; " + (e ? "display:none;" : "") + '"\n                    >\n                        ' + A.legIntSettings.PRemoveObjectionText + "\n                    </button>\n                </div>")
    }, n.prototype.syncAlertBoxCookie = function(e) {
        var t = I.ReconsentFrequencyDays;
        g.setCookie(C.ALERT_BOX_CLOSED, e = e || "", t, !1, new Date(e))
    }, n.prototype.syncCookieExpiry = function() {
        var e, t, o;
        L.syncRequired && (e = I.ReconsentFrequencyDays, t = g.getCookie(C.ALERT_BOX_CLOSED), o = g.getCookie(C.OPTANON_CONSENT), g.setCookie(C.OPTANON_CONSENT, o, e, !1, new Date(t)), p.needReconsent() && g.removeAlertBox(), (o = g.getCookie(C.EU_PUB_CONSENT)) && (p.isIABCrossConsentEnabled() ? g.removeIab2() : g.setCookie(C.EU_PUB_CONSENT, o, e, !1, new Date(t))), o = g.getCookie(C.ADDITIONAL_CONSENT_STRING)) && g.setCookie(C.ADDITIONAL_CONSENT_STRING, o, e, !1, new Date(t))
    }, n.prototype.syncOtPreviewCookie = function() {
        var e = g.getCookie(C.OT_PREVIEW);
        e && g.setCookie(C.OT_PREVIEW, e, 1, !1)
    }, n.prototype.dispatchConsentEvent = function() {
        window.dispatchEvent(new CustomEvent("OTConsentApplied", {
            OTConsentApplied: "yes"
        }))
    }, n.prototype.getConsentLanguage = function() {
        var e;
        return L.lang ? (e = L.lang.toUpperCase(), this.IABTCF_SUPPORTED_LANGUAGES.has(e) || (e = e.substr(0, 2), this.IABTCF_SUPPORTED_LANGUAGES.has(e)) ? e : "PT" === e ? this.IABTCF_DEFAULT_PORTUGUESE : "SR" === e ? this.IABTCF_DEFAULT_SERBIAN : this.IABTCF_DEFAULT_LANGUAGE) : this.IABTCF_DEFAULT_LANGUAGE
    };
    var _, p = new n,
        jt = function() {};
    Xt.prototype.isAlwaysActiveGroup = function(e) {
        var t;
        return !this.getGrpStatus(e) || (t = this.getGrpStatus(e).toLowerCase(), (t = e.Parent && t !== S.ALWAYS_ACTIVE ? this.getGrpStatus(this.getParentGroup(e.Parent)).toLowerCase() : t) === S.ALWAYS_ACTIVE)
    }, Xt.prototype.getGrpStatus = function(e) {
        return e && e.Status ? A.DNTEnabled && e.IsDntEnabled ? S.DNT : e.Status : ""
    }, Xt.prototype.getParentGroup = function(t) {
        var e;
        return t && 0 < (e = I.Groups.filter(function(e) {
            return e.OptanonGroupId === t
        })).length ? e[0] : null
    }, Xt.prototype.checkIfGroupHasConsent = function(t) {
        var e = L.groupsConsent,
            o = P.findIndex(e, function(e) {
                return e.split(":")[0] === t.CustomGroupId
            });
        return -1 < o && "1" === e[o].split(":")[1]
    }, Xt.prototype.checkIsActiveByDefault = function(e) {
        var t;
        return !this.getGrpStatus(e) || (t = this.getGrpStatus(e).toLowerCase(), (t = e.Parent && t !== S.ALWAYS_ACTIVE ? this.getGrpStatus(this.getParentGroup(e.Parent)).toLowerCase() : t) === S.ALWAYS_ACTIVE) || t === S.INACTIVE_LANDING_PAGE || t === S.ACTIVE || t === S.DNT && !A.DNTEnabled
    }, Xt.prototype.getGroupById = function(e) {
        for (var t = null, o = 0, n = I.Groups; o < n.length; o++) {
            for (var r = n[o], i = 0, s = U(r.SubGroups, [r]); i < s.length; i++) {
                var a = s[i];
                if (a.CustomGroupId === e) {
                    t = a;
                    break
                }
            }
            if (t) break
        }
        return t
    }, Xt.prototype.isSoftOptInGrp = function(e) {
        return !!e && (e = e && !e.Parent ? e : y.getParentGroup(e.Parent), "inactive landingpage" === y.getGrpStatus(e).toLowerCase())
    }, Xt.prototype.isOptInGrp = function(e) {
        return !!e && "inactive" === y.getGrpStatus(e).toLowerCase()
    }, Xt.prototype.getParentByGrp = function(e) {
        return e.Parent ? this.getGroupById(e.Parent) : null
    }, Xt.prototype.getVSById = function(e) {
        return L.getVendorsInDomain().get(e)
    }, Xt.prototype.getGrpByVendorId = function(e) {
        var t = null;
        return t = L.getVendorsInDomain().has(e) ? L.getVendorsInDomain().get(e).groupRef : t
    };
    var y, Kt, zt, Wt, Yt, Jt = Xt;

    function Xt() {}(s = Kt = Kt || {}).SaleOptOut = "SaleOptOutCID", s.SharingOptOut = "SharingOptOutCID", s.PersonalDataConsents = "PersonalDataCID", (s = zt = zt || {}).SharingOptOutNotice = "SharingOptOutCID", s.SaleOptOutNotice = "SaleOptOutCID", s.SensitiveDataLimitUseNotice = "SensitivePICID || SensitiveSICID || GeolocationCID || RREPInfoCID || CommunicationCID || GeneticCID|| BiometricCID || HealthCID || SexualOrientationCID", (s = Wt = Wt || {}).KnownChildSensitiveDataConsents1 = "KnownChildSellPICID", s.KnownChildSensitiveDataConsents2 = "KnownChildSharePICID", (s = Yt = Yt || {}).SensitiveDataProcessing1 = "SensitivePICID", s.SensitiveDataProcessing2 = "SensitiveSICID", s.SensitiveDataProcessing3 = "GeolocationCID", s.SensitiveDataProcessing4 = "RREPInfoCID", s.SensitiveDataProcessing5 = "CommunicationCID", s.SensitiveDataProcessing6 = "GeneticCID", s.SensitiveDataProcessing7 = "BiometricCID", s.SensitiveDataProcessing8 = "HealthCID", s.SensitiveDataProcessing9 = "SexualOrientationCID", $t.prototype.initialiseCssReferences = function() {
        var e, t = "";
        document.getElementById("onetrust-style") ? e = document.getElementById("onetrust-style") : ((e = document.createElement("style")).id = "onetrust-style", m.moduleInitializer.CookieV2CSPEnabled && L.nonce && e.setAttribute("nonce", L.nonce)), N.commonStyles && (t += N.commonStyles), N.bannerGroup && (t += N.bannerGroup.css, m.fp.CookieV2SSR || (t += this.addCustomBannerCSS()), I.bannerCustomCSS) && (t += I.bannerCustomCSS), N.preferenceCenterGroup && (t = (t += N.preferenceCenterGroup.css) + this.addCustomPreferenceCenterCSS()), N.cookieListGroup && !m.fp.CookieV2TrackingTechnologies && (t = (t += N.cookieListGroup.css) + this.addCustomCookieListCSS()), I.cookiePersistentLogo && !I.cookiePersistentLogo.includes("ot_guard_logo.svg") && (t += ".ot-floating-button__front{background-image:url('" + h.updateCorrectUrl(I.cookiePersistentLogo) + "')}"), this.processedCSS = t, A.ignoreInjectingHtmlCss || (e.textContent = t, T(document.head).append(e))
    }, $t.prototype.setButonColor = function() {
        var e, t = I.pcButtonColor,
            o = I.pcButtonTextColor,
            n = I.pcLegIntButtonColor,
            r = I.pcLegIntButtonTextColor,
            i = "";
        return (t || o) && (e = A.pcName === ot ? "#onetrust-consent-sdk #onetrust-pc-sdk " + k.P_Category_Item + ",\n                    #onetrust-consent-sdk #onetrust-pc-sdk.ot-leg-opt-out " + k.P_Li_Hdr + "{\n                    border-color: " + t + ";\n                }" : "", i = "#onetrust-consent-sdk #onetrust-pc-sdk\n            button:not(#clear-filters-handler):not(.ot-close-icon):not(#filter-btn-handler):not(.ot-remove-objection-handler):not(.ot-obj-leg-btn-handler):not([aria-expanded]):not(.ot-link-btn),\n            #onetrust-consent-sdk #onetrust-pc-sdk .ot-leg-btn-container .ot-active-leg-btn {\n                " + (t ? "background-color: " + t + ";border-color: " + t + ";" : "") + "\n                " + (o ? "color: " + o + ";" : "") + "\n            }\n            #onetrust-consent-sdk #onetrust-pc-sdk ." + k.P_Active_Menu + " {\n                " + (t ? "border-color: " + t + ";" : "") + "\n            }\n            " + e + "\n            #onetrust-consent-sdk #onetrust-pc-sdk .ot-leg-btn-container .ot-remove-objection-handler{\n                background-color: transparent;\n                border: 1px solid transparent;\n            }\n            #onetrust-consent-sdk #onetrust-pc-sdk .ot-leg-btn-container .ot-inactive-leg-btn {\n                " + (n ? "background-color: " + n + ";" : "") + "\n                " + (r ? "color: " + r + "; border-color: " + r + ";" : "") + "\n            }"), i
    }, $t.prototype.setFocusBorderColor = function() {
        var e = "",
            t = I.PCFocusBorderColor;
        return t && (e += '\n            #onetrust-consent-sdk #onetrust-pc-sdk .ot-tgl input:focus + .ot-switch, .ot-switch .ot-switch-nob, .ot-switch .ot-switch-nob:before,\n            #onetrust-pc-sdk .ot-checkbox input[type="checkbox"]:focus + label::before,\n            #onetrust-pc-sdk .ot-chkbox input[type="checkbox"]:focus + label::before {\n                outline-color: ' + t + ";\n                outline-width: 1px;\n                outline-offset: 1px;\n            }\n            #onetrust-pc-sdk .ot-host-item > button:focus, #onetrust-pc-sdk .ot-ven-item > button:focus {\n                border: 1px solid " + t + ";\n            }\n            #onetrust-consent-sdk #onetrust-pc-sdk *:focus,\n            #onetrust-consent-sdk #onetrust-pc-sdk .ot-vlst-cntr > a:focus {\n               outline: 1px solid " + t + ";\n               outline-offset: 1px;\n            }"), e
    }, $t.prototype.setCloseIconColor = function() {
        var e = "";
        return I.PCCloseButtonType === Pe.Link && (e += "#onetrust-pc-sdk.ot-close-btn-link .ot-close-icon {color: " + I.PCContinueColor + "}"), e
    }, $t.prototype.setTabLayoutStyles = function() {
        var e = "",
            t = I.pcMenuColor,
            o = I.pcMenuHighLightColor;
        return A.pcName === it && (t && (e += "#onetrust-consent-sdk #onetrust-pc-sdk .category-menu-switch-handler {\n                    background-color: " + t + "\n                }"), o) && (e += "#onetrust-consent-sdk #onetrust-pc-sdk ." + k.P_Active_Menu + " {\n                    background-color: " + o + "\n                }"), e
    }, $t.prototype.setFocusIfTemplateUpgrade = function() {
        var e = "",
            t = I.PCFocusBorderColor;
        return !I.PCTemplateUpgrade && t && (e += '\n            #onetrust-pc-sdk input[type="checkbox"]:focus + .accordion-header,\n            #onetrust-pc-sdk .category-item .ot-switch.ot-toggle input:focus + .ot-switch-label,\n            #onetrust-pc-sdk .checkbox input:focus + label::after {\n                outline-color: ' + t + ";\n                outline-width: 1px;\n            }"), e
    }, $t.prototype.setExtLnkUrl = function() {
        var e = "",
            t = h.updateCorrectUrl(I.OTExternalLinkLogo);
        return t && (e += "#onetrust-pc-sdk .ot-vlst-cntr .ot-ext-lnk,  #onetrust-pc-sdk .ot-ven-hdr .ot-ext-lnk{\n                    background-image: url('" + t + "');\n                }\n            "), e
    }, $t.prototype.setCustomCss = function() {
        var e = "";
        return I.pcCustomCSS && (e += I.pcCustomCSS), e
    };
    var Qt, Zt = $t;

    function $t() {
        this.processedCSS = "", this.addCustomBannerCSS = function() {
            var e = I.backgroundColor,
                t = I.buttonColor,
                o = I.textColor,
                n = I.buttonTextColor,
                r = I.bannerMPButtonColor,
                i = I.bannerMPButtonTextColor,
                s = I.bannerAccordionBackgroundColor,
                a = I.BSaveBtnColor,
                l = I.BCategoryContainerColor,
                c = I.BLineBreakColor,
                d = I.BCategoryStyleColor,
                u = I.bannerLinksTextColor,
                p = I.BFocusBorderColor,
                o = "\n        " + (A.bannerName === Xe ? e ? "#onetrust-consent-sdk #onetrust-banner-sdk .ot-sdk-container {\n                    background-color: " + e + ";}" : "" : e ? "#onetrust-consent-sdk #onetrust-banner-sdk {background-color: " + e + ";}" : "") + "\n            " + (o ? "#onetrust-consent-sdk #onetrust-policy-title,\n                    #onetrust-consent-sdk #onetrust-policy-text,\n                    #onetrust-consent-sdk .ot-b-addl-desc,\n                    #onetrust-consent-sdk .ot-dpd-desc,\n                    #onetrust-consent-sdk .ot-dpd-title,\n                    #onetrust-consent-sdk #onetrust-policy-text *:not(.onetrust-vendors-list-handler),\n                    #onetrust-consent-sdk .ot-dpd-desc *:not(.onetrust-vendors-list-handler),\n                    #onetrust-consent-sdk #onetrust-banner-sdk #banner-options *,\n                    #onetrust-banner-sdk .ot-cat-header,\n                    #onetrust-banner-sdk .ot-optout-signal\n                    {\n                        color: " + o + ";\n                    }" : "") + "\n            " + (s ? "#onetrust-consent-sdk #onetrust-banner-sdk .banner-option-details {\n                    background-color: " + s + ";}" : "") + "\n            " + (u ? " #onetrust-consent-sdk #onetrust-banner-sdk a[href],\n                    #onetrust-consent-sdk #onetrust-banner-sdk a[href] font,\n                    #onetrust-consent-sdk #onetrust-banner-sdk .ot-link-btn\n                        {\n                            color: " + u + ";\n                        }" : "");
            return (t || n) && (o += "#onetrust-consent-sdk #onetrust-accept-btn-handler,\n                         #onetrust-banner-sdk #onetrust-reject-all-handler {\n                            " + (t ? "background-color: " + t + ";border-color: " + t + ";" : "") + "\n                " + (n ? "color: " + n + ";" : "") + "\n            }"), p && (o += "\n            #onetrust-consent-sdk #onetrust-banner-sdk *:focus,\n            #onetrust-consent-sdk #onetrust-banner-sdk:focus {\n               outline-color: " + p + ";\n               outline-width: 1px;\n            }"), (i || r) && (o += "\n            #onetrust-consent-sdk #onetrust-pc-btn-handler,\n            #onetrust-consent-sdk #onetrust-pc-btn-handler.cookie-setting-link {\n                " + (i ? "color: " + i + "; border-color: " + i + ";" : "") + "\n                background-color:\n                " + (r && !I.BannerSettingsButtonDisplayLink ? r : e) + ";\n            }"), A.bannerName === $e && (r = i = t = u = s = void 0, d && (i = "background-color: " + d + ";", r = "border-color: " + d + ";"), p && (o += "\n                #onetrust-consent-sdk #onetrust-banner-sdk .ot-tgl input:focus+.ot-switch .ot-switch-nob,\n                #onetrust-consent-sdk #onetrust-banner-sdk .ot-chkbox input:focus + label::before {\n                    outline-color: " + p + ";\n                    outline-width: 1px;\n                }"), o += "#onetrust-banner-sdk .ot-bnr-save-handler {" + (s = a ? "color: " + n + ";border-color: " + n + ";background-color: " + a + ";" : s) + "}#onetrust-banner-sdk .ot-cat-lst {" + (u = l ? "background-color: " + l + ";" : u) + "}#onetrust-banner-sdk .ot-cat-bdr {" + (t = c ? "border-color: " + c + ";" : t) + "}#onetrust-banner-sdk .ot-tgl input:checked+.ot-switch .ot-switch-nob:before,#onetrust-banner-sdk .ot-chkbox input:checked~label::before {" + i + "}#onetrust-banner-sdk .ot-chkbox label::before,#onetrust-banner-sdk .ot-tgl input:checked+.ot-switch .ot-switch-nob {" + r + "}#onetrust-banner-sdk #onetrust-pc-btn-handler.cookie-setting-link {background: inherit}"), I.BCloseButtonType === Pe.Link && (o += "#onetrust-banner-sdk.ot-close-btn-link .banner-close-button {color: " + I.BContinueColor + "}"), o
        }, this.addCustomPreferenceCenterCSS = function() {
            var e = I.pcBackgroundColor,
                t = I.pcTextColor,
                o = I.pcLinksTextColor,
                n = I.PCenterEnableAccordion,
                r = I.pcAccordionBackgroundColor,
                e = "\n            " + (e ? (A.pcName === ot ? "#onetrust-consent-sdk #onetrust-pc-sdk .group-parent-container,\n                        #onetrust-consent-sdk #onetrust-pc-sdk .manage-pc-container,\n                        #onetrust-pc-sdk " + k.P_Vendor_List : "#onetrust-consent-sdk #onetrust-pc-sdk") + ",\n                #onetrust-consent-sdk " + k.P_Search_Cntr + ",\n                " + (n && A.pcName === ot ? "#onetrust-consent-sdk #onetrust-pc-sdk .ot-accordion-layout" + k.P_Category_Item : "#onetrust-consent-sdk #onetrust-pc-sdk .ot-switch.ot-toggle") + ",\n                #onetrust-consent-sdk #onetrust-pc-sdk " + k.P_Tab_Grp_Hdr + " .checkbox,\n                #onetrust-consent-sdk #onetrust-pc-sdk " + k.P_Title + ":after\n                " + (m.isV2Template ? ",#onetrust-consent-sdk #onetrust-pc-sdk #ot-sel-blk,\n                        #onetrust-consent-sdk #onetrust-pc-sdk #ot-fltr-cnt,\n                        #onetrust-consent-sdk #onetrust-pc-sdk " + k.P_Triangle : "") + " {\n                    background-color: " + e + ";\n                }\n               " : "") + "\n            " + (t ? "#onetrust-consent-sdk #onetrust-pc-sdk h3,\n                #onetrust-consent-sdk #onetrust-pc-sdk h4,\n                #onetrust-consent-sdk #onetrust-pc-sdk h5,\n                #onetrust-consent-sdk #onetrust-pc-sdk h6,\n                #onetrust-consent-sdk #onetrust-pc-sdk p,\n                #onetrust-consent-sdk #onetrust-pc-sdk " + k.P_Vendor_Container + " " + k.P_Ven_Opts + " p,\n                #onetrust-consent-sdk #onetrust-pc-sdk " + k.P_Policy_Txt + ",\n                #onetrust-consent-sdk #onetrust-pc-sdk " + k.P_Title + ",\n                #onetrust-consent-sdk #onetrust-pc-sdk " + k.P_Li_Title + ",\n                #onetrust-consent-sdk #onetrust-pc-sdk " + k.P_Leg_Select_All + " span,\n                #onetrust-consent-sdk #onetrust-pc-sdk " + k.P_Host_Cntr + " " + k.P_Host_Info + ",\n                #onetrust-consent-sdk #onetrust-pc-sdk " + k.P_Fltr_Modal + " #modal-header,\n                #onetrust-consent-sdk #onetrust-pc-sdk .ot-checkbox label span,\n                #onetrust-consent-sdk #onetrust-pc-sdk " + k.P_Vendor_List + " " + k.P_Select_Cntr + " p,\n                #onetrust-consent-sdk #onetrust-pc-sdk " + k.P_Vendor_List + " " + k.P_Vendor_Title + ",\n                #onetrust-consent-sdk #onetrust-pc-sdk " + k.P_Vendor_List + " .back-btn-handler p,\n                #onetrust-consent-sdk #onetrust-pc-sdk " + k.P_Vendor_List + " " + k.P_Ven_Name + ",\n                #onetrust-consent-sdk #onetrust-pc-sdk " + k.P_Vendor_List + " " + k.P_Vendor_Container + " .consent-category,\n                #onetrust-consent-sdk #onetrust-pc-sdk .ot-leg-btn-container .ot-inactive-leg-btn,\n                #onetrust-consent-sdk #onetrust-pc-sdk .ot-label-status,\n                #onetrust-consent-sdk #onetrust-pc-sdk .ot-chkbox label span,\n                #onetrust-consent-sdk #onetrust-pc-sdk #clear-filters-handler,\n                #onetrust-consent-sdk #onetrust-pc-sdk .ot-optout-signal\n                {\n                    color: " + t + ";\n                }" : "") + "\n            " + (o ? " #onetrust-consent-sdk #onetrust-pc-sdk .privacy-notice-link,\n                    #onetrust-consent-sdk #onetrust-pc-sdk .ot-pgph-link,\n                    #onetrust-consent-sdk #onetrust-pc-sdk .category-vendors-list-handler,\n                    #onetrust-consent-sdk #onetrust-pc-sdk .category-vendors-list-handler + a,\n                    #onetrust-consent-sdk #onetrust-pc-sdk .category-host-list-handler,\n                    #onetrust-consent-sdk #onetrust-pc-sdk " + k.P_Ven_Link + ",\n                    #onetrust-consent-sdk #onetrust-pc-sdk " + k.P_Ven_Leg_Claim + ",\n                    #onetrust-consent-sdk #onetrust-pc-sdk " + k.P_Host_Cntr + " " + k.P_Host_Title + " a,\n                    #onetrust-consent-sdk #onetrust-pc-sdk " + k.P_Host_Cntr + " " + k.P_Acc_Header + " " + k.P_Host_View_Cookies + ",\n                    #onetrust-consent-sdk #onetrust-pc-sdk " + k.P_Host_Cntr + " " + k.P_Host_Info + " a,\n                    #onetrust-consent-sdk #onetrust-pc-sdk " + k.P_Content + " " + k.P_Policy_Txt + " .ot-link-btn,\n                    #onetrust-consent-sdk #onetrust-pc-sdk .ot-vnd-serv .ot-vnd-item .ot-vnd-info a,\n                    #onetrust-consent-sdk #onetrust-pc-sdk #ot-lst-cnt .ot-vnd-info a\n                    {\n                        color: " + o + ";\n                    }" : "") + "\n            #onetrust-consent-sdk #onetrust-pc-sdk .category-vendors-list-handler:hover { text-decoration: underline;}\n            " + (n && r ? "#onetrust-consent-sdk #onetrust-pc-sdk " + k.P_Acc_Container + k.P_Acc_Txt + ",\n            #onetrust-consent-sdk #onetrust-pc-sdk " + k.P_Acc_Txt + " " + k.P_Subgrp_Tgl_Cntr + " .ot-switch.ot-toggle\n             {\n                background-color: " + r + ";\n            }" : "") + "\n            " + (r ? " #onetrust-consent-sdk #onetrust-pc-sdk " + k.P_Host_Cntr + " " + k.P_Host_Info + ",\n                    " + (m.isV2Template ? "#onetrust-consent-sdk #onetrust-pc-sdk " + k.P_Acc_Txt + " .ot-ven-dets" : "#onetrust-consent-sdk #onetrust-pc-sdk " + k.P_Acc_Txt + " " + k.P_Ven_Opts) + "\n                            {\n                                background-color: " + r + ";\n                            }" : "") + "\n        ";
            return (e += Qt.setButonColor()) + Qt.setFocusBorderColor() + Qt.setCloseIconColor() + Qt.setTabLayoutStyles() + Qt.setTabLayoutStyles() + Qt.setFocusIfTemplateUpgrade() + Qt.setExtLnkUrl() + Qt.setCustomCss()
        }, this.addCustomCookieListCSS = function() {
            var e = I.CookiesV2NewCookiePolicy ? "-v2.ot-sdk-cookie-policy" : "",
                e = "\n                " + (I.cookieListPrimaryColor ? "\n                    #ot-sdk-cookie-policy" + e + " h5,\n                    #ot-sdk-cookie-policy" + e + " h6,\n                    #ot-sdk-cookie-policy" + e + " li,\n                    #ot-sdk-cookie-policy" + e + " p,\n                    #ot-sdk-cookie-policy" + e + " a,\n                    #ot-sdk-cookie-policy" + e + " span,\n                    #ot-sdk-cookie-policy" + e + " td,\n                    #ot-sdk-cookie-policy" + e + " #cookie-policy-description {\n                        color: " + I.cookieListPrimaryColor + ";\n                    }" : "") + "\n                    " + (I.cookieListTableHeaderColor ? "#ot-sdk-cookie-policy" + e + " th {\n                        color: " + I.cookieListTableHeaderColor + ";\n                    }" : "") + "\n                    " + (I.cookieListGroupNameColor ? "#ot-sdk-cookie-policy" + e + " .ot-sdk-cookie-policy-group {\n                        color: " + I.cookieListGroupNameColor + ";\n                    }" : "") + "\n                    " + (I.cookieListTitleColor ? "\n                    #ot-sdk-cookie-policy" + e + " #cookie-policy-title {\n                            color: " + I.cookieListTitleColor + ";\n                        }\n                    " : "") + "\n            " + (e && I.CookieListTableHeaderBackgroundColor ? "\n                    #ot-sdk-cookie-policy" + e + " table th {\n                            background-color: " + I.CookieListTableHeaderBackgroundColor + ";\n                        }\n                    " : "") + "\n            ";
            return I.cookieListCustomCss && (e += I.cookieListCustomCss), e
        }
    }
    oo.prototype.getAllowAllButton = function() {
        return T("#onetrust-pc-sdk #accept-recommended-btn-handler")
    }, oo.prototype.getSelectedVendors = function() {
        return T("#onetrust-pc-sdk " + k.P_Tgl_Cntr + " .ot-checkbox input:checked")
    };
    var eo, to = oo;

    function oo() {}
    io.prototype.isIabCookieValid = function() {
        var e = null;
        return null !== (e = A.isIab2orv2Template ? g.getCookie("eupubconsent-v2") : e)
    }, io.prototype.iabTypeIsChanged = function() {
        this.isIabCookieValid() || (g.removeAlertBox(), g.removeIab1())
    }, io.prototype.initializeIABModule = function() {
        return F(this, void 0, void 0, function() {
            return M(this, function(e) {
                switch (e.label) {
                    case 0:
                        return I.IsIabEnabled ? (m.moduleInitializer.otIABModuleData = window.otIabModule, p.setIabData(), [4, p.populateVendorListTCF()]) : [3, 2];
                    case 1:
                        return e.sent(), p.isIABCrossConsentEnabled() || this.iabTypeIsChanged(), p.populateIABCookies(), I.UseGoogleVendors && (I.NewVendorsInactiveEnabled && this.removeATPListVendors(), this.removeInActiveAddtlVendors()), [3, 3];
                    case 2:
                        g.removeIab1(), e.label = 3;
                    case 3:
                        return [2]
                }
            })
        })
    }, io.prototype.removeATPListVendors = function() {
        var e, t, o = m.moduleInitializer.GoogleData.vendorListVersion;
        for (t in L.addtlVendorsList)(null == (e = L.addtlVendorsList[t]) ? void 0 : e.gvlVersion) > o && (L.deletedGoogleVendors[t] = L.addtlVendorsList[t], delete L.addtlVendorsList[t])
    }, io.prototype.removeInActiveAddtlVendors = function() {
        var e, t = I.OverridenGoogleVendors;
        for (e in t) t[e].active || delete L.addtlVendorsList[e]
    }, io.prototype.getIABConsentData = function() {
        var e = L.oneTrustIABConsent,
            t = p.iabStringSDK().tcString(),
            o = (L.tcModel.unsetAllPurposeConsents(), L.tcModel.unsetAllVendorConsents(), L.tcModel.unsetAllVendorLegitimateInterests(), L.tcModel.unsetAllSpecialFeatureOptins(), L.tcModel.unsetAllPurposeLegitimateInterests(), L.tcModel.publisherConsents.empty(), L.tcModel.publisherLegitimateInterests.empty(), L.tcModel.purposeConsents.set(P.getActiveIdArray(e.purpose)), L.tcModel.publisherConsents.set(P.getActiveIdArray(e.purpose)), A.legIntSettings.PAllowLI ? P.getActiveIdArray(e.legimateInterest) : []),
            o = (L.tcModel.purposeLegitimateInterests.set(o), L.tcModel.publisherLegitimateInterests.set(o), L.tcModel.vendorConsents.set(P.getActiveIdArray(P.distinctArray(e.vendors))), A.legIntSettings.PAllowLI && this.shouldSetVendorLegitimateInterest(e) && (e.legIntVendors = []), L.tcModel.vendorLegitimateInterests.set(P.getActiveIdArray(P.distinctArray(e.legIntVendors))), L.tcModel.specialFeatureOptins.set(P.getActiveIdArray(e.specialFeatures)), new Date),
            e = new Date(o.getUTCFullYear(), o.getUTCMonth(), o.getUTCDate(), 0, 0, 0),
            o = (L.tcModel.lastUpdated = e, L.tcModel.created = e, t.encode(L.tcModel));
        return L.cmpApi.update(o, !1), o
    }, io.prototype.shouldSetVendorLegitimateInterest = function(e) {
        return !L.anyVendorHasOnlySplPur && !P.getActiveIdArray(e.legimateInterest)
    }, io.prototype.decodeTCString = function(e) {
        return p.iabStringSDK().tcString().decode(e)
    }, io.prototype.getVendorConsentsRequestV2 = function(e) {
        var o;
        return window.__tcfapi("getInAppTCData", 2, function(e, t) {
            o = [e, t]
        }), e.apply(this, o)
    }, io.prototype.getPingRequestForTcf = function(e) {
        var t;
        return window.__tcfapi("ping", 2, function(e) {
            t = [e]
        }), e.apply(this, t)
    }, io.prototype.populateVendorAndPurposeFromCookieData = function() {
        var n = L.oneTrustIABConsent,
            e = no.decodeTCString(n.IABCookieValue),
            t = b.GroupTypes,
            r = {},
            i = {},
            s = (A.iabGrps.forEach(function(e) {
                e.Type === t.Pur ? r[A.iabGrpIdMap[e.CustomGroupId]] = e : e.Type === t.Spl_Ft && (i[A.iabGrpIdMap[e.CustomGroupId]] = e)
            }), []);
        this.syncVendorConsent(e), s = [], e.vendorLegitimateInterests.forEach(function(e, t) {
            var o = e;
            L.vendorsSetting[t] && L.vendorsSetting[t].legInt || !e || (s.push(t), o = !1), n.legIntVendors.push(t + ":" + o)
        }), e.vendorLegitimateInterests.unset(s), s = [], e.purposeConsents.forEach(function(e, o) {
            var t = e,
                e = (!(r[o] && r[o].HasConsentOptOut) && e && (s.push(o), t = !1), P.findIndex(n.purpose, function(e, t) {
                    return e.split(":")[0] === o.toString()
                })); - 1 === e ? n.purpose.push(o + ":" + t) : n.purpose[e] = o + ":" + t
        }), e.purposeConsents.unset(s), e.publisherConsents.unset(s), s = [], e.specialFeatureOptins.forEach(function(e, o) {
            var t = e,
                e = (!(i[o] && i[o].HasConsentOptOut) && e && (s.push(o), t = !1), P.findIndex(n.specialFeatures, function(e, t) {
                    return e.split(":")[0] === o.toString()
                })); - 1 === e ? n.specialFeatures.push(o + ":" + t) : n.specialFeatures[e] = o + ":" + t
        }), e.specialFeatureOptins.unset(s), this.syncPurAndPubLegInt(e, r), this.syncBundleAndStack(), e.gvl = L.tcModel.gvl, e.isServiceSpecific = !p.isIABCrossConsentEnabled(), L.tcModel = e, p.isAlertBoxClosedAndValid() ? L.cmpApi.update(n.IABCookieValue, !1) : p.resetTCModel()
    }, io.prototype.syncVendorConsent = function(e) {
        var n = [],
            r = [];
        e.vendorConsents.forEach(function(e, t) {
            var o = e;
            L.vendorsSetting[t] && L.vendorsSetting[t].consent || !e || (n.push(t), o = !1), r.push(t + ":" + o)
        }), L.oneTrustIABConsent.vendors = r, e.vendorConsents.unset(n)
    }, io.prototype.syncPurAndPubLegInt = function(e, n) {
        var r = [],
            i = L.oneTrustIABConsent;
        e.purposeLegitimateInterests.forEach(function(e, o) {
            var t = e,
                e = (!(n[o] && n[o].HasLegIntOptOut && A.legIntSettings.PAllowLI) && e && (r.push(o), t = !1), P.findIndex(i.legimateInterest, function(e, t) {
                    return e.split(":")[0] === o.toString()
                })); - 1 === e ? i.legimateInterest.push(o + ":" + t) : i.legimateInterest[e] = o + ":" + t
        }), e.purposeLegitimateInterests.unset(r), e.publisherLegitimateInterests.unset(r)
    }, io.prototype.syncBundleAndStack = function() {
        var e = g.readCookieParam(C.OPTANON_CONSENT, "groups"),
            n = (L.groupsConsent = P.strToArr(e), b.GroupTypes);
        I.Groups.forEach(function(t) {
            var e, o;
            t.Type !== n.Bundle && t.Type !== n.Stack || (o = h.isBundleOrStackActive(t), e = P.findIndex(L.groupsConsent, function(e) {
                return e.split(":")[0] === t.CustomGroupId
            }), o = t.CustomGroupId + ":" + Number(o), -1 < e ? L.groupsConsent[e] = o : L.groupsConsent.push(o))
        }), g.writeCookieParam(C.OPTANON_CONSENT, "groups", L.groupsConsent.join(","))
    }, io.prototype.populateGoogleConsent = function() {
        var e;
        I.UseGoogleVendors && (e = g.getCookie(C.ADDITIONAL_CONSENT_STRING)) && (L.isAddtlConsent = !0, L.addtlVendors.vendorConsent = e.replace(L.addtlConsentVersion, "").split("."))
    }, io.prototype.isInitIABCookieData = function(e) {
        return "init" === e || p.needReconsent()
    }, io.prototype.updateFromGlobalConsent = function(e) {
        var t = L.oneTrustIABConsent;
        t.IABCookieValue = e, t.purpose = t.purpose || [], t.specialFeatures = t.specialFeatures || [], t.legIntVendors = [], t.legimateInterest = t.legimateInterest || [], t.vendors = [], no.populateVendorAndPurposeFromCookieData(), g.setCookie(C.EU_PUB_CONSENT, "", -1)
    };
    var no, ro = io;

    function io() {}
    lo.prototype.loadBanner = function() {
        m.moduleInitializer.ScriptDynamicLoadEnabled ? "complete" === document.readyState ? T(window).trigger("otloadbanner") : window.addEventListener("load", function(e) {
            T(window).trigger("otloadbanner")
        }) : "loading" !== document.readyState ? T(window).trigger("otloadbanner") : window.addEventListener("DOMContentLoaded", function(e) {
            T(window).trigger("otloadbanner")
        }), A.pubDomainData.IsBannerLoaded = !0
    }, lo.prototype.OnConsentChanged = function(e) {
        var t = e.toString();
        so.consentChangedEventMap[t] || (so.consentChangedEventMap[t] = !0, window.addEventListener("consent.onetrust", e))
    }, lo.prototype.triggerGoogleAnalyticsEvent = function(e, t, o, n) {
        var r = !1;
        m.moduleInitializer.GATrackToggle && ("AS" === m.moduleInitializer.GATrackAssignedCategory || "" === m.moduleInitializer.GATrackAssignedCategory || window.OnetrustActiveGroups.includes("," + m.moduleInitializer.GATrackAssignedCategory + ",")) && (r = !0), !A.ignoreGoogleAnlyticsCall && r && (void 0 !== window._gaq && window._gaq.push(["_trackEvent", e, t, o, n]), "function" == typeof window.ga && window.ga("send", "event", e, t, o, n), r = window[A.otDataLayer.name], !A.otDataLayer.ignore) && void 0 !== r && r && r.constructor === Array && ("function" == typeof window.gtag ? window.gtag("event", "trackOptanonEvent", {
            optanonCategory: e,
            optanonAction: t,
            optanonLabel: o,
            optanonValue: n
        }) : r.push({
            event: "trackOptanonEvent",
            optanonCategory: e,
            optanonAction: t,
            optanonLabel: o,
            optanonValue: n
        }))
    }, lo.prototype.setAlertBoxClosed = function(e) {
        var t = (new Date).toISOString(),
            e = (e ? g.setCookie(C.ALERT_BOX_CLOSED, t, I.ReconsentFrequencyDays) : g.setCookie(C.ALERT_BOX_CLOSED, t, 0), T(".onetrust-pc-dark-filter").el[0]);
        e && "none" !== getComputedStyle(e).getPropertyValue("display") && T(".onetrust-pc-dark-filter").fadeOut(400)
    }, lo.prototype.updateConsentFromCookie = function(t) {
        return F(this, void 0, void 0, function() {
            return M(this, function(e) {
                return t ? (no.isInitIABCookieData(t) || no.updateFromGlobalConsent(t), "init" === t && (g.removeIab1(), p.isAlertBoxClosedAndValid() && p.resetTCModel(), g.removeAlertBox())) : (p.resetTCModel(), p.updateCrossConsentCookie(!1), p.setIABCookieData()), so.assetPromise.then(function() {
                    so.loadBanner()
                }), [2]
            })
        })
    };
    var so, ao = lo;

    function lo() {
        var t = this;
        this.consentChangedEventMap = {}, this.assetResolve = null, this.assetPromise = new Promise(function(e) {
            t.assetResolve = e
        })
    }
    var co, uo = "groups",
        po = "hosts",
        Co = "genVendors",
        go = "vs",
        ho = (yo.prototype.writeHstParam = function(e, t) {
            g.writeCookieParam(e, "hosts", P.arrToStr((t = void 0 === t ? null : t) || L.hostsConsent))
        }, yo.prototype.writeGenVenCookieParam = function(e) {
            var t = I.GeneralVendors,
                o = L.genVendorsConsent,
                n = "";
            t.forEach(function(e) {
                n += e.VendorCustomId + ":" + (o[e.VendorCustomId] ? "1" : "0") + ","
            }), g.writeCookieParam(e, "genVendors", n)
        }, yo.prototype.writeVSConsentCookieParam = function(e) {
            var o = "";
            L.vsConsent.forEach(function(e, t) {
                return o += t + ":" + (e ? "1" : "0") + ","
            }), o = o.slice(0, -1), g.writeCookieParam(e, go, o)
        }, yo.prototype.updateGroupsInCookie = function(e, t) {
            g.writeCookieParam(e, "groups", P.arrToStr((t = void 0 === t ? null : t) || L.groupsConsent))
        }, yo.prototype.writeGrpParam = function(e, t) {
            this.updateGroupsInCookie(e, t = void 0 === t ? null : t), I.IsIabEnabled && p.isAlertBoxClosedAndValid() && this.insertOrUpdateIabCookies()
        }, yo.prototype.insertOrUpdateIabCookies = function() {
            var e, t = L.oneTrustIABConsent;
            t.purpose && t.vendors && (L.isAddtlConsent = I.UseGoogleVendors, t.IABCookieValue = no.getIABConsentData(), e = I.ReconsentFrequencyDays, p.isIABCrossConsentEnabled() ? p.setIAB3rdPartyCookie(C.EU_CONSENT, t.IABCookieValue, e, !1) : (g.setCookie(C.EU_PUB_CONSENT, t.IABCookieValue, e), I.UseGoogleVendors && g.setCookie(C.ADDITIONAL_CONSENT_STRING, "" + L.addtlConsentVersion + L.addtlVendors.vendorConsent.join("."), e)))
        }, yo);

    function yo() {}
    mo.prototype.initGenVendorConsent = function() {
        var e, t, n = this;
        I.GenVenOptOut ? (e = A.consentableGrps, (t = g.readCookieParam(C.OPTANON_CONSENT, "genVendors")) ? (L.genVendorsConsent = {}, t.split(",").forEach(function(e) {
            e && "1" === (e = e.split(":"))[1] && (L.genVendorsConsent[e[0]] = !0)
        })) : (L.genVendorsConsent = {}, e.forEach(function(e) {
            var o = L.syncRequired ? y.checkIfGroupHasConsent(e) : y.checkIsActiveByDefault(e);
            e.GeneralVendorsIds && e.GeneralVendorsIds.length && e.GeneralVendorsIds.forEach(function(e) {
                var t = n.isGenVenPartOfAlwaysActiveGroup(e);
                L.genVendorsConsent[e] = t || o
            })
        }))) : (L.genVendorsConsent = {}, co.writeGenVenCookieParam(C.OPTANON_CONSENT))
    }, mo.prototype.populateGenVendorLists = function() {
        A.consentableGrps.forEach(function(e) {
            e.GeneralVendorsIds && (y.isAlwaysActiveGroup(e) ? e.GeneralVendorsIds.forEach(function(e) {
                L.alwaysActiveGenVendors.push(e)
            }) : y.isOptInGrp(e) ? e.GeneralVendorsIds.forEach(function(e) {
                L.optInGenVendors.push(e)
            }) : y.isSoftOptInGrp(e) && e.GeneralVendorsIds.forEach(function(e) {
                L.optInGenVendors.includes(e) || L.softOptInGenVendors.push(e)
            }))
        })
    }, mo.prototype.updateGenVendorStatus = function(e, t) {
        L.genVendorsConsent[e] = t || this.isGenVenPartOfAlwaysActiveGroup(e)
    }, mo.prototype.isGenVenPartOfAlwaysActiveGroup = function(e) {
        return L.alwaysActiveGenVendors.includes(e)
    };
    var fo, So = mo;

    function mo() {}
    Po.prototype.isLandingPage = function() {
        var e = g.readCookieParam(C.OPTANON_CONSENT, "landingPath");
        return !e || e === location.href
    }, Po.prototype.setLandingPathParam = function(e) {
        g.writeCookieParam(C.OPTANON_CONSENT, "landingPath", e)
    };
    var vo, To = Po;

    function Po() {}
    Ao.prototype.synchroniseCookieGroupData = function(e) {
        var n = this,
            t = g.readCookieParam(C.OPTANON_CONSENT, "groups"),
            r = P.strToArr(t),
            i = P.strToArr(t.replace(/:0|:1/g, "")),
            t = p.needReconsent(),
            s = !1,
            a = !1,
            l = b.GroupTypes;
        e.forEach(function(e) {
            var t, o = e.CustomGroupId;
            e.Type !== l.Bundle && e.Type !== l.Stack && (-1 === P.indexOf(i, o) ? (s = !0, t = y.checkIsActiveByDefault(e), a = !0, r.push(o + (t ? ":1" : ":0"))) : (a = n.updateImpliedConsentGroup(e, r, o, a), A.gpcEnabled && e.IsGpcEnabled && A.gpcValueChanged && -1 < (t = r.indexOf(o + ":1")) && (a = !0, L.gpcConsentTxn = !0, r[t] = o + ":0")))
        }), a = this.updateConsentForBundleGrps(e, r, i, a, t), (a = this.removeRedundantGrpsFromCookie(r, t, a)) && (L.fireOnetrustGrp = !0, co.updateGroupsInCookie(C.OPTANON_CONSENT, r), L.syncRequired) && s && g.removeAlertBox()
    }, Ao.prototype.updateImpliedConsentGroup = function(e, t, o, n) {
        return e.Status !== S.INACTIVE_LANDING_PAGE || p.isAlertBoxClosedAndValid() || vo.isLandingPage() || 0 <= (e = t.indexOf(o + ":0")) && (n = !0, t[e] = o + ":1"), n
    }, Ao.prototype.removeRedundantGrpsFromCookie = function(e, o, t) {
        for (var n = e.length, r = t; n--;)(() => {
            var t = e[n].replace(/:0|:1/g, "");
            I.Groups.some(function(e) {
                return (!o || e.Type !== b.GroupTypes.Stack) && (e.CustomGroupId === t || e.SubGroups.some(function(e) {
                    return e.CustomGroupId === t
                }))
            }) || (r = !0, e.splice(n, 1))
        })();
        return r
    }, Ao.prototype.updateConsentForBundleGrps = function(e, r, i, t, s) {
        var a = this,
            l = t,
            c = b.GroupTypes;
        return e.forEach(function(e) {
            var t, o = e.Type === c.Bundle || e.Type === c.Stack,
                n = e.CustomGroupId;
            o && (-1 === P.indexOf(i, n) ? (o = h.isBundleOrStackActive(e, r), l = !0, r.push(n + (o ? ":1" : ":0"))) : s && "false" === p.getIABCrossConsentflagData() || A.gpcEnabled && A.gpcValueChanged || L.syncRequired ? (o = h.isBundleOrStackActive(e, r), -1 < (t = r.indexOf(n + ":" + (o ? "0" : "1"))) && (l = !0, r[t] = n + (o ? ":1" : ":0"))) : l = a.updateImpliedConsentGroup(e, r, n, l))
        }), l
    }, Ao.prototype.groupHasConsent = function(t) {
        var e = P.strToArr(g.readCookieParam(C.OPTANON_CONSENT, "groups")),
            o = P.findIndex(e, function(e) {
                return e.split(":")[0] === t.CustomGroupId
            });
        return -1 < o && "1" === e[o].split(":")[1]
    }, Ao.prototype.synchroniseCookieHostData = function() {
        for (var n = this, e = g.readCookieParam(C.OPTANON_CONSENT, "hosts"), r = P.strToArr(e), i = P.strToArr(e.replace(/:0|:1/g, "")), s = !1, o = (I.Groups.forEach(function(e) {
                U(e.SubGroups, [e]).forEach(function(o) {
                    o.Hosts.length && o.Hosts.forEach(function(e) {
                        var t; - 1 === P.indexOf(i, e.HostId) && (s = !0, t = L.syncRequired ? n.groupHasConsent(o) : y.checkIsActiveByDefault(o), r.push(e.HostId + (t ? ":1" : ":0")))
                    })
                })
            }), r.length); o--;)(() => {
            var t = r[o].replace(/:0|:1/g, "");
            I.Groups.some(function(e) {
                return U(e.SubGroups, [e]).some(function(e) {
                    return e.Hosts.some(function(e) {
                        return e.HostId === t
                    })
                })
            }) || (s = !0, r.splice(o, 1))
        })();
        s && (L.fireOnetrustGrp = !0, co.writeHstParam(C.OPTANON_CONSENT, r))
    }, Ao.prototype.toggleGroupHosts = function(e, t) {
        var o = this;
        e.Hosts.forEach(function(e) {
            o.updateHostStatus(e, t)
        })
    }, Ao.prototype.toggleGroupGenVendors = function(e, t) {
        e.GeneralVendorsIds.forEach(function(e) {
            fo.updateGenVendorStatus(e, t)
        })
    }, Ao.prototype.updateHostStatus = function(t, e) {
        var o = P.findIndex(L.hostsConsent, function(e) {
            return !t.isActive && t.HostId === e.replace(/:0|:1/g, "")
        }); - 1 < o && (e = e || this.isHostPartOfAlwaysActiveGroup(t.HostId), L.hostsConsent[o] = t.HostId + ":" + (e ? "1" : "0"))
    }, Ao.prototype.isHostPartOfAlwaysActiveGroup = function(e) {
        return L.oneTrustAlwaysActiveHosts.includes(e)
    };
    var ko, bo = Ao;

    function Ao() {}
    var Io, Lo = "OneTrust Cookie Consent",
        _o = "Banner Auto Close",
        Eo = "Banner Close Button",
        Oo = "Banner - Continue without Accepting",
        Vo = "Banner - Confirm",
        Do = "Preferences Close Button",
        No = "Preference Center Opened From Banner",
        wo = "Preference Center Opened From Button",
        Go = "Preference Center Opened From Function",
        Bo = "Preferences Save Settings",
        xo = "Vendors List Opened From Function",
        Ho = "Floating Cookie Settings Open Button",
        Ro = "Floating Cookie Settings Close Button",
        Fo = "Preferences Toggle On",
        Mo = "Preferences Toggle Off",
        Uo = "General Vendor Toggle On",
        qo = "General Vendor Toggle Off",
        jo = "Host Toggle On",
        Ko = "Host Toggle Off",
        zo = "Preferences Legitimate Interest Objection",
        Wo = "Preferences Legitimate Interest Remove Objection",
        Yo = "IAB Vendor Toggle ON",
        Jo = "IAB Vendor Toggle Off",
        Xo = "IAB Vendor Legitimate Interest Objection",
        Qo = "IAB Vendor Legitimate Interest Remove Objection",
        Zo = "Vendor Service Toggle On",
        $o = "Vendor Service Toggle Off",
        en = (tn.prototype.setBannerFocus = function() {
            var e = this,
                t = Array.prototype.slice.call(T("#onetrust-banner-sdk .onetrust-vendors-list-handler").el),
                o = Array.prototype.slice.call(T('#onetrust-banner-sdk #onetrust-policy-text [href],#onetrust-banner-sdk #onetrust-policy-text button,#onetrust-banner-sdk #onetrust-policy-text [tabindex]:not([tabindex="-1"])').el),
                n = Array.prototype.slice.call(T("#onetrust-banner-sdk .ot-bnr-save-handler").el),
                r = Array.prototype.slice.call(T("#onetrust-banner-sdk #onetrust-pc-btn-handler").el),
                i = Array.prototype.concat.call(Array.prototype.slice.call(T("#onetrust-banner-sdk .category-switch-handler:not([disabled])").el), Array.prototype.slice.call(T("#onetrust-banner-sdk .ot-cat-lst button").el), t),
                i = Array.prototype.concat.call(o, i),
                s = Array.prototype.slice.call(T("#onetrust-banner-sdk .onetrust-close-btn-handler").el),
                t = (A.bannerName === Xe && (i = Array.prototype.concat.call(t, o)), Array.prototype.slice.call(T("#onetrust-banner-sdk #onetrust-accept-btn-handler").el)),
                o = Array.prototype.slice.call(T("#onetrust-banner-sdk #onetrust-reject-all-handler").el),
                n = Array.prototype.concat.call(n, t, o, r),
                r = ((A.bannerName !== Ye || I.IsIabEnabled) && A.bannerName !== We && A.bannerName !== Ze || (n = Array.prototype.concat.call(r, o, t)), Array.prototype.slice.call(T("#onetrust-banner-sdk .ot-gv-list-handler").el)),
                o = (A.bannerName === $e ? (i = Array.prototype.concat.call(r, i), n = Array.prototype.slice.call(T("#onetrust-banner-sdk #onetrust-button-group button").el)) : i = Array.prototype.concat.call(i, r), T("#onetrust-banner-sdk .ot-b-addl-desc").el[0]),
                t = this.getTabbableElements(o),
                i = I.BannerAdditionalDescPlacement === le.AfterTitle ? Array.prototype.concat.call(t, i) : Array.prototype.concat.call(i, t),
                r = new Set(Array.prototype.concat.call(Array.prototype.slice.call(T("#onetrust-banner-sdk #onetrust-cookie-btn").el), i, Array.prototype.slice.call(T("#onetrust-banner-sdk .banner-option-input").el), n, Array.prototype.slice.call(T("#onetrust-banner-sdk .ot-bnr-footer-logo a").el), s));
            this.bannerEl = Array.from(r), this.banner = T("#onetrust-banner-sdk").el[0], (I.BInitialFocus || I.BInitialFocusLinkAndButton || I.ForceConsent) && (I.BInitialFocus ? setTimeout(function() {
                e.banner.focus()
            }, 1e3) : setTimeout(function() {
                e.bannerEl[0].focus()
            }, 1e3))
        }, tn.prototype.handleBannerFocus = function(e, t) {
            var o = e.target,
                n = Io.bannerEl,
                r = n.indexOf(o),
                i = n.length - 1,
                s = null;
            if (this.handleBannerFocusBodyReset(t, r, i)) h.resetFocusToBody();
            else if (this.banner === o) s = this.handleInitialBannerFocus(t, n, i, s);
            else
                for (; !s;) {
                    var a = void 0;
                    0 !== (a = t ? r <= 0 ? n[i] : n[r - 1] : r === i ? n[0] : n[r + 1]).clientHeight || 0 !== a.offsetHeight ? s = a : t ? r-- : r++
                }
            s && (e.preventDefault(), s.focus())
        }, tn.prototype.handleBannerFocusBodyReset = function(e, t, o) {
            return !(I.ForceConsent || !I.BInitialFocus && !I.BInitialFocusLinkAndButton || !(e && 0 === t || !e && t === o))
        }, tn.prototype.handleInitialBannerFocus = function(e, t, o, n) {
            return e && I.ForceConsent ? n = t[o] : e || (n = t[0]), n
        }, tn.prototype.setPCFocus = function(e) {
            if (e && !(e.length <= 0)) {
                for (var t = 0; t < e.length; t++) e[t].setAttribute("tabindex", "0");
                this.setFirstAndLast(e);
                this.firstItem ? this.firstItem.focus({
                    preventScroll: !0
                }) : e[0].focus(), this.firstItem && T(this.firstItem).on("keydown", Io.firstItemHandler), this.lastItem && T(this.lastItem).on("keydown", Io.lastItemHandler)
            }
        }, tn.prototype.setFirstAndLast = function(e) {
            this.firstItem = this.getElementForFocus(e, 0, !0), this.lastItem = this.firstItem ? this.getElementForFocus(e, e.length - 1, !1) : null
        }, tn.prototype.setLastItem = function() {
            var e = this.getPCElements(),
                e = this.getElementForFocus(e, e.length - 1, !1);
            e !== this.lastItem && (T(this.lastItem).off("keydown", Io.lastItemHandler), this.lastItem = e, T(e).on("keydown", Io.lastItemHandler))
        }, tn.prototype.getPCElements = function() {
            var e = "#onetrust-pc-sdk #close-pc-btn-handler,\n            #onetrust-pc-sdk .back-btn-handler,\n            #onetrust-pc-sdk ." + k.P_Active_Menu + ',\n            #onetrust-pc-sdk input,\n            #onetrust-pc-sdk a,\n            #onetrust-pc-sdk [tabindex="0"] button,\n            #onetrust-pc-sdk .save-preference-btn-handler,\n            #onetrust-pc-sdk .ot-pc-refuse-all-handler,\n            #onetrust-pc-sdk #accept-recommended-btn-handler';
            return L.pcLayer === se.CookieList ? e += " ,#onetrust-pc-sdk " + k.P_Content + " .powered-by-logo" : e += ",#onetrust-pc-sdk #vendor-list-save-btn .powered-by-logo", Array.prototype.slice.call(T(e).el)
        }, tn.prototype.getActiveTab = function() {
            return document.querySelector('#onetrust-pc-sdk .category-menu-switch-handler[tabindex="0"]')
        }, tn.prototype.getElementForFocus = function(e, t, o) {
            for (var n = e[t]; o ? n && null === n.offsetParent && t < e.length - 1 : n && null === n.offsetParent && 0 < t;) n = e[t], o ? ++t : --t;
            return n
        }, tn.prototype.handleFocusTabLayoutExceptClosePC = function(e) {
            var t = "close-pc-btn-handler" === e.target.id && (13 === e.keyCode || 32 === e.keyCode || "Enter" === e.code || "Space" === e.code);
            I.PCLayout.Tab && L.pcLayer === se.PrefCenterHome && !t && (t = Io.getActiveTab()) && (e.preventDefault(), t.focus())
        }, tn.prototype.firstItemHandler = function(e) {
            var t = document.getElementById("onetrust-banner-sdk");
            9 === e.keyCode && e.shiftKey && Io.firstItem !== t ? (e.preventDefault(), Io.lastItem.focus()) : I.ShowPreferenceCenterCloseButton ? Io.handleFocusTabLayoutExceptClosePC(e) : !I.PCLayout.Tab || L.pcLayer !== se.PrefCenterHome || 37 !== e.keyCode && 39 !== e.keyCode || (t = Io.getActiveTab()) && T(t).on("keydown", Io.firstItemHandler)
        }, tn.prototype.lastItemHandler = function(e) {
            9 !== e.keyCode || e.shiftKey || (e.preventDefault(), e = L.pcLayer === se.VendorList || L.pcLayer === se.CookieList, (I.PCLayout.Tab && L.isPCVisible && !I.ShowPreferenceCenterCloseButton && !e ? Io.getActiveTab() : Io.firstItem).focus())
        }, tn.prototype.getTabbableElements = function(e) {
            return e ? Array.from(e.querySelectorAll(["a[href]", "area[href]", "input:not([disabled])", "select:not([disabled])", "textarea:not([disabled])", "button:not([disabled])", '[tabindex]:not([tabindex="-1"])', "[contenteditable]"].join(","))).filter(function(e) {
                return !e.hasAttribute("disabled")
            }) : []
        }, tn);

    function tn() {
        this.bannerEl = []
    }
    nn.prototype.getAllGroupElements = function() {
        return document.querySelectorAll("div#onetrust-pc-sdk " + k.P_Category_Grp + " " + k.P_Category_Item + ":not(.ot-vnd-item)")
    }, nn.prototype.toggleGrpElements = function(e, t, o, n) {
        void 0 === n && (n = !1);
        for (var r = (e = A.pcName === it && I.PCTemplateUpgrade ? document.querySelector("#ot-desc-id-" + e.getAttribute("data-optanongroupid")) : e).querySelectorAll('input[class*="category-switch-handler"]'), i = 0; i < r.length; i++) {
            var s = r[i].getAttribute("id").includes("leg-out");
            n && s || (P.setCheckedAttribute(null, r[i], o), r[i] && I.PCShowConsentLabels && (r[i].parentElement.parentElement.querySelector(".ot-label-status").innerHTML = v.getInnerHtmlContent(o ? I.PCActiveText : I.PCInactiveText)))
        }
        A.legIntSettings.PAllowLI && A.legIntSettings.PShowLegIntBtn && t.Type === b.GroupTypes.Pur && t.HasLegIntOptOut && !n && f.updateLegIntBtnElement(e.querySelector(".ot-leg-btn-container"), o)
    }, nn.prototype.toogleAllSubGrpElements = function(e, t) {
        var o;
        e.ShowSubgroup ? (o = e.CustomGroupId, o = this.getGroupElementByOptanonGroupId(o.toString()), f.toogleSubGroupElement(o, t, e.IsLegIntToggle)) : this.updateHiddenSubGroupData(e, t)
    }, nn.prototype.isSubGrpLegIntEnabled = function(e, t) {
        return A.legIntSettings.PAllowLI && A.legIntSettings.PShowLegIntBtn && e.Type === b.GroupTypes.Pur && e.HasLegIntOptOut && t.ShowSubgroupToggle
    }, nn.prototype.toogleSubGroupElement = function(e, t, o, n) {
        void 0 === o && (o = !1), void 0 === n && (n = !1);
        for (var r = (e = A.pcName === it && I.PCTemplateUpgrade ? document.querySelector("#ot-desc-id-" + e.getAttribute("data-optanongroupid")) : e).querySelectorAll("li" + k.P_Subgrp_li), i = 0; i < r.length; i++) {
            var s = y.getGroupById(r[i].getAttribute("data-optanongroupid")),
                a = s.OptanonGroupId,
                l = y.getParentGroup(s.Parent),
                l = (this.isSubGrpLegIntEnabled(s, l) && o && f.updateLegIntBtnElement(r[i], t), o ? "[id='ot-sub-group-id-" + a + "-leg-out']" : "[id='ot-sub-group-id-" + a + "']"),
                a = r[i].querySelector('input[class*="cookie-subgroup-handler"]' + l);
            P.setCheckedAttribute(null, a, t), a && I.PCShowConsentLabels && (a.parentElement.parentElement.querySelector(".ot-label-status").innerHTML = v.getInnerHtmlContent(t ? I.PCActiveText : I.PCInactiveText)), n || (s.IsLegIntToggle = o, f.toggleGrpStatus(s, t), s.IsLegIntToggle = !1, ko.toggleGroupHosts(s, t), L.genVenOptOutEnabled && ko.toggleGroupGenVendors(s, t))
        }
    }, nn.prototype.toggleGrpStatus = function(e, t) {
        var o = e.IsLegIntToggle && e.Type === b.GroupTypes.Pur ? t ? Wo : zo : t ? Fo : Mo;
        so.triggerGoogleAnalyticsEvent(Lo, o, e.GroupName + ": " + e.OptanonGroupId), t ? this.updateEnabledGroupData(e) : this.updateDisabledGroupData(e)
    }, nn.prototype.setInputID = function(e, t, o, n, r) {
        T(e).attr("id", t), T(e).attr("name", t), T(e).data("optanonGroupId", o), P.setCheckedAttribute(null, e, n), T(e).attr("aria-labelledby", r)
    }, nn.prototype.updateEnabledGroupData = function(e) {
        var t, o; - 1 < Pt.indexOf(e.Type) ? this.updateIabGroupData(e, !0) : (t = f.getGroupVariable(), -1 !== (o = P.indexOf(t, e.CustomGroupId + ":0")) && (t[o] = e.CustomGroupId + ":1"))
    }, nn.prototype.updateDisabledGroupData = function(e) {
        var t, o; - 1 < Pt.indexOf(e.Type) ? this.updateIabGroupData(e, !1) : e.Status !== S.ALWAYS_ACTIVE && (t = f.getGroupVariable(), -1 !== (o = P.indexOf(t, e.CustomGroupId + ":1")) && (t[o] = e.CustomGroupId + ":0"), this.isImplicitConsentDefaultStatus(e)) && A.removeGroupFromImpliedConsentableGroup(e)
    }, nn.prototype.updateIabGroupData = function(e, t) {
        var o;
        e.Type === b.GroupTypes.Spl_Ft ? this.updateIabSpecialFeatureData(e.IabGrpId, t) : (o = e.IsLegIntToggle ? L.vendors.selectedLegInt : L.vendors.selectedPurpose, this.updateIabPurposeData(e.IabGrpId, t, o))
    }, nn.prototype.isAllSubgroupsDisabled = function(e) {
        return !e.SubGroups.some(function(e) {
            return f.isGroupActive(e)
        })
    }, nn.prototype.isAllSubgroupsEnabled = function(e) {
        return !e.SubGroups.some(function(e) {
            return f.IsGroupInActive(e)
        })
    }, nn.prototype.toggleGroupHtmlElement = function(e, t, o) {
        A.legIntSettings.PAllowLI && A.legIntSettings.PShowLegIntBtn && e.Type === b.GroupTypes.Pur && e.HasLegIntOptOut && (e = document.querySelector("[data-el-id=" + t + "]")) && this.updateLegIntBtnElement(e, o);
        e = T("#ot-group-id-" + t).el[0];
        P.setCheckedAttribute(null, e, o), e && I.PCShowConsentLabels && (e.parentElement.querySelector(".ot-label-status").innerHTML = v.getInnerHtmlContent(o ? I.PCActiveText : I.PCInactiveText))
    }, nn.prototype.updateLegIntBtnElement = function(e, t) {
        var o = A.legIntSettings,
            n = e.querySelector(".ot-obj-leg-btn-handler"),
            e = e.querySelector(".ot-remove-objection-handler");
        t ? (n.classList.add("ot-inactive-leg-btn"), n.classList.add("ot-leg-int-enabled"), n.classList.remove("ot-active-leg-btn"), n.focus()) : (n.classList.add("ot-active-leg-btn"), n.classList.remove("ot-inactive-leg-btn"), n.classList.remove("ot-leg-int-enabled")), n.querySelector("span").innerText = t ? o.PObjectLegIntText : o.PObjectionAppliedText, d(e, "display: " + (t ? "none" : "inline-block") + ";", !0)
    }, nn.prototype.isGroupActive = function(e) {
        e = -1 < Pt.indexOf(e.Type) ? -1 !== this.isIabPurposeActive(e) : -1 !== v.inArray(e.CustomGroupId + ":1", f.getGroupVariable()) || this.isGroupEnabledForImplicitConsent(e);
        return e
    }, nn.prototype.isGroupEnabledForImplicitConsent = function(e) {
        return this.isImplicitConsentDefaultStatus(e) && A.isGroupExistInImpliedConsentableGroup(e)
    }, nn.prototype.isImplicitConsentDefaultStatus = function(e) {
        return e.Status === S.INACTIVE_LANDING_PAGE && !p.isAlertBoxClosedAndValid() && vo.isLandingPage()
    }, nn.prototype.safeFormattedGroupDescription = function(e) {
        return e && e.GroupDescription ? e.GroupDescription.replace(/\r\n/g, "<br>") : ""
    }, nn.prototype.canInsertForGroup = function(e, t) {
        void 0 === t && (t = !1);
        var o = null != e && void 0 !== e,
            n = g.readCookieParam(C.OPTANON_CONSENT, "groups"),
            r = L.groupsConsent.join(","),
            i = g.readCookieParam(C.OPTANON_CONSENT, "hosts"),
            s = L.hostsConsent.join(",");
        if (t) return !0;
        n === r && i === s || N.ensureHtmlGroupDataInitialised();
        var a = [];
        if (L.showGeneralVendors)
            for (var l = 0, c = Object.entries(L.genVendorsConsent); l < c.length; l++) {
                var d = c[l],
                    u = d[0];
                a.push(u + ":" + (d[1] ? "1" : "0"))
            }
        L.showVendorService && L.vsConsent.forEach(function(e, t) {
            a.push(t + ":" + (e ? "1" : "0"))
        });
        t = L.groupsConsent.concat(L.hostsConsent).concat(a), n = P.contains(t, e + ":1"), r = this.doesHostExist(e), i = this.doesGroupExist(e), s = !1, L.showGeneralVendors ? s = this.doesGenVendorExist(e) : L.showVendorService && (s = this.doesVendorServiceExist(e)), t = !(!r && !s) || n && N.canSoftOptInInsertForGroup(e);
        return !(!o || !(n && t || !i && !r && !s))
    }, nn.prototype.setAllowAllButton = function() {
        var t = 0,
            e = I.Groups.some(function(e) {
                if (-1 === kt.indexOf(e.Type)) return f.IsGroupInActive(e) && t++, e.SubGroups.some(function(e) {
                    return f.IsGroupInActive(e)
                }) && t++, 1 <= t
            }),
            o = eo.getAllowAllButton();
        return e ? o.show("inline-block") : o.hide(), Io.lastItem && Io.setLastItem(), e
    }, nn.prototype.isAnyGroupOptedOut = function() {
        for (var e = !1, t = 0, o = I.Groups; t < o.length; t++) {
            var n = o[t];
            if (!0 === f.IsGroupInActive(n)) {
                e = !0;
                break
            }
        }
        return e
    }, nn.prototype.getGroupVariable = function() {
        return L.groupsConsent
    }, nn.prototype.IsGroupInActive = function(e) {
        e = -1 < Pt.indexOf(e.Type) ? -1 === this.isIabPurposeActive(e) : !(-1 < kt.indexOf(e.Type)) && -1 === v.inArray(e.CustomGroupId + ":1", f.getGroupVariable());
        return e
    }, nn.prototype.updateIabPurposeData = function(t, e, o) {
        var n = P.findIndex(o, function(e) {
            return e.split(":")[0] === t
        });
        o[-1 === n ? Number(t) : n] = t + ":" + e
    }, nn.prototype.updateIabSpecialFeatureData = function(t, e) {
        var o = -1 === (o = P.findIndex(L.vendors.selectedSpecialFeatures, function(e) {
            return e.split(":")[0] === t
        })) ? Number(t) : o;
        L.vendors.selectedSpecialFeatures[o] = t + ":" + e
    }, nn.prototype.getGroupElementByOptanonGroupId = function(e) {
        return document.querySelector("#onetrust-pc-sdk " + k.P_Category_Grp + " " + k.P_Category_Item + '[data-optanongroupid=\n            "' + e + '"]')
    }, nn.prototype.updateHiddenSubGroupData = function(e, t) {
        e.SubGroups.forEach(function(e) {
            f.toggleGrpStatus(e, t), ko.toggleGroupHosts(e, t), L.genVenOptOutEnabled && ko.toggleGroupGenVendors(e, t)
        })
    }, nn.prototype.isIabPurposeActive = function(e) {
        var t = e.Type === b.GroupTypes.Spl_Ft ? L.vendors.selectedSpecialFeatures : e.IsLegIntToggle ? L.vendors.selectedLegInt : L.vendors.selectedPurpose;
        return v.inArray(e.IabGrpId + ":true", t)
    }, nn.prototype.doesGroupExist = function(e) {
        return !!y.getGroupById(e)
    }, nn.prototype.doesHostExist = function(e) {
        var t = L.hostsConsent;
        return -1 !== t.indexOf(e + ":0") || -1 !== t.indexOf(e + ":1")
    }, nn.prototype.doesGenVendorExist = function(t) {
        return !!I.GeneralVendors && !!I.GeneralVendors.find(function(e) {
            return e.VendorCustomId === t
        })
    }, nn.prototype.doesVendorServiceExist = function(e) {
        return L.getVendorsInDomain().has(e)
    };
    var f, on = nn;

    function nn() {}
    var rn, sn, an = "#onetrust-banner-sdk",
        ln = ".banner_logo",
        cn = "#onetrust-pc-sdk",
        dn = (un.prototype.BannerPushDownHandler = function() {
            this.checkIsBrowserIE11OrBelow() || (sn.pushPageDown(an), T(window).on("resize", function() {
                "none" !== T(an).css("display") && sn.pushPageDown(an)
            }))
        }, un.prototype.checkIsBrowserIE11OrBelow = function() {
            var e = window.navigator.userAgent;
            return 0 < e.indexOf("MSIE ") || 0 < e.indexOf("Trident/")
        }, un.prototype.addOTCssPropertiesToBody = function(e, t) {
            var o = sn.getCssData(e, t);
            L.customerStyles.set(e, o), sn.setStylesOnBody(t)
        }, un.prototype.removeAddedOTCssStyles = function(e) {
            void 0 === e && (e = rn.Banner);
            var t = L.customerStyles.get(e);
            t ? (sn.setStylesOnBody(t.customerBodyCSS), sn.setStylesOnHtml(t.customerHtmlCSS), L.customerStyles.delete(e)) : 0 < L.customerStyles.size && L.customerStyles.forEach(function(e, t) {
                return sn.removeAddedOTCssStyles(t)
            })
        }, un.prototype.getCssData = function(e, t) {
            var o, n, r = T("body").el[0],
                i = T("html").el[0],
                s = {},
                a = {},
                e = L.customerStyles.get(e),
                a = e ? (o = e.scriptBodyCSS, n = e.customerBodyCSS, e = e.customerHtmlCSS, r.style.top !== o.top && (n.top = r.style.top), r.style.position !== o.position && (n.position = r.style.position), r.style.overflow !== o.overflow && (n.overflow = r.style.overflow), i.style.overflow !== o.overflow && (e.overflow = i.style.overflow), s = n, e) : (s = {
                    top: r.style.top,
                    position: r.style.position,
                    overflow: r.style.overflow
                }, {
                    overflow: i.style.overflow
                });
            return {
                scriptBodyCSS: t,
                customerBodyCSS: s,
                customerHtmlCSS: a
            }
        }, un.prototype.setStylesOnBody = function(e) {
            var t = T("body").el[0];
            sn.setStylesOnHtmlElement(t, e)
        }, un.prototype.setStylesOnHtml = function(e) {
            var t = T("html").el[0];
            sn.setStylesOnHtmlElement(t, {
                overflow: e.overflow
            })
        }, un.prototype.setStylesOnHtmlElement = function(e, t) {
            for (var o = "", n = 0, r = Object.entries(t); n < r.length; n++) {
                var i = r[n],
                    s = i[0],
                    i = i[1];
                i ? o += s + ": " + i + ";" : e.style.removeProperty(s)
            }
            o && d(e, o, !0)
        }, un.prototype.pushPageDown = function(e) {
            var t = T(e).height() + "px",
                e = (T(e).show().css("\n            bottom: auto;\n            position: absolute;\n            top: -" + t + ";\n        "), L.isPCVisible ? rn.PC : rn.Banner),
                t = {
                    position: "relative",
                    top: t
                };
            L.isPCVisible && (t.overflow = "hidden"), sn.addOTCssPropertiesToBody(e, t)
        }, un);

    function un() {}(s = rn = rn || {}).Banner = "Banner", s.PC = "PC", gn.prototype.showConsentNotice = function() {
        var e, t, o;
        !I.NoBanner || I.ForceConsent ? T(".onetrust-pc-dark-filter").removeClass("ot-hide") : T(".onetrust-pc-dark-filter").addClass("ot-hide"), T("" + pn.ONETRUST_PC_SDK).removeClass("ot-hide"), m.isV2Template && this.closePCText(!0), A.pcName === nt && (T("" + pn.ONETRUST_PC_SDK).el[0].classList.contains("ot-animated") || T("" + pn.ONETRUST_PC_SDK).addClass("ot-animated"), e = I.PreferenceCenterPosition, t = (o = I.useRTL) ? "right" : "left", o = o ? "left" : "right", T("" + pn.ONETRUST_PC_SDK).el[0].classList.contains("ot-slide-out-" + ("right" === e ? o : t)) && T("" + pn.ONETRUST_PC_SDK).removeClass("ot-slide-out-" + ("right" === e ? o : t)), T("" + pn.ONETRUST_PC_SDK).addClass("ot-slide-in-" + ("right" === e ? o : t))), f.setAllowAllButton(), Io.setPCFocus(Io.getPCElements()), I.NoBanner && I.ScrollCloseBanner || this.pcHasScroll(), this.handleBodyStylesForBannerPushdown()
    }, gn.prototype.hideConsentNoticeV2 = function() {
        var e, t, o;
        0 === T(this.ONETRUST_PC_SDK).length ? this.setFocusOnPage() : (m.isV2Template && this.closePCText(), I.ForceConsent && !h.isCookiePolicyPage(I.AlertNoticeText) && !p.isAlertBoxClosedAndValid() && I.ShowAlertNotice ? T("" + this.ONETRUST_PC_DARK_FILTER).css("z-index: 2147483645;").show() : T("" + this.ONETRUST_PC_DARK_FILTER).fadeOut(I.PCLayout.Panel ? 500 : 400), I.PCLayout.Panel && (e = I.PreferenceCenterPosition, t = (o = I.useRTL) ? "right" : "left", o = o ? "left" : "right", T("" + this.ONETRUST_PC_SDK).removeClass("ot-slide-in-" + ("right" === e ? o : t)), T("" + this.ONETRUST_PC_SDK).addClass("ot-slide-out-" + ("right" === e ? o : t))), T("" + this.ONETRUST_PC_SDK).fadeOut(I.PCLayout.Panel ? 500 : 400), L.isPCVisible = !1, L.pcLayer = se.Banner, this.setFocus())
    }, gn.prototype.setFocus = function() {
        var e;
        L.pcSource || p.isAlertBoxClosedAndValid() ? L.pcSource ? (L.pcSource.focus(), L.pcSource = null) : this.setFocusOnPage() : (e = T("#onetrust-banner-sdk #onetrust-pc-btn-handler").el[0]) && e.focus()
    }, gn.prototype.handleBodyStylesForBannerPushdown = function() {
        A.pcName === it && A.pagePushedDown && "top" === I.BannerPosition && sn.addOTCssPropertiesToBody(rn.PC, {})
    }, gn.prototype.setFocusOnPage = function() {
        var e = document.querySelectorAll('button, a, input, select, textarea, [tabindex]:not([tabindex="-1"])');
        L.isKeyboardUser && e.length && e[0].focus()
    }, gn.prototype.closePCText = function(e) {
        void 0 === e && (e = !1);
        var t = document.querySelector("#onetrust-pc-sdk span[aria-live]"),
            o = I.AboutCookiesText;
        t && (t.innerText = e ? "" : o + (" " + I.pcDialogClose))
    }, gn.prototype.pcHasScroll = function() {
        this.bodyStyleChanged = !0;
        var e = T("body");
        e && e.length && sn.addOTCssPropertiesToBody(rn.PC, {
            overflow: "hidden"
        })
    }, gn.prototype.checkIfPcSdkContainerExist = function() {
        return !T("" + pn.ONETRUST_PC_SDK).length
    };
    var pn, Cn = gn;

    function gn() {
        this.ONETRUST_PC_SDK = "#onetrust-pc-sdk", this.ONETRUST_PC_DARK_FILTER = ".onetrust-pc-dark-filter", this.bodyStyleChanged = !1
    }
    fn.prototype.updateGtmMacros = function(e) {
        void 0 === e && (e = !0);
        var n = [];
        L.groupsConsent.forEach(function(e) {
            var t = e.replace(":1", ""),
                o = y.getGrpStatus(y.getGroupById(t)).toLowerCase() === S.ALWAYS_ACTIVE;
            P.endsWith(e, ":1") && (N.canSoftOptInInsertForGroup(t) || o) && n.push(t)
        }), L.hostsConsent.forEach(function(e) {
            P.endsWith(e, ":1") && n.push(e.replace(":1", ""))
        }), L.showGeneralVendors && I.GenVenOptOut && I.GeneralVendors.forEach(function(e) {
            !L.genVendorsConsent[e.VendorCustomId] || L.softOptInGenVendors.includes(e.VendorCustomId) && vo.isLandingPage() || n.push(e.VendorCustomId)
        });
        L.vsIsActiveAndOptOut && L.getVendorsInDomain().forEach(function(e) {
            L.vsConsent.get(e.CustomVendorServiceId) && n.push(e.CustomVendorServiceId)
        });
        var t = "," + P.arrToStr(n) + ",",
            o = this.includeAllActiveIABData();
        I.GoogleConsent.GCEnable && !A.otDataLayer.ignore && this.updateGCMTags(U(n, o)), I.MCMData && I.MCMData.Enabled && this.updateMCMTags(U(n, o)), window.OnetrustActiveGroups = t, window.OptanonActiveGroups = t, A.gcmUpdateCallback && A.gcmUpdateCallback(), A.otDataLayer.ignore || void 0 === this._window[A.otDataLayer.name] || this._window[A.otDataLayer.name].constructor !== Array ? !A.otDataLayer.ignore && A.otDataLayer.name && (this._window[A.otDataLayer.name] = [{
            event: "OneTrustLoaded",
            OnetrustActiveGroups: t
        }, {
            event: "OptanonLoaded",
            OptanonActiveGroups: t
        }]) : (this._window[A.otDataLayer.name].push({
            event: "OneTrustLoaded",
            OnetrustActiveGroups: t
        }), this._window[A.otDataLayer.name].push({
            event: "OptanonLoaded",
            OptanonActiveGroups: t
        })), this.dispatchEvents(e, n, t)
    }, fn.prototype.includeAllActiveIABData = function() {
        try {
            for (var n = [], e = 0, t = ["purpose", "features", "specialFeatures", "specialPurposes"]; e < t.length; e++)(o => {
                var t, e = L.oneTrustIABConsent[o];
                "purpose" === o || "specialFeatures" === o ? e.forEach(function(e) {
                    var t = "purpose" === o ? "IAB2V2" : "ISF2V2",
                        e = e.split(":");
                    "true" === e[1] && n.push(t + "_" + e[0])
                }) : (t = [], e.forEach(function(e) {
                    e.value && t.push(e.groupId.toString())
                }), n = U(n, t))
            })(t[e]);
            return n
        } catch (e) {
            return []
        }
    }, fn.prototype.dispatchEvents = function(e, t, o) {
        !e && A.gtmUpdatedinStub || (n = new CustomEvent("consent.onetrust", {
            detail: t
        }));
        var n, r, i = g.readCookieParam(C.OPTANON_CONSENT, "groups"),
            s = L.fireOnetrustGrp || !i || e || !A.gtmUpdatedinStub;
        s && (L.fireOnetrustGrp = !1, !A.otDataLayer.ignore && this._window[A.otDataLayer.name] && this._window[A.otDataLayer.name].constructor === Array && this._window[A.otDataLayer.name].push({
            event: "OneTrustGroupsUpdated",
            OnetrustActiveGroups: o
        }), r = new CustomEvent("OneTrustGroupsUpdated", {
            detail: t
        })), setTimeout(function() {
            n && s && window.dispatchEvent(n), r && window.dispatchEvent(r)
        })
    }, fn.prototype.isCategoryMapped = function(e) {
        return e !== lt && "" !== e
    }, fn.prototype.updateGCMTags = function(o) {
        var n, r = this,
            i = {},
            e = (this.canUpdateGCMCategories() && (e = [
                [I.GoogleConsent.GCAdStorage, Ae.ad_storage],
                [I.GoogleConsent.GCAnalyticsStorage, Ae.analytics_storage],
                [I.GoogleConsent.GCFunctionalityStorage, Ae.functionality_storage],
                [I.GoogleConsent.GCPersonalizationStorage, Ae.personalization_storage],
                [I.GoogleConsent.GCSecurityStorage, Ae.security_storage]
            ], m.fp.CookieV2GCMDMA && (e.push([I.GoogleConsent.GCAdUserData, Ae.ad_user_data]), e.push([I.GoogleConsent.GCAdPersonalization, Ae.ad_personalization])), e.forEach(function(e) {
                var t;
                r.isCategoryMapped(e[0]) && (t = o.includes(e[0]) ? Ie.granted : Ie.denied, i[e[1]] = t)
            })), g.getCookie(C.ALERT_BOX_CLOSED)),
            t = A.getRegionRule().Global;
        "function" != typeof window.gtag && (n = this._window, window.gtag = function(e, t, o) {
            A.otDataLayer.ignore || (n[A.otDataLayer.name] ? n[A.otDataLayer.name].push(arguments) : n[A.otDataLayer.name] = [arguments])
        }), "function" == typeof window.gtag && (A.gcmDevIdSet || (window.gtag(ke.set, "developer_id.dYWJhMj", !0), A.gcmDevIdSet = !0), e) && (t || (i[Ae.region] = A.gcmCountries), 0 !== Object.keys(i).length) && window.gtag(ke.consent, be.update, i)
    }, fn.prototype.updateMCMTags = function(e) {
        for (var t = "uetq", o = {}, n = 0, r = Object.entries(I.MCMData.StorageTypes); n < r.length; n++) {
            var i = r[n],
                s = i[0],
                i = i[1];
            this.isCategoryMapped(i) && (i = e.includes(i) ? Ie.granted : Ie.denied, o[s] = i), this._window[t] = this._window[t] || [], this._window[t].push("consent", "update", o)
        }
    }, fn.prototype.canUpdateGCMCategories = function() {
        return I.GoogleConsent.GCAdStorage !== lt || I.GoogleConsent.GCAnalyticsStorage !== lt || I.GoogleConsent.GCFunctionalityStorage !== lt || I.GoogleConsent.GCPersonalizationStorage !== lt || I.GoogleConsent.GCSecurityStorage !== lt || I.GoogleConsent.GCAdUserData !== lt || I.GoogleConsent.GCAdPersonalization !== lt
    }, fn.prototype.checkAndWarnGCMConfig = function() {
        var e = 0,
            t = 0,
            o = 0,
            n = 0;
        if (I.GoogleConsent.GCEnable && !A.otDataLayer.ignore) {
            for (var r = this._window[A.otDataLayer.name], i = 0, s = Object.keys(r); i < s.length; i++) {
                var a = s[i];
                n++, this.isObjectTypeArgs(r[a]) && ("consent" === r[a][0] && "default" === r[a][1] ? t = n : "consent" === r[a][0] && "update" === r[a][1] ? o = n : 0 === e && "config" === r[a][0] && this.isGoogleTag(r[a][1]) && (e = n))
            }
            this.addGCMConfigStatus(e, t, o)
        }
    }, fn.prototype.addGCMConfigStatus = function(e, t, o) {
        0 !== e && (e < t ? console.warn("Google Consent mode default value is set after the Google tags were loaded.") : 0 === t ? console.warn("Google Consent mode default or consent value has not been set but the Google tags were loaded.") : (t < e || o < e) && console.info("Google Consent mode is properly configured."))
    }, fn.prototype.isGoogleTag = function(e) {
        return e && (-1 < e.indexOf("GT-") || -1 < e.indexOf("G-") || -1 < e.indexOf("AW-"))
    }, fn.prototype.isObjectTypeArgs = function(e) {
        return "[object Arguments]" === Object.prototype.toString.call(e)
    };
    var hn, yn = fn;

    function fn() {
        this._window = window
    }
    vn.prototype.updateFilterSelection = function(e) {
        o = (e = void 0 === e ? !1 : e) ? (t = L.filterByCategories, "data-optanongroupid") : (t = L.filterByIABCategories, "data-purposeid");
        for (var t, o, n = T("#onetrust-pc-sdk .category-filter-handler").el, r = 0; r < n.length; r++) {
            var i = n[r].getAttribute(o),
                i = -1 < t.indexOf(i);
            P.setCheckedAttribute(null, n[r], i)
        }
    }, vn.prototype.cancelHostFilter = function() {
        for (var e = T("#onetrust-pc-sdk .category-filter-handler").el, t = 0; t < e.length; t++) {
            var o = e[t].getAttribute("data-optanongroupid"),
                o = 0 <= L.filterByCategories.indexOf(o);
            P.setCheckedAttribute(null, e[t], o)
        }
    }, vn.prototype.updateHostFilterList = function() {
        for (var e = T("#onetrust-pc-sdk .category-filter-handler").el, t = 0; t < e.length; t++) {
            var o, n = e[t].getAttribute("data-optanongroupid");
            e[t].checked && L.filterByCategories.indexOf(n) < 0 ? L.filterByCategories.push(n) : !e[t].checked && -1 < L.filterByCategories.indexOf(n) && (o = L.filterByCategories, L.filterByCategories.splice(o.indexOf(n), 1))
        }
        return L.filterByCategories
    }, vn.prototype.InitializeHostList = function() {
        var e = k.P_Vendor_List + " " + k.P_Host_Cntr + " li";
        L.hosts.hostTemplate = T(e).el[0].cloneNode(!0), L.hosts.hostCookieTemplate = T(k.P_Vendor_List + " " + k.P_Host_Cntr + " " + k.P_Host_Opt + " li").el[0].cloneNode(!0)
    }, vn.prototype.getCookiesForGroup = function(t) {
        var o = [],
            n = [];
        return t.FirstPartyCookies.length && t.FirstPartyCookies.forEach(function(e) {
            n.push(R(R({}, e), {
                groupName: t.GroupName
            }))
        }), t.Hosts.length && t.Hosts.forEach(function(e) {
            o.push(R(R({}, e), {
                isActive: "always active" === y.getGrpStatus(t).toLowerCase(),
                groupName: t.GroupName,
                Type: he.Host
            }))
        }), {
            firstPartyCookiesList: n,
            thirdPartyCookiesList: o
        }
    }, vn.prototype.reactivateSrcTag = function(e) {
        var t = ["src"];
        e.setAttribute(t[0], e.getAttribute("data-" + t[0])), e.removeAttribute("data-src")
    }, vn.prototype.reactivateScriptTag = function(e) {
        var t = e.parentNode,
            o = document.createElement(e.tagName),
            n = (o.innerHTML = v.getInnerHtmlContent(v.getInnerHtmlContent(e.innerHTML)), e.attributes);
        if (0 < n.length)
            for (var r = 0; r < n.length; r++) "type" !== n[r].name ? o.setAttribute(n[r].name, n[r].value, !0) : o.setAttribute("type", "text/javascript", !0);
        t.appendChild(o), t.removeChild(e)
    }, vn.prototype.reactivateTag = function(e, t) {
        var o, n = 0 <= e.className.indexOf("ot-vscat"),
            r = 0 <= e.className.indexOf("optanon-category"),
            i = (n && r ? o = this.getGroupElements(e.className, L.showVendorService) : n ? L.showVendorService ? o = this.getGroupElements(e.className, !0) : this.unBlockTag(t, e) : r && (L.showVendorService ? this.unBlockTag(t, e) : o = this.getGroupElements(e.className, !1)), !0);
        if (o && 0 < o.length) {
            for (var s = 0; s < o.length; s++)
                if (!f.canInsertForGroup(o[s].trim())) {
                    i = !1;
                    break
                }
            i && this.unBlockTag(t, e)
        }
    }, vn.prototype.unBlockTag = function(e, t) {
        e ? this.reactivateSrcTag(t) : this.reactivateScriptTag(t)
    }, vn.prototype.getGroupElements = function(e, t) {
        return (t ? e.match(/ot-vscat(-[a-zA-Z0-9,]+)+($|\s)/)[0].split(/ot-vscat-/i) : e.match(/optanon-category(-[a-zA-Z0-9,]+)+($|\s)/)[0].split(/optanon-category-/i))[1].split("-")
    }, vn.prototype.substitutePlainTextScriptTags = function() {
        var t = this,
            e = [].slice.call(document.querySelectorAll('script[class*="optanon-category"]')),
            o = [].slice.call(document.querySelectorAll('*[class*="optanon-category"]')),
            e = Array.from(new Set(e.concat([].slice.call(document.querySelectorAll('script[class*="ot-vscat"]') || [])))),
            o = Array.from(new Set(o.concat([].slice.call(document.querySelectorAll('*[class*="ot-vscat"]') || []))));
        Array.prototype.forEach.call(o, function(e) {
            "SCRIPT" !== e.tagName && e.hasAttribute("data-src") && t.reactivateTag(e, !0)
        }), Array.prototype.forEach.call(e, function(e) {
            e.hasAttribute("type") && "text/plain" === e.getAttribute("type") && t.reactivateTag(e, !1)
        })
    };
    var Sn, mn = vn;

    function vn() {}
    var Tn, Pn = "Banner",
        kn = "Preference Center",
        bn = "API",
        An = "Close",
        In = "Allow All",
        Ln = "Reject All",
        _n = "Confirm",
        En = "Confirm",
        On = "Continue without Accepting",
        Vn = (Dn.prototype.init = function() {
            this.insertHtml(), this.insertCss(), this.showNty(), this.initHandler()
        }, Dn.prototype.getContent = function() {
            return F(this, void 0, void 0, function() {
                return M(this, function(e) {
                    return [2, xt.getSyncNtfyContent().then(function(e) {
                        L.syncNtfyGrp = {
                            name: e.name,
                            html: atob(e.html),
                            css: e.css
                        }
                    })]
                })
            })
        }, Dn.prototype.insertHtml = function() {
            this.removeHtml();

            function e(e) {
                return t.querySelector(e)
            }
            var t = document.createDocumentFragment(),
                o = document.createElement("div"),
                o = (T(o).html(L.syncNtfyGrp.html), o.querySelector(this.El)),
                n = (I.BannerRelativeFontSizesToggle && T(o).addClass("otRelFont"), I.useRTL && T(o).attr("dir", "rtl"), T(t).append(o), I.NtfyConfig),
                n = (this.initHtml("Sync", n.Sync, e, t.querySelector(this.El)), n.ShowCS ? T(e(".ot-pc-handler")).html(n.CSTxt) : (T(o).addClass("ot-hide-csbtn"), e(".ot-sync-btncntr").parentElement.removeChild(e(".ot-sync-btncntr"))), document.createElement("div"));
            T(n).append(t), T("#onetrust-consent-sdk").append(n.firstChild)
        }, Dn.prototype.initHandler = function() {
            T(this.El + " .ot-sync-close-handler").on("click", function() {
                return Tn.close()
            })
        }, Dn.prototype.showNty = function() {
            var e = T(this.El);
            e.css("bottom: -300px;"), e.animate({
                bottom: "1em;"
            }, 1e3), setTimeout(function() {
                e.css("bottom: 1rem;")
            }, 1e3), e.focus()
        }, Dn.prototype.changeState = function() {
            setTimeout(function() {
                Tn.refreshState()
            }, 1500)
        }, Dn.prototype.refreshState = function() {
            function e(e) {
                return t.querySelector(e)
            }
            var t = T(this.El).el[0],
                o = (t.classList.add("ot-nty-complete"), t.classList.remove("ot-nty-sync"), I.NtfyConfig);
            this.initHtml("Complete", o.Complete, e, t), o.ShowCS && ("LINK" === o.CSType && T(e(".ot-pc-handler")).addClass("ot-pc-link"), T(".ot-sync-btncntr").show("inline-block"), this.alignContent(), T(window).on("resize", function() {
                return Tn.resizeEvent
            })), setTimeout(function() {
                Tn.close()
            }, 1e3 * I.NtfyConfig.NtfyDuration)
        }, Dn.prototype.insertCss = function() {
            var e = document.getElementById("onetrust-style");
            e.innerHTML = v.getInnerHtmlContent(e.innerHTML + L.syncNtfyGrp.css), e.innerHTML = v.getInnerHtmlContent(e.innerHTML + this.addCustomStyles())
        }, Dn.prototype.addCustomStyles = function() {
            var e = I.NtfyConfig,
                t = e.Sync,
                o = e.Complete,
                n = e.CSButton,
                r = e.CSLink;
            return "\n        #onetrust-consent-sdk #ot-sync-ntfy.ot-nty-sync {\n            background-color: " + t.BgColor + ";\n            border: 1px solid " + t.BdrColor + ";\n        }\n        #onetrust-consent-sdk #ot-sync-ntfy .ot-sync-refresh>g {\n            fill: " + t.IconBgColor + ";\n        }\n        #onetrust-consent-sdk #ot-sync-ntfy.ot-nty-sync #ot-sync-title {\n            text-align: " + t.TitleAlign + ";\n            color: " + t.TitleColor + ";\n        }\n        #onetrust-consent-sdk #ot-sync-ntfy.ot-nty-sync .ot-sync-desc  {\n            text-align: " + t.DescAlign + ";\n            color: " + t.DescColor + ";\n        }\n        #onetrust-consent-sdk #ot-sync-ntfy.ot-nty-complete {\n            background-color: " + o.BgColor + ";\n            border: 1px solid " + o.BdrColor + ";\n        }\n        #onetrust-consent-sdk #ot-sync-ntfy .ot-sync-check>g {\n            fill: " + o.IconBgColor + ";\n        }\n        #onetrust-consent-sdk #ot-sync-ntfy.ot-nty-complete #ot-sync-title {\n            text-align: " + o.TitleAlign + ";\n            color: " + o.TitleColor + ";\n        }\n        #onetrust-consent-sdk #ot-sync-ntfy.ot-nty-complete .ot-sync-desc  {\n            text-align: " + o.DescAlign + ";\n            color: " + o.DescColor + ";\n        }\n        " + ("BUTTON" === e.CSType ? "\n        #onetrust-consent-sdk #ot-sync-ntfy .ot-pc-handler {\n            background-color: " + n.BgColor + ";\n            border: 1px solid " + n.BdrColor + ";\n            color: " + n.Color + ";\n            text-align: " + n.Align + ";\n        }" : " #onetrust-consent-sdk #ot-sync-ntfy .ot-pc-handler.ot-pc-link {\n            color: " + r.Color + ";\n            text-align: " + r.Align + ";\n        }") + "\n        "
        }, Dn.prototype.initHtml = function(e, t, o, n) {
            var r = "Complete" === e ? ".ot-sync-refresh" : ".ot-sync-check";
            t.ShowIcon ? (T(o("Sync" === e ? ".ot-sync-refresh" : ".ot-sync-check")).show(), T(o(r)).hide(), T(o(".ot-sync-icon")).show("inline-block"), n.classList.remove("ot-hide-icon")) : (T(o(".ot-sync-icon")).hide(), n.classList.add("ot-hide-icon")), t.Title ? T(o("#ot-sync-title")).html(t.Title) : T(o("#ot-sync-title")).hide(), t.Desc ? T(o(".ot-sync-desc")).html(t.Desc) : T(o(".ot-sync-desc")).hide(), t.ShowClose ? (T(o(".ot-sync-close-handler")).show("inline-block"), T(o(".ot-close-icon")).attr("aria-label", t.CloseAria), n.classList.remove("ot-hide-close")) : (T(o(".ot-sync-close-handler")).hide(), n.classList.add("ot-hide-close"))
        }, Dn.prototype.close = function() {
            this.hideSyncNtfy(), h.resetFocusToBody()
        }, Dn.prototype.hideSyncNtfy = function() {
            I.NtfyConfig.ShowCS && window.removeEventListener("resize", Tn.resizeEvent), T("#ot-sync-ntfy").fadeOut(400)
        }, Dn.prototype.removeHtml = function() {
            var e = T(this.El).el;
            e && P.removeChild(e)
        }, Dn.prototype.alignContent = function() {
            T(".ot-sync-btncntr").el[0].clientHeight > T(".ot-sync-titlecntr").el[0].clientHeight && (T(".ot-sync-titlecntr").addClass("ot-pos-abs"), T(".ot-sync-btncntr").addClass("ot-pos-rel"))
        }, Dn.prototype.resizeEvent = function() {
            window.innerWidth <= 896 && Tn.alignContent()
        }, Dn);

    function Dn() {
        this.El = "#ot-sync-ntfy"
    }
    Gn.prototype.toggleVendorConsent = function(e, t) {
        void 0 === t && (t = null), (e = (e = void 0 === e ? [] : e).length ? e : L.oneTrustIABConsent.vendors).forEach(function(e) {
            var e = e.split(":"),
                t = e[0],
                e = e[1],
                t = T(k.P_Vendor_Container + " ." + k.P_Ven_Ctgl + ' [vendorid="' + t + '"]').el[0];
            t && P.setCheckedAttribute("", t, "true" === e)
        });
        var o, n = T("#onetrust-pc-sdk #select-all-vendor-groups-handler").el[0];
        n && (o = P.getActiveIdArray(P.distinctArray(e)), (t = null === t ? o.length === e.length : t) || 0 === o.length ? n.parentElement.classList.remove(Vt.P_Line_Through) : n.parentElement.classList.add(Vt.P_Line_Through), P.setCheckedAttribute("", n, t))
    }, Gn.prototype.toggleVendorLi = function(e, t) {
        void 0 === t && (t = null), (e = (e = void 0 === e ? [] : e).length ? e : L.oneTrustIABConsent.legIntVendors).forEach(function(e) {
            var e = e.split(":"),
                t = e[0],
                e = e[1],
                t = T(k.P_Vendor_Container + " ." + k.P_Ven_Ltgl + ' [leg-vendorid="' + t + '"]').el[0];
            t && P.setCheckedAttribute("", t, "true" === e)
        });
        var o, n = T("#onetrust-pc-sdk #select-all-vendor-leg-handler").el[0];
        n && (o = P.getActiveIdArray(P.distinctArray(e)), (t = null === t ? o.length === e.length : t) || 0 === o.length ? n.parentElement.classList.remove(Vt.P_Line_Through) : n.parentElement.classList.add(Vt.P_Line_Through), P.setCheckedAttribute("", n, t))
    }, Gn.prototype.updateVendorLegBtns = function(e) {
        (e = (e = void 0 === e ? [] : e).length ? e : L.oneTrustIABConsent.legIntVendors).forEach(function(e) {
            var e = e.split(":"),
                t = e[0],
                e = e[1],
                t = T(k.P_Vendor_Container + ' .ot-leg-btn-container[data-group-id="' + t + '"]').el[0];
            t && f.updateLegIntBtnElement(t, "true" === e)
        })
    };
    var Nn, wn = Gn;

    function Gn() {}

    function Bn() {
        return (!A.isIab2orv2Template && I.PCTemplateUpgrade && I.PCCategoryStyle === ve.Toggle ? _.toggleEl : _.chkboxEl).cloneNode(!0)
    }
    Hn.prototype.setHtmlTemplate = function(e) {
        E.setInternalData(), E.rootHtml = e, E.cloneHtmlElements()
    }, Hn.prototype.getVendorListEle = function(e) {
        var t = document.createDocumentFragment(),
            o = document.createElement("div"),
            n = (o.classList.add("ot-vs-list"), I.VendorServiceConfig.PCVSExpandGroup);
        return e.forEach(function(e, t) {
            e = E.createVendor(e.groupRef, e, n, "ot-vs-lst-id-" + t);
            o.appendChild(e)
        }), t.appendChild(o), t
    }, Hn.prototype.insertVendorServiceHtml = function(e, t) {
        var o;
        E.checkIfIsInvalid(e, t) || (o = document.createDocumentFragment(), E.setVendorContainer(o, e), E.setVendorList(o, e), e.SubGroups && 0 < e.SubGroups.length ? (o.querySelector(this.MAIN_CONT_ELE).classList.add("ot-vnd-subgrp-cnt"), e = t.children[1], A.pcName === it && (e = t.children[2]), t.insertBefore(o, e)) : t.appendChild(o))
    }, Hn.prototype.toggleVendorService = function(e, t, o, n) {
        e = y.getGroupById(e), t = y.getVSById(t);
        n = n || E.getVendorInputElement(t.CustomVendorServiceId), E.setVendorServiceState(n, t, o), o ? E.changeGroupState(e, o, E.isToggle) : E.checkGroupChildrenState(e) || E.changeGroupState(e, !1, E.isToggle)
    }, Hn.prototype.setVendorStateByGroup = function(e, t) {
        e = e.VendorServices;
        if (L.showVendorService && e)
            for (var o = 0, n = e; o < n.length; o++) {
                var r = n[o],
                    i = E.getVendorInputElement(r.CustomVendorServiceId);
                E.setVendorServiceState(i, r, t)
            }
    }, Hn.prototype.resetVendorUIState = function(e) {
        e.forEach(function(e, t) {
            t = E.getVendorInputElement(t);
            E.changeVendorServiceUIState(t, e)
        })
    }, Hn.prototype.setVendorServiceState = function(e, t, o) {
        E.changeVendorServiceState(t, o), E.changeVendorServiceUIState(e, o);
        e = o ? Zo : $o;
        so.triggerGoogleAnalyticsEvent(Lo, e, t.ServiceName + ": " + t.CustomVendorServiceId)
    }, Hn.prototype.removeVSUITemplate = function(e) {
        var t = e.querySelector(this.MAIN_CONT_ELE);
        t && e.removeChild(t)
    }, Hn.prototype.consentAll = function(o) {
        L.getVendorsInDomain().forEach(function(e) {
            var t = o;
            o || (t = y.isAlwaysActiveGroup(e.groupRef)), E.toggleVendorService(e.groupRef.CustomGroupId, e.CustomVendorServiceId, t || o)
        })
    }, Hn.prototype.cloneHtmlElements = function() {
        var e, t, o, n, r = E.rootHtml.querySelector(this.MAIN_CONT_ELE);
        r && (e = r.querySelector(".ot-vnd-serv-hdr-cntr"), n = (o = (t = r.querySelector(".ot-vnd-lst-cont")).querySelector(".ot-vnd-item")).querySelector(".ot-vnd-info"), E.vendorLabelContainerClone = e.cloneNode(!0), r.removeChild(e), E.vendorInfoClone = n.cloneNode(!0), o.querySelector(".ot-vnd-info-cntr").removeChild(n), E.vendorItemClone = o.cloneNode(!0), t.removeChild(o), E.vendorListContainerClone = t.cloneNode(!0), r.removeChild(t), E.vendorServMainContainerClone = r.cloneNode(!0), E.rootHtml.removeChild(r))
    }, Hn.prototype.setInternalData = function() {
        E.isToggle = I.PCCategoryStyle === ve.Toggle;
        var e = I.VendorServiceConfig;
        E.stringTranslation = new Map, E.stringTranslation.set("ServiceName", e.PCVSNameText || "ServiceName"), E.stringTranslation.set("ParentCompany", e.PCVSParentCompanyText || "ParentCompany"), E.stringTranslation.set("Address", e.PCVSAddressText || "Address"), E.stringTranslation.set("DefaultCategoryName", e.PCVSDefaultCategoryText || "DefaultCategoryName"), E.stringTranslation.set("Description", e.PCVSDefaultDescriptionText || "Description"), E.stringTranslation.set("DPOEmail", e.PCVSDPOEmailText || "DPOEmail"), E.stringTranslation.set("DPOLink", e.PCVSDPOLinkText || "DPOLink"), E.stringTranslation.set("PrivacyPolicyLink", e.PCVSPrivacyPolicyLinkText || "PrivacyPolicyLink"), E.stringTranslation.set("CookiePolicyLink", e.PCVSCookiePolicyLinkText || "CookiePolicyLink"), E.stringTranslation.set("OptOutLink", e.PCVSOptOutLinkText || "OptOutLink"), E.stringTranslation.set("LegalBasis", e.PCVSLegalBasisText || "LegalBasis")
    }, Hn.prototype.setVendorContainer = function(e, t) {
        var o = E.vendorServMainContainerClone.cloneNode(!0),
            t = (o.setAttribute("data-group-id", t.CustomGroupId), E.vendorLabelContainerClone.cloneNode(!0));
        t.querySelector(".ot-vnd-serv-hdr").innerHTML = v.getInnerHtmlContent(I.VendorServiceConfig.PCVSListTitle), o.appendChild(t), e.appendChild(o)
    }, Hn.prototype.setVendorList = function(e, t) {
        for (var o = 0, n = E.getVSFromGroupAndSubgroups(t), r = n.length, e = e.querySelector(this.MAIN_CONT_ELE), i = E.vendorListContainerClone.cloneNode(), s = I.VendorServiceConfig.PCVSExpandCategory; o < r; o++) {
            var a = E.createVendor(t, n[o], s);
            i.appendChild(a)
        }
        e.appendChild(i)
    }, Hn.prototype.getVSFromGroupAndSubgroups = function(e, t) {
        var o, n = null != (o = e.VendorServices) ? o : [];
        if (t = void 0 === t ? !1 : t)
            for (var r = 0, i = null != (o = e.SubGroups) ? o : []; r < i.length; r++) {
                var s = null != (s = i[r].VendorServices) ? s : [];
                n.push.apply(n, s)
            }
        return n
    }, Hn.prototype.createVendor = function(e, t, o, n) {
        var r = E.vendorItemClone.cloneNode(!0),
            i = (r.setAttribute("data-vnd-id", t.CustomVendorServiceId), I.PCAccordionStyle === ce.NoAccordion ? (r.classList.remove("ot-accordion-layout"), (i = r.querySelector("button")) && r.removeChild(i)) : E.setExpandVendorList(r, o), E.setVendorHeader(e, t, r, n), r.querySelector(".ot-vnd-info-cntr"));
        return E.setVendorInfo(i, t), r
    }, Hn.prototype.setExpandVendorList = function(e, t) {
        e.querySelector("button").setAttribute("aria-expanded", "" + t)
    }, Hn.prototype.setVendorHeader = function(e, t, o, n) {
        var r = I.PCShowAlwaysActiveToggle,
            i = "always active" === y.getGrpStatus(e).toLowerCase(),
            o = o.querySelector(".ot-acc-hdr"),
            s = (i && o.classList.add("ot-always-active-group"), null),
            e = (i && I.PCCategoryStyle === ve.Toggle || (s = E.setHeaderInputStyle(e, t, i, n)), E.setHeaderText(t, o)),
            n = (o.appendChild(e), E.getPositionForElement(I.PCAccordionStyle, E.isToggle)),
            t = n.positionIcon;
        s && o.insertAdjacentElement(n.positionInput, s), i && r && (e = E.getAlwaysActiveElement(), o.insertAdjacentElement("beforeend", e)), I.PCAccordionStyle !== ce.NoAccordion && (n = E.setHeaderAccordionIcon(), o.insertAdjacentElement(t, n))
    }, Hn.prototype.getPositionForElement = function(e, t) {
        var o = "beforeend",
            n = "beforeend";
        return {
            positionIcon: o = t && e === ce.PlusMinus ? "afterbegin" : o,
            positionInput: n = t ? n : "afterbegin"
        }
    }, Hn.prototype.setHeaderAccordionIcon = function() {
        var e = (I.PCAccordionStyle === ce.Caret ? _.arrowEl : _.plusMinusEl).cloneNode(!0);
        return e
    }, Hn.prototype.setHeaderText = function(e, t) {
        var o = t.querySelector(".ot-cat-header"),
            n = o.cloneNode();
        return t.removeChild(o), n.innerText = e.ServiceName, n
    }, Hn.prototype.setHeaderInputStyle = function(e, t, o, n) {
        var r, i, s, a;
        return I.VendorServiceConfig.PCVSOptOut ? (e = y.checkIsActiveByDefault(e), r = !1, r = (i = L.vsConsent).has(t.CustomVendorServiceId) ? i.get(t.CustomVendorServiceId) : e, (i = Bn()).querySelector("input").classList.add("category-switch-handler"), e = i.querySelector("input"), a = t.CustomVendorServiceId, n = null != n ? n : "ot-vendor-id-" + a, s = "ot-vendor-header-id-" + a, T(e).attr("id", n), T(e).attr("name", n), T(e).attr("aria-labelledby", s), T(e).data("ot-vs-id", a), T(e).data("optanongroupid", t.groupRef.CustomGroupId), e.disabled = o, P.setCheckedAttribute(null, e, r), a = E.isToggle ? n : s, T(i.querySelector("label")).attr("for", a), T(i.querySelector(".ot-label-txt")).html(t.ServiceName), i) : null
    }, Hn.prototype.getAlwaysActiveElement = function() {
        var e = document.createElement("div");
        return e.classList.add("ot-always-active"), e.innerText = I.AlwaysActiveText, e
    }, Hn.prototype.setVendorInfo = function(e, t) {
        var o, n, r, i, s, a, l = ["DPOLink", "PrivacyPolicyLink", "CookiePolicyLink", "OptOutLink"];
        for (o in t) E.skipVendorInfoKey(o, t) || (n = t[o], (r = E.vendorInfoClone.cloneNode(!0)).dataset.vndInfoKey = o + "-" + t.CustomVendorServiceId, i = r.querySelector(".ot-vnd-lbl"), s = r.querySelector(".ot-vnd-cnt"), i.innerHTML = v.getInnerHtmlContent(E.getLocalizedString(o)), l.includes(o) ? (s.remove(), a = document.createElement("a"), T(a).attr("href", n), T(a).attr("target", "_blank"), T(a).attr("rel", "noopener"), T(a).attr("aria-label", n + " " + I.NewWinTxt), a.classList.add("ot-vnd-cnt"), a.innerText = n, i.insertAdjacentElement("afterend", a)) : s.innerHTML = v.getInnerHtmlContent(n), e.appendChild(r))
    }, Hn.prototype.skipVendorInfoKey = function(e, t) {
        return "VendorServiceId" === e || "DefaultCategoryId" === e || "ServiceName" === e || "groupRef" === e || "CustomVendorServiceId" === e || "PurposeId" === e || !t[e]
    }, Hn.prototype.getLocalizedString = function(e) {
        return E.stringTranslation.has(e) ? E.stringTranslation.get(e) : "DEFAULT"
    }, Hn.prototype.checkGroupChildrenState = function(e) {
        for (var t, o = 0, n = null != (t = e.SubGroups) ? t : []; o < n.length; o++) {
            var r = n[o];
            if (E.checkGroupChildrenState(r)) return !0
        }
        for (var i = 0, s = null != (t = e.VendorServices) ? t : []; i < s.length; i++) {
            var a = s[i];
            if (L.vsConsent.get(a.CustomVendorServiceId)) return !0
        }
        return !1
    }, Hn.prototype.changeVendorServiceState = function(e, t) {
        L.vsConsent.set(e.CustomVendorServiceId, t)
    }, Hn.prototype.changeVendorServiceUIState = function(e, t) {
        e && P.setCheckedAttribute(null, e, t)
    }, Hn.prototype.changeGroupState = function(e, t, o) {
        var n = y.getParentByGrp(e);
        f.toggleGrpStatus(e, t), E.updateGroupUIState(e.CustomGroupId, t, o, null !== n), n && (e = E.checkGroupChildrenState(n), E.changeGroupState(n, e, o))
    }, Hn.prototype.updateGroupUIState = function(e, t, o, n) {
        void 0 === n && (n = !1);
        n = document.querySelector((n ? "#ot-sub-group-id-" : "#ot-group-id-") + e);
        n && P.setCheckedAttribute(null, n, t)
    }, Hn.prototype.getVendorInputElement = function(e) {
        return document.getElementById("ot-vendor-id-" + e)
    }, Hn.prototype.checkIfIsInvalid = function(e, t) {
        return !e || !e.VendorServices || !t || e.VendorServices.length <= 0
    };
    var E, xn = Hn;

    function Hn() {
        this.MAIN_CONT_ELE = ".ot-vnd-serv"
    }

    function Rn(e, t) {
        var o, n, r = "otGenericBackdrop",
            i = "#" + r,
            s = "ot-generic-modal-layer";

        function a(e) {
            e ? (T(i).removeClass("ot-hide"), T(i).el[0].removeAttribute("style")) : (T(i).fadeOut(400), T(i).addClass("ot-hide"))
        }
        return (o = document.createElement("div")).classList.add(s), (n = document.createElement("div")).setAttribute("id", r), n.classList.add("onetrust-pc-dark-filter"), o.appendChild(n), (r = document.createElement("div")).classList.add("ot-general-modal"), r.setAttribute("id", null != e ? e : "genericModal"), o.appendChild(r), n = "#onetrust-consent-sdk .ot-general-modal { background-color: " + I.pcBackgroundColor + ";}", (e = document.getElementById("onetrust-style")).textContent = e.textContent + n, {
            dialogLayerHtml: o,
            modalHtml: r,
            closeModalHandler: function() {
                a(!1);
                var e = t.querySelector("." + s);
                t.removeChild(e)
            },
            openModalHandler: function() {
                a(!0)
            }
        }
    }
    Mn.getInstance = function() {
        return Mn.instance = Mn.instance ? Mn.instance : new Mn
    }, Mn.prototype.getHealthSignatureUIIfNeeded = function(e) {
        if ((void 0 === e && (e = !1), A.requireSignatureEnabled) && (this.healthSignatureGroup = I.Groups.find(function(e) {
                return e.needsHealthSignature
            }), this.healthSignatureGroup))
            if (A.healthSignatureGroup || e)
                if (A.healthSignatureData) this.setSignHealthDataIntoCookieGroup(A.healthSignatureData);
                else {
                    var t = f.isGroupActive(this.healthSignatureGroup),
                        o = "1" === g.readCookieParam(C.OPTANON_CONSENT, u.HEALTH_SIGNATURE_AUTHORIZATION);
                    if (!(e && t && o)) return this.showHealthSignatureModal(function() {}), this.healthSignatureElement
                }
        else(t = f.isGroupActive(this.healthSignatureGroup)) && pr.setDataSubjectIdV2(A.healthSignatureData), g.writeCookieParam(C.OPTANON_CONSENT, u.HEALTH_SIGNATURE_AUTHORIZATION, t ? "1" : "");
        return null
    }, Mn.prototype.checkIfHealthSignatureNeeded = function(e) {
        var t, o, n = this;
        return void 0 === e && (e = !1), !A.requireSignatureEnabled || L.bannerCloseSource === ee.RejectAll || L.bannerCloseSource === ee.BannerCloseButton || L.bannerCloseSource === ee.ContinueWithoutAcceptingButton ? Promise.resolve() : (this.healthSignatureGroup = I.Groups.find(function(e) {
            return e.needsHealthSignature
        }), this.healthSignatureGroup ? (e = e || this.getGroupToggleHtmlValue()) ? A.healthSignatureData ? (this.setSignHealthDataIntoCookieGroup(A.healthSignatureData), Promise.resolve()) : (t = f.isGroupActive(this.healthSignatureGroup), o = "1" === g.readCookieParam(C.OPTANON_CONSENT, u.HEALTH_SIGNATURE_AUTHORIZATION), e && t && o ? Promise.resolve() : new Promise(function(e) {
            n.showHealthSignatureModal(e)
        })) : ((t = f.isGroupActive(this.healthSignatureGroup)) && pr.setDataSubjectIdV2(A.healthSignatureData), g.writeCookieParam(C.OPTANON_CONSENT, u.HEALTH_SIGNATURE_AUTHORIZATION, t ? "1" : ""), Promise.resolve()) : (e = "🛑 INVALID Cookie category: " + I.RequireSignatureCID, Promise.reject(e)))
    }, Mn.prototype.getHealthSignatureComponent = function(e, t) {
        this.isModal = !1, this.langJson = I, this.parentElement = e, this.healthSignatureGroup = t;
        e = {
            errorMessage: this.langJson.PCRequireSignatureHelpText,
            inputLabelText: this.langJson.PCRequireSignatureFieldLabel
        }, t = '<form class="ot-signature-health-form" id="form">\n        <div class="ot-input-field-cont">\n            <label for="otHealthSignatureData" class="ot-signature-label">' + e.inputLabelText + '</label>\n            <input type="text" id="otHealthSignatureData" name="otHealthSignatureData" required aria-required="true" class="ot-signature-input"\n                aria-label="' + e.inputLabelText + '" autofocus aria-invalid="true" aria-describedby="otHealthSignatureErrorMesg"/>\n            <span id="otHealthSignatureErrorMesg" class="ot-health-signature-error">\n                ' + e.errorMessage + "\n            </span>\n        </div>\n    </form>", e = document.createElement("div");
        e.innerHTML = v.getInnerHtmlContent(t), e.classList.add("ot-signature-health-group"), this.setConsentIdInput(e), this.healthSignatureElement = e, this.parentElement.appendChild(e), this.addEventHandlers()
    }, Mn.prototype.resetHealthSignatureData = function(e) {
        void 0 === e && (e = !1), A.requireSignatureEnabled && (A.healthSignatureData = "", A.healthSignatureGroup = null, e) && g.writeCookieParam(C.OPTANON_CONSENT, u.HEALTH_SIGNATURE_AUTHORIZATION, "")
    }, Mn.prototype.setConsentIdInPC = function() {
        this.setConsentIdInput(null)
    }, Mn.prototype.setConsentIdInput = function(e) {
        var t;
        this.healthSignatureGroup && (g.readCookieParam(C.OPTANON_CONSENT, u.HEALTH_SIGNATURE_AUTHORIZATION) ? (t = (e || document).querySelector(this.HEALTH_SIGNATURE_INPUT_SELECTOR)) && (e = "", f.isGroupActive(this.healthSignatureGroup) && (e = g.readCookieParam(C.OPTANON_CONSENT, u.CONSENT_ID)), t.value = e) : (t = document.querySelector(this.HEALTH_SIGNATURE_INPUT_SELECTOR)) && (t.value = ""))
    }, Mn.prototype.showHealthSignatureModal = function(t) {
        var o = this;
        pn.hideConsentNoticeV2(), this.langJson = I, this.parentElement = document.querySelector(this.PARENT_SELECTOR), this.setMyHealthDataModal(function(e) {
            o.setSignHealthDataIntoCookieGroup(e), t()
        }, function() {
            f.toggleGrpStatus(o.healthSignatureGroup, !1), f.toggleGroupHtmlElement(o.healthSignatureGroup, o.healthSignatureGroup.CustomGroupId, !1), t()
        })
    }, Mn.prototype.setMyHealthDataModal = function(e, t) {
        this.isModal = !0, this.rejectCallback = t, this.confirmCallback = e, this.configOptions = {
            mainTitle: this.healthSignatureGroup.GroupName,
            description: this.healthSignatureGroup.GroupDescription,
            subtitle: this.langJson.PCRequireSignatureHeaderText,
            ariaLabel: this.langJson.PCRequireSignatureHeaderDesc,
            errorMessage: this.langJson.PCRequireSignatureHelpText,
            subDescription: this.langJson.PCRequireSignatureHeaderDesc,
            inputLabelText: this.langJson.PCRequireSignatureFieldLabel,
            rejectButtonText: this.langJson.PCRequireSignatureRejectBtnText,
            acceptButtonText: this.langJson.PCRequireSignatureConfirmBtnText
        };
        t = document.createDocumentFragment(), e = this.createModal(t);
        this.healthSignatureElement = this.createHealtSignatureForm(e), this.parentElement.appendChild(t), this.setFocusOnInput(), this.addEventHandlers(), this.genericModal.openModalHandler()
    }, Mn.prototype.setSignHealthDataIntoCookieGroup = function(e) {
        e ? (pr.setDataSubjectIdV2(e), A.healthSignatureData = e, f.toggleGrpStatus(this.healthSignatureGroup, !0)) : (A.healthSignatureData = "", f.toggleGrpStatus(this.healthSignatureGroup, !1)), g.writeCookieParam(C.OPTANON_CONSENT, u.HEALTH_SIGNATURE_AUTHORIZATION, e ? "1" : "")
    }, Mn.prototype.createModal = function(e) {
        return this.genericModal = Rn(this.MODAL_ID, this.parentElement), e.appendChild(this.genericModal.dialogLayerHtml), this.genericModal.modalHtml
    }, Mn.prototype.createHealtSignatureForm = function(e) {
        var t = '<div\n        class="ot-signature-health"\n        role="dialog"\n        aria-label="' + (t = this.configOptions).ariaLabel + '"\n        aria-describedby="otSignatureGroupDesc">\n        <section class="ot-signature-cont">\n            <h4 id="otSignatureSubtitle" class="ot-signature-subtitle">' + t.subtitle + '</h4>\n            <p class="ot-signature-paragraph">' + t.subDescription + '</p>\n        </section>\n        <section class="ot-signature-cont">\n            <h5 id="otSignatureGroupTitle" class="ot-signature-group-title">' + t.mainTitle + '</h5>\n            <p id="otSignatureGroupDesc" class="ot-signature-paragraph">' + t.description + '</p>\n        </section>\n        <form class="ot-signature-health-form" id="form">\n            <label for="otHealthSignatureData" class="ot-signature-label">' + t.inputLabelText + '</label>\n            <input type="text" id="otHealthSignatureData" name="otHealthSignatureData" required aria-required="true" class="ot-signature-input"\n                aria-label="' + t.inputLabelText + '" autofocus aria-invalid="true" aria-describedby="otHealthSignatureErrorMesg"/>\n            <span id="otHealthSignatureErrorMesg" class="ot-health-signature-error" aria-live="assertive">\n                ' + t.errorMessage + '\n            </span>\n        </form>\n        <div class="ot-signature-buttons-cont">\n            <button class="ot-signature-button reject">' + t.rejectButtonText + '</button>\n            <button class="ot-signature-button accept">' + t.acceptButtonText + "</button>\n        </div>\n    </div>";
        return e.innerHTML = v.getInnerHtmlContent(t), this.setConsentIdInput(e), this.addStyles(), e.querySelector(".ot-signature-health")
    }, Mn.prototype.addEventHandlers = function() {
        this.isModal ? (this.parentElement.querySelector(this.REJECT_SELECTOR).addEventListener("click", this.rejectListener.bind(this)), this.parentElement.querySelector(this.CONFIRM_SELECTOR).addEventListener("click", this.confirmListener.bind(this))) : this.parentElement.querySelector(this.HEALTH_SIGNATURE_INPUT_SELECTOR).addEventListener("keyup", this.healthSignatureInputChanged.bind(this))
    }, Mn.prototype.removeModal = function() {
        this.removeEventHandlers(), this.genericModal.closeModalHandler()
    }, Mn.prototype.removeEventHandlers = function() {
        this.isModal ? (this.parentElement.querySelector(this.REJECT_SELECTOR).removeEventListener("click", this.rejectListener), this.parentElement.querySelector(this.CONFIRM_SELECTOR).removeEventListener("click", this.confirmListener)) : this.parentElement.querySelector(this.HEALTH_SIGNATURE_INPUT_SELECTOR).removeEventListener("keyup", this.healthSignatureInputChanged)
    }, Mn.prototype.rejectListener = function() {
        this.removeModal(), this.rejectCallback && this.rejectCallback()
    }, Mn.prototype.confirmListener = function() {
        var e = this.healthSignatureElement.querySelector(this.HEALTH_SIGNATURE_INPUT_SELECTOR).value;
        e && (this.removeModal(), this.confirmCallback(e))
    }, Mn.prototype.healthSignatureInputChanged = function(e) {
        A.healthSignatureData = e.target.value
    }, Mn.prototype.setFocusOnInput = function() {
        this.healthSignatureElement.querySelector(this.HEALTH_SIGNATURE_INPUT_SELECTOR).focus()
    }, Mn.prototype.addStyles = function() {
        var e = "",
            t = (e = (e = (e += this.setParagraphStyles()) + this.setAcceptButtonsStyles()) + this.setRejectButtonsStyles(), document.getElementById("onetrust-style"));
        t.textContent = t.textContent + e
    }, Mn.prototype.setRejectButtonsStyles = function() {
        return "#onetrust-consent-sdk .ot-signature-health " + this.REJECT_SELECTOR + " {\n            color: " + I.bannerMPButtonTextColor + ";\n            border-color: " + I.bannerMPButtonTextColor + ";\n            background-color: " + I.bannerMPButtonColor + ";\n        }"
    }, Mn.prototype.setAcceptButtonsStyles = function() {
        return "#onetrust-consent-sdk .ot-signature-health " + this.CONFIRM_SELECTOR + " {\n            color: " + I.buttonTextColor + ";\n            border-color: " + I.buttonColor + ";\n            background-color: " + I.buttonColor + ";\n        }"
    }, Mn.prototype.setParagraphStyles = function() {
        return this.HEALTH_SIGNATURE_PARAGRAPH_SELECTOR + " {\n            color: " + I.textColor + ";\n        }"
    }, Mn.prototype.getGroupToggleHtmlValue = function() {
        var e = this.healthSignatureGroup.CustomGroupId,
            e = document.querySelector("input#ot-group-id-" + e + ", input#ot-bnr-hdr-id-" + e + ", input#ot-bnr-grp-id-" + e);
        return !!e && !0 === e.checked
    };
    var Fn = Mn;

    function Mn() {
        this.MODAL_ID = "healthSignatureDataModal", this.PARENT_SELECTOR = "#onetrust-consent-sdk", this.REJECT_SELECTOR = ".ot-signature-button.reject", this.CONFIRM_SELECTOR = ".ot-signature-button.accept", this.HEALTH_SIGNATURE_INPUT_SELECTOR = "#otHealthSignatureData", this.HEALTH_SIGNATURE_PARAGRAPH_SELECTOR = "p.ot-signature-paragraph"
    }
    qn.prototype.updateDataSubjectTimestamp = function() {
        var e = p.alertBoxCloseDate(),
            e = e && h.getUTCFormattedDate(e);
        T(".ot-userid-timestamp").html(I.PCenterUserIdTimestampTitleText + ": " + e)
    }, qn.prototype.closeBanner = function(e) {
        this.closeOptanonAlertBox(), e ? this.allowAll(!1) : this.close(!1)
    }, qn.prototype.allowAll = function(e, t) {
        void 0 === t && (t = !1), m.moduleInitializer.MobileSDK ? window.OneTrust.AllowAll() : this.AllowAllV2(e, t)
    }, qn.prototype.bannerActionsHandler = function(t, n, e) {
        var r = this,
            i = (void 0 === e && (e = !1), vo.setLandingPathParam(u.NOT_LANDING_PAGE), L.groupsConsent = [], L.hostsConsent = [], L.genVendorsConsent = {}, {});
        I.Groups.forEach(function(e) {
            if (e.IsAboutGroup) return !1;
            U(e.SubGroups, [e]).forEach(function(e) {
                var o = r.getGroupStatus(t, n, e);
                r.setGroupConsent(o, e), e.Hosts.length && h.isOptOutEnabled() && e.Hosts.forEach(function(e) {
                    var t;
                    i[e.HostId] ? ko.updateHostStatus(e, o) : (i[e.HostId] = !0, t = ko.isHostPartOfAlwaysActiveGroup(e.HostId), L.hostsConsent.push(e.HostId + ":" + (t || o ? "1" : "0")))
                }), L.genVenOptOutEnabled && e.GeneralVendorsIds && e.GeneralVendorsIds.length && e.GeneralVendorsIds.forEach(function(e) {
                    fo.updateGenVendorStatus(e, o)
                })
            })
        }), I.IsIabEnabled && (t ? this.iab.allowAllhandler() : this.iab.rejectAllHandler(e)), sn.removeAddedOTCssStyles(), pn.hideConsentNoticeV2(), co.writeGrpParam(C.OPTANON_CONSENT), co.writeHstParam(C.OPTANON_CONSENT), L.genVenOptOutEnabled && co.writeGenVenCookieParam(C.OPTANON_CONSENT), L.vsIsActiveAndOptOut && co.writeVSConsentCookieParam(C.OPTANON_CONSENT), Sn.substitutePlainTextScriptTags(), hn.updateGtmMacros(), this.executeOptanonWrapper()
    }, qn.prototype.getGroupStatus = function(e, t, o) {
        return e ? o.Status.toLowerCase() !== S.ALWAYS_INACTIVE : !!t && y.isAlwaysActiveGroup(o)
    }, qn.prototype.setGroupConsent = function(e, t) {
        var o; - 1 < Tt.indexOf(t.Type) && (o = "", o = A.requireSignatureEnabled && t.needsHealthSignature ? A.healthSignatureData ? "1" : "0" : e && t.HasConsentOptOut ? "1" : "0", L.groupsConsent.push(t.CustomGroupId + ":" + o))
    }, qn.prototype.nextPageCloseBanner = function() {
        vo.isLandingPage() || p.isAlertBoxClosedAndValid() || this.closeBanner(I.NextPageAcceptAllCookies)
    }, qn.prototype.rmScrollAndClickBodyEvents = function() {
        I.ScrollCloseBanner && window.removeEventListener("scroll", this.scrollCloseBanner), I.OnClickCloseBanner && document.body.removeEventListener("click", this.bodyClickEvent)
    }, qn.prototype.onClickCloseBanner = function(e) {
        p.isAlertBoxClosedAndValid() || (so.triggerGoogleAnalyticsEvent(Lo, _o), this.closeBanner(I.OnClickAcceptAllCookies)), O.rmScrollAndClickBodyEvents()
    }, qn.prototype.scrollCloseBanner = function() {
        var e = T(document).height() - T(window).height(),
            e = (0 === e && (e = T(window).height()), 100 * T(window).scrollTop() / e);
        25 < (e = e <= 0 ? 100 * (document.scrollingElement && document.scrollingElement.scrollTop || document.documentElement && document.documentElement.scrollTop || document.body && document.body.scrollTop) / (document.scrollingElement && document.scrollingElement.scrollHeight || document.documentElement && document.documentElement.scrollHeight || document.body && document.body.scrollHeight) : e) && !p.isAlertBoxClosedAndValid() && (!L.isPCVisible || I.NoBanner) ? (so.triggerGoogleAnalyticsEvent(Lo, _o), O.closeBanner(I.ScrollAcceptAllCookies), O.rmScrollAndClickBodyEvents()) : p.isAlertBoxClosedAndValid() && O.rmScrollAndClickBodyEvents()
    }, qn.prototype.AllowAllV2 = function(e, t) {
        void 0 === t && (t = !1);
        for (var o = this.groupsClass.getAllGroupElements(), n = 0; n < o.length; n++) {
            var r = y.getGroupById(o[n].getAttribute("data-optanongroupid"));
            A.requireSignatureEnabled && r.needsHealthSignature ? this.groupsClass.toggleGrpElements(o[n], r, !!A.healthSignatureData) : (this.groupsClass.toggleGrpElements(o[n], r, !0), this.groupsClass.toogleSubGroupElement(o[n], !0, !1, !0), this.groupsClass.toogleSubGroupElement(o[n], !0, !0, !0))
        }
        L.showVendorService && E.consentAll(!0), this.bannerActionsHandler(!0, !1), this.consentTransactions(e, !0, t), I.IsIabEnabled && (this.iab.updateIabVariableReference(), this.iab.updateVendorsDOMToggleStatus(!0), this.updateVendorLegBtns(!0))
    }, qn.prototype.rejectAll = function(e, t) {
        for (var o, n, r = (t = void 0 === t ? !1 : t) ? Ce[5] : Ce[2], i = this.groupsClass.getAllGroupElements(), s = null != (o = null == (o = m) ? void 0 : o.fp) && o.CookieV2RejectAll ? (n = this.initializeObjectToLIRejectAll(t), this.initializeAllowLIRejectAll(t)) : !(n = !0), a = 0; a < i.length; a++) {
            var l = y.getGroupById(i[a].getAttribute("data-optanongroupid"));
            "always active" !== y.getGrpStatus(l).toLowerCase() && (f.toggleGrpElements(i[a], l, !1, s), this.groupsClass.toogleSubGroupElement(i[a], !1, !1, !0), I.IsIabEnabled && (I.IsIabEnabled, !n) || this.groupsClass.toogleSubGroupElement(i[a], !1, !0, !0))
        }
        L.showVendorService && E.consentAll(!1), this.bannerActionsHandler(!1, !0, s), r !== L.consentInteractionType && this.consentTransactions(e, !1, t), I.IsIabEnabled && (this.iab.updateIabVariableReference(), this.iab.updateVendorsDOMToggleStatus(!1, s), s || this.updateVendorLegBtns(!1))
    }, qn.prototype.initializeObjectToLIRejectAll = function(e) {
        return !e && I.BannerShowRejectAllButton && I.BRejectConsentType === Le.OBJECT_TO_LI || e && I.PCenterShowRejectAllButton && I.BRejectConsentType === Le.OBJECT_TO_LI
    }, qn.prototype.initializeAllowLIRejectAll = function(e) {
        return I.IsIabEnabled && (!e && I.BannerShowRejectAllButton && I.BRejectConsentType === Le.LI_ACTIVE_IF_LEGAL_BASIS || e && I.PCenterShowRejectAllButton && I.BRejectConsentType === Le.LI_ACTIVE_IF_LEGAL_BASIS)
    }, qn.prototype.executeCustomScript = function() {
        I.CustomJs && new Function(I.CustomJs)()
    }, qn.prototype.updateConsentData = function(e) {
        vo.setLandingPathParam(u.NOT_LANDING_PAGE), I.IsIabEnabled && !e && this.iab.saveVendorStatus(), co.writeGrpParam(C.OPTANON_CONSENT), co.writeHstParam(C.OPTANON_CONSENT), L.showGeneralVendors && I.GenVenOptOut && co.writeGenVenCookieParam(C.OPTANON_CONSENT), L.vsIsActiveAndOptOut && co.writeVSConsentCookieParam(C.OPTANON_CONSENT), Sn.substitutePlainTextScriptTags(), hn.updateGtmMacros()
    }, qn.prototype.close = function(e, t) {
        var o;
        void 0 === t && (t = te.Banner), pn.hideConsentNoticeV2(), this.updateConsentData(e), I.IsConsentLoggingEnabled ? (e = t === te.PC ? _n : t === te.Banner ? An : A.apiSource, o = t === te.PC ? kn : t === te.Banner ? Pn : bn, L.bannerCloseSource === ee.ContinueWithoutAcceptingButton && (e = On), L.bannerCloseSource === ee.BannerSaveSettings && (e = En), hs.createConsentTxn(!1, o + " - " + e, t === te.PC)) : p.dispatchConsentEvent(), this.executeOptanonWrapper()
    }, qn.prototype.executeOptanonWrapper = function() {
        try {
            if (this.executeCustomScript(), "function" == typeof window.OptanonWrapper && "undefined" !== window.OptanonWrapper) {
                window.OptanonWrapper();
                for (var e = 0, t = L.srcExecGrpsTemp; e < t.length; e++) {
                    var o = t[e]; - 1 === L.srcExecGrps.indexOf(o) && L.srcExecGrps.push(o)
                }
                L.srcExecGrpsTemp = [];
                for (var n = 0, r = L.htmlExecGrpsTemp; n < r.length; n++) {
                    o = r[n]; - 1 === L.htmlExecGrps.indexOf(o) && L.htmlExecGrps.push(o)
                }
                L.htmlExecGrpsTemp = []
            }
        } catch (e) {
            console.warn("Error in Optanon wrapper, please review your code. " + e)
        }
    }, qn.prototype.updateVendorLegBtns = function(e) {
        if (A.legIntSettings.PAllowLI && A.legIntSettings.PShowLegIntBtn)
            for (var t = T(k.P_Vendor_Container + " .ot-leg-btn-container").el, o = 0; o < t.length; o++) this.groupsClass.updateLegIntBtnElement(t[o], e)
    }, qn.prototype.showFltgCkStgButton = function() {
        var e = T("#ot-sdk-btn-floating"),
            e = (e.removeClass("ot-hide"), e.removeClass("ot-pc-open"), I.cookiePersistentLogo.includes("ot_guard_logo.svg") && T(O.fltgFrontBtnSvg).attr(gt, ""), T(O.fltgBackBtnSvg).attr(gt, "true"), document.querySelector(O.fltgBtnBackBtn)),
            t = document.querySelector(O.fltgBtnFrontBtn);
        t && (t.setAttribute(gt, "false"), t.style.display = "block"), e && (e.setAttribute(gt, "true"), e.style.display = "none")
    }, qn.prototype.consentTransactions = function(e, t, o) {
        void 0 === o && (o = !1), hs && !e && I.IsConsentLoggingEnabled ? hs.createConsentTxn(!1, (o ? kn : Pn) + " - " + (t ? In : Ln), o) : p.dispatchConsentEvent()
    }, qn.prototype.hideVendorsList = function() {
        pn.checkIfPcSdkContainerExist() || (I.PCTemplateUpgrade ? T("#onetrust-pc-sdk " + k.P_Content).removeClass("ot-hide") : T("#onetrust-pc-sdk .ot-main-content").show(), T("#onetrust-pc-sdk #close-pc-btn-handler.main").show(), T("#onetrust-pc-sdk " + k.P_Vendor_List).addClass("ot-hide"))
    }, qn.prototype.resetConsent = function() {
        var e = this,
            t = this.getInitialConsent();
        L.groupsConsent = JSON.parse(JSON.stringify(t)), L.hostsConsent = JSON.parse(JSON.stringify(L.initialHostConsent)), L.showGeneralVendors && (L.genVendorsConsent = JSON.parse(JSON.stringify(L.initialGenVendorsConsent))), L.vsIsActiveAndOptOut && (L.vsConsent = new Map(L.initialVendorsServiceConsent)), I.IsIabEnabled && (L.oneTrustIABConsent = JSON.parse(JSON.stringify(L.initialOneTrustIABConsent)), L.vendors = JSON.parse(JSON.stringify(L.initialVendors)), L.vendors.vendorTemplate = L.initialVendors.vendorTemplate), I.UseGoogleVendors && (L.addtlVendors = JSON.parse(JSON.stringify(L.initialAddtlVendors)), L.addtlVendorsList = JSON.parse(JSON.stringify(L.initialAddtlVendorsList))), setTimeout(function() {
            e.resetConsentUI()
        }, 400)
    }, qn.prototype.getInitialConsent = function() {
        var e;
        return I.NoBanner && I.ShowPreferenceCenterCloseButton && 0 < A.consentableImpliedConsentGroup.length ? (e = L.initialGroupsConsent.map(function(e) {
            var t = e.split(":")[0];
            return A.consentableImpliedConsentGroup.find(function(e) {
                return e.CustomGroupId === t
            }) ? t + ":1" : e
        }), A.consentableImpliedConsentGroup = [], e) : L.initialGroupsConsent
    }, qn.prototype.setLblTxtForTgl = function(e, t) {
        e = e.querySelector(".ot-label-status");
        I.PCShowConsentLabels && e && (e.innerHTML = v.getInnerHtmlContent(t ? I.PCActiveText : I.PCInactiveText))
    }, qn.prototype.resetConsentUI = function() {
        var p = this;
        f.getAllGroupElements().forEach(function(e) {
            var t = e.getAttribute("data-optanongroupid"),
                t = y.getGroupById(t),
                o = f.isGroupActive(t),
                n = b.GroupTypes;
            if (A.pcName === it && I.PCTemplateUpgrade && (e = document.querySelector("#ot-desc-id-" + e.getAttribute("data-optanongroupid"))), p.setLblTxtForTgl(e, o), t.Type === ht || t.Type === n.Stack || 0 < (null == (n = t.SubGroups) ? void 0 : n.length))
                for (var n = h.isBundleOrStackActive(t, L.initialGroupsConsent), r = e.querySelector('input[class*="category-switch-handler"]'), i = (P.setCheckedAttribute(null, r, n), e.querySelectorAll("li" + k.P_Subgrp_li)), s = 0; s < i.length; s++) {
                    var a = y.getGroupById(i[s].getAttribute("data-optanongroupid")),
                        l = (a.OptanonGroupId, f.isGroupActive(a)),
                        c = i[s].querySelector('input[class*="cookie-subgroup-handler"]'),
                        d = i[s].querySelector(".ot-label-status"),
                        u = e.querySelector(".ot-label-status");
                    I.PCShowConsentLabels && d && (u.innerHTML = v.getInnerHtmlContent(l ? I.PCActiveText : I.PCInactiveText)), P.setCheckedAttribute(null, c, l), O.resetLegIntButton(a, i[s])
                } else {
                    r = e.querySelector('input[class*="category-switch-handler"]');
                    P.setCheckedAttribute(null, r, o), O.resetLegIntButton(t, e)
                }
        }), I.IsIabEnabled && Nn.toggleVendorConsent(), this.resetGenVenUI(), this.resetGoogleVenUI(), L.vsIsActiveAndOptOut && E.resetVendorUIState(L.vsConsent)
    }, qn.prototype.resetGenVenUI = function() {
        var e = T("#onetrust-pc-sdk .ot-gnven-chkbox-handler").el;
        if (L.showGeneralVendors && e && e.length) {
            for (var t = 0, o = e; t < o.length; t++) {
                var n = o[t],
                    r = n.getAttribute("gn-vid"),
                    i = Boolean(L.genVendorsConsent[r]);
                P.setCheckedAttribute("", n, i), fo.updateGenVendorStatus(r, i)
            }
            w.genVenSelectAllTglEvent()
        }
    }, qn.prototype.resetGoogleVenUI = function() {
        var e = T("#onetrust-pc-sdk .ot-addtlven-chkbox-handler").el;
        if (I.UseGoogleVendors && e && e.length)
            for (var t = 0, o = e; t < o.length; t++) {
                var n = o[t],
                    r = n.getAttribute("addtl-vid");
                L.addtlVendorsList[r] && (r = Boolean(L.addtlVendors.vendorSelected[r]), P.setCheckedAttribute("", n, r))
            }
    }, qn.prototype.resetLegIntButton = function(e, t) {
        var o;
        A.legIntSettings.PAllowLI && e.Type === b.GroupTypes.Pur && e.HasLegIntOptOut && A.legIntSettings.PShowLegIntBtn && (o = !0, -1 < L.vendors.selectedLegInt.indexOf(e.IabGrpId + ":false") && (o = !1), f.updateLegIntBtnElement(t, o))
    }, qn.prototype.handleTogglesOnSingularConsentUpdate = function(e, t) {
        if (this.closeOptanonAlertBox(), e === ct)
            for (var s = this, o = 0, n = t; o < n.length; o++) {
                var r = n[o];
                ((e, t) => {
                    for (var o = y.getGroupById(e), n = s.groupsClass.getAllGroupElements(), r = 0; r < n.length; r++) {
                        var i = y.getGroupById(n[r].getAttribute("data-optanongroupid"));
                        if (i.OptanonGroupId === o.OptanonGroupId && !i.Parent) {
                            D.toggleV2Category(null, i, t, i.CustomGroupId);
                            break
                        }
                        i = i.SubGroups.find(function(e) {
                            return e.OptanonGroupId === o.OptanonGroupId
                        });
                        i && D.toggleSubCategory(null, i.CustomGroupId, t, i.CustomGroupId)
                    }
                })(c = r.id, d = r.isEnabled)
            } else if (e === pt)
                for (var i = 0, a = t; i < a.length; i++) {
                    var l = a[i],
                        c = l.id,
                        d = l.isEnabled,
                        l = y.getGrpByVendorId(c);
                    l && E.toggleVendorService(l.CustomGroupId, c, d)
                }
        this.close(!1, te.API)
    }, qn.prototype.checkImplicitConsentWhenBannerIsClosed = function(e) {
        var t;
        void 0 === e && (e = !1), p.isAlertBoxClosedAndValid() || !vo.isLandingPage() && !e || (L.bannerCloseSource === ee.BannerCloseButton && A.resetImpliedConsentableGroups(), t = new Map, A.consentableImpliedConsentGroup.forEach(function(o) {
            var n;
            o.Status === S.INACTIVE_LANDING_PAGE && 0 <= (n = P.findIndex(L.groupsConsent, function(e) {
                return e.split(":")[0] === o.CustomGroupId
            })) && (t.set(o.CustomGroupId, o), U(o.SubGroups, [o]).forEach(function(e) {
                var t = A.gpcEnabled && e.IsGpcEnabled;
                L.groupsConsent[n] = o.CustomGroupId + ":1", t && (L.groupsConsent[n] = o.CustomGroupId + ":0"), !t && e.Hosts.length && h.isOptOutEnabled() && e.Hosts.forEach(function(e) {
                    return ko.updateHostStatus(e, !0)
                }), !t && L.genVenOptOutEnabled && e.GeneralVendorsIds && e.GeneralVendorsIds.length && e.GeneralVendorsIds.forEach(function(e) {
                    return fo.updateGenVendorStatus(e, !0)
                })
            }))
        }), this.setImplicitConsentUI(t))
    }, qn.prototype.setImplicitConsentUI = function(e) {
        var o = this;
        e.size <= 0 || e.forEach(function(e, t) {
            t = o.getGroupElement(t);
            t && (o.groupsClass.toggleGrpElements(t, e, !0), o.groupsClass.toogleSubGroupElement(t, !0, !1, !0), o.groupsClass.toogleSubGroupElement(t, !0, !0, !0))
        })
    }, qn.prototype.getGroupElement = function(e) {
        return document.querySelector("div#onetrust-pc-sdk " + k.P_Category_Grp + " " + k.P_Category_Item + '[data-optanongroupid="' + e + '"]:not(.ot-vnd-item)')
    };
    var O, Un = qn;

    function qn() {
        var n = this;
        this.iab = w, this.groupsClass = f, this.fltgBackBtnSvg = ".ot-floating-button__back svg", this.fltgFrontBtnSvg = ".ot-floating-button__front svg", this.fltgBtnBackBtn = ".ot-floating-button__back button", this.fltgBtnFrontBtn = ".ot-floating-button__front button", this.closeOptanonAlertBox = function() {
            var e;
            h.hideBanner(), T(document).off("keydown", D.closePCWhenEscPressed), I.NtfyConfig.ShowNtfy && Tn.hideSyncNtfy(), so.setAlertBoxClosed(!0), I.PCTemplateUpgrade && I.PCenterUserIdTitleText && I.IsConsentLoggingEnabled && n.updateDataSubjectTimestamp(), p.isAlertBoxClosedAndValid() && (e = T(".onetrust-pc-dark-filter").el[0]) && "none" !== getComputedStyle(e).getPropertyValue("display") && T(".onetrust-pc-dark-filter").fadeOut(400), N.csBtnGroup && n.showFltgCkStgButton()
        }, this.bodyClickEvent = function(e) {
            var t = e.target;
            t.closest("#onetrust-banner-sdk") || t.closest("#onetrust-pc-sdk") || t.closest(".onetrust-pc-dark-filter") || t.closest(".ot-sdk-show-settings") || t.closest(".optanon-show-settings") || t.closest(".optanon-toggle-display") || O.onClickCloseBanner(e)
        }, this.bannerCloseButtonHandler = function(o) {
            return void 0 === o && (o = !1), F(n, void 0, void 0, function() {
                var t;
                return M(this, function(e) {
                    switch (e.label) {
                        case 0:
                            return (O.checkImplicitConsentWhenBannerIsClosed(o), O.closeOptanonAlertBox(), m.moduleInitializer.MobileSDK) ? (window.OneTrust.Close(), [3, 5]) : [3, 1];
                        case 1:
                            return e.trys.push([1, 3, , 4]), [4, Fn.getInstance().checkIfHealthSignatureNeeded()];
                        case 2:
                            return e.sent(), [3, 4];
                        case 3:
                            return t = e.sent(), console.error(t), [3, 4];
                        case 4:
                            t = L.bannerCloseSource === ee.ConfirmChoiceButton ? te.PC : te.Banner, O.close(o, t), e.label = 5;
                        case 5:
                            return [2, !1]
                    }
                })
            })
        }, this.allowAllEventHandler = function(o) {
            return void 0 === o && (o = !1), F(n, void 0, void 0, function() {
                var t;
                return M(this, function(e) {
                    switch (e.label) {
                        case 0:
                            T(document).off("keydown", D.shiftBannerFocus), t = o ? "Preferences Allow All" : "Banner Accept Cookies", so.triggerGoogleAnalyticsEvent(Lo, t), o && A.requireSignatureEnabled && (pn.hideConsentNoticeV2(), this.closeOptanonAlertBox()), e.label = 1;
                        case 1:
                            return e.trys.push([1, 3, , 4]), [4, Fn.getInstance().checkIfHealthSignatureNeeded(!0)];
                        case 2:
                            return e.sent(), [3, 4];
                        case 3:
                            return t = e.sent(), console.error(t), [3, 4];
                        case 4:
                            return this.allowAllEvent(!1, o), this.hideVendorsList(), [2]
                    }
                })
            })
        }, this.allowAllEvent = function(e, t) {
            void 0 === e && (e = !1), void 0 === t && (t = !1), n.closeOptanonAlertBox(), O.allowAll(e, t)
        }, this.rejectAllEventHandler = function(e) {
            void 0 === e && (e = !1), T(document).off("keydown", D.shiftBannerFocus), so.triggerGoogleAnalyticsEvent(Lo, e ? "Preferences Reject All" : "Banner Reject All"), Fn.getInstance().resetHealthSignatureData(!0), m.moduleInitializer.MobileSDK ? window.OneTrust.RejectAll() : (n.rejectAllEvent(!1, e), n.hideVendorsList())
        }, this.rejectAllEvent = function(e, t) {
            void 0 === e && (e = !1), void 0 === t && (t = !1), n.closeOptanonAlertBox(), !p.isIABCrossConsentEnabled() || A.thirdPartyiFrameLoaded ? n.rejectAll(e, t) : A.thirdPartyiFramePromise.then(function() {
                n.rejectAll(e, t)
            })
        }
    }
    zn.prototype.setFilterList = function(o) {
        var n = this,
            r = T("#onetrust-pc-sdk " + k.P_Fltr_Modal + " " + k.P_Fltr_Option).el[0].cloneNode(!0);
        T("#onetrust-pc-sdk " + k.P_Fltr_Modal + " " + k.P_Fltr_Options).html(""), (m.isV2Template || I.PCLayout.Popup) && T("#onetrust-pc-sdk #filter-cancel-handler").html(I.PCenterCancelFiltersText || "Cancel"), !m.isV2Template && I.PCLayout.Popup || (T("#onetrust-pc-sdk " + k.P_Clr_Fltr_Txt).html(I.PCenterClearFiltersText), T("#filter-btn-handler").el[0].setAttribute("aria-label", I.PCenterFilterText)), T("#onetrust-pc-sdk #filter-apply-handler").html(I.PCenterApplyFiltersText), o ? A.consentableGrps.forEach(function(e) {
            var t = L.cookieListType === ye.GenVen || L.cookieListType === ye.HostAndGenVen ? e.Hosts.length || e.FirstPartyCookies.length || e.GeneralVendorsIds && e.GeneralVendorsIds.length : e.Hosts.length || e.FirstPartyCookies.length;
            t && n.filterGroupOptionSetter(r, e, o)
        }) : A.iabGrps.forEach(function(e) {
            n.filterGroupOptionSetter(r, e, o)
        })
    }, zn.prototype.setFilterListByGroup = function(e, t) {
        var o, n = this;
        !e || e.length <= 0 ? T("#onetrust-pc-sdk " + k.P_Fltr_Modal + " " + k.P_Fltr_Options).html("") : (o = T("#onetrust-pc-sdk " + k.P_Fltr_Modal + " " + k.P_Fltr_Option).el[0].cloneNode(!0), T("#onetrust-pc-sdk " + k.P_Fltr_Modal + " " + k.P_Fltr_Options).html(""), (m.isV2Template || I.PCLayout.Popup) && T("#onetrust-pc-sdk #filter-cancel-handler").html(I.PCenterCancelFiltersText || "Cancel"), !m.isV2Template && I.PCLayout.Popup || (T("#onetrust-pc-sdk " + k.P_Clr_Fltr_Txt).html(I.PCenterClearFiltersText), T("#filter-btn-handler").el[0].setAttribute("aria-label", I.PCenterFilterText)), T("#onetrust-pc-sdk #filter-apply-handler").html(I.PCenterApplyFiltersText), e.forEach(function(e) {
            n.filterGroupOptionSetter(o, e, t)
        }))
    }, zn.prototype.filterGroupOptionSetter = function(e, t, o) {
        var n = t.CustomGroupId,
            r = n + "-filter",
            e = e.cloneNode(!0);
        T(k.P_Fltr_Modal + " " + k.P_Fltr_Options).append(e), T(e.querySelector("input")).attr("id", r), T(e.querySelector("label")).attr("for", r), (m.isV2Template ? T(e.querySelector(k.P_Label_Txt)) : T(e.querySelector("label span"))).html(t.GroupName), T(e.querySelector("input")).attr(o ? "data-optanongroupid" : "data-purposeid", n)
    };
    var jn, Kn = zn;

    function zn() {
        this.bodyScrollProp = "", this.htmlScrollProp = "", this.ONETRUST_PC_SDK = "#onetrust-pc-sdk", this.ONETRUST_PC_DARK_FILTER = ".onetrust-pc-dark-filter"
    }
    Jn.prototype.showParagraph = function(e) {
        var t = R({}, e),
            o = t.listTitle,
            n = t.htmlFragment,
            t = t.paragrphContainerSelector;
        Wn.options = e, Wn.hideOtherHtmlElements(e), Wn.setParagraphTitle(o), Wn.addItemListToRootElement(n, t)
    }, Jn.prototype.hideParagraphUI = function() {
        var e = R({}, Wn.options),
            t = e.showFooter;
        e.showSearchBox || (null != (e = Wn.checkboxesContainerEle) && e.classList.remove("ot-hide"), null != (e = Wn.searchInputContainerEle) && e.classList.remove("ot-hide"), null != (e = Wn.listHotsVendorsContainerEle) && e.classList.remove("ot-hide")), t || null != (e = Wn.footerButtonContainerEle) && e.classList.remove("ot-hide"), Wn.rootEle.removeChild(Wn.paragraphContainerEle)
    }, Jn.prototype.addItemListToRootElement = function(e, t) {
        var o = document.querySelector("#onetrust-pc-sdk " + k.P_Vendor_List);
        Wn.rootEle = o.querySelector(this.MAIN_CONT_ELE), Wn.rootEle.appendChild(e), Wn.paragraphContainerEle = Wn.rootEle.querySelector(t)
    }, Jn.prototype.setParagraphTitle = function(e) {
        document.querySelector("#onetrust-pc-sdk " + k.P_Vendor_Title).innerHTML = v.getInnerHtmlContent(e)
    }, Jn.prototype.hideOtherHtmlElements = function(e) {
        var e = R({}, e),
            t = e.showFooter,
            e = e.showSearchBox,
            o = document.querySelector("#onetrust-pc-sdk " + k.P_Vendor_List),
            o = (!e && o && (Wn.checkboxesContainerEle = o.querySelector(this.SEL_BLK_ELE), Wn.searchInputContainerEle = o.querySelector(this.LST_SUBHDR_ELE), Wn.listHotsVendorsContainerEle = o.querySelector(this.SDK_ROW_ELE), null != (e = Wn.checkboxesContainerEle) && e.classList.add("ot-hide"), null != (o = Wn.searchInputContainerEle) && o.classList.add("ot-hide"), null != (e = Wn.listHotsVendorsContainerEle)) && e.classList.add("ot-hide"), document.querySelector("#onetrust-pc-sdk .ot-pc-footer .ot-btn-container"));
        !t && o && (Wn.footerButtonContainerEle = o, null != (e = Wn.footerButtonContainerEle)) && e.classList.add("ot-hide")
    };
    var Wn, Yn = Jn;

    function Jn() {
        this.SDK_ROW_ELE = ".ot-sdk-row", this.SEL_BLK_ELE = "#ot-sel-blk", this.MAIN_CONT_ELE = "#ot-lst-cnt", this.LST_SUBHDR_ELE = ".ot-lst-subhdr"
    }
    Zn.prototype.showIllustrations = function(e, t) {
        e = Xn.insertParagraphContainer(e, t), t = {
            showFooter: !1,
            showSearchBox: !1,
            listTitle: I.PCIllusText,
            htmlFragment: e,
            paragrphContainerSelector: "." + this.PARAGRAPH_CONTAINER_ELE
        };
        Wn.showParagraph(t)
    }, Zn.prototype.hideUI = function() {
        Wn.hideParagraphUI()
    }, Zn.prototype.addIllustrationsLink = function(e, t, o, n) {
        void 0 === n && (n = !1);
        var r = t.IabIllustrations && 0 < t.IabIllustrations.length;
        o && r && I.PCGrpDescType === re.UserFriendly && (o = I.PCVendorFullLegalText + "&nbsp;", (r = document.createElement("button")).classList.add("ot-link-btn"), r.classList.add("ot-pgph-link"), r.setAttribute("aria-label", I.PCVendorFullLegalText), r.setAttribute("data-parent-id", t.CustomGroupId), n ? (r.classList.add("ot-pgph-link-subgroup"), e.appendChild(r)) : (o = "&nbsp;|&nbsp" + o, e.insertAdjacentElement("afterend", r)), r.innerHTML = v.getInnerHtmlContent(o))
    }, Zn.prototype.insertParagraphContainer = function(e, t) {
        var o = document.createDocumentFragment(),
            n = document.createElement("div"),
            e = (n.classList.add(this.PARAGRAPH_CONTAINER_ELE), Xn.insertPurposeTitle(e)),
            r = (n.appendChild(e), document.createElement("div"));
        return r.classList.add("ot-paragraph-lst"), t.forEach(function(e, t) {
            e = Xn.insertDescriptionElement(e, t);
            r.appendChild(e)
        }), n.appendChild(r), o.appendChild(n), o
    }, Zn.prototype.insertPurposeTitle = function(e) {
        var t = document.createElement("h4"),
            e = (t.classList.add("ot-pgph-title"), document.createTextNode(e));
        return t.appendChild(e), t
    }, Zn.prototype.insertDescriptionElement = function(e, t) {
        var o = document.createElement("p");
        return o.setAttribute("id", "ot-pgph-desc-id-" + t), o.classList.add("ot-pgph-desc"), o.innerText = e, o
    };
    var Xn, Qn = Zn;

    function Zn() {
        this.PARAGRAPH_CONTAINER_ELE = "ot-pgph-contr"
    }
    r.prototype.insertPcHtml = function() {
        V.jsonAddAboutCookies(I);
        var t = document.createDocumentFragment(),
            e = (N.preferenceCenterGroup && (o = document.createElement("div"), T(o).html(N.preferenceCenterGroup.html), o = o.querySelector("#onetrust-pc-sdk"), V.addClassesPerConfig(o), T(t).append(o), V.manageCloseButtons(o, o = function(e) {
                return t.querySelectorAll(e)
            }, n = function(e) {
                return t.querySelector(e)
            }), I.Language && I.Language.Culture && T(n("#onetrust-pc-sdk")).attr("lang", I.Language.Culture), V.addLogos(n, o), T(n(k.P_Title)).html(I.MainText), I.PCCloseButtonType === Pe.Link && I.PCTemplateUpgrade && A.pcName === it && T(n(k.P_Title)).addClass("ot-pc-title-shrink"), I.PCTemplateUpgrade && T(n(cn + ' > div[role="dialog"]')).css("height: 100%;"), T(n(cn + ' > div[role="dialog"]')).attr(this._ariaLabel, I.MainText), I.PCRegionAriaLabel && (T(n("#onetrust-pc-sdk")).attr(this._ariaLabel, I.PCRegionAriaLabel), T(n("#onetrust-pc-sdk")).attr("role", "region")), A.pcName === it && (T(n(k.P_Privacy_Txt)).html(I.AboutCookiesText), T(n(k.P_Privacy_Hdr)).html(I.AboutCookiesText)), e = '<span class="ot-tcf2-vendor-count ot-text-bold tcf2-vcount">' + A.tcf2ActiveVendors.all.toString() + "</span>", e = h.replaceTextFromString("[VENDOR_NUMBER]", I.MainInfoText, e), T(n(k.P_Policy_Txt)).html(e), V.configureLinkFields(n), V.configureSubjectDataFields(n), V.configureButtons(n, o), V.setManagePreferenceText(n), V.initializePreferenceCenterGroups(n, t), V.removeListsWhenAppropriate(n), I.PCTemplateUpgrade) && V.setOptOutSignalNotification(n), document.createElement("iframe")),
            o = (e.setAttribute("class", "ot-text-resize"), e.setAttribute("sandbox", "allow-same-origin"), e.setAttribute("title", "onetrust-text-resize"), d(e, "position: absolute; top: -50000px; width: 100em;"), e.setAttribute(this._ariaHidden, "true"), T(t.querySelector("#onetrust-pc-sdk")).append(e), document.getElementById("onetrust-consent-sdk")),
            n = (T(o).append(t), A.ignoreInjectingHtmlCss || T(document.body).append(o), (I.showCookieList || L.showGeneralVendors) && Sn.InitializeHostList(), k.P_Vendor_List + " " + k.P_Host_Cntr + " li"),
            e = T(n).el[0];
        e && P.removeChild(e)
    }, r.prototype.addClassesPerConfig = function(e) {
        /Chrome|Safari/i.test(navigator.userAgent) && /Google Inc|Apple Computer/i.test(navigator.vendor) || T(e).addClass("ot-sdk-not-webkit"), I.useRTL && T(e).attr("dir", "rtl"), A.legIntSettings.PAllowLI && A.isIab2orv2Template && (T(e).addClass("ot-leg-opt-out"), A.legIntSettings.PShowLegIntBtn) && T(e).addClass("ot-leg-btn"), I.BannerRelativeFontSizesToggle && T(e).addClass("otRelFont"), I.PCShowConsentLabels && T(e).addClass("ot-tgl-with-label"), (I.UseGoogleVendors || L.showGeneralVendors) && T(e).addClass("ot-addtl-vendors"), "right" === I.PreferenceCenterPosition && T(e).addClass(I.useRTL ? "right-rtl" : "right")
    }, r.prototype.manageCloseButtons = function(e, t, o) {
        var n = T(t(k.P_Close_Btn)).el;
        if (I.ShowPreferenceCenterCloseButton) {
            I.CloseText || (I.CloseText = "Close Preference Center");
            for (var r = 0, i = n; r < i.length; r++) {
                var s = i[r];
                I.PCCloseButtonType === Pe.Link && I.PCTemplateUpgrade ? (T(s).html(I.PCContinueText), T(e).addClass("ot-close-btn-link"), T(s).el.removeAttribute(this._ariaLabel)) : (T(s).el.setAttribute(this._ariaLabel, I.CloseText), h.setCloseIcon(o("#onetrust-pc-sdk .ot-close-icon")))
            }
        } else
            for (var a = 0; a < n.length; a++) T(n[a].parentElement).el.removeChild(n[a])
    }, r.prototype.addLogos = function(e, t) {
        var o, n, e = e(k.P_Logo);
        e && I.optanonLogo && (o = h.updateCorrectUrl(I.optanonLogo), h.checkMobileOfflineRequest(h.getBannerVersionUrl()) && (o = P.getRelativeURL(o, !0, !0)), (n = document.createElement("img")).setAttribute("alt", I.PCLogoAria), n.setAttribute("src", o), e.append(n), I.PCLogoAria) && T(e).attr(this._ariaLabel, I.PCLogoAria), h.insertFooterLogo(t(".ot-pc-footer-logo a"))
    }, r.prototype.configureLinkFields = function(e) {
        var t;
        I.AboutText && T(e(k.P_Policy_Txt)).html(T(e(k.P_Policy_Txt)).html() + '\n            <br/><a href="' + I.AboutLink + '" class="privacy-notice-link" rel="noopener" target="_blank"\n                    aria-label="' + I.PCCookiePolicyLinkScreenReader + '">' + I.AboutText + "</a>"), I.PCenterImprintLinkText && (I.AboutText || e(k.P_Policy_Txt).insertAdjacentHTML("beforeend", v.getInnerHtmlContent("<br/>")), (t = document.createElement("a")).classList.add("ot-link-btn", "ot-imprint-handler"), t.textContent = I.PCenterImprintLinkText, t.setAttribute(this._ariaLabel, I.PCenterImprintLinkScreenReader), t.setAttribute("href", I.PCenterImprintLinkUrl), t.setAttribute("rel", "noopener"), t.setAttribute("target", "_blank"), e(k.P_Policy_Txt).appendChild(t)), I.PCenterVendorListLinkText && (t = !I.IsIabEnabled && L.showGeneralVendors ? "ot-gv-list-handler" : "onetrust-vendors-list-handler", e(k.P_Policy_Txt).insertAdjacentHTML("beforeend", v.getInnerHtmlContent('<button class="ot-link-btn ' + t + '" aria-label="' + I.PCenterVendorListLinkAriaLabel + '">\n                    ' + I.PCenterVendorListLinkText + "\n                    </button>")))
    }, r.prototype.configureSubjectDataFields = function(e) {
        var t;
        I.PCTemplateUpgrade && I.PCenterUserIdTitleText && I.IsConsentLoggingEnabled && (t = g.readCookieParam(C.OPTANON_CONSENT, u.CONSENT_ID), e(k.P_Policy_Txt).insertAdjacentHTML("beforeend", v.getInnerHtmlContent('<div class="ot-userid-title"><span>' + I.PCenterUserIdTitleText + ": </span> " + t + "</div>")), I.PCenterUserIdDescriptionText && e(k.P_Policy_Txt).insertAdjacentHTML("beforeend", v.getInnerHtmlContent('<div class="ot-userid-desc">' + I.PCenterUserIdDescriptionText + "</div>")), I.PCenterUserIdTimestampTitleText) && (t = (t = g.getCookie(C.ALERT_BOX_CLOSED)) && h.getUTCFormattedDate(t) || I.PCenterUserIdNotYetConsentedText, e(k.P_Policy_Txt).insertAdjacentHTML("beforeend", v.getInnerHtmlContent('<div class="ot-userid-timestamp"><span>' + I.PCenterUserIdTimestampTitleText + ": </span> " + t + "</div>")))
    }, r.prototype.setManagePreferenceText = function(e) {
        var e = e(k.P_Manage_Cookies_Txt),
            t = T(e);
        e && (t.html(I.ManagePreferenceText), I.ManagePreferenceText || P.removeChild(t.el))
    }, r.prototype.configureButtons = function(e, t) {
        I.ConfirmText.trim() ? T(e("#accept-recommended-btn-handler")).html(I.ConfirmText) : e("#accept-recommended-btn-handler").parentElement.removeChild(e("#accept-recommended-btn-handler"));
        for (var o = t(".save-preference-btn-handler"), n = 0; n < o.length; n++) T(o[n]).html(I.AllowAllText);
        var r = t(".ot-pc-refuse-all-handler");
        if (I.PCenterShowRejectAllButton && I.PCenterRejectAllButtonText.trim())
            for (n = 0; n < r.length; n++) T(r[n]).html(I.PCenterRejectAllButtonText);
        else P.removeChild(r)
    }, r.prototype.removeListsWhenAppropriate = function(e) {
        var t;
        I.IsIabEnabled || (t = e(k.P_Vendor_Container)) && t.parentElement.removeChild(t), I.showCookieList || L.showGeneralVendors || (t = e(k.P_Host_Cntr)) && t.parentElement.removeChild(t)
    }, r.prototype.setParentGroupName = function(e, t, o, n) {
        var r = e.querySelector(".category-header,.ot-cat-header,.category-menu-switch-handler>h3");
        T(r).html(t), T(r).attr("id", o), A.pcName === it && (e.querySelector(k.P_Category_Header).innerHTML = v.getInnerHtmlContent(t), e.querySelector("" + k.P_Desc_Container).setAttribute("id", n), e.querySelector(".category-menu-switch-handler").setAttribute("aria-controls", n))
    }, r.prototype.setLegIntButton = function(e, t, o, n) {
        void 0 === o && (o = !1);
        var r = !0,
            r = (-1 < L.vendors.selectedLegInt.indexOf(t.IabGrpId + ":false") && (r = !1), p.generateLegIntButtonElements(r, t.OptanonGroupId)),
            t = (o ? n.insertAdjacentHTML("afterend", r) : e.insertAdjacentHTML("beforeend", r), e.querySelector(".ot-remove-objection-handler"));
        t && d(t, t.getAttribute("data-style"))
    }, r.prototype.setParentGroupDescription = function(e, t, o, n, r) {
        var i = f.safeFormattedGroupDescription(t),
            s = e.querySelector("p:not(.ot-always-active)"),
            a = e.querySelector(k.P_Acc_Grp_Desc),
            s = s || a;
        return -1 < bt.indexOf(t.Type) && o.PCGrpDescType === re.Legal ? i = t.DescriptionLegal : s.classList.add("ot-category-desc"), A.legIntSettings.PAllowLI && !A.legIntSettings.PShowLegIntBtn && (t.SubGroups.some(function(e) {
            return e.HasLegIntOptOut
        }) || t.HasLegIntOptOut ? s.parentElement.classList.add("ot-leg-border-color") : P.removeChild(e.querySelector(k.P_Li_Hdr))), A.pcName !== it && s.setAttribute("id", n), T(s).html(i), t.Type === b.GroupTypes.Stack && P.removeChild(s), s
    }, r.prototype.cloneOtHtmlEls = function(e) {
        var t = /otPcPanel|otPcCenter/;
        _.toggleEl = T(e(".ot-tgl")).el.cloneNode(!0), _.arrowEl = T(e('#onetrust-pc-sdk [role="dialog"] > ' + k.P_Arrw_Cntr)).el.cloneNode(!0), _.subGrpEl = T(e(k.P_Sub_Grp_Cntr)).el.cloneNode(!0), _.vListEl = T(e(k.P_Ven_Lst_Cntr)).el.cloneNode(!0), _.cListEl = T(e(k.P_Host_Lst_cntr)).el.cloneNode(!0), _.chkboxEl = T(e(k.P_CBx_Cntr)).el.cloneNode(!0), _.accordionEl = T(e(".ot-acc-cntr")).el.cloneNode(!0), t.test(A.pcName) && (_.plusMinusEl = T(e(".ot-plus-minus")).el.cloneNode(!0)), P.removeChild(e(".ot-tgl")), P.removeChild(e('#onetrust-pc-sdk [role="dialog"] > ' + k.P_Arrw_Cntr)), P.removeChild(e(k.P_Sub_Grp_Cntr)), P.removeChild(e(k.P_Ven_Lst_Cntr)), P.removeChild(e(k.P_Host_Lst_cntr)), P.removeChild(e(k.P_CBx_Cntr)), P.removeChild(e(".ot-acc-cntr")), t.test(A.pcName) && P.removeChild(e(".ot-plus-minus"))
    }, r.prototype.insertSelectAllEls = function(e) {
        var e = e(k.P_Select_Cntr + " .ot-sel-all-chkbox"),
            t = L.showVendorService ? Bn() : _.chkboxEl.cloneNode(!0),
            t = (t.id = k.P_Sel_All_Host_El, t.querySelector("input").id = "select-all-hosts-groups-handler", t.querySelector("label").setAttribute("for", "select-all-hosts-groups-handler"), T(e).append(t), L.showVendorService ? Bn() : _.chkboxEl.cloneNode(!0)),
            t = (t.id = k.P_Sel_All_Vendor_Consent_El, t.querySelector("input").id = "select-all-vendor-groups-handler", t.querySelector("label").setAttribute("for", "select-all-vendor-groups-handler"), T(e).append(t), L.showVendorService ? Bn() : _.chkboxEl.cloneNode(!0));
        t.id = k.P_Sel_All_Vendor_Leg_El, t.querySelector("input").id = "select-all-vendor-leg-handler", t.querySelector("label").setAttribute("for", "select-all-vendor-leg-handler"), T(e).append(t)
    }, r.prototype.initializePreferenceCenterGroups = function(e, t) {
        var o, n = A.pcName,
            r = (m.isV2Template && (V.cloneOtHtmlEls(e), (r = _.chkboxEl.cloneNode(!0)).querySelector("input").classList.add("category-filter-handler"), T(e(k.P_Fltr_Modal + " " + k.P_Fltr_Option)).append(r), V.insertSelectAllEls(e)), T(e("#onetrust-pc-sdk " + k.P_Category_Grp))),
            i = (n === tt || n === nt || n === ot ? I.PCenterEnableAccordion ? P.removeChild(r.el.querySelector(k.P_Category_Item + ":not(.ot-accordion-layout)")) : P.removeChild(r.el.querySelector(k.P_Category_Item + ".ot-accordion-layout")) : n === it && (I.PCenterEnableAccordion = !1), e("#onetrust-pc-sdk " + k.P_Category_Item)),
            s = m.isV2Template ? _.subGrpEl.cloneNode(!0) : T(e(k.P_Sub_Grp_Cntr)),
            a = m.isV2Template ? null : T(e(k.P_Acc_Container + " " + k.P_Sub_Grp_Cntr));
        I.PCTemplateUpgrade && /otPcTab/.test(n) && (o = e(".ot-abt-tab").cloneNode(!0), P.removeChild(e(".ot-abt-tab"))), r.el.removeChild(i), V.setVendorListClass(e, i), V.setPCHeader(e, i), V.createHtmlForEachGroup({
            fm: e,
            fragment: t,
            categoryGroupTemplate: i,
            cookiePreferencesContainer: r,
            popupSubGrpContainer: a,
            subGrpContainer: s
        }), V.setPcTabLayout(e, t, o)
    }, r.prototype.getActiveVendorCount = function(e) {
        var t = parseInt(e.IabGrpId),
            o = 0;
        return e.Type === b.GroupTypes.Pur ? o = A.tcf2ActiveVendors.pur.get(t) : e.Type === b.GroupTypes.Ft ? o = A.tcf2ActiveVendors.ft.get(t) : e.Type === b.GroupTypes.Spl_Pur ? o = A.tcf2ActiveVendors.spl_pur.get(t) : e.Type === b.GroupTypes.Spl_Ft && (o = A.tcf2ActiveVendors.spl_ft.get(t)), o || 0
    }, r.prototype.getActiveVendorCountForStack = function(e) {
        return A.tcf2ActiveVendors.stack.get(e) || 0
    }, r.prototype.getVendorCountEl = function(e, t) {
        var o = "[VENDOR_NUMBER]",
            n = "";
        switch (t) {
            case St:
                n = I.PCVendorsCountFeatureText;
                break;
            case mt:
                n = I.PCVendorsCountSpcFeatureText;
                break;
            case ft:
                n = I.PCVendorsCountSpcPurposeText;
                break;
            default:
                n = I.PCVendorsCountText
        }
        return n && -1 < n.indexOf(o) ? '<span class="ot-pur-vdr-count"> ' + n.replace(o, e.toString()) + " </span>" : ""
    }, r.prototype.createHtmlForEachGroup = function(e) {
        var t = e.fm,
            o = e.fragment,
            n = e.categoryGroupTemplate,
            r = e.cookiePreferencesContainer,
            i = e.popupSubGrpContainer,
            s = e.subGrpContainer,
            e = I.Groups.filter(function(e) {
                return e.Order
            }),
            a = 0 === r.el.children.length;
        I.PCTemplateUpgrade && (L.showVendorService ? E.setHtmlTemplate(t('#onetrust-pc-sdk div[role="dialog"]')) : E.removeVSUITemplate(t('#onetrust-pc-sdk div[role="dialog"]')));
        for (var l = 0, c = e; l < c.length; l++) {
            var d = c[l],
                u = d.GroupName,
                p = d.CustomGroupId,
                u = V.appendVendorCountElement(d, u),
                C = n.cloneNode(!0),
                C = T(C).el,
                g = "ot-group-id-" + p,
                h = "ot-header-id-" + p,
                y = "ot-desc-id-" + p,
                f = "",
                p = (d.Status === S.ALWAYS_ACTIVE && (f = " ot-status-id-" + p), C.setAttribute("data-optanongroupid", p), C.querySelector("input,button")),
                p = (p && (p.setAttribute("aria-controls", y), p.setAttribute("aria-labelledby", h + f)), V.setParentGroupName(C, u, h, y), V.setPopupData(d, C), V.setParentGroupDescription(C, d, I, y, g)),
                f = (m.isV2Template ? V.setToggle(C, p, d, g, h) : V.setToggleProps(C, p, d, g, h), !!t("#onetrust-pc-sdk " + k.P_Category_Grp).querySelector(k.P_Category_Item)),
                u = (u = r.el.querySelectorAll(k.P_Category_Item + ":not(.ot-vnd-item)"))[u.length - 1],
                y = (a ? r.append(C) : f ? v.insertAfter(C, u) : v.insertAfter(C, r.el.querySelector(k.P_Li_Hdr) || r.el.querySelector("h3")), V.setSubGroupData(d, C, i, s), I.PCGrpDescLinkPosition === ie.Top),
                g = (d.Type === b.GroupTypes.Stack && y && (p = C.querySelector(k.P_Sub_Grp_Cntr)), y ? p : null);
            V.setVendorListBtn(C, t, o, d, g, I), V.setHostListBtn(C, t, o, d), V.setVendorServiceData(d, C), V.appendHealthSignatureFormToGroup(d, C), L.dataGroupState.push(d)
        }
    }, r.prototype.appendHealthSignatureFormToGroup = function(e, t) {
        var o;
        A.requireSignatureEnabled && e.needsHealthSignature && (o = k.P_Acc_Container, I.PCLayout.Tab && (o = "#ot-desc-id-" + e.CustomGroupId), t = t.querySelector(o), Fn.getInstance().getHealthSignatureComponent(t, e))
    }, r.prototype.appendVendorCountElement = function(e, t) {
        var o, n, r = -1 < e.SubGroups.findIndex(function(e) {
            return e.IsIabPurpose
        });
        return A.isTcfV2Template && (e.IsIabPurpose || r) && (n = void 0, n = e.Type !== b.GroupTypes.Stack && e.Type !== b.GroupTypes.Bundle && e.Type !== b.GroupTypes.Cookie ? this.getActiveVendorCount(e) : (o = "", o = !e.IsIabPurpose && r ? e.CustomGroupId : e.IabGrpId, this.getActiveVendorCountForStack(o)), t += this.getVendorCountEl(n, e.Type)), t
    }, r.prototype.setPopupData = function(e, t) {
        A.pcName === rt && (e.ShowVendorList && A.isIab2orv2Template ? (P.removeChild(t.querySelector("p:not(.ot-always-active)")), P.removeChild(t.querySelector(k.P_Acc_Txt + ":not(" + k.P_Acc_Container + ")")), e.SubGroups.length || m.isV2Template || P.removeChild(t.querySelector(k.P_Sub_Grp_Cntr))) : P.removeChild(t.querySelector(k.P_Acc_Container)))
    }, r.prototype.setVendorServiceData = function(e, t) {
        var o, n = A.pcName;
        L.showVendorService && I.VendorServiceConfig.PCVSCategoryView && (o = k.P_Acc_Txt, n === it && (o = k.P_Desc_Container), n = t.querySelector(o), I.PCAccordionStyle === ce.NoAccordion && (n = t), E.insertVendorServiceHtml(e, n))
    }, r.prototype.jsonAddAboutCookies = function(e) {
        var t = {};
        return t.GroupName = e.AboutCookiesText, t.GroupDescription = e.MainInfoText, t.ShowInPopup = !0, t.Order = 0, t.IsAboutGroup = !0, t
    }, r.prototype.setVendorListBtn = function(e, t, o, n, r, i) {
        var s, a, l = A.pcName;
        n.ShowVendorList ? (s = a = void 0, m.isV2Template ? a = (s = _.vListEl.cloneNode(!0)).querySelector(".category-vendors-list-handler") : s = (a = e.querySelector(".category-vendors-list-handler")).parentElement, a.innerHTML = v.getInnerHtmlContent(i.VendorListText + "&#x200E;"), a.setAttribute(this._ariaLabel, I.PCOpensVendorDetailsAlert), a.setAttribute("data-parent-id", n.CustomGroupId), V.setIABLegalLink(a, n, i), m.isV2Template && (a = e, l === it ? a = e.querySelector("" + k.P_Desc_Container) : i.PCenterEnableAccordion && (a = e.querySelector(k.P_Acc_Txt)), a.insertAdjacentElement("beforeend", s)), r && r.insertAdjacentElement("beforebegin", s)) : m.isV2Template || (l !== nt && l !== tt || i.PCenterEnableAccordion ? (l === rt || l === nt || l === tt && i.PCenterEnableAccordion) && (n = t("#vendor-list-container"), a = e.querySelector(k.P_Acc_Txt), n && o.querySelector("" + k.P_Content).removeChild(n), m.isV2Template || T(a).el.removeChild(a.querySelector(k.P_Ven_Lst_Cntr))) : P.removeChild(e.querySelector(k.P_Ven_Lst_Cntr)), l !== it && l !== ot) || (r = e.querySelector(k.P_Ven_Lst_Cntr)) && r.parentElement.removeChild(r)
    }, r.prototype.setIABLegalLink = function(e, t, o) {
        A.isTcfV2Template ? Xn.addIllustrationsLink(e, t, t.ShowVendorList) : o.PCGrpDescType === re.UserFriendly && (e.insertAdjacentHTML("afterend", v.getInnerHtmlContent("<span class='ot-ext-lnk'></span>")), e.insertAdjacentHTML("afterend", v.getInnerHtmlContent("<a href='" + I.IabLegalTextUrl + "?lang=" + L.consentLanguage + "'\n                        rel=\"noopener\" target='_blank'>&nbsp;|&nbsp;" + o.PCVendorFullLegalText + '&nbsp;<span class="ot-scrn-rdr">\n                        ' + I.NewWinTxt + "</span></a>")))
    }, r.prototype.setHostListBtn = function(e, t, o, n) {
        var r, i = A.pcName,
            s = !1,
            a = (I.showCookieList && (s = -1 < P.findIndex(U(n.SubGroups, [n]), function(e) {
                return -1 === vt.indexOf(e.Type) && e.FirstPartyCookies.length
            })), L.showGeneralVendors && n.GeneralVendorsIds && n.GeneralVendorsIds.length);
        !L.showVendorService && (I.showCookieList || L.showGeneralVendors) && (n.ShowHostList || s || a) ? (s = void 0, m.isV2Template ? (s = (a = _.cListEl.cloneNode(!0)).querySelector(".category-host-list-handler"), r = e, i === it ? r = e.querySelector("" + k.P_Desc_Container) : I.PCenterEnableAccordion && (r = e.querySelector(k.P_Acc_Txt)), r.insertAdjacentElement("beforeend", a)) : s = e.querySelector(".category-host-list-handler"), V.setcListHandler(s, n)) : V.setHostListVendorList(t, o, e)
    }, r.prototype.setcListHandler = function(e, t) {
        var o, n;
        e && (o = (n = V.setcListHeaderTitleAndScreenReader())[0], n = n[1], e.innerHTML = v.getInnerHtmlContent(o + "&#x200E;"), e.setAttribute(this._ariaLabel, n), e.setAttribute("data-parent-id", t.CustomGroupId))
    }, r.prototype.setcListHeaderTitleAndScreenReader = function() {
        var e, t = L.showTrackingTech ? (e = I.AdditionalTechnologiesConfig.PCTechDetailsText, I.AdditionalTechnologiesConfig.PCTechDetailsAriaLabel) : L.showGeneralVendors ? (e = I.GroupGenVenListLabel, I.PCenterVendorListScreenReader) : (e = I.ThirdPartyCookieListText, I.PCOpensCookiesDetailsAlert);
        return [e, t]
    }, r.prototype.setHostListVendorList = function(e, t, o) {
        var n;
        A.pcName === rt ? (e = e("#vendor-list-container"), n = o.querySelector(k.P_Acc_Txt), e && t.querySelector("" + k.P_Content).removeChild(e), n.querySelector(k.P_Host_Lst_cntr) && T(n).el.removeChild(n.querySelector(k.P_Host_Lst_cntr))) : (t = o.querySelector(k.P_Host_Lst_cntr)) && t.parentElement.removeChild(t)
    }, r.prototype.setSubGroupData = function(e, t, o, n) {
        var r;
        0 < e.SubGroups.length && e.ShowSubgroup && (r = A.pcName === rt && e.ShowVendorList && A.isIab2orv2Template && !I.PCTemplateUpgrade, V.setSubGrps(e, r ? o : n, t, I))
    }, r.prototype.setSubGrps = function(t, o, n, r) {
        var e;
        A.pcName === rt && t.ShowVendorList && A.isIab2orv2Template && !I.PCTemplateUpgrade && (e = n.querySelector(k.P_Sub_Grp_Cntr)).parentElement.removeChild(e), t.SubGroups.forEach(function(e) {
            V.setSubGroups({
                group: t,
                subgroup: e,
                grpEl: n,
                subGrpEl: o,
                json: r
            })
        })
    }, r.prototype.setSubGroups = function(e) {
        var t, o = e.group,
            n = e.subgroup,
            r = e.grpEl,
            i = e.subGrpEl,
            e = e.json,
            s = A.pcName,
            a = V.getRemoveConsentToggle(n),
            i = (m.isV2Template ? i : i.el).cloneNode(!0),
            l = i.querySelector(k.P_Subgp_ul),
            c = i.querySelector(k.P_Subgrp_li).cloneNode(!0),
            d = n.CustomGroupId,
            u = "ot-sub-group-id-" + d,
            p = y.getGrpStatus(n).toLowerCase(),
            C = c.querySelector(".cookie-subgroup>h4, .cookie-subgroup>h5, .cookie-subgroup>h6, .ot-subgrp>h4, .ot-subgrp>h5, .ot-subgrp>h6"),
            g = c.querySelector(k.P_Tgl_Cntr),
            d = (c.setAttribute("data-optanongroupid", d), m.isV2Template ? ((t = V.getInputEle()).querySelector("input").setAttribute("data-optanongroupid", d), t.querySelector("input").classList.add("cookie-subgroup-handler"), t = t.cloneNode(!0), g.insertAdjacentElement("beforeend", t)) : (t = c.querySelector(".ot-toggle")).querySelector("input").setAttribute("data-optanongroupid", d), T(i.querySelector(k.P_Subgp_ul)).html(""), V.addSubgroupName(n, C), V.setDataIfVendorServiceEnabled(C, c, t), t.querySelector("input").setAttribute("id", u), t.querySelector("input").setAttribute(this._ariaLabel, n.GroupName), t.querySelector("label").setAttribute("for", u), V.setSubGroupDescription({
                json: e,
                group: o,
                subgroup: n,
                subGroupClone: c
            }), A.isTcfV2Template && Xn.addIllustrationsLink(c, n, o.ShowVendorList, !0), U(Pt, Tt));
        o.ShowSubgroupToggle && -1 < d.indexOf(n.Type) ? V.setSubGroupToggle({
            id: u,
            subGroupClone: c,
            group: o,
            subgroup: n,
            toggleGroup: g
        }) : p === S.ALWAYS_ACTIVE && (o.ShowSubgroupToggle || -1 === kt.indexOf(n.Type)) || (a = !0), V.setSubGroupsProperties({
            removeConsentToggle: a,
            subGroupToggle: t,
            subGroupClone: c,
            status: p,
            subgroup: n,
            grpEl: r,
            pcName: s,
            json: e,
            subGrpElClone: i,
            ulParentContainerEle: l
        })
    }, r.prototype.getRemoveConsentToggle = function(e) {
        var t = !1;
        return t = A.isIab2orv2Template && e.Type === b.GroupTypes.Pur && !e.HasConsentOptOut ? !0 : t
    }, r.prototype.addSubgroupName = function(e, t) {
        var o, n = e.GroupName;
        A.isTcfV2Template && e.IsIabPurpose && (o = this.getActiveVendorCount(e), n += this.getVendorCountEl(o, e.Type)), T(t).html(n)
    }, r.prototype.setDataIfVendorServiceEnabled = function(e, t, o) {
        var n;
        L.showVendorService && ((n = document.createElement("div")).classList.add("ot-acc-hdr"), e.classList.add("ot-cat-header"), n.appendChild(e), e = "afterbegin", I.PCCategoryStyle === ve.Toggle && (e = "beforeend"), n.insertAdjacentElement(e, o), t.removeChild(t.querySelector(k.P_Subgrp_Tgl_Cntr)), t.insertAdjacentElement("afterbegin", n))
    }, r.prototype.setSubGroupDescription = function(e) {
        var t, o = e.json,
            n = e.group,
            r = e.subgroup,
            e = e.subGroupClone,
            i = A.pcName,
            s = o.PCGrpDescType === re.Legal,
            i = i === rt && n.ShowVendorList && A.isIab2orv2Template,
            a = T(e.querySelector(k.P_Subgrp_Desc));
        i ? (t = r.DescriptionLegal && s ? r.DescriptionLegal : r.GroupDescription, a.html(t)) : (t = f.safeFormattedGroupDescription(r), i = !1, -1 < bt.indexOf(r.Type) && s && (i = !0, t = r.DescriptionLegal), o.PCenterEnableAccordion && i || (a = T(e.querySelector("p"))), n.ShowSubGroupDescription ? a.html(t) : a.html(""))
    }, r.prototype.setSubGroupToggle = function(e) {
        var t = e.id,
            o = e.subGroupClone,
            n = e.group,
            r = e.subgroup,
            e = e.toggleGroup,
            i = f.isGroupActive(r),
            n = (V.setSubGroupActive({
                group: n,
                subgroup: r,
                subGroupClone: o
            }, i), e.querySelector(".ot-label-status"));
        I.PCShowConsentLabels ? n.innerHTML = v.getInnerHtmlContent(i ? I.PCActiveText : I.PCInactiveText) : P.removeChild(n), A.legIntSettings.PAllowLI && r.Type === b.GroupTypes.Pur && r.HasLegIntOptOut && (A.legIntSettings.PShowLegIntBtn ? V.setLegIntButton(o, r) : (i = e.cloneNode(!0), e.insertAdjacentElement("afterend", i), n = i.querySelector(".ot-label-status"), (o = i.querySelector("input")).setAttribute("id", t + "-leg-out"), i.querySelector("label").setAttribute("for", t + "-leg-out"), r.IsLegIntToggle = !0, e = f.isGroupActive(r), I.PCShowConsentLabels ? n.innerHTML = v.getInnerHtmlContent(e ? I.PCActiveText : I.PCInactiveText) : P.removeChild(n), P.setCheckedAttribute(null, o, e), r.IsLegIntToggle = !1))
    }, r.prototype.setSubGroupActive = function(e, t) {
        var o;
        t && (t = e.group, o = e.subgroup, e = e.subGroupClone, t = y.getGrpStatus(t).toLowerCase(), e.querySelector("input").setAttribute("checked", ""), t === S.ALWAYS_ACTIVE) && -1 === bt.indexOf(o.Type) && (e.querySelector("input").disabled = !0, e.querySelector("input").setAttribute("disabled", "true"))
    }, r.prototype.setSubGroupsProperties = function(e) {
        var t = e.removeConsentToggle,
            o = e.subGroupToggle,
            n = e.subGroupClone,
            r = e.status,
            i = e.subgroup,
            s = e.grpEl,
            a = e.pcName,
            l = e.json,
            c = e.subGrpElClone,
            e = e.ulParentContainerEle;
        t && (o.classList.add("ot-hide-tgl"), o.querySelector("input").setAttribute(this._ariaHidden, "true")), r !== S.ALWAYS_ACTIVE && r !== S.ALWAYS_INACTIVE || t || (o && o.parentElement.removeChild(o), (t = n.querySelector(k.P_Tgl_Cntr)) && t.classList.add("ot-always-active-subgroup"), V.setAlwaysActive(n, !0, r === S.ALWAYS_INACTIVE)), "COOKIE" === i.Type && -1 !== i.Parent.indexOf("STACK") && d(c, "display: none;"), T(e).append(n), m.isV2Template ? (o = s, "otPcTab" === a ? o = s.querySelector("" + k.P_Desc_Container) : l.PCenterEnableAccordion && (o = s.querySelector(k.P_Acc_Txt)), o.insertAdjacentElement("beforeend", c)) : (t = s.querySelector(k.P_Category_Item + " " + k.P_Ven_Lst_Cntr)) && t.insertAdjacentElement("beforebegin", c), L.showVendorService && I.VendorServiceConfig.PCVSCategoryView && E.insertVendorServiceHtml(i, e)
    }, r.prototype.getInputEleForCategory = function(e) {
        return L.showVendorService && I.PCCategoryStyle === ve.Checkbox && e.classList.add("ot-checkbox-consent"), V.getInputEle()
    }, r.prototype.getInputEle = function() {
        return !A.isIab2orv2Template && I.PCTemplateUpgrade ? Bn() : _.toggleEl.cloneNode(!0)
    }, r.prototype.setToggle = function(e, t, o, n, r) {
        var i = V.getInputEleForCategory(e),
            s = (i.querySelector("input").classList.add("category-switch-handler"), i.querySelector("input")),
            a = e.querySelector(k.P_Category_Header),
            l = f.isGroupActive(o),
            c = [S.ALWAYS_ACTIVE, S.ALWAYS_INACTIVE].includes(y.getGrpStatus(o).toLowerCase()),
            d = o.OptanonGroupId.toString(),
            u = b.GroupTypes,
            p = !0;
        !A.isIab2orv2Template || o.Type !== u.Pur && o.Type !== u.Stack || o.HasConsentOptOut || (p = !1), T(i.querySelector("label")).attr("for", n), T(i.querySelector(".ot-label-txt")).html(o.GroupName);
        A.legIntSettings.PAllowLI && o.Type === u.Pur && o.HasLegIntOptOut && (A.legIntSettings.PShowLegIntBtn ? V.setLegIntButton(e, o, !0, t) : (u = i.cloneNode(!0), o.IsLegIntToggle = !0, t = f.isGroupActive(o), C = u.querySelector(".ot-label-status"), I.PCShowConsentLabels ? C.innerHTML = v.getInnerHtmlContent(t ? I.PCActiveText : I.PCInactiveText) : P.removeChild(C), o.IsLegIntToggle = !1, f.setInputID(u.querySelector("input"), n + "-leg-out", d, t, r), T(u.querySelector("label")).attr("for", n + "-leg-out"), a.insertAdjacentElement("afterend", u)));
        var C = i.querySelector(".ot-label-status"),
            d = (I.PCShowConsentLabels ? C.innerHTML = v.getInnerHtmlContent(l ? I.PCActiveText : I.PCInactiveText) : P.removeChild(C), I.PCCategoryStyle === ve.Toggle);
        this.hideToggleContainer(c, p, d, i), p && this.setAlwaysActiveOrToggleInput(o, e, i, s, n, r), V.setNoAccordionHeader(e, c)
    }, r.prototype.setNoAccordionHeader = function(e, t) {
        var o, n, r, i;
        !A.isIab2orv2Template && I.PCTemplateUpgrade && (o = I.PCCategoryStyle === ve.Checkbox, I.PCAccordionStyle === ce.NoAccordion) && o && ((o = document.createElement("div")).classList.add("ot-acc-hdr"), n = e.querySelector(".ot-chkbox"), r = e.querySelector(".ot-always-active"), i = e.querySelector(k.P_Category_Header), n && o.appendChild(n), o.appendChild(i), t && o.appendChild(r), e.insertBefore(o, e.firstChild))
    }, r.prototype.hideToggleContainer = function(e, t, o, n) {
        !e && t || !o || (n.classList.add("ot-hide-tgl"), n.querySelector("input").setAttribute(this._ariaHidden, "true"))
    }, r.prototype.setAlwaysActiveOrToggleInput = function(e, t, o, n, r, i) {
        var s = "always active" === y.getGrpStatus(e).toLowerCase(),
            a = "always inactive" === y.getGrpStatus(e).toLowerCase(),
            l = I.PCCategoryStyle === ve.Toggle,
            c = e.OptanonGroupId.toString(),
            e = f.isGroupActive(e),
            d = t.querySelector(k.P_Category_Header);
        !A.isIab2orv2Template && I.PCTemplateUpgrade ? ((s || a) && I.PCShowAlwaysActiveToggle && (V.setAlwaysActive(t, !1, a), o.querySelector("input").setAttribute("disabled", "true")), s && l || V.insertAccordionInputHeader(d, o), f.setInputID(n, r, c, e, i), V.insertAccordionPointer(t, d)) : (V.insertAccordionPointer(t, d), s || a ? I.PCShowAlwaysActiveToggle && V.setAlwaysActive(t, !1, a) : (V.insertAccordionInputHeader(d, o), f.setInputID(n, r, c, e, i)))
    }, r.prototype.setOptOutSignalVisibility = function(e) {
        var t = A.gpcEnabled && A.gpcForAGrpEnabled,
            o = p.isAlertBoxClosedAndValid() && f.isAnyGroupOptedOut();
        I.PCShowOptOutSignal && (t || o || A.previewMode) ? e.classList.remove("ot-hide") : e.classList.add("ot-hide")
    }, r.prototype.setOptOutSignalNotification = function(e) {
        e = h.createOptOutSignalElement(e, !0);
        V.setOptOutSignalVisibility(e)
    }, r.prototype.insertAccordionInputHeader = function(e, t) {
        var o = V.getPositionForInputEle();
        e.insertAdjacentElement(o, t)
    }, r.prototype.getPositionForInputEle = function() {
        var e = "beforebegin";
        return e = !A.isIab2orv2Template && I.PCTemplateUpgrade && I.PCCategoryStyle !== ve.Toggle ? e : "afterend"
    }, r.prototype.insertAccordionPointer = function(e, t) {
        var o, n;
        e.classList.add("ot-vs-config"), I.PCenterEnableAccordion && (!A.isIab2orv2Template && I.PCTemplateUpgrade ? (e = e.querySelector(k.P_Acc_Header), o = n = void 0, n = (I.PCAccordionStyle === ce.Caret ? (o = "beforeend", _.arrowEl) : (o = I.PCCategoryStyle === ve.Checkbox ? "beforeend" : "afterbegin", _.plusMinusEl)).cloneNode(!0), e.insertAdjacentElement(o, n)) : I.PCAccordionStyle === ce.Caret ? t.insertAdjacentElement("afterend", _.arrowEl.cloneNode(!0)) : t.insertAdjacentElement("beforebegin", _.plusMinusEl.cloneNode(!0)))
    }, r.prototype.setToggleProps = function(e, t, o, n, r) {
        var i = e.querySelectorAll("input:not(.cookie-subgroup-handler)"),
            s = e.querySelectorAll("label"),
            a = f.isGroupActive(o),
            l = o.CustomGroupId,
            c = e.querySelector(".label-text");
        c && T(c).html(o.GroupName);
        for (var d, u, p, C, g = 0; g < i.length; g++) s[g] && T(s[g]).attr("for", n), 2 <= i.length && 0 === g ? T(i[g]).attr("id", n + "-toggle") : (d = this.canShowConsentToggle(o), this.canShowLegIntToggle(o) && (A.legIntSettings.PShowLegIntBtn ? V.setLegIntButton(e, o, !0, t) : (C = (u = e.querySelector(k.P_Tgl_Cntr + ":not(" + k.P_Subgrp_Tgl_Cntr + ")") || e.querySelector(".ot-toggle")).cloneNode(!0), u.insertAdjacentElement("afterend", C), u = C.querySelector("input"), o.IsLegIntToggle = !0, p = f.isGroupActive(o), o.IsLegIntToggle = !1, f.setInputID(u, n + "-leg-out", l, p, r), T(C.querySelector("label")).attr("for", n + "-leg-out"), P.removeChild(C.querySelector(k.P_Arrw_Cntr)))), u = y.getGrpStatus(o).toLowerCase() === S.ALWAYS_ACTIVE, p = y.getGrpStatus(o).toLowerCase() === S.ALWAYS_INACTIVE, !u && d || (C = i[g].closest(".ot-toggle")) && (C.classList.add("ot-hide-tgl"), C.querySelector("input").setAttribute(this._ariaHidden, !0)), d && (u && V.setAlwaysActive(e, !1, p), f.setInputID(i[g], n, l, a, r)))
    }, r.prototype.canShowConsentToggle = function(e) {
        var t = !0,
            o = b.GroupTypes;
        return t = !A.isIab2orv2Template || e.Type !== o.Pur && e.Type !== o.Stack || e.HasConsentOptOut ? t : !1
    }, r.prototype.canShowLegIntToggle = function(e) {
        var t = b.GroupTypes;
        return A.legIntSettings.PAllowLI && e.Type === t.Pur && e.HasLegIntOptOut
    }, r.prototype.setAlwaysActive = function(e, t, o) {
        void 0 === t && (t = !1), void 0 === o && (o = !1);
        var n, r = A.pcName;
        r === rt || r === it || t ? (r = e.querySelector(k.P_Tgl_Cntr)) && r.insertAdjacentElement("afterbegin", T("<div class='ot-always-active'>" + (o ? I.AlwaysInactiveText : I.AlwaysActiveText) + "</div>", "ce").el) : (r = "ot-status-id-" + (r = null == (n = r = (t = e.querySelector(k.P_Category_Header)).id) ? void 0 : n.split("-")[3]), !m.isV2Template && I.PCenterEnableAccordion && (r = "ot-status-id-" + (r = null == (n = r = (t = e.querySelector(k.P_Arrw_Cntr)).id) ? void 0 : n.split("-")[3])), T(t).el.insertAdjacentElement("afterend", T('<div id="' + r + "\" class='ot-always-active'>" + (o ? I.AlwaysInactiveText : I.AlwaysActiveText) + "</div>", "ce").el)), I.PCenterEnableAccordion ? (n = e.querySelector(k.P_Acc_Header)) && n.classList.add("ot-always-active-group") : ((t = e.querySelector("" + k.P_Desc_Container)) && t.classList.add("ot-always-active-group"), e.classList.add("ot-always-active-group"))
    }, r.prototype.setPcTabLayout = function(e, t, o) {
        var n = e(".ot-tab-desc");
        "otPcTab" === A.pcName && (o && e("#onetrust-pc-sdk " + k.P_Category_Grp).insertAdjacentElement("afterbegin", o), n && 640 < window.innerWidth && T(n).append(t.querySelectorAll("#onetrust-pc-sdk " + k.P_Desc_Container)), I.IsIabEnabled ? e(k.P_Desc_Container + " .category-vendors-list-handler").innerHTML = v.getInnerHtmlContent(I.VendorListText + "&#x200E;") : (o = e(k.P_Desc_Container + " .category-vendors-list-handler")) && o.parentElement.removeChild(o))
    }, r.prototype.setVendorListClass = function(e, t) {
        m.isV2Template ? I.PCAccordionStyle === ce.Caret && (T(e("#onetrust-pc-sdk " + k.P_Vendor_List)).addClass("ot-enbl-chr"), I.PCenterEnableAccordion) && T(e("#onetrust-pc-sdk " + k.P_Content)).addClass("ot-enbl-chr") : T(t.querySelector(k.P_Sub_Grp_Cntr)).remove()
    }, r.prototype.setPCHeader = function(e, t) {
        var o = A.pcName,
            n = e(k.P_Li_Hdr) || t.querySelector(k.P_Li_Hdr);
        A.legIntSettings.PAllowLI && A.grpContainLegalOptOut && A.isIab2orv2Template && !A.legIntSettings.PShowLegIntBtn ? (n.querySelector("span:first-child").innerText = I.ConsentText, n.querySelector("span:last-child").innerText = I.LegitInterestText, m.isV2Template && (n.querySelector("span:first-child").innerText = I.PCenterConsentText, n.querySelector("span:last-child").innerText = I.PCenterLegIntColumnHeader), I.PCenterEnableAccordion && n ? n.classList.add("ot-leg-border-color") : "otPcList" === o && t.insertAdjacentElement("afterbegin", n)) : (P.removeChild(e("#onetrust-pc-sdk " + k.P_Li_Hdr)), P.removeChild(t.querySelector(k.P_Li_Hdr)))
    };
    var V, $n = r;

    function r() {
        this._ariaHidden = "aria-hidden", this._ariaLabel = "aria-label"
    }
    or.prototype.showBanner = function() {
        var e = A.bannerName,
            t = T(this.El);
        L.skipAddingHTML && "none" === getComputedStyle(t.el[0]).getPropertyValue("display") && e !== Je && e !== Ye && e !== Ze ? t.css("display: block;") : I.BAnimation === Te.SlideIn ? this.slideInAnimation(t, e) : I.BAnimation === Te.FadeIn && t.addClass("ot-fade-in")
    }, or.prototype.insertAlertHtml = function() {
        I.IsGPPEnabled && ps.setCmpDisplayStatus("visible");

        function e(e) {
            return t.querySelector(e)
        }
        var t = document.createDocumentFragment(),
            o = document.createElement("div"),
            o = (T(o).html(N.bannerGroup.html), o.querySelector("#onetrust-banner-sdk"));
        this.setAriaModalForBanner(o), m.fp.CookieV2SSR ? (T(t).append(o), this.setBannerLinkAttributes(e), this._rejectBtn = e("#onetrust-reject-all-handler"), this._acceptBtn = e("#onetrust-accept-btn-handler")) : this.insertHtmlForNonSSRFlow(o, t, e, function(e) {
            return t.querySelectorAll(e)
        }), this.ssrAndNonSSRCommonHtml(t)
    }, or.prototype.insertHtmlForNonSSRFlow = function(e, t, o, n) {
        var r, i, s = A.bannerName;
        N.bannerGroup && (I.BannerRelativeFontSizesToggle && T(e).addClass("otRelFont"), (I.BInitialFocus || I.BInitialFocusLinkAndButton) && e.setAttribute("tabindex", "0"), I.useRTL && T(e).attr("dir", "rtl"), A.isIab2orv2Template && I.BannerDPDDescription.length && T(e).addClass("ot-iab-2"), (r = I.BannerPosition) && ("bottom-left" === r ? T(e).addClass("ot-bottom-left") : "bottom-right" === r ? T(e).addClass("ot-bottom-right") : T(e).addClass(r)), T(t).append(e), this.setBannerData(o), r = this.setIAB2HtmlData(o), this.setAcceptAndRejectBtnHtml(o), t = this.htmlForBannerButtons(e, o, n), n = I.showBannerCloseButton, i = I.BCloseButtonType === Pe.Link, this.setWidthForFlatBanner(o, r, t), n && s === Xe && A.isIab2orv2Template && !i && ((t = o(".banner-close-btn-container")).parentElement.removeChild(t), T(e).el.insertAdjacentElement("beforeEnd", t), T(o("#onetrust-banner-sdk .ot-sdk-container")).addClass("ot-top-cntr")), this.setBannerOptions(o, r), this.setBannerLogo(e, o))
    }, or.prototype.setBannerOptions = function(e, t) {
        var o = this,
            n = A.bannerName,
            r = this.isCmpEnabled(),
            i = [{
                type: "purpose",
                titleKey: "BannerPurposeTitle",
                descriptionKey: "BannerPurposeDescription",
                identifier: "purpose-option"
            }, {
                type: "feature",
                titleKey: "BannerFeatureTitle",
                descriptionKey: "BannerFeatureDescription",
                identifier: "feature-option"
            }, {
                type: "information",
                titleKey: "BannerInformationTitle",
                descriptionKey: "BannerInformationDescription",
                identifier: "information-option"
            }],
            s = T(e(this._bannerOptionsSelector)).el;
        r ? (n === Qe ? this.setFloatingRoundedIconBannerCmpOptions(e, i) : (this.setCmpBannerOptions(e, i), n === $e && t.el.insertAdjacentElement("beforeend", s)), T(window).on("resize", function() {
            window.innerWidth <= 896 && o.setBannerOptionContent()
        })) : (A.bannerName === Xe && (s = T(e(".banner-options-card")).el), P.removeChild(s))
    }, or.prototype.setWidthForFlatBanner = function(e, t, o) {
        var n = A.bannerName,
            r = I.showBannerCloseButton,
            i = this.hasNoActionButtons();
        n === Ye && (A.isIab2orv2Template && (t.removeClass("ot-sdk-eight"), I.showBannerAcceptButton && o.insertAdjacentElement("afterbegin", this._acceptBtn), I.showBannerCookieSettings) && o.insertAdjacentElement("beforeend", e("#onetrust-pc-btn-handler")), r && !i && A.isIab2orv2Template ? t.addClass("ot-sdk-nine") : r && i ? t.addClass("ot-sdk-eleven") : !r && i ? t.addClass("ot-sdk-twelve") : r || i || !A.isIab2orv2Template || (t.addClass("ot-sdk-ten"), T(e(this._btnGrpParentSelector)).addClass("ot-sdk-two"), T(e(this._btnGrpParentSelector)).removeClass("ot-sdk-three")))
    }, or.prototype.hasNoActionButtons = function() {
        var e = !I.showBannerAcceptButton && !I.showBannerCookieSettings && !I.BannerShowRejectAllButton;
        return A.bannerName === $e ? e && !I.BShowSaveBtn : e
    }, or.prototype.htmlForBannerButtons = function(e, t, o) {
        var n = A.bannerName,
            r = (this.hasNoActionButtons() && t(this._btnGrpParentSelector).parentElement.removeChild(t(this._btnGrpParentSelector)), I.showBannerCloseButton),
            i = T(o(".banner-close-button")).el,
            s = t("#onetrust-button-group"),
            a = I.BCloseButtonType === Pe.Link;
        if (r)
            for (l = 0; l < i.length; l++) a ? (T(i[l]).html(I.BContinueText), T(e).addClass("ot-close-btn-link"), T(i[l]).addClass("ot-close-link"), T(i[l]).removeClass("onetrust-close-btn-ui"), T(i[l]).removeClass("ot-close-icon"), n !== Xe && n !== Qe || (s.insertAdjacentElement("afterbegin", t(".onetrust-close-btn-handler").parentElement), T(i[l]).attr("tabindex", "1"))) : (h.setCloseIcon(t("#onetrust-banner-sdk .ot-close-icon")), T(i[l]).el.setAttribute(Ct, I.BannerCloseButtonText || "Close Cookie Banner"));
        else {
            for (var l = 0; l < i.length; l++) T(i[l].parentElement).el.removeChild(i[l]);
            n !== Ye && n !== Qe || P.removeChild(t("#onetrust-close-btn-container-mobile"))
        }
        return s
    }, or.prototype.setAcceptAndRejectBtnHtml = function(e) {
        var t = A.bannerName,
            e = (I.showBannerAcceptButton ? (this._acceptBtn = e("#onetrust-accept-btn-handler"), T(this._acceptBtn).html(I.AlertAllowCookiesText), t !== Ze || I.showBannerCookieSettings || I.BannerShowRejectAllButton || T(this._acceptBtn.parentElement).addClass("accept-btn-only")) : P.removeChild(e("#onetrust-accept-btn-handler")), I.BannerShowRejectAllButton && I.BannerRejectAllButtonText.trim() ? (this._rejectBtn = e("#onetrust-reject-all-handler"), T(this._rejectBtn).html(I.BannerRejectAllButtonText), e(this._btnGrpParentSelector).classList.add("has-reject-all-button")) : (P.removeChild(e("#onetrust-reject-all-handler")), P.removeChild(e("#onetrust-reject-btn-container"))), T(e("#onetrust-pc-btn-handler")));
        I.showBannerCookieSettings ? (e.html(I.AlertMoreInfoText), I.BannerSettingsButtonDisplayLink && e.addClass("cookie-setting-link"), t !== Ze || I.showBannerAcceptButton || e.addClass("cookie-settings-btn-only")) : P.removeChild(e.el)
    }, or.prototype.setIAB2HtmlData = function(e) {
        var t = A.bannerName,
            o = (A.isIab2orv2Template && I.BannerDPDDescription.length && t !== $e ? (T(e(".ot-dpd-container .ot-dpd-title")).html(I.BannerDPDTitle), T(e(".ot-dpd-container .ot-dpd-desc")).html(I.BannerDPDDescription.join(",&nbsp;"))) : P.removeChild(e(".ot-dpd-container")), T(e(this._otGrpContainerSelector))),
            t = (A.isIab2orv2Template && I.BannerAdditionalDescription.trim() && this.setAdditionalDesc(e), A.isIab2orv2Template && I.BannerDPDDescription.length ? t !== $e ? T(e(".ot-dpd-container .ot-dpd-desc")) : o : T(e(er.POLICY_TEXT_SELECTOR)));
        return I.IsIabEnabled && I.BannerIABPartnersLink && t.append('<button class="ot-link-btn onetrust-vendors-list-handler">\n        ' + I.BannerIABPartnersLink + "\n        </button>"), o
    }, or.prototype.setBannerData = function(e) {
        var t;
        I.BannerTitle ? (T(e("#onetrust-policy-title")).html(I.BannerTitle), T(e('[role="dialog"]')).attr(Ct, I.BannerTitle)) : (P.removeChild(e("#onetrust-policy-title")), T(e("#onetrust-banner-sdk")).addClass("ot-wo-title"), T(e('[role="dialog"]')).attr(Ct, I.AriaPrivacy)), !I.IsIabEnabled && L.showGeneralVendors && I.BannerNonIABVendorListText && ((t = document.createElement("div")).setAttribute("id", "ot-gv-link-ctnr"), T(t).html('<button class="ot-link-btn ot-gv-list-handler">' + I.BannerNonIABVendorListText + "</button>"), T(e("#onetrust-policy")).el.appendChild(t)), T(e(er.POLICY_TEXT_SELECTOR)).html(I.AlertNoticeText), this.setBannerLinkAttributes(e)
    }, or.prototype.setBannerLinkAttributes = function(e) {
        var t;
        T(e(this.cookiePolicyLinkSelector)).length && (t = T(e(er.POLICY_TEXT_SELECTOR + " .ot-cookie-policy-link")), e = T(e(er.POLICY_TEXT_SELECTOR + " .ot-imprint-link")), I.BShowPolicyLink && t && (t.attr(Ct, I.BCookiePolicyLinkScreenReader), t.attr("rel", "noopener"), t.attr("target", "_blank")), I.BShowImprintLink) && e && (e.attr(Ct, I.BImprintLinkScreenReader), e.attr("rel", "noopener"), e.attr("target", "_blank"))
    }, or.prototype.isCmpEnabled = function() {
        return I.BannerPurposeTitle || I.BannerPurposeDescription || I.BannerFeatureTitle || I.BannerFeatureDescription || I.BannerInformationTitle || I.BannerInformationDescription
    }, or.prototype.ssrAndNonSSRCommonHtml = function(t) {
        function e(e) {
            return t.querySelector(e)
        }
        var o, n = this,
            r = this.isCmpEnabled(),
            i = (this.setOptOutSignalNotification(e), "[VENDOR_NUMBER]"),
            s = T(e(er.POLICY_TEXT_SELECTOR)).html(),
            i = (A.isIab2orv2Template && -1 < s.indexOf(i) && (o = '<span class="ot-tcf2-vendor-count ot-text-bold">' + A.tcf2ActiveVendors.all.toString() + "</span>", s = h.replaceTextFromString(i, s, o), T(e(er.POLICY_TEXT_SELECTOR)).html(s)), T(e("#onetrust-banner-sdk")).attr("role", "region"), I.BRegionAriaLabel && T(e("#onetrust-banner-sdk")).attr(Ct, I.BRegionAriaLabel), A.bannerName === $e && m.moduleInitializer.IsSuppressPC && (L.dataGroupState = I.Groups.filter(function(e) {
                return e.Order
            })), A.bannerName === $e && (this._fourBtns = I.BannerShowRejectAllButton && I.showBannerAcceptButton && I.showBannerCookieSettings && I.BShowSaveBtn, this._saveBtn = e(".ot-bnr-save-handler"), this._settingsBtn = e("#onetrust-pc-btn-handler"), this._btnsCntr = e(".banner-actions-container"), I.BShowSaveBtn ? T(this._saveBtn).html(I.BSaveBtnTxt) : (P.removeChild(this._saveBtn), this._saveBtn = null), h.insertFooterLogo(t.querySelectorAll(".ot-bnr-footer-logo a")), this._descriptCntr = e(".ot-cat-lst"), this.setBannerBtn(), window.addEventListener("resize", function() {
                n.setBannerBtn()
            }), this._fourBtns && T(e("#onetrust-banner-sdk")).addClass("has-reject-all-button"), this.insertGrps(e)), document.createElement("div"));
        T(i).append(t), A.ignoreInjectingHtmlCss || (T("#onetrust-consent-sdk").append(i.firstChild), r && this.setBannerOptionContent()), this.setBnrBtnGrpAlignment()
    }, or.prototype.setAriaModalForBanner = function(e) {
        I.ForceConsent && e.querySelector('[role="dialog"]').setAttribute("aria-modal", "true")
    }, or.prototype.setBnrBtnGrpAlignment = function() {
        var e = T(this._otGrpContainerSelector).el,
            t = T(this._btnGrpParentSelector).el,
            e = ((e.length && e[0].clientHeight) < (t.length && t[0].clientHeight) ? T("#onetrust-banner-sdk").removeClass("vertical-align-content") : T("#onetrust-banner-sdk").addClass("vertical-align-content"), document.querySelector("#onetrust-button-group-parent button:first-of-type")),
            t = document.querySelector("#onetrust-button-group-parent button:last-of-type");
        t && e && 1 < Math.abs(t.offsetTop - e.offsetTop) && T("#onetrust-banner-sdk").addClass("ot-buttons-fw")
    }, or.prototype.slideInAnimation = function(e, t) {
        t === Ye ? "bottom" === I.BannerPosition ? (e.css("bottom: -99px;"), e.animate({
            bottom: "0px"
        }, 1e3), L.bnrAnimationInProg = !0, setTimeout(function() {
            e.css("bottom: 0px;"), L.bnrAnimationInProg = !1
        }, 1e3)) : (e.css("top: -99px; bottom: auto;"), A.pagePushedDown && !sn.checkIsBrowserIE11OrBelow() ? sn.BannerPushDownHandler() : (e.animate({
            top: "0"
        }, 1e3), L.bnrAnimationInProg = !0, setTimeout(function() {
            e.css("top: 0px; bottom: auto;"), L.bnrAnimationInProg = !1
        }, 1e3))) : t !== Je && t !== Ze || (e.css("bottom: -300px;"), e.animate({
            bottom: "1em"
        }, 2e3), L.bnrAnimationInProg = !0, setTimeout(function() {
            e.css("bottom: 1rem;"), L.bnrAnimationInProg = !1
        }, 2e3))
    }, or.prototype.setBannerBtn = function() {
        window.innerWidth <= 600 ? (P.insertElement(this._btnsCntr, this._settingsBtn, "afterbegin"), P.insertElement(this._btnsCntr, this._saveBtn, "afterbegin"), P.insertElement(this._btnsCntr, this._acceptBtn, "afterbegin"), P.insertElement(this._btnsCntr, this._rejectBtn, "afterbegin")) : this._fourBtns ? (this._descriptCntr.insertAdjacentElement("beforeend", this._settingsBtn), this._acceptBtn.insertAdjacentElement("beforebegin", this._rejectBtn), this._btnsCntr.insertAdjacentElement("beforebegin", this._saveBtn)) : (P.insertElement(this._btnsCntr, this._settingsBtn, "beforebegin"), P.insertElement(this._btnsCntr, this._saveBtn, this._settingsBtn ? "afterbegin" : "beforebegin"), P.insertElement(this._btnsCntr, this._rejectBtn, "beforeend"), P.insertElement(this._btnsCntr, this._acceptBtn, "beforeend"))
    }, or.prototype.setCmpBannerOptions = function(n, e) {
        var r = T(n("#banner-options .banner-option")).el.cloneNode(!0),
            i = (T(n(this._bannerOptionsSelector)).html(""), 1);
        e.forEach(function(e) {
            var t = r.cloneNode(!0),
                o = I[e.titleKey],
                e = I[e.descriptionKey];
            (o || e) && (t.querySelector(".banner-option-header :first-child").innerHTML = v.getInnerHtmlContent(o), o = t.querySelector(".banner-option-details"), e ? (o.setAttribute("id", "option-details-" + i++), o.innerHTML = v.getInnerHtmlContent(e)) : o.parentElement.removeChild(o), T(n("#banner-options")).el.appendChild(t))
        })
    }, or.prototype.setFloatingRoundedIconBannerCmpOptions = function(r, e) {
        var i = this,
            s = T(r("#banner-options button")).el.cloneNode(!0),
            n = T(r(".banner-option-details")).el.cloneNode(!0);
        T(r(this._bannerOptionsSelector)).html(""), e.forEach(function(e) {
            var t = s.cloneNode(!0),
                o = I[e.titleKey],
                n = I[e.descriptionKey];
            (o || n) && (t.setAttribute("id", e.identifier), t.querySelector(".banner-option-header :first-child").innerHTML = v.getInnerHtmlContent(o), T(r(i._bannerOptionsSelector)).el.appendChild(t))
        }), e.forEach(function(e) {
            var t, o = I[e.descriptionKey];
            o && ((t = n.cloneNode(!0)).innerHTML = v.getInnerHtmlContent(o), t.classList.add(e.identifier), T(r(i._bannerOptionsSelector)).el.appendChild(t))
        })
    }, or.prototype.setBannerOptionContent = function() {
        var t = this;
        A.bannerName !== Ye && A.bannerName !== Qe || setTimeout(function() {
            var e;
            (window.innerWidth < 769 ? (e = T(t._bannerOptionsSelector).el[0], T(t._otGrpContainerSelector)) : (e = T(t._bannerOptionsSelector).el[0], A.bannerName === Qe ? T(".banner-content") : T("#onetrust-banner-sdk .ot-sdk-container"))).el[0].appendChild(e)
        })
    }, or.prototype.setAdditionalDesc = function(e) {
        var t = I.BannerAdditionalDescPlacement,
            o = document.createElement("span"),
            n = (o.classList.add("ot-b-addl-desc"), T(o).html(I.BannerAdditionalDescription), e(er.POLICY_TEXT_SELECTOR));
        t === le.AfterTitle ? n.insertAdjacentElement("beforeBegin", o) : t === le.AfterDescription ? n.insertAdjacentElement("afterEnd", o) : t === le.AfterDPD && (n = e(".ot-dpd-container .ot-dpd-desc"), (n = I.ChoicesBanner ? e(this._otGrpContainerSelector) : n).insertAdjacentElement("beforeEnd", o))
    }, or.prototype.insertGrps = function(e) {
        var d = e(".ot-cat-item").cloneNode(!0),
            u = (P.removeChild(e(".ot-cat-item")), I.BCategoryStyle === ve.Checkbox ? P.removeChild(d.querySelector(".ot-tgl")) : (P.removeChild(d.querySelector(".ot-chkbox")), T(d).addClass("ot-cat-bdr")), e(".ot-cat-lst ul"));
        I.Groups.forEach(function(e) {
            var t = d.cloneNode(!0),
                o = t.querySelector(".ot-tgl,.ot-chkbox"),
                n = e.GroupName,
                r = e.CustomGroupId,
                i = "ot-bnr-grp-id-" + r,
                s = "ot-bnr-hdr-id-" + r,
                a = -1 !== kt.indexOf(e.Type),
                l = y.getGrpStatus(e).toLowerCase() === S.ALWAYS_ACTIVE || a,
                c = y.getGrpStatus(e).toLowerCase() === S.ALWAYS_INACTIVE || a,
                a = f.isGroupActive(e) || a,
                e = (T(o.querySelector("label")).attr("for", i), T(o.querySelector(".ot-label-txt")).html(e.GroupName), o.querySelector("input")),
                l = ((l || c) && (I.BCategoryStyle === ve.Toggle ? (P.removeChild(o), t.insertAdjacentElement("beforeend", T("<div class='ot-always-active'>" + (c ? I.AlwaysInactiveText : I.AlwaysActiveText) + "</div>", "ce").el)) : T(e).attr("disabled", !0)), e.classList.add("category-switch-handler"), f.setInputID(e, i, r, a, s), t.querySelector("h4"));
            T(l).html(n), T(l).attr("id", s), T(u).append(t)
        })
    }, or.prototype.setBannerLogo = function(e, t) {
        var o, n;
        m.fp.CookieV2BannerLogo && I.BnrLogo && (o = t(ln), n = "afterend", A.bannerName === Qe && (o = t("#onetrust-cookie-btn"), n = "beforeend"), t = h.updateCorrectUrl(I.BnrLogo), T(e).addClass("ot-bnr-w-logo"), T(o).el.innerHTML = v.getInnerHtmlContent(""), o.insertAdjacentHTML(n, v.getInnerHtmlContent("<img class='ot-bnr-logo' src='" + t + "'\n            title='" + I.BnrLogoAria + "'\n            alt='" + I.BnrLogoAria + "'/>")))
    }, or.prototype.setOptOutSignalNotification = function(e) {
        var t = A.gpcEnabled && A.gpcForAGrpEnabled;
        I.BShowOptOutSignal && (t || A.previewMode) && h.createOptOutSignalElement(e, !1)
    };
    var er, tr = or;

    function or() {
        this.POLICY_TEXT_SELECTOR = "#onetrust-policy-text", this.El = "#onetrust-banner-sdk", this._saveBtn = null, this._settingsBtn = null, this._acceptBtn = null, this._rejectBtn = null, this._descriptCntr = null, this._btnsCntr = null, this._fourBtns = !1, this._bannerOptionsSelector = "#banner-options", this._btnGrpParentSelector = "#onetrust-button-group-parent", this._otGrpContainerSelector = "#onetrust-group-container", this.cookiePolicyLinkSelector = "#onetrust-policy-text a"
    }
    rr.prototype.setHeaderConfig = function() {
        c.setHeader(), c.setSearchInput(), c.setHeaderUIConsent();
        var e = c.getGroupsForFilter();
        jn.setFilterListByGroup(e, !1)
    }, rr.prototype.filterVendorByString = function(e) {
        c.searchQuery = e, c.filterVendorByGroupOrQuery()
    }, rr.prototype.filterVendorByGroup = function(e) {
        c.filterGroups = e, c.filterVendorByGroupOrQuery()
    }, rr.prototype.showVSList = function() {
        c.removeListeners(), c.showEmptyResults(!1, ""), c.clearUIElementsInMain(), c.addVSList(L.getVendorsInDomain())
    }, rr.prototype.showEmptyResults = function(e, t) {
        e ? this.setNoResultsContent(t) : (T("#onetrust-pc-sdk " + k.P_Vendor_Content).removeClass("no-results"), (e = T("#onetrust-pc-sdk #no-results")).length && e.remove())
    }, rr.prototype.setNoResultsContent = function(e) {
        var t, o, n, r, i = T("#onetrust-pc-sdk #no-results").el[0];
        if (!i) return t = document.createElement("div"), o = document.createElement("p"), n = document.createTextNode(" " + I.PCVendorNotFound + "."), r = document.createElement("span"), t.id = "no-results", r.id = "user-text", r.innerText = e, o.appendChild(r), o.appendChild(n), t.appendChild(o), T("#onetrust-pc-sdk " + k.P_Vendor_Content).addClass("no-results"), T("#vendor-search-handler").el[0].setAttribute("aria-describedby", t.id), T("#onetrust-pc-sdk " + k.P_Vendor_Content).append(t);
        i.querySelector("span").innerText = e
    }, rr.prototype.getGroupsFilter = function() {
        for (var e = [], t = 0, o = T("#onetrust-pc-sdk .category-filter-handler").el; t < o.length; t++) {
            var n = o[t],
                r = n.getAttribute("data-purposeid");
            n.checked && e.push(r)
        }
        return e
    }, rr.prototype.cancelFilter = function() {
        for (var e = 0, t = T("#onetrust-pc-sdk .category-filter-handler").el; e < t.length; e++) {
            var o = t[e],
                n = o.getAttribute("data-optanongroupid"),
                n = 0 <= L.filterByCategories.indexOf(n);
            P.setCheckedAttribute(null, o, n)
        }
        var r = c.getGroupsFilter();
        c.filterVendorByGroup(r)
    }, rr.prototype.clearFilter = function() {
        c.searchQuery = "", c.filterGroups = []
    }, rr.prototype.toggleVendors = function(r) {
        L.getVendorsInDomain().forEach(function(e, t) {
            var o, n;
            y.isAlwaysActiveGroup(e.groupRef) || (o = document.getElementById("ot-vendor-id-" + t), n = document.getElementById("ot-vs-lst-id-" + t), E.toggleVendorService(e.groupRef.CustomGroupId, t, r, o), E.toggleVendorService(e.groupRef.CustomGroupId, t, r, n))
        })
    }, rr.prototype.hideVendorList = function() {
        c.removeListeners(), c.clearUIElementsInMain()
    }, rr.prototype.addListeners = function() {
        T("#onetrust-pc-sdk " + k.P_Vendor_Content + " .ot-vs-list .category-switch-handler").on("click", c.toggleVendorHandler), T("#onetrust-pc-sdk").on("click", ".ot-vs-list", D.onCategoryItemToggle.bind(this))
    }, rr.prototype.removeListeners = function() {
        var e;
        document.querySelectorAll("#onetrust-pc-sdk .ot-vs-list .category-switch-handler").forEach(function(e) {
            return e.removeEventListener("click", D.toggleGroupORVendorHandler)
        }), null != (e = document.querySelector("#onetrust-pc-sdk .ot-vs-list")) && e.removeEventListener("click", D.onCategoryItemToggle)
    }, rr.prototype.toggleVendorHandler = function(e) {
        D.toggleVendorFromListHandler(e), c.checkAllowAllCheckedValue()
    }, rr.prototype.filterVendorByGroupOrQuery = function() {
        var o = new Map;
        L.getVendorsInDomain().forEach(function(e, t) {
            c.checkVendorConditions(e) && o.set(t, e)
        }), c.showEmptyResults(o.size <= 0, c.searchQuery), c.removeListeners(), c.clearUIElementsInMain(), c.addVSList(o)
    }, rr.prototype.checkVendorConditions = function(e) {
        return !("" !== c.searchQuery && e.ServiceName.toLowerCase().indexOf(c.searchQuery.toLowerCase()) < 0 || 0 < c.filterGroups.length && c.filterGroups.indexOf(e.groupRef.CustomGroupId) < 0)
    }, rr.prototype.addVSList = function(e) {
        var t = T("#onetrust-pc-sdk " + k.P_Vendor_Content + " .ot-sdk-column"),
            e = E.getVendorListEle(e);
        t.append(e), c.addListeners()
    }, rr.prototype.getGroupsForFilter = function() {
        var t = new Map;
        return L.getVendorsInDomain().forEach(function(e) {
            t.has(e.groupRef.CustomGroupId) || t.set(e.groupRef.CustomGroupId, e.groupRef)
        }), Array.from(t.values())
    }, rr.prototype.clearUIElementsInMain = function() {
        T("#onetrust-pc-sdk " + k.P_Vendor_Content + " ul" + k.P_Host_Cntr).html(""), T("#onetrust-pc-sdk " + k.P_Vendor_Content + " ul" + k.P_Host_Cntr).hide(), T("#onetrust-pc-sdk " + k.P_Vendor_Content + " ul" + k.P_Vendor_Container).html(""), T("#onetrust-pc-sdk " + k.P_Vendor_Content + " ul" + k.P_Vendor_Container).hide();
        var e = T("#onetrust-pc-sdk " + k.P_Vendor_Content + " .ot-vs-list");
        e && e.length && e.remove()
    }, rr.prototype.setHeader = function() {
        var e = I.VendorServiceConfig.PCVSListTitle,
            t = document.querySelector("#onetrust-pc-sdk " + k.P_Vendor_Title);
        t && (t.innerText = e)
    }, rr.prototype.setSearchInput = function() {
        var e = I.PCenterCookieListSearch,
            t = I.PCenterCookieSearchAriaLabel,
            o = T("#onetrust-pc-sdk " + k.P_Vendor_Search_Input);
        o.el[0].placeholder = e, o.attr("aria-label", t)
    }, rr.prototype.setHeaderUIConsent = function() {
        var e, t, o;
        T("#onetrust-pc-sdk " + k.P_Select_Cntr).addClass("ot-vnd-list-cnt"), T("#onetrust-pc-sdk " + k.P_Select_Cntr + " .ot-sel-all").addClass("ot-vs-selc-all"), I.PCCategoryStyle === ve.Toggle && (T("#onetrust-pc-sdk " + k.P_Select_Cntr + " .ot-sel-all").addClass("ot-toggle-conf"), I.PCAccordionStyle === ce.Caret) && T("#onetrust-pc-sdk " + k.P_Select_Cntr + " .ot-sel-all").addClass("ot-caret-conf"), T("#onetrust-pc-sdk " + k.P_Leg_Select_All).hide(), T("#onetrust-pc-sdk #" + k.P_Sel_All_Host_El).hide(), T("#onetrust-pc-sdk " + k.P_Host_Cntr).hide(), T(k.P_Vendor_List + " #select-all-text-container").hide(), T("#onetrust-pc-sdk #" + k.P_Sel_All_Vendor_Leg_El).hide(), T("#onetrust-pc-sdk " + k.P_Vendor_Container).show(), T("#onetrust-pc-sdk " + k.P_Select_Cntr).show(), T("#onetrust-pc-sdk #" + k.P_Sel_All_Vendor_Consent_El).show("inline-block"), T("#onetrust-pc-sdk " + k.P_Vendor_List).removeClass(k.P_Host_UI), T("#onetrust-pc-sdk " + k.P_Vendor_Content).removeClass(k.P_Host_Cnt), document.querySelector("#onetrust-pc-sdk .ot-sel-all-chkbox .sel-all-hdr") || ((e = document.createElement("h4")).className = "sel-all-hdr", e.textContent = (null == (t = I.VendorServiceConfig) ? void 0 : t.PCVSAllowAllText) || "PCVSAllowAllText", t = document.querySelector("#onetrust-pc-sdk .ot-sel-all-chkbox"), o = I.PCCategoryStyle === ve.Checkbox ? "beforeend" : "afterbegin", t.insertAdjacentElement(o, e)), c.checkAllowAllCheckedValue()
    }, rr.prototype.checkAllowAllCheckedValue = function() {
        var t = !0,
            e = (L.vsConsent.forEach(function(e) {
                e || (t = !1)
            }), document.getElementById("#select-all-vendor-groups-handler"));
        P.setCheckedAttribute(null, e, t)
    };
    var c, nr = rr;

    function rr() {
        this.searchQuery = "", this.filterGroups = []
    }
    i.prototype.initCookieSettingHandlers = function() {
        T(document).on("click", ".optanon-show-settings, .optanon-toggle-display, .ot-sdk-show-settings, .ot-pc-handler", this.cookiesSettingsBoundListener)
    }, i.prototype.initFlgtCkStgBtnEventHandlers = function() {
        T(".ot-floating-button__open").on("click", function(e) {
            setTimeout(function() {
                D.floatingCookieSettingOpenBtnClicked(e)
            }, 0)
        }), T(".ot-floating-button__close").on("click", function(e) {
            setTimeout(function() {
                D.floatingCookieSettingCloseBtnClicked(e)
            }, 0)
        })
    }, i.prototype.floatingCookieSettingOpenBtnClicked = function(e) {
        T(D.fltgBtnSltr).addClass("ot-pc-open"), I.cookiePersistentLogo.includes("ot_guard_logo.svg") && T(D.fltgBtnFSltr).attr(gt, "true"), T(D.fltgBtnBSltr).attr(gt, ""), T(D.fltgBtnFrontBtn).el[0].setAttribute(gt, !0), T(D.fltgBtnFrontBtn).el[0].style.display = "none", T(D.fltgBtnBackBtn).el[0].setAttribute(Ct, I.AriaClosePreferences), T(D.fltgBtnBackBtn).el[0].setAttribute(gt, !1), T(D.fltgBtnBackBtn).el[0].style.display = "block", so.triggerGoogleAnalyticsEvent(Lo, Ho), D.showCookieSettingsHandler(e)
    }, i.prototype.floatingCookieSettingCloseBtnClicked = function(e) {
        T(D.fltgBtnFrontBtn).el[0].setAttribute(Ct, I.CookieSettingButtonText), T(D.fltgBtnFrontBtn).el[0].setAttribute(gt, !1), T(D.fltgBtnFrontBtn).el[0].style.display = "block", T(D.fltgBtnBackBtn).el[0].setAttribute(gt, !0), T(D.fltgBtnBackBtn).el[0].style.display = "none", e && (so.triggerGoogleAnalyticsEvent(Lo, Ro), D.hideCookieSettingsHandler(e))
    }, i.prototype.initialiseLegIntBtnHandlers = function() {
        T(document).on("click", ".ot-obj-leg-btn-handler", D.onLegIntButtonClick), T(document).on("click", ".ot-remove-objection-handler", D.onLegIntButtonClick)
    }, i.prototype.initialiseAddtlVenHandler = function() {
        T("#onetrust-pc-sdk #ot-addtl-venlst").on("click", D.selectVendorsGroupHandler), T("#onetrust-pc-sdk #ot-selall-adtlven-handler").on("click", D.selAllAdtlVenHandler)
    }, i.prototype.initializeGenVenHandlers = function() {
        T("#onetrust-pc-sdk #ot-gn-venlst .ot-gnven-chkbox-handler").on("click", D.genVendorToggled), T("#onetrust-pc-sdk #ot-gn-venlst .ot-gv-venbox").on("click", D.genVendorDetails), T("#onetrust-pc-sdk #ot-selall-gnven-handler").on("click", D.selectAllGenVenHandler)
    }, i.prototype.initialiseConsentNoticeHandlers = function() {
        var e = this;
        A.pcName === it && D.categoryMenuSwitchHandler(), T("#onetrust-pc-sdk .onetrust-close-btn-handler").on("click", function(e) {
            setTimeout(function() {
                D.bannerCloseButtonHandler(e)
            }, 0)
        }), T("#onetrust-pc-sdk #accept-recommended-btn-handler").on("click", function() {
            setTimeout(function() {
                O.allowAllEventHandler(!0)
            }, 0)
        }), T("#onetrust-pc-sdk .ot-pc-refuse-all-handler").on("click", function() {
            setTimeout(function() {
                O.rejectAllEventHandler(!0)
            }, 0)
        }), T("#onetrust-pc-sdk #close-pc-btn-handler").on("click", function(e) {
            setTimeout(function() {
                D.hideCookieSettingsHandler(e)
            }, 0)
        }), T(document).on("keydown", D.closePCWhenEscPressed), T("#onetrust-pc-sdk #vendor-close-pc-btn-handler").on("click", D.hideCookieSettingsHandler), T("#onetrust-pc-sdk .category-switch-handler").on("click", D.toggleGroupORVendorHandler), T("#onetrust-pc-sdk .cookie-subgroup-handler").on("click", D.toggleSubCategory), T("#onetrust-pc-sdk .category-menu-switch-handler").on("keydown", function(e) {
            A.pcName !== it || e.keyCode !== ae.UpArrow && e.keyCode !== ae.DownArrow || (e.preventDefault(), I.PCTemplateUpgrade ? D.changeSelectedTabV2(e) : D.changeSelectedTab(e))
        }), T("" + D.PC_SELECTOR).on("click", k.P_Category_Item + " > input:first-child," + k.P_Category_Item + " > button:first-child", D.onCategoryItemToggle.bind(this)), (I.showCookieList || L.showGeneralVendors) && (T("#onetrust-pc-sdk .category-host-list-handler").on("click", function(e) {
            setTimeout(function() {
                L.showGeneralVendors && I.showCookieList ? L.cookieListType = ye.HostAndGenVen : L.showGeneralVendors ? L.cookieListType = ye.GenVen : L.cookieListType = ye.Host, D.pcLinkSource = e.target, D.loadCookieList(e.target)
            }, 0)
        }), h.isOptOutEnabled() ? (T("#onetrust-pc-sdk #select-all-hosts-groups-handler").on("click", D.selectAllHostsGroupsHandler), T("#onetrust-pc-sdk " + k.P_Host_Cntr).on("click", D.selectHostsGroupHandler)) : T("#onetrust-pc-sdk " + k.P_Host_Cntr).on("click", D.toggleAccordionStatus)), D.addListenerWhenIabEnabled(), D.addEventListenerWhenIsHostOrVendorsAreEnabled(), D.adddListenerWhenNoBanner(), T("#onetrust-pc-sdk .ot-gv-list-handler").on("click", function(t) {
            return F(e, void 0, void 0, function() {
                return M(this, function(e) {
                    return L.cookieListType = ye.GenVen, D.loadCookieList(t.target), [2]
                })
            })
        }), D.addListenerWhenVendorServices()
    }, i.prototype.addEventListenerWhenIsHostOrVendorsAreEnabled = function() {
        var e;
        (I.IsIabEnabled || I.showCookieList || L.showGeneralVendors || L.showVendorService) && (T(document).on("click", ".back-btn-handler", D.backBtnHandler), D.addListenerSearchKeyEvent(), T("#onetrust-pc-sdk #filter-btn-handler").on("click", D.toggleVendorFiltersHandler), T("#onetrust-pc-sdk #filter-apply-handler").on("click", function() {
            setTimeout(function() {
                D.applyFilterHandler()
            }, 0)
        }), T("#onetrust-pc-sdk " + k.P_Fltr_Modal).on("click", D.tglFltrOptionHandler), !m.isV2Template && A.pcName !== rt || T("#onetrust-pc-sdk #filter-cancel-handler").on("click", D.cancelFilterHandler), !m.isV2Template && A.pcName === rt || T("#onetrust-pc-sdk #clear-filters-handler").on("click", D.clearFiltersHandler), m.isV2Template ? T("#onetrust-pc-sdk #filter-cancel-handler").on("keydown", function(e) {
            9 !== e.keyCode && "tab" !== e.code || e.shiftKey || (e.preventDefault(), T("#onetrust-pc-sdk #clear-filters-handler").el[0].focus())
        }) : T("#onetrust-pc-sdk #filter-apply-handler").on("keydown", function(e) {
            9 !== e.keyCode && "tab" !== e.code || e.shiftKey || (e.preventDefault(), T("#onetrust-pc-sdk .category-filter-handler").el[0].focus())
        }), e = T("#onetrust-pc-sdk .category-filter-handler").el, T(e[0]).on("keydown", function(e) {
            9 !== e.keyCode && "tab" !== e.code || !e.shiftKey || (e.preventDefault(), T("#onetrust-pc-sdk #filter-apply-handler").el[0].focus())
        }))
    }, i.prototype.addListenerSearchKeyEvent = function() {
        T(D.VENDOR_SEARCH_SELECTOR).on("keyup", function(e) {
            e = e.target.value.trim();
            D.currentSearchInput !== e && (L.showVendorService ? c.filterVendorByString(e) : D.isCookieList ? (w.searchHostList(e), L.showTrackingTech && D.addEventAdditionalTechnologies()) : (w.loadVendorList(e, []), I.UseGoogleVendors && w.searchVendors(w.googleSearchSelectors, L.addtlVendorsList, me.GoogleVendor, e), L.showGeneralVendors && I.GeneralVendors.length && w.searchVendors(w.genVendorSearchSelectors, I.GeneralVendors, me.GeneralVendor, e)), w.playSearchStatus(D.isCookieList), D.currentSearchInput = e)
        })
    }, i.prototype.addListenerWhenIabEnabled = function() {
        I.IsIabEnabled && (T("#onetrust-pc-sdk .category-vendors-list-handler").on("click", function(e) {
            setTimeout(function() {
                D.pcLinkSource = e.target, D.showVendorsList(e.target)
            }, 0)
        }), T("#onetrust-pc-sdk .ot-pgph-link").on("click", function(e) {
            D.pcLinkSource = e.target, D.showIllustrations(e.target)
        }), T("#onetrust-pc-sdk " + k.P_Vendor_Container).on("click", D.selectVendorsGroupHandler), I.UseGoogleVendors || D.bindSelAllHandlers(), D.initialiseLegIntBtnHandlers())
    }, i.prototype.adddListenerWhenNoBanner = function() {
        I.NoBanner && (I.OnClickCloseBanner && document.body.addEventListener("click", O.bodyClickEvent), I.ScrollCloseBanner) && window.addEventListener("scroll", O.scrollCloseBanner)
    }, i.prototype.addListenerWhenVendorServices = function() {
        L.showVendorService && (D.bindSelAllHandlers(), T("#onetrust-pc-sdk .onetrust-vendors-list-handler").on("click", function() {
            setTimeout(function() {
                D.showVendorsList(null, !0)
            }, 0)
        }))
    }, i.prototype.bindSelAllHandlers = function() {
        T("#onetrust-pc-sdk #select-all-vendor-leg-handler").on("click", D.selectAllVendorsLegIntHandler), T("#onetrust-pc-sdk #select-all-vendor-groups-handler").on("click", D.SelectAllVendorConsentHandler)
    }, i.prototype.hideCookieSettingsHandler = function(e) {
        return void 0 === e && (e = window.event), Fn.getInstance().resetHealthSignatureData(), so.triggerGoogleAnalyticsEvent(Lo, Do), sn.removeAddedOTCssStyles(rn.PC), pn.hideConsentNoticeV2(), T(document).off("keydown", D.closePCWhenEscPressed), D.getResizeElement().removeEventListener("resize", D.setCenterLayoutFooterHeight), window.removeEventListener("resize", D.setCenterLayoutFooterHeight), !m.isV2Template && A.pcName !== rt || D.closeFilter(!1), A.pcName === ot && T("#onetrust-pc-sdk " + k.P_Content).removeClass("ot-hide"), O.hideVendorsList(), N.csBtnGroup && (T(D.fltgBtnSltr).removeClass("ot-pc-open"), D.floatingCookieSettingCloseBtnClicked(null)), D.confirmPC(e), O.resetConsent(), !1
    }, i.prototype.selectAllHostsGroupsHandler = function(e) {
        var t = e.target.checked,
            e = T("#onetrust-pc-sdk #" + k.P_Sel_All_Host_El).el[0],
            o = e.classList.contains("line-through"),
            n = T("#onetrust-pc-sdk .host-checkbox-handler").el;
        P.setCheckedAttribute("#select-all-hosts-groups-handler", null, t), P.setAriaCheckedAttribute("#select-all-hosts-groups-handler", null, t.toString());
        for (var r = 0; r < n.length; r++) n[r].getAttribute("disabled") || P.setCheckedAttribute(null, n[r], t);
        L.optanonHostList.forEach(function(e) {
            ko.updateHostStatus(e, t)
        }), n.forEach(function(e) {
            fo.updateGenVendorStatus(e.getAttribute("hostId"), t)
        }), o && e.classList.remove("line-through")
    }, i.prototype.selectHostsGroupHandler = function(e) {
        D.toggleAccordionStatus(e);
        var t = e.target.getAttribute("hostId"),
            o = e.target.getAttribute("ckType"),
            n = e.target.checked;
        null !== t && (o === he.GenVendor ? (o = I.GeneralVendors.find(function(e) {
            return e.VendorCustomId === t
        }).Name, so.triggerGoogleAnalyticsEvent(Lo, n ? Uo : qo, o + ": VEN_" + t), fo.updateGenVendorStatus(t, n)) : (o = P.findIndex(L.optanonHostList, function(e) {
            return e.HostId === t
        }), o = L.optanonHostList[o], D.toggleHostStatus(o, n)), P.setCheckedAttribute(null, e.target, n))
    }, i.prototype.onCategoryItemToggle = function(e) {
        e.stopPropagation();
        var t = e.target;
        "BUTTON" !== t.tagName && "INPUT" !== t.tagName || (A.pcName === ot && this.setPcListContainerHeight(), D.toggleAccordionStatus(e))
    }, i.prototype.toggleAccordionStatus = function(e) {
        var t, e = e.target;
        e && e.getAttribute("aria-expanded") && (t = "true" === e.getAttribute("aria-expanded") ? "false" : "true", e.setAttribute("aria-expanded", t))
    }, i.prototype.toggleHostStatus = function(e, t) {
        so.triggerGoogleAnalyticsEvent(Lo, t ? jo : Ko, e.HostName + ": H_" + e.HostId), ko.updateHostStatus(e, t)
    }, i.prototype.toggleBannerOptions = function(e) {
        T(".banner-option-input").each(function(e) {
            T(e).el.setAttribute("aria-expanded", !1)
        }), D.toggleAccordionStatus(e)
    }, i.prototype.bannerCloseButtonHandler = function(n) {
        return F(this, void 0, void 0, function() {
            var t, o;
            return M(this, function(e) {
                return T(document).off("keydown", D.shiftBannerFocus), n && n.target && n.target.className && (-1 < (t = n.target.className).indexOf("save-preference-btn-handler") ? (L.bannerCloseSource = ee.ConfirmChoiceButton, so.triggerGoogleAnalyticsEvent(Lo, Bo)) : -1 < t.indexOf("banner-close-button") ? (L.bannerCloseSource = ee.BannerCloseButton, o = Eo, -1 < t.indexOf("ot-close-link") && (o = Oo, L.bannerCloseSource = ee.ContinueWithoutAcceptingButton), so.triggerGoogleAnalyticsEvent(Lo, o)) : -1 < t.indexOf("ot-bnr-save-handler") && (L.bannerCloseSource = ee.BannerSaveSettings, so.triggerGoogleAnalyticsEvent(Lo, Vo))), sn.removeAddedOTCssStyles(), O.hideVendorsList(), [2, O.bannerCloseButtonHandler()]
            })
        })
    }, i.prototype.onLegIntButtonClick = function(e) {
        var t, o, n;
        e && (n = "true" === (e = e.currentTarget).parentElement.getAttribute("is-vendor"), t = e.parentElement.getAttribute("data-group-id"), o = !e.classList.contains("ot-leg-int-enabled"), n ? D.onVendorToggle(t, de.LI) : (n = y.getGroupById(t)).Parent ? D.updateSubGroupToggles(n, o, !0) : D.updateGroupToggles(n, o, !0), f.updateLegIntBtnElement(e.parentElement, o))
    }, i.prototype.updateGroupToggles = function(t, o, e) {
        ko.toggleGroupHosts(t, o), L.genVenOptOutEnabled && ko.toggleGroupGenVendors(t, o), t.IsLegIntToggle = e, D.toggleGroupStatus(t, o), t.SubGroups && t.SubGroups.length && (A.bannerName === $e && m.moduleInitializer.IsSuppressPC && t.SubGroups.length ? t.SubGroups.forEach(function(e) {
            e.IsLegIntToggle = t.IsLegIntToggle, f.toggleGrpStatus(e, o), e.IsLegIntToggle = !1, ko.toggleGroupHosts(e, o), L.genVenOptOutEnabled && ko.toggleGroupGenVendors(e, o), E.setVendorStateByGroup(e, o)
        }) : f.toogleAllSubGrpElements(t, o), t.SubGroups.forEach(function(e) {
            return E.setVendorStateByGroup(e, o)
        })), E.setVendorStateByGroup(t, o), this.allowAllVisible(f.setAllowAllButton()), t.IsLegIntToggle = !1
    }, i.prototype.toggleGroupStatus = function(e, t) {
        var o;
        A.requireSignatureEnabled && e.needsHealthSignature ? (o = !1, t ? (A.healthSignatureData && (o = !0), A.healthSignatureGroup = e) : A.healthSignatureGroup = null, f.toggleGrpStatus(e, o)) : f.toggleGrpStatus(e, t)
    }, i.prototype.updateSubGroupToggles = function(e, t, o) {
        ko.toggleGroupHosts(e, t), L.genVenOptOutEnabled && ko.toggleGroupGenVendors(e, t);
        var n = y.getGroupById(e.Parent),
            o = (e.IsLegIntToggle = o, n.IsLegIntToggle = e.IsLegIntToggle, f.isGroupActive(n));
        t ? (f.toggleGrpStatus(e, !0), f.isAllSubgroupsEnabled(n) && !o && (f.toggleGrpStatus(n, !0), ko.toggleGroupHosts(n, t), L.genVenOptOutEnabled && ko.toggleGroupGenVendors(n, t), f.toggleGroupHtmlElement(e, e.Parent + (e.IsLegIntToggle ? "-leg-out" : ""), !0))) : (f.toggleGrpStatus(e, !1), f.isAllSubgroupsDisabled(n) && o ? (f.toggleGrpStatus(n, !1), ko.toggleGroupHosts(n, t), L.genVenOptOutEnabled && ko.toggleGroupGenVendors(n, t), f.toggleGroupHtmlElement(e, e.Parent + (e.IsLegIntToggle ? "-leg-out" : ""), t)) : (f.toggleGrpStatus(n, !1), ko.toggleGroupHosts(n, !1), L.genVenOptOutEnabled && ko.toggleGroupGenVendors(n, t), f.toggleGroupHtmlElement(e, e.Parent + (e.IsLegIntToggle ? "-leg-out" : ""), !1))), this.allowAllVisible(f.setAllowAllButton()), e.IsLegIntToggle = !1, n.IsLegIntToggle = e.IsLegIntToggle
    }, i.prototype.hideCategoryContainer = function(e) {
        this.isCookieList = e = void 0 === e ? !1 : e, D.addHideClassContainer(), L.showVendorService ? c.setHeaderConfig() : (e ? D.setCookieListTemplate() : D.setVendorListTemplate(), jn.setFilterList(e))
    }, i.prototype.setCookieListTemplate = function() {
        var e = m.isV2Template;
        T(k.P_Vendor_List + " #select-all-text-container").show("inline-block"), T("#onetrust-pc-sdk " + k.P_Host_Cntr).show(), h.isOptOutEnabled() ? T("#onetrust-pc-sdk #" + k.P_Sel_All_Host_El).show("inline-block") : T("#onetrust-pc-sdk #" + k.P_Sel_All_Host_El).hide(), T("#onetrust-pc-sdk #" + k.P_Sel_All_Vendor_Leg_El).hide(), T("#onetrust-pc-sdk " + k.P_Leg_Header).hide(), e || T("#onetrust-pc-sdk " + k.P_Leg_Select_All).hide(), T("#onetrust-pc-sdk #" + k.P_Sel_All_Vendor_Consent_El).hide(), T("#onetrust-pc-sdk  " + k.P_Vendor_Container).hide(), (I.UseGoogleVendors || L.showGeneralVendors) && T("#onetrust-pc-sdk .ot-acc-cntr").hide(), T("#onetrust-pc-sdk " + k.P_Vendor_List).addClass(k.P_Host_UI), T("#onetrust-pc-sdk " + k.P_Vendor_Content).addClass(k.P_Host_Cnt)
    }, i.prototype.setVendorListTemplate = function() {
        T("#onetrust-pc-sdk " + k.P_Vendor_Container).show(), T("#onetrust-pc-sdk #" + k.P_Sel_All_Vendor_Consent_El).show("inline-block"), I.UseGoogleVendors && T("#onetrust-pc-sdk .ot-acc-cntr").show(), A.legIntSettings.PAllowLI && A.isIab2orv2Template ? (T("#onetrust-pc-sdk " + k.P_Select_Cntr).show(m.isV2Template ? void 0 : "inline-block"), T("#onetrust-pc-sdk " + k.P_Leg_Select_All).show("inline-block"), T("#onetrust-pc-sdk #" + k.P_Sel_All_Vendor_Leg_El).show("inline-block"), T(k.P_Vendor_List + " #select-all-text-container").hide(), A.legIntSettings.PShowLegIntBtn ? (T("#onetrust-pc-sdk " + k.P_Leg_Header).hide(), T("#onetrust-pc-sdk #" + k.P_Sel_All_Vendor_Leg_El).hide()) : T("#onetrust-pc-sdk " + k.P_Leg_Header).show()) : (T("#onetrust-pc-sdk " + k.P_Select_Cntr).show(), T(k.P_Vendor_List + " #select-all-text-container").show("inline-block"), T("#onetrust-pc-sdk " + k.P_Leg_Select_All).hide(), T("#onetrust-pc-sdk #" + k.P_Sel_All_Vendor_Leg_El).hide()), T("#onetrust-pc-sdk #" + k.P_Sel_All_Host_El).hide(), T("#onetrust-pc-sdk " + k.P_Host_Cntr).hide(), T("#onetrust-pc-sdk " + k.P_Vendor_List).removeClass(k.P_Host_UI), T("#onetrust-pc-sdk " + k.P_Vendor_Content).removeClass(k.P_Host_Cnt)
    }, i.prototype.showAllVendors = function(t) {
        return F(this, void 0, void 0, function() {
            return M(this, function(e) {
                switch (e.label) {
                    case 0:
                        return [4, D.fetchAndSetupPC()];
                    case 1:
                        return e.sent(), D.showVendorsList(null, !0), L.isPCVisible ? [3, 3] : [4, D.showCookieSettingsHandler(t)];
                    case 2:
                        e.sent(), e.label = 3;
                    case 3:
                        return [2]
                }
            })
        })
    }, i.prototype.fetchAndSetupPC = function() {
        return F(this, void 0, void 0, function() {
            var t;
            return M(this, function(e) {
                switch (e.label) {
                    case 0:
                        return m.moduleInitializer.IsSuppressPC && 0 === T("" + D.PC_SELECTOR).length ? [4, xt.getPcContent()] : [3, 2];
                    case 1:
                        t = e.sent(), N.preferenceCenterGroup = {
                            name: t.name,
                            html: atob(t.html),
                            css: t.css
                        }, m.isV2Template = I.PCTemplateUpgrade && /otPcPanel|otPcCenter|otPcTab/.test(t.name), (t = document.getElementById("onetrust-style")).innerHTML = v.getInnerHtmlContent(t.innerHTML + N.preferenceCenterGroup.css), t.innerHTML = v.getInnerHtmlContent(t.innerHTML + Qt.addCustomPreferenceCenterCSS()), V.insertPcHtml(), D.initialiseConsentNoticeHandlers(), I.IsIabEnabled && w.InitializeVendorList(), e.label = 2;
                    case 2:
                        return 0 !== T("" + D.PC_SELECTOR).length && I.PCTemplateUpgrade && (t = document.querySelector("#onetrust-pc-sdk .ot-optout-signal"), V.setOptOutSignalVisibility(t)), [2]
                }
            })
        })
    }, i.prototype.setVendorContent = function() {
        T("" + D.FILTER_COUNT_SELECTOR).text(L.filterByIABCategories.length.toString()), w.loadVendorList("", L.filterByIABCategories), I.UseGoogleVendors && (L.vendorDomInit ? w.resetAddtlVendors() : (w.initGoogleVendors(), T("" + D.PC_SELECTOR).on("click", ".ot-acc-cntr > button", D.toggleAccordionStatus.bind(this)))), L.vendorDomInit || (L.vendorDomInit = !0, D.initialiseLegIntBtnHandlers(), I.UseGoogleVendors && (D.initialiseAddtlVenHandler(), D.bindSelAllHandlers())), L.showGeneralVendors && !L.genVendorDomInit && (L.genVendorDomInit = !0, w.initGenVendors(), D.initializeGenVenHandlers(), I.UseGoogleVendors || (D.bindSelAllHandlers(), T("" + D.PC_SELECTOR).on("click", ".ot-acc-cntr > button", D.toggleAccordionStatus.bind(this))))
    }, i.prototype.addEventAdditionalTechnologies = function() {
        var e = document.querySelectorAll("#onetrust-pc-sdk .ot-acc-cntr.ot-add-tech > button");
        0 < e.length && (T(e).off("click", D.toggleAccordionStatus), T(e).on("click", D.toggleAccordionStatus))
    }, i.prototype.showVendorsList = function(e, t) {
        return void 0 === t && (t = !1), L.cookieListType = null, D.hideCategoryContainer(!1), sn.addOTCssPropertiesToBody(rn.PC, {}), L.showVendorService ? c.showVSList() : (t || (t = e.getAttribute("data-parent-id")) && (t = y.getGroupById(t)) && (t = U(t.SubGroups, [t]).reduce(function(e, t) {
            return -1 < vt.indexOf(t.Type) && e.push(t.CustomGroupId), e
        }, []), L.filterByIABCategories = U(L.filterByIABCategories, t)), D.setVendorContent(), Sn.updateFilterSelection(!1)), L.pcLayer = se.VendorList, e && Io.setPCFocus(Io.getPCElements()), this.setSearchInputFocus(), !1
    }, i.prototype.showIllustrations = function(e) {
        e = e.getAttribute("data-parent-id"), e = y.getGroupById(e);
        L.cookieListType = null, L.pcLayer = se.IabIllustrations, D.addHideClassContainer(), Xn.showIllustrations(e.GroupName, e.IabIllustrations), Io.setPCFocus(Io.getPCElements())
    }, i.prototype.addHideClassContainer = function() {
        var e = A.pcName;
        I.PCTemplateUpgrade ? T("#onetrust-pc-sdk " + k.P_Content).addClass("ot-hide") : T("#onetrust-pc-sdk .ot-main-content").hide(), T("#onetrust-pc-sdk " + k.P_Vendor_List).removeClass("ot-hide"), e !== rt && e !== ot && T("#onetrust-pc-sdk #close-pc-btn-handler.main").hide(), e === ot && d(T("" + D.PC_SELECTOR).el[0], 'height: "";', !0)
    }, i.prototype.loadCookieList = function(e) {
        L.filterByCategories = [], D.hideCategoryContainer(!0);
        var t, e = e && e.getAttribute("data-parent-id");
        return e && (t = y.getGroupById(e), L.filterByCategories.push(e), t.SubGroups.length) && t.SubGroups.forEach(function(e) {
            -1 === vt.indexOf(e.Type) && (e = e.CustomGroupId, L.filterByCategories.indexOf(e) < 0) && L.filterByCategories.push(e)
        }), w.loadHostList("", L.filterByCategories), L.showTrackingTech && D.addEventAdditionalTechnologies(), T("" + D.FILTER_COUNT_SELECTOR).text(L.filterByCategories.length.toString()), Sn.updateFilterSelection(!0), L.pcLayer = se.CookieList, Io.setPCFocus(Io.getPCElements()), this.setSearchInputFocus(), !1
    }, i.prototype.selectAllVendorsLegIntHandler = function(e) {
        var t = T("#onetrust-pc-sdk #" + k.P_Sel_All_Vendor_Leg_El).el[0],
            o = t.classList.contains("line-through"),
            n = T(k.P_Vendor_Container + ' li:not([style="display: none;"]) .vendor-leg-checkbox-handler').el,
            r = e.target.checked,
            i = {};
        L.vendors.selectedLegIntVendors.map(function(e, t) {
            i[e.split(":")[0]] = t
        });
        for (var s = 0; s < n.length; s++) {
            P.setCheckedAttribute(null, n[s], r), I.PCShowConsentLabels && (n[s].parentElement.querySelector(".ot-label-status").innerHTML = v.getInnerHtmlContent(r ? I.PCActiveText : I.PCInactiveText));
            var a = n[s].getAttribute("leg-vendorid"),
                l = i[a];
            void 0 === l && (l = a), L.vendors.selectedLegIntVendors[l] = a + ":" + r
        }
        o && t.classList.remove("line-through"), P.setCheckedAttribute(null, e.target, r), P.setAriaCheckedAttribute(null, e.target, r)
    }, i.prototype.selAllAdtlVenHandler = function(e) {
        for (var t = T("#onetrust-pc-sdk #ot-selall-adtlvencntr").el[0], o = t.classList.contains("line-through"), n = T("#onetrust-pc-sdk .ot-addtlven-chkbox-handler").el, r = e.target.checked, i = 0; i < n.length; i++) P.setCheckedAttribute(null, n[i], r), I.PCShowConsentLabels && (n[i].parentElement.querySelector(".ot-label-status").innerHTML = v.getInnerHtmlContent(r ? I.PCActiveText : I.PCInactiveText));
        r ? I.UseGoogleVendors && Object.keys(L.addtlVendorsList).forEach(function(e) {
            L.addtlVendors.vendorSelected[e] = !0
        }) : L.addtlVendors.vendorSelected = {}, o && t.classList.remove("line-through")
    }, i.prototype.selectAllGenVenHandler = function(e) {
        var t = e.target.checked;
        D.selectAllHandler({
            selAllEl: "#onetrust-pc-sdk #ot-selall-gnvencntr",
            vendorBoxes: "#onetrust-pc-sdk .ot-gnven-chkbox-handler"
        }, "genven", t), P.setCheckedAttribute(null, e.target, t), P.setAriaCheckedAttribute(null, e.target, t)
    }, i.prototype.selectAllHandler = function(e, t, o) {
        for (var n = T(e.selAllEl).el[0], r = n.classList.contains("line-through"), i = T(e.vendorBoxes).el, s = 0; s < i.length; s++) "genven" === t && !o && L.alwaysActiveGenVendors.includes(i[s].getAttribute("gn-vid")) ? (P.setDisabledAttribute(null, i[s], !0), P.setCheckedAttribute(null, i[s], !0)) : P.setCheckedAttribute(null, i[s], o), I.PCShowConsentLabels && (i[s].parentElement.querySelector(".ot-label-status").innerHTML = v.getInnerHtmlContent(o ? I.PCActiveText : I.PCInactiveText));
        o ? "googleven" === t && I.UseGoogleVendors ? Object.keys(L.addtlVendorsList).forEach(function(e) {
            L.addtlVendors.vendorSelected[e] = !0
        }) : "genven" === t && L.showGeneralVendors && I.GeneralVendors.forEach(function(e) {
            L.genVendorsConsent[e.VendorCustomId] = !0
        }) : "googleven" === t ? L.addtlVendors.vendorSelected = {} : (L.genVendorsConsent = {}, L.alwaysActiveGenVendors.forEach(function(e) {
            L.genVendorsConsent[e] = !0
        })), r && n.classList.remove("line-through")
    }, i.prototype.SelectAllVendorConsentHandler = function(e) {
        var t = e.target.checked;
        if (L.showVendorService) c.toggleVendors(t);
        else {
            var o = T("#onetrust-pc-sdk #" + k.P_Sel_All_Vendor_Consent_El).el[0],
                n = o.classList.contains("line-through"),
                r = T(k.P_Vendor_Container + ' li:not([style="display: none;"]) .vendor-checkbox-handler').el,
                i = {};
            L.vendors.selectedVendors.map(function(e, t) {
                i[e.split(":")[0]] = t
            });
            for (var s = 0; s < r.length; s++) {
                P.setCheckedAttribute(null, r[s], t), I.PCShowConsentLabels && (r[s].parentElement.querySelector(".ot-label-status").innerHTML = v.getInnerHtmlContent(t ? I.PCActiveText : I.PCInactiveText));
                var a = r[s].getAttribute("vendorid"),
                    l = i[a];
                void 0 === l && (l = a), L.vendors.selectedVendors[l] = a + ":" + t
            }
            n && o.classList.remove("line-through")
        }
        P.setCheckedAttribute(null, e.target, t), P.setAriaCheckedAttribute(null, e.target, t)
    }, i.prototype.onVendorToggle = function(o, e) {
        var t = L.vendors,
            n = L.addtlVendors,
            r = e === de.LI ? t.selectedLegIntVendors : e === de.AddtlConsent ? [] : t.selectedVendors,
            i = !1,
            s = Number(o);
        r.some(function(e, t) {
            e = e.split(":");
            if (e[0] === o) return s = t, i = "true" === e[1], !0
        }), e === de.LI ? (so.triggerGoogleAnalyticsEvent(Lo, i ? Xo : Qo, t.list.find(function(e) {
            return e.vendorId === o
        }).vendorName + ": " + b.IdPatterns.Pur + o), t.selectedLegIntVendors[s] = o + ":" + !i, A.legIntSettings.PShowLegIntBtn || w.vendorLegIntToggleEvent()) : e === de.AddtlConsent ? (n.vendorSelected[o] ? delete n.vendorSelected[o] : n.vendorSelected[o] = !0, w.venAdtlSelAllTglEvent()) : (so.triggerGoogleAnalyticsEvent(Lo, i ? Jo : Yo, t.list.find(function(e) {
            return e.vendorId === o
        }).vendorName + ": " + b.IdPatterns.Pur + o), t.selectedVendors[s] = o + ":" + !i, w.vendorsListEvent())
    }, i.prototype.onVendorDisclosure = function(r) {
        var i;
        return F(this, void 0, void 0, function() {
            var t, o, n;
            return M(this, function(e) {
                switch (e.label) {
                    case 0:
                        return (t = L.discVendors)[r].isFetched ? [3, 4] : (t[r].isFetched = !0, o = t[r].disclosureUrl, n = void 0, null != (i = m.moduleInitializer) && i.DisclosureCDNUrl ? (o = m.moduleInitializer.DisclosureCDNUrl + "/" + r + ".json", [4, xt.getStorageDisclosure(o)]) : [3, 2]);
                    case 1:
                        if (n = e.sent()) return [2, w.updateVendorDisclosure(r, n)];
                        o = t[r].disclosureUrl, e.label = 2;
                    case 2:
                        return [4, xt.getStorageDisclosure(o)];
                    case 3:
                        return n = e.sent(), [2, w.updateVendorDisclosure(r, n)];
                    case 4:
                        return [2]
                }
            })
        })
    }, i.prototype.tglFltrOptionHandler = function(e) {
        e && e.target.classList.contains("category-filter-handler") && P.setCheckedAttribute(null, e.target, e.target.checked)
    }, i.prototype.selectVendorsGroupHandler = function(e) {
        D.toggleAccordionStatus(e);
        var t = e.target.getAttribute("leg-vendorid"),
            o = e.target.getAttribute("vendorid"),
            n = e.target.getAttribute("addtl-vid"),
            r = e.target.getAttribute("disc-vid");
        t ? D.onVendorToggle(t, de.LI) : o ? D.onVendorToggle(o, de.Consent) : n && D.onVendorToggle(n, de.AddtlConsent), r && D.onVendorDisclosure(r), (t || o || n) && (P.setCheckedAttribute(null, e.target, e.target.checked), I.PCShowConsentLabels) && (e.target.parentElement.querySelector(".ot-label-status").innerHTML = v.getInnerHtmlContent(e.target.checked ? I.PCActiveText : I.PCInactiveText))
    }, i.prototype.toggleVendorFiltersHandler = function() {
        var e, t = !1,
            o = T("#onetrust-pc-sdk " + k.P_Fltr_Modal).el[0];
        switch (A.pcName) {
            case nt:
            case tt:
            case ot:
            case it:
                (t = "block" === o.style.display) ? D.closeFilter(): (e = T("#onetrust-pc-sdk " + k.P_Triangle).el[0], T(e).attr("style", "display: block;"), T(o).attr("style", "display: block;"), e = Array.prototype.slice.call(o.querySelectorAll("[href], input, button")), Io.setPCFocus(e));
                break;
            case rt:
                896 < window.innerWidth || 896 < window.screen.height ? d(o, "width: 400px;", !0) : d(o, "height: 100%; width: 100%;"), o.querySelector(".ot-checkbox input").focus();
                break;
            default:
                return
        }
        m.isV2Template && !t && (T("#onetrust-pc-sdk").addClass("ot-shw-fltr"), T("#onetrust-pc-sdk .ot-fltr-scrlcnt").el[0].scrollTop = 0)
    }, i.prototype.clearFiltersHandler = function() {
        D.setAriaLabelforButtonInFilter(I.PCenterFilterClearedAria);
        for (var e = T("#onetrust-pc-sdk " + k.P_Fltr_Modal + " input").el, t = 0; t < e.length; t++) P.setCheckedAttribute(null, e[t], !1);
        D.isCookieList ? L.filterByCategories = [] : L.filterByIABCategories = []
    }, i.prototype.cancelFilterHandler = function() {
        L.showVendorService ? c.cancelFilter() : D.isCookieList ? Sn.cancelHostFilter() : w.cancelVendorFilter(), D.closeFilter(), T("#onetrust-pc-sdk #filter-btn-handler").focus()
    }, i.prototype.applyFilterHandler = function() {
        var e;
        D.setAriaLabelforButtonInFilter(I.PCenterFilterAppliedAria), L.showVendorService ? (e = c.getGroupsFilter(), c.filterVendorByGroup(e)) : D.isCookieList ? (e = Sn.updateHostFilterList(), w.loadHostList("", e), L.showTrackingTech && D.addEventAdditionalTechnologies()) : (e = w.updateVendorFilterList(), w.loadVendorList("", e)), T("" + D.FILTER_COUNT_SELECTOR).text(String(e.length)), D.closeFilter(), T("#onetrust-pc-sdk #filter-btn-handler").focus()
    }, i.prototype.setAriaLabelforButtonInFilter = function(e) {
        var t = L.isPCVisible ? document.querySelector("#onetrust-pc-sdk span[aria-live]") : document.querySelector("#onetrust-banner-sdk span[aria-live]");
        if (!t) {
            (t = document.createElement("span")).classList.add("ot-scrn-rdr"), t.setAttribute("aria-atomic", "true");
            var o = void 0;
            if (L.isPCVisible ? o = document.getElementById(D.pcSDKSelector) : document.getElementById(D.bannerSelector) && (o = document.getElementById(D.bannerSelector)), !o) return;
            o.appendChild(t)
        }
        t.setAttribute("aria-atomic", "true"), t.setAttribute("aria-relevant", "additions"), t.setAttribute("aria-live", "assertive"), t.setAttribute(Ct, e), D.timeCallback && clearTimeout(D.timeCallback), D.timeCallback = setTimeout(function() {
            D.timeCallback = null, t.setAttribute(Ct, "")
        }, 900)
    }, i.prototype.setPcListContainerHeight = function() {
        T("#onetrust-pc-sdk " + k.P_Content).el[0].classList.contains("ot-hide") ? d(T("" + D.PC_SELECTOR).el[0], 'height: "";', !0) : setTimeout(function() {
            var e = window.innerHeight;
            768 <= window.innerWidth && 600 <= window.innerHeight && (e = .8 * window.innerHeight), !T("#onetrust-pc-sdk " + k.P_Content).el[0].scrollHeight || T("#onetrust-pc-sdk " + k.P_Content).el[0].scrollHeight >= e ? d(T("" + D.PC_SELECTOR).el[0], "height: " + e + "px;", !0) : d(T("" + D.PC_SELECTOR).el[0], "height: auto;", !0)
        })
    }, i.prototype.changeSelectedTab = function(e) {
        var t, o = T("#onetrust-pc-sdk .category-menu-switch-handler"),
            n = 0,
            r = T(o.el[0]);
        o.each(function(e, t) {
            T(e).el.classList.contains(k.P_Active_Menu) && (n = t, T(e).el.classList.remove(k.P_Active_Menu), r = T(e))
        }), e.keyCode === ae.DownArrow ? t = n + 1 >= o.el.length ? T(o.el[0]) : T(o.el[n + 1]) : e.keyCode === ae.UpArrow && (t = T(n - 1 < 0 ? o.el[o.el.length - 1] : o.el[n - 1])), this.tabMenuToggle(t, r)
    }, i.prototype.changeSelectedTabV2 = function(e) {
        var t, o = e.target.parentElement,
            e = (e.keyCode === ae.DownArrow ? t = o.nextElementSibling || o.parentElement.firstChild : e.keyCode === ae.UpArrow && (t = o.previousElementSibling || o.parentElement.lastChild), t.querySelector(".category-menu-switch-handler"));
        e.focus(), this.groupTabClick(e)
    }, i.prototype.categoryMenuSwitchHandler = function() {
        for (var o = this, e = T("#onetrust-pc-sdk .category-menu-switch-handler").el, n = this, t = 0; t < e.length; t++)(t => {
            e[t].addEventListener("click", n.groupTabClick), e[t].addEventListener("keydown", function(e) {
                if (1 <= t && e.shiftKey && 9 === e.keyCode && !I.ShowPreferenceCenterCloseButton && I.PCLayout.Tab && (e.preventDefault(), Io.lastItem.focus()), 32 === e.keyCode || "space" === e.code) return o.groupTabClick(e.currentTarget), e.preventDefault(), !1
            })
        })(t)
    }, i.prototype.groupTabClick = function(e) {
        var t = T("#onetrust-pc-sdk " + k.P_Grp_Container).el[0],
            o = t.querySelector("." + k.P_Active_Menu),
            e = e.currentTarget || e,
            n = e.getAttribute("aria-controls");
        o.setAttribute("tabindex", -1), o.setAttribute("aria-selected", !1), o.classList.remove(k.P_Active_Menu), t.querySelector(k.P_Desc_Container + ":not(.ot-hide)").classList.add("ot-hide"), t.querySelector("#" + n).classList.remove("ot-hide"), e.setAttribute("tabindex", 0), e.setAttribute("aria-selected", !0), e.classList.add(k.P_Active_Menu)
    }, i.prototype.tabMenuToggle = function(e, t) {
        e.el.setAttribute("tabindex", 0), e.el.setAttribute("aria-selected", !0), t.el.setAttribute("tabindex", -1), t.el.setAttribute("aria-selected", !1), e.focus(), t.el.parentElement.parentElement.querySelector("" + k.P_Desc_Container).classList.add("ot-hide"), e.el.parentElement.parentElement.querySelector("" + k.P_Desc_Container).classList.remove("ot-hide"), e.el.classList.add(k.P_Active_Menu)
    }, i.prototype.closeFilter = function(e) {
        var t, o;
        void 0 === e && (e = !0), pn.checkIfPcSdkContainerExist() || (t = T("#onetrust-pc-sdk " + k.P_Fltr_Modal).el[0], o = T("#onetrust-pc-sdk " + k.P_Triangle).el[0], A.pcName === rt ? 896 < window.innerWidth || 896 < window.screen.height ? d(t, "width: 0;", !0) : d(t, "height: 0;") : d(t, "display: none;"), o && T(o).attr("style", "display: none;"), m.isV2Template && T("#onetrust-pc-sdk").removeClass("ot-shw-fltr"), e && Io.setFirstAndLast(Io.getPCElements()))
    }, i.prototype.setBackButtonFocus = function() {
        T("#onetrust-pc-sdk .back-btn-handler").el[0].focus()
    }, i.prototype.setSearchInputFocus = function() {
        T(D.VENDOR_SEARCH_SELECTOR).el[0].focus()
    }, i.prototype.setCenterLayoutFooterHeight = function() {
        var e = D.pc;
        if (D.setMainContentHeight(), A.pcName === it && e) {
            var t = e.querySelectorAll("" + k.P_Desc_Container),
                o = e.querySelectorAll("li .category-menu-switch-handler");
            if (!e.querySelector(".category-menu-switch-handler + " + k.P_Desc_Container) && window.innerWidth <= 640)
                for (var n = 0; n < t.length; n++) o[n].insertAdjacentElement("afterend", t[n]);
            else e.querySelector(".category-menu-switch-handler + " + k.P_Desc_Container) && 640 < window.innerWidth && T(e.querySelector(".ot-tab-desc")).append(t)
        }
    }, i.prototype.setMainContentHeight = function() {
        var e = this.pc,
            t = e.querySelector(".ot-pc-footer"),
            o = e.querySelector(".ot-pc-header"),
            n = e.querySelectorAll(".ot-pc-footer button"),
            r = n[n.length - 1],
            i = I.PCLayout,
            r = (e.classList.remove("ot-ftr-stacked"), n[0] && r && 1 < Math.abs(n[0].offsetTop - r.offsetTop) && e.classList.add("ot-ftr-stacked"), I.PCTemplateUpgrade || i.Center || (n = e.clientHeight - t.clientHeight - o.clientHeight - 3, I.PCTemplateUpgrade && !i.Tab && I.PCenterVendorListDescText && (n = n - ((r = T("#vdr-lst-dsc").el).length && r[0].clientHeight) - 10), d(e.querySelector("" + k.P_Vendor_List), "height: " + n + "px;", !0)), e.querySelector("" + k.P_Content));
        I.PCTemplateUpgrade && i.Center ? (n = 600 < window.innerWidth && 475 < window.innerHeight, !this.pcBodyHeight && n && (this.pcBodyHeight = r.scrollHeight), n ? (i = this.pcBodyHeight + t.clientHeight + o.clientHeight + 20) > .8 * window.innerHeight || 0 === this.pcBodyHeight ? d(e, "height: " + .8 * window.innerHeight + "px;", !0) : d(e, "height: " + i + "px;", !0) : d(e, "height: 100%;", !0)) : d(e.querySelector("" + k.P_Content), "height: " + (e.clientHeight - t.clientHeight - o.clientHeight - 3) + "px;", !0)
    }, i.prototype.allowAllVisible = function(e) {
        e !== this.allowVisible && I.PCLayout.Tab && I.PCTemplateUpgrade && (this.pc && this.setMainContentHeight(), this.allowVisible = e)
    }, i.prototype.restorePc = function() {
        L.pcLayer === se.CookieList ? (D.hideCategoryContainer(!0), w.loadHostList("", L.filterByCategories), L.showTrackingTech && D.addEventAdditionalTechnologies(), T("" + D.FILTER_COUNT_SELECTOR).text(L.filterByCategories.length.toString())) : L.pcLayer === se.VendorList && (D.hideCategoryContainer(!1), D.setVendorContent()), L.isPCVisible = !1, D.toggleInfoDisplay(), L.pcLayer !== se.VendorList && L.pcLayer !== se.CookieList || (Sn.updateFilterSelection(L.pcLayer === se.CookieList), D.setBackButtonFocus(), Io.setPCFocus(Io.getPCElements()))
    }, i.prototype.toggleInfoDisplay = function() {
        return F(this, void 0, void 0, function() {
            var t;
            return M(this, function(e) {
                switch (e.label) {
                    case 0:
                        return N.csBtnGroup && (T(D.fltgBtnSltr).addClass("ot-pc-open"), D.otGuardLogoPromise.then(function() {
                            I.cookiePersistentLogo.includes("ot_guard_logo.svg") && T(D.fltgBtnFSltr).attr(gt, "true")
                        }), T(D.fltgBtnBSltr).attr(gt, ""), T(D.fltgBtnBackBtn).el[0].style.display = "block"), [4, D.fetchAndSetupPC()];
                    case 1:
                        return e.sent(), A.pcName === ot && this.setPcListContainerHeight(), void 0 !== L.pcLayer && L.pcLayer !== se.Banner || (L.pcLayer = se.PrefCenterHome), t = T("" + D.PC_SELECTOR).el[0], T(".onetrust-pc-dark-filter").el[0].removeAttribute("style"), t.removeAttribute("style"), L.isPCVisible || (pn.showConsentNotice(), L.isPCVisible = !0, I.PCTemplateUpgrade && (this.pc = t, t = t.querySelector("#accept-recommended-btn-handler"), this.allowVisible = t && 0 < t.clientHeight, this.setCenterLayoutFooterHeight(), D.getResizeElement().addEventListener("resize", D.setCenterLayoutFooterHeight), window.addEventListener("resize", D.setCenterLayoutFooterHeight)), T(document).on("keydown", D.closePCWhenEscPressed)), window.dispatchEvent(new CustomEvent("OneTrustPCLoaded", {
                            OneTrustPCLoaded: "yes"
                        })), D.captureInitialConsent(), A.requireSignatureEnabled && Fn.getInstance().setConsentIdInPC(), [2]
                }
            })
        })
    }, i.prototype.close = function(t) {
        return F(this, void 0, void 0, function() {
            return M(this, function(e) {
                switch (e.label) {
                    case 0:
                        return I.BCloseButtonType === Pe.Link ? L.bannerCloseSource = ee.ContinueWithoutAcceptingButton : L.bannerCloseSource = ee.BannerCloseButton, [4, O.bannerCloseButtonHandler(t)];
                    case 1:
                        return e.sent(), sn.removeAddedOTCssStyles(), D.getResizeElement().removeEventListener("resize", D.setCenterLayoutFooterHeight), window.removeEventListener("resize", D.setCenterLayoutFooterHeight), [2]
                }
            })
        })
    }, i.prototype.closePreferenceCenter = function(e) {
        e && e.preventDefault(), window.location.href = "http://otsdk//consentChanged"
    }, i.prototype.initializeAlartHtmlAndHandler = function() {
        L.skipAddingHTML = 0 < T("#onetrust-banner-sdk").length, L.skipAddingHTML || er.insertAlertHtml(), this.initialiseAlertHandlers()
    }, i.prototype.initialiseAlertHandlers = function() {
        var e = this,
            t = (er.showBanner(), I.ForceConsent && !h.isCookiePolicyPage(I.AlertNoticeText) && T(".onetrust-pc-dark-filter").removeClass("ot-hide").css("z-index:2147483645;"), I.OnClickCloseBanner && document.body.addEventListener("click", O.bodyClickEvent), I.ScrollCloseBanner && (window.addEventListener("scroll", O.scrollCloseBanner), T(document).on("click", ".onetrust-close-btn-handler", O.rmScrollAndClickBodyEvents), T(document).on("click", "#onetrust-accept-btn-handler", O.rmScrollAndClickBodyEvents), T(document).on("click", "#accept-recommended-btn-handler", O.rmScrollAndClickBodyEvents)), this.addEventListnerForVendorsList(), I.FloatingRoundedIcon && T("#onetrust-banner-sdk #onetrust-cookie-btn").on("click", function(e) {
                L.pcSource = e.currentTarget, D.showCookieSettingsHandler(e)
            }), T("#onetrust-banner-sdk .onetrust-close-btn-handler").on("click", function(e) {
                setTimeout(function() {
                    Fn.getInstance().resetHealthSignatureData(), D.bannerCloseButtonHandler(e)
                }, 0)
            }), T("#onetrust-banner-sdk .ot-bnr-save-handler").on("click", D.bannerCloseButtonHandler), T("#onetrust-banner-sdk #onetrust-pc-btn-handler").on("click", function(e) {
                setTimeout(function() {
                    D.showCookieSettingsHandler(e)
                }, 0)
            }), T("#onetrust-banner-sdk #onetrust-accept-btn-handler").on("click", function() {
                setTimeout(function() {
                    O.allowAllEventHandler(!1)
                }, 0)
            }), T("#onetrust-banner-sdk #onetrust-reject-all-handler").on("click", function() {
                setTimeout(function() {
                    O.rejectAllEventHandler(!1)
                }, 0)
            }), T("#onetrust-banner-sdk .banner-option-input").on("click", A.bannerName === Qe ? D.toggleBannerOptions : D.toggleAccordionStatus), T("#onetrust-banner-sdk .ot-gv-list-handler").on("click", function(t) {
                return F(e, void 0, void 0, function() {
                    return M(this, function(e) {
                        switch (e.label) {
                            case 0:
                                return L.cookieListType = ye.GenVen, [4, D.fetchAndSetupPC()];
                            case 1:
                                return e.sent(), D.loadCookieList(t.target), D.showCookieSettingsHandler(t), [2]
                        }
                    })
                })
            }), T("#onetrust-banner-sdk .category-switch-handler").on("click", D.toggleBannerCategory), document.getElementById("onetrust-banner-sdk"));
        I.ForceConsent && t && "none" !== window.getComputedStyle(t).display && T(document).on("keydown", D.shiftBannerFocus), T("#onetrust-banner-sdk").on("keydown", function(e) {
            32 !== e.keyCode && "Space" !== e.code && 13 !== e.keyCode && "Enter" !== e.code || h.findUserType(e)
        })
    }, i.prototype.addEventListnerForVendorsList = function() {
        (I.IsIabEnabled || I.UseGoogleVendors || L.showGeneralVendors) && !L.showVendorService && T(document).on("click", ".onetrust-vendors-list-handler", function(e) {
            setTimeout(function() {
                D.showAllVendors(e)
            }, 0)
        })
    }, i.prototype.getResizeElement = function() {
        var e = document.querySelector("#onetrust-pc-sdk .ot-text-resize");
        return e ? e.contentWindow || e : document
    }, i.prototype.insertCookieSettingText = function(e) {
        void 0 === e && (e = !1);
        for (var t = I.CookieSettingButtonText, o = T(".ot-sdk-show-settings").el, n = T(".optanon-toggle-display").el, r = 0; r < o.length; r++) T(o[r]).text(t), T(n[r]).text(t);
        e ? (null != (e = document.querySelector(".ot-sdk-show-settings")) && e.addEventListener("click", this.cookiesSettingsBoundListener), null != (e = document.querySelector(".optanon-toggle-display")) && e.addEventListener("click", this.cookiesSettingsBoundListener)) : D.initCookieSettingHandlers()
    }, i.prototype.genVendorToggled = function(e) {
        var t = e.target.getAttribute("gn-vid"),
            o = (fo.updateGenVendorStatus(t, e.target.checked), I.GeneralVendors.find(function(e) {
                return e.VendorCustomId === t
            }).Name);
        so.triggerGoogleAnalyticsEvent(Lo, e.target.checked ? Uo : qo, o + ": VEN_" + t), w.genVenSelectAllTglEvent()
    }, i.prototype.genVendorDetails = function(e) {
        D.toggleAccordionStatus(e)
    }, i.prototype.confirmPC = function(n) {
        return F(this, void 0, void 0, function() {
            var t, o;
            return M(this, function(e) {
                switch (e.label) {
                    case 0:
                        return (t = p.isAlertBoxClosedAndValid(), I.NoBanner && I.ShowPreferenceCenterCloseButton && !t) ? (L.bannerCloseSource = ee.BannerCloseButton, [4, O.bannerCloseButtonHandler()]) : [3, 2];
                    case 1:
                        e.sent(), e.label = 2;
                    case 2:
                        return o = h.isBannerVisible(), !m.moduleInitializer.MobileSDK || !t && o || D.closePreferenceCenter(n), [2]
                }
            })
        })
    }, i.prototype.captureInitialConsent = function() {
        L.initialGroupsConsent = JSON.parse(JSON.stringify(L.groupsConsent)), L.initialHostConsent = JSON.parse(JSON.stringify(L.hostsConsent)), L.showGeneralVendors && (L.initialGenVendorsConsent = JSON.parse(JSON.stringify(L.genVendorsConsent))), I.IsIabEnabled && (L.initialOneTrustIABConsent = JSON.parse(JSON.stringify(L.oneTrustIABConsent)), L.initialVendors = JSON.parse(JSON.stringify(L.vendors)), L.initialVendors.vendorTemplate = L.vendors.vendorTemplate), I.UseGoogleVendors && (L.initialAddtlVendorsList = JSON.parse(JSON.stringify(L.addtlVendorsList)), L.initialAddtlVendors = JSON.parse(JSON.stringify(L.addtlVendors))), L.vsIsActiveAndOptOut && (L.initialVendorsServiceConsent = new Map(L.vsConsent))
    }, i.prototype.getShowCookieSettingClassName = function(e) {
        if (!e || !e.target) return "";
        var e = e.target,
            t = e.className;
        if ("BUTTON" !== e.tagName) {
            e = e.closest("button");
            if (!e) return "";
            t = e.className
        }
        return "string" != typeof t ? "" : t
    };
    var D, ir = i;

    function i() {
        var t = this;
        this.allowVisible = !1, this.fltgBtnBackBtn = ".ot-floating-button__back button", this.fltgBtnBSltr = ".ot-floating-button__back svg", this.fltgBtnFrontBtn = ".ot-floating-button__front button", this.fltgBtnFSltr = ".ot-floating-button__front svg", this.fltgBtnSltr = "#ot-sdk-btn-floating", this.PC_SELECTOR = "#onetrust-pc-sdk", this.FILTER_COUNT_SELECTOR = "#onetrust-pc-sdk #filter-count", this.VENDOR_SEARCH_SELECTOR = "#onetrust-pc-sdk #vendor-search-handler", this.isCookieList = !1, this.pc = null, this.currentSearchInput = "", this.pcLinkSource = null, this.pcSDKSelector = "onetrust-pc-sdk", this.bannerSelector = "onetrust-banner-sdk", this.otGuardLogoResolve = null, this.otGuardLogoPromise = new Promise(function(e) {
            t.otGuardLogoResolve = e
        }), this.closePCWhenEscPressed = function(e) {
            var t, o = document.getElementById(D.pcSDKSelector);
            o && (t = "none" !== window.getComputedStyle(o).display, 27 === e.keyCode && o && t && ("block" === (o = T("#onetrust-pc-sdk " + k.P_Fltr_Modal).el[0]).style.display || "0px" < o.style.width ? (D.closeFilter(), T("#onetrust-pc-sdk #filter-btn-handler").focus()) : I.NoBanner && !I.ShowPreferenceCenterCloseButton || D.hideCookieSettingsHandler(), D.confirmPC()), t && 32 === e.keyCode || "Space" === e.code || 13 === e.keyCode || "Enter" === e.code) && h.findUserType(e)
        }, this.showCookieSettingsHandler = function(n) {
            return F(t, void 0, void 0, function() {
                var t, o;
                return M(this, function(e) {
                    switch (e.label) {
                        case 0:
                            return (o = document.getElementById(D.pcSDKSelector), o && "none" !== window.getComputedStyle(o).getPropertyValue("display")) ? [2] : (T(document).on("keydown", D.closePCWhenEscPressed), n && n.stopPropagation(), n && n.target && (o = this.getShowCookieSettingClassName(n), t = "onetrust-pc-btn-handler" === n.target.id, o = o.includes("ot-sdk-show-settings"), (t || o) && (o = t ? No : wo, so.triggerGoogleAnalyticsEvent(Lo, o)), L.pcSource = n.target), [4, D.toggleInfoDisplay()]);
                        case 1:
                            return e.sent(), [2, !1]
                    }
                })
            })
        }, this.cookiesSettingsBoundListener = this.showCookieSettingsHandler.bind(this), this.backBtnHandler = function() {
            return L.pcLayer === se.IabIllustrations ? Xn.hideUI() : (L.showVendorService && c.hideVendorList(), L.showTrackingTech && (D.currentSearchInput = "")), O.hideVendorsList(), A.pcName === ot && (T("#onetrust-pc-sdk " + k.P_Content).removeClass("ot-hide"), T("" + D.PC_SELECTOR).el[0].removeAttribute("style"), t.setPcListContainerHeight()), T("" + D.FILTER_COUNT_SELECTOR).text("0"), T(D.VENDOR_SEARCH_SELECTOR).length && (T(D.VENDOR_SEARCH_SELECTOR).el[0].value = ""), L.currentGlobalFilteredList = [], L.filterByCategories = [], L.filterByIABCategories = [], L.vendors.searchParam = "", D.closeFilter(), L.pcLayer = se.PrefCenterHome, t.pcLinkSource ? (t.pcLinkSource.focus(), t.pcLinkSource = null) : Io.setPCFocus(Io.getPCElements()), !1
        }, this.bannerCloseBoundListener = this.bannerCloseButtonHandler.bind(this), this.toggleGroupORVendorHandler = function(e) {
            var t = e.currentTarget;
            t.dataset.otVsId ? D.toggleVendorServiceHandler.bind(this)(e) : t.dataset.optanongroupid && D.toggleV2Category.bind(this)()
        }, this.toggleVendorFromListHandler = function(e) {
            var e = e.currentTarget,
                t = e.checked,
                o = e.dataset.otVsId,
                e = e.dataset.optanongroupid,
                n = document.getElementById("ot-vendor-id-" + o);
            E.toggleVendorService(e, o, t, n)
        }, this.toggleVendorServiceHandler = function(e) {
            var e = e.currentTarget,
                t = e.checked,
                o = e.dataset.otVsId,
                n = e.dataset.optanongroupid,
                n = (E.toggleVendorService(n, o, t, e), y.getVSById(o));
            D.setAriaLabelforButtonInFilter(n.ServiceName)
        }, this.toggleV2Category = function(e, t, o, n) {
            t || (r = this.getAttribute("data-optanongroupid"), i = "function" == typeof this.getAttribute, a = P.findIndex(L.dataGroupState, function(e) {
                return i && e.CustomGroupId === r
            }), t = L.dataGroupState[a]), void 0 === o && (o = T(this).is(":checked")), I.ChoicesBanner && P.setCheckedAttribute("#ot-bnr-grp-id-" + t.CustomGroupId, null, o), n ? document.querySelector("#ot-group-id-" + n) && (P.setCheckedAttribute("#ot-group-id-" + n, null, o), s = document.querySelector("#ot-group-id-" + n)) : (P.setCheckedAttribute(null, s = this, o), s.parentElement.querySelector(".ot-switch-nob")), I.PCShowConsentLabels && (s.parentElement.parentElement.querySelector(".ot-label-status").innerHTML = v.getInnerHtmlContent(o ? I.PCActiveText : I.PCInactiveText));
            var r, i, s, a = this instanceof HTMLElement && -1 !== this.getAttribute("id").indexOf("-leg-out");
            D.setAriaLabelforButtonInFilter(t.GroupName), D.updateGroupToggles(t, o, a)
        }, this.toggleBannerCategory = function() {
            var t = this,
                e = P.findIndex(L.dataGroupState, function(e) {
                    return "function" == typeof t.getAttribute && e.CustomGroupId === t.getAttribute("data-optanongroupid")
                }),
                e = L.dataGroupState[e],
                o = T(t).is(":checked");
            D.toggleV2Category(null, e, o, e.CustomGroupId)
        }, this.shiftBannerFocus = function(e) {
            var t = document.getElementById(D.pcSDKSelector),
                o = !1;
            t && (o = "none" !== window.getComputedStyle(t).display), "Tab" !== e.code || o || Io.handleBannerFocus(e, e.shiftKey)
        }, this.toggleSubCategory = function(e, t, o, n) {
            t = t || this.getAttribute("data-optanongroupid");
            var r, t = y.getGroupById(t),
                n = (void 0 === o && (o = T(this).is(":checked")), n ? (P.setCheckedAttribute("#ot-sub-group-id-" + n, null, o), r = document.querySelector("#ot-sub-group-id-" + n)) : P.setCheckedAttribute(null, r = this, o), y.getParentGroup(t.Parent).ShowSubgroup),
                n = (I.PCShowConsentLabels && n && (r.parentElement.parentElement.querySelector(".ot-label-status").innerHTML = v.getInnerHtmlContent(o ? I.PCActiveText : I.PCInactiveText)), this instanceof HTMLElement && -1 !== this.getAttribute("id").indexOf("-leg-out"));
            D.setAriaLabelforButtonInFilter(t.GroupName), D.updateSubGroupToggles(t, o, n), E.setVendorStateByGroup(t, o)
        }
    }
    lr.prototype.initialiseLandingPath = function() {
        var e = p.needReconsent();
        vo.isLandingPage() ? vo.setLandingPathParam(location.href) : e && !p.awaitingReconsent() ? (vo.setLandingPathParam(location.href), g.writeCookieParam(C.OPTANON_CONSENT, u.AWAITING_RE_CONSENT, !0)) : (e || g.writeCookieParam(C.OPTANON_CONSENT, u.AWAITING_RE_CONSENT, !1), vo.setLandingPathParam(u.NOT_LANDING_PAGE), A.isSoftOptInMode && !m.moduleInitializer.MobileSDK && so.setAlertBoxClosed(!0), I.NextPageCloseBanner && I.ShowAlertNotice && O.nextPageCloseBanner())
    };
    var sr, ar = lr;

    function lr() {}
    ur.prototype.insertCookiePolicyHtml = function() {
        if (T(this.ONETRUST_COOKIE_POLICY).length) {
            var e, t, o, n = document.createDocumentFragment(),
                r = (N.cookieListGroup && (t = I.CookiesV2NewCookiePolicy ? ".ot-sdk-cookie-policy" : "#ot-sdk-cookie-policy-v2", o = document.createElement("div"), T(o).html(N.cookieListGroup.html), o.removeChild(o.querySelector(t)), e = o.querySelector(".ot-sdk-cookie-policy"), I.useRTL) && T(e).attr("dir", "rtl"), e.querySelector("#cookie-policy-title").innerHTML = v.getInnerHtmlContent(I.CookieListTitle || ""), e.querySelector("#cookie-policy-description").innerHTML = v.getInnerHtmlContent(I.CookieListDescription || ""), e.querySelector("section")),
                i = e.querySelector("section tbody tr"),
                s = null,
                a = null;
            I.CookiesV2NewCookiePolicy || (s = e.querySelector("section.subgroup"), a = e.querySelector("section.subgroup tbody tr"), T(e).el.removeChild(e.querySelector("section.subgroup"))), T(e).el.removeChild(e.querySelector("section")), !T(this.COOKIE_POLICY_SELECTOR).length && T(this.OPTANON_POLICY_SELECTOR).length ? T(this.OPTANON_POLICY_SELECTOR).append('<div id="ot-sdk-cookie-policy"></div>') : (T(this.COOKIE_POLICY_SELECTOR).html(""), T(this.OPTANON_POLICY_SELECTOR).html(""));
            for (var l = 0, c = I.Groups; l < c.length; l++) {
                var d = c[l],
                    u = {
                        json: I,
                        group: d,
                        sectionTemplate: r,
                        tableRowTemplate: i,
                        cookieList: e,
                        fragment: n
                    };
                if (I.CookiesV2NewCookiePolicy) this.insertGroupHTMLV2(u);
                else if (this.insertGroupHTML(u), d.ShowSubgroup)
                    for (var p = 0, C = d.SubGroups; p < C.length; p++) {
                        var g = C[p],
                            g = {
                                json: I,
                                group: g,
                                sectionTemplate: s,
                                tableRowTemplate: a,
                                cookieList: e,
                                fragment: n
                            };
                        this.insertGroupHTML(g)
                    }
            }
        }
    }, ur.prototype.insertGroupHTMLV2 = function(e) {
        function t(e) {
            return c.querySelector(e)
        }
        var o, n = this,
            r = e.json,
            i = e.group,
            s = e.sectionTemplate,
            a = e.tableRowTemplate,
            l = e.cookieList,
            e = e.fragment,
            c = s.cloneNode(!0),
            s = i.SubGroups,
            d = (T(t("tbody")).html(""), i.Hosts.slice()),
            u = i.FirstPartyCookies.slice(),
            p = d.length || u.length ? i.GroupName : "",
            s = (i.ShowSubgroup && s.length ? (o = c.querySelector("section.ot-sdk-subgroup ul li"), s.forEach(function(e) {
                var t = o.cloneNode(!0);
                d = d.concat(e.Hosts), u = u.concat(e.FirstPartyCookies), (e.Hosts.length || e.FirstPartyCookies.length) && (p += "," + e.GroupName), T(t.querySelector(".ot-sdk-cookie-policy-group")).html(e.GroupName), T(t.querySelector(".ot-sdk-cookie-policy-group-desc")).html(n.groupsClass.safeFormattedGroupDescription(e)), T(o.parentElement).append(t)
            }), c.querySelector("section.ot-sdk-subgroup ul").removeChild(o)) : c.removeChild(c.querySelector("section.ot-sdk-subgroup")), I.TTLGroupByTech && (this.setCookieListHeaderOrder(c), this.setCookieListBodyOrder(a)), r.IsLifespanEnabled ? T(t("th.ot-life-span")).el.innerHTML = v.getInnerHtmlContent(r.LifespanText) : T(t("thead tr")).el.removeChild(T(t("th.ot-life-span")).el), T(t("th.ot-cookies")).el.innerHTML = v.getInnerHtmlContent(r.CookiesText), T(t("th.ot-host")).el.innerHTML = v.getInnerHtmlContent(r.CategoriesText), T(t("th.ot-cookies-type")).el.innerHTML = v.getInnerHtmlContent(r.CookiesUsedText), T(t("th.ot-host-description")).el.innerHTML = v.getInnerHtmlContent(r.CookiesDescText), this.transformFirstPartyCookies(u, d, i)),
            C = !1;
        (C = I.TTLGroupByTech ? I.TTLShowTechDesc : s.some(function(e) {
            return e.Description
        })) || T(t("thead tr")).el.removeChild(T(t("th.ot-host-description")).el), T(t(".ot-sdk-cookie-policy-group")).html(i.GroupName), T(t(".ot-sdk-cookie-policy-group-desc")).html(this.groupsClass.safeFormattedGroupDescription(i)), I.TTLGroupByTech ? this.insertCookieLineByLine({
            json: r,
            hosts: s,
            tableRowTemplate: a,
            showHostDescription: C,
            st: t
        }) : this.insertHostHtmlV2({
            json: r,
            hosts: s,
            tableRowTemplate: a,
            showHostDescription: C,
            st: t
        }), 0 === s.length ? c.removeChild(c.querySelector("table")) : T(t("caption")).el.innerHTML = v.getInnerHtmlContent(p), T(l).append(c), T(e).append(l), T(this.COOKIE_POLICY_SELECTOR).append(e)
    }, ur.prototype.insertHostHtmlV2 = function(e) {
        for (var l, c = e.json, d = e.tableRowTemplate, u = e.showHostDescription, p = e.st, C = this, t = 0, o = e.hosts; t < o.length; t++)(e => {
            for (var t = d.cloneNode(!0), o = function(e) {
                    return t.querySelector(e)
                }, n = (C.clearCookieRowElement(o), []), r = [], i = 0, s = e.Cookies; i < s.length; i++) {
                var a = s[i],
                    a = ((l = a).IsSession ? n.push(c.LifespanTypeText) : n.push(h.getDuration(l)), l.Name);
                e.Type && (a = '\n                    <a href="https://cookiepedia.co.uk/cookies/' + l.Name + '"\n                        rel="noopener" target="_blank" aria-label="' + l.Name + " " + I.NewWinTxt + '">\n                        ' + l.Name + "\n                    </a>"), r.push(a)
            }
            C.setDataLabelAttribute(o, c), C.createCookieRowHtmlElement({
                host: e,
                subGroupCookie: l,
                trt: o,
                json: c,
                lifespanText: n.join(", "),
                hostType: r.join(", ")
            }), C.removeLifeSpanOrHostDescription(c, u, t, o), T(p("tbody")).append(t)
        })(o[t])
    }, ur.prototype.insertGroupHTML = function(e) {
        function t(e) {
            return l.querySelector(e)
        }
        var o, n = e.json,
            r = e.group,
            i = e.sectionTemplate,
            s = e.tableRowTemplate,
            a = e.cookieList,
            e = e.fragment,
            l = i.cloneNode(!0),
            i = (T(t("caption")).el.innerHTML = v.getInnerHtmlContent(r.GroupName), T(t("tbody")).html(""), T(t("thead tr")), n.IsLifespanEnabled ? T(t("th.life-span")).el.innerHTML = v.getInnerHtmlContent(n.LifespanText) : T(t("thead tr")).el.removeChild(T(t("th.life-span")).el), T(t("th.cookies")).el.innerHTML = v.getInnerHtmlContent(n.CookiesText), T(t("th.host")).el.innerHTML = v.getInnerHtmlContent(n.CategoriesText), !1);
        if (r.Hosts.some(function(e) {
                return e.description
            }) ? i = !0 : T(t("thead tr")).el.removeChild(T(t("th.host-description")).el), T(t(".ot-sdk-cookie-policy-group")).html(r.GroupName), T(t(".ot-sdk-cookie-policy-group-desc")).html(this.groupsClass.safeFormattedGroupDescription(r)), 0 < r.FirstPartyCookies.length) {
            T(t(".cookies-used-header")).html(n.CookiesUsedText), T(t(".cookies-list")).html("");
            for (var c = 0; c < r.FirstPartyCookies.length; c++) o = r.FirstPartyCookies[c], T(t(".cookies-list")).append("<li> " + h.getCookieLabel(o, n.AddLinksToCookiepedia) + " <li>")
        } else l.removeChild(t(".cookies-used-header")), l.removeChild(t(".cookies-list"));
        this.insertHostHtmlV1({
            json: n,
            hosts: r.Hosts,
            tableRowTemplate: s,
            showHostDescription: i,
            st: t
        }), T(a).append(l), T(e).append(a), T(this.COOKIE_POLICY_SELECTOR).append(e)
    }, ur.prototype.insertHostHtmlV1 = function(e) {
        for (var l = e.json, t = e.hosts, c = e.tableRowTemplate, d = e.showHostDescription, u = e.st, o = 0, n = t; o < n.length; o++)(e => {
            for (var t = c.cloneNode(!0), o = function(e) {
                    return t.querySelector(e)
                }, n = (T(o(".cookies-td ul")).html(""), T(o(".life-span-td ul")).html(""), T(o(".host-td")).html(""), T(o(".host-description-td")).html('<span class="ot-mobile-border"></span><p>' + e.Description + "</p> "), 0), r = 0, i = e.Cookies; r < i.length; r++) {
                var s = i[r],
                    a = "",
                    a = s.IsSession ? l.LifespanTypeText : 0 === s.Length ? "<1 " + l.LifespanDurationText || l.PCenterVendorListLifespanDays : s.Length + " " + l.LifespanDurationText || l.PCenterVendorListLifespanDays,
                    a = l.IsLifespanEnabled ? "&nbsp;(" + a + ")" : "";
                T(o(".cookies-td ul")).append("<li> " + s.Name + " " + a + " </li>"), l.IsLifespanEnabled && (a = s.Length ? s.Length + " days" : "N/A", T(o(".life-span-td ul")).append("<li>" + a + "</li>")), 0 === n && (T(o(".host-td")).append('<span class="ot-mobile-border"></span>'), T(o(".host-td")).append('<a href="https://cookiepedia.co.uk/host/' + s.Host + '" rel="noopener" target="_blank"\n                        aria-label="' + (e.DisplayName || e.HostName) + " " + I.NewWinTxt + '">' + (e.DisplayName || e.HostName) + "</a>")), n++
            }
            d || t.removeChild(o("td.host-description-td")), T(u("tbody")).append(t)
        })(n[o]);
        0 === t.length && T(u("table")).el.removeChild(T(u("thead")).el)
    }, ur.prototype.transformFirstPartyCookies = function(e, t, o) {
        var n = this,
            r = t.slice(),
            t = (e.forEach(function(e) {
                n.populateHostGroup(e, r, I.firstPartyTxt)
            }), o.GeneralVendorsIds),
            e = (this.populateGenVendor(t, o, r), o.SubGroups || []);
        return e.length && e.forEach(function(e) {
            var t = e.GeneralVendorsIds;
            n.populateGenVendor(t, e, r)
        }), r
    }, ur.prototype.populateGenVendor = function(e, o, n) {
        var r = this;
        e.length && e.forEach(function(t) {
            var e = I.GeneralVendors.find(function(e) {
                return e.VendorCustomId === t
            });
            e.Cookies.length && e.Cookies.forEach(function(e) {
                var t;
                e.category === o.GroupName && (t = e.isThirdParty ? "" : I.firstPartyTxt, r.populateHostGroup(e, n, t))
            })
        })
    }, ur.prototype.populateHostGroup = function(t, e, o) {
        e.some(function(e) {
            if (e.HostName === t.Host && e.Type === o) return e.Cookies.push(t), !0
        }) || e.unshift({
            HostName: t.Host,
            DisplayName: t.Host,
            HostId: "",
            Description: "",
            Type: o,
            Cookies: [t]
        })
    }, ur.prototype.insertCookieLineByLine = function(e) {
        for (var t = e.json, o = e.tableRowTemplate, n = e.showHostDescription, r = e.st, i = 0, s = e.hosts; i < s.length; i++)
            for (var a = s[i], l = 0, c = a.Cookies; l < c.length; l++) {
                var d = c[l],
                    u = d.IsSession ? t.LifespanTypeText : h.getDuration(d),
                    p = d.Name,
                    C = (a.Type && (p = '<a href="https://cookiepedia.co.uk/cookies/' + p + '"\n                        rel="noopener" target="_blank" aria-label="' + p + " " + I.NewWinTxt + '">' + p + "\n                    </a>"), o.cloneNode(!0)),
                    g = this.queryToHtmlElement(C);
                this.clearCookieRowElement(g), this.createCookieRowHtmlElement({
                    host: a,
                    subGroupCookie: d,
                    trt: g,
                    json: t,
                    lifespanText: u,
                    hostType: p
                }), this.removeLifeSpanOrHostDescription(t, n, C, g), T(r("tbody")).append(C)
            }
    }, ur.prototype.removeLifeSpanOrHostDescription = function(e, t, o, n) {
        e.IsLifespanEnabled || o.removeChild(n("td.ot-life-span-td")), t || o.removeChild(n("td.ot-host-description-td"))
    }, ur.prototype.createCookieRowHtmlElement = function(e) {
        var t = e.host,
            o = e.subGroupCookie,
            n = e.trt,
            r = e.lifespanText,
            i = e.hostType,
            s = ".ot-host-td",
            e = (this.setDataLabelAttribute(n, e.json), T(n(".ot-host-description-td")).html('<span class="ot-mobile-border"></span><p>' + o.description + "</p> "), T(n(s)).append('<span class="ot-mobile-border"></span>'), t.DisplayName || t.HostName);
        T(n(s)).append(t.Type ? e : '<a href="https://cookiepedia.co.uk/host/' + o.Host + '" rel="noopener" target="_blank"\n                        aria-label="' + e + " " + I.NewWinTxt + '">\n                        ' + e + "\n                        </a>"), n(".ot-cookies-td .ot-cookies-td-content").insertAdjacentHTML("beforeend", v.getInnerHtmlContent(i)), T(n(".ot-life-span-td .ot-life-span-td-content")).html(r), T(n(".ot-cookies-type .ot-cookies-type-td-content")).html(t.Type ? I.firstPartyTxt : I.thirdPartyTxt)
    }, ur.prototype.setDataLabelAttribute = function(e, t) {
        var o = "data-label";
        e(".ot-host-td").setAttribute(o, t.CategoriesText), e(".ot-cookies-td").setAttribute(o, t.CookiesText), e(".ot-cookies-type").setAttribute(o, t.CookiesUsedText), e(".ot-life-span-td").setAttribute(o, t.LifespanText), e(".ot-host-description-td").setAttribute(o, t.CookiesDescText)
    }, ur.prototype.clearCookieRowElement = function(e) {
        T(e(".ot-cookies-td span")).text(""), T(e(".ot-life-span-td span")).text(""), T(e(".ot-cookies-type span")).text(""), T(e(".ot-cookies-td .ot-cookies-td-content")).html(""), T(e(".ot-host-td")).html("")
    }, ur.prototype.setCookieListHeaderOrder = function(e) {
        var e = e.querySelector("section table thead tr"),
            t = e.querySelector("th.ot-host"),
            o = e.querySelector("th.ot-cookies"),
            n = e.querySelector("th.ot-life-span"),
            r = e.querySelector("th.ot-cookies-type"),
            i = e.querySelector("th.ot-host-description");
        e.innerHTML = v.getInnerHtmlContent(""), e.appendChild(o.cloneNode(!0)), e.appendChild(t.cloneNode(!0)), e.appendChild(n.cloneNode(!0)), e.appendChild(r.cloneNode(!0)), e.appendChild(i.cloneNode(!0))
    }, ur.prototype.setCookieListBodyOrder = function(e) {
        var t = e.querySelector("td.ot-host-td"),
            o = e.querySelector("td.ot-cookies-td"),
            n = e.querySelector("td.ot-life-span-td"),
            r = e.querySelector("td.ot-cookies-type"),
            i = e.querySelector("td.ot-host-description-td");
        e.innerHTML = v.getInnerHtmlContent(""), e.appendChild(o.cloneNode(!0)), e.appendChild(t.cloneNode(!0)), e.appendChild(n.cloneNode(!0)), e.appendChild(r.cloneNode(!0)), e.appendChild(i.cloneNode(!0))
    }, ur.prototype.queryToHtmlElement = function(t) {
        return function(e) {
            return t.querySelector(e)
        }
    };
    var cr, dr = ur;

    function ur() {
        this.groupsClass = f, this.COOKIE_POLICY_SELECTOR = "#ot-sdk-cookie-policy", this.OPTANON_POLICY_SELECTOR = "#optanon-cookie-policy", this.ONETRUST_COOKIE_POLICY = "#ot-sdk-cookie-policy, #optanon-cookie-policy"
    }
    gr.prototype.IsAlertBoxClosedAndValid = function() {
        return p.isAlertBoxClosedAndValid()
    }, gr.prototype.LoadBanner = function() {
        so.loadBanner()
    }, gr.prototype.Init = function(e) {
        void 0 === e && (e = !1), Ge.insertViewPortTag(), N.ensureHtmlGroupDataInitialised(), hn.updateGtmMacros(!1), sr.initialiseLandingPath(), e || Qt.initialiseCssReferences()
    }, gr.prototype.FetchAndDownloadPC = function() {
        D.fetchAndSetupPC()
    }, gr.prototype.ToggleInfoDisplay = function() {
        so.triggerGoogleAnalyticsEvent(Lo, Go), D.toggleInfoDisplay()
    }, gr.prototype.Close = function(e) {
        D.close(e)
    }, gr.prototype.AllowAll = function(e) {
        O.allowAllEvent(e)
    }, gr.prototype.RejectAll = function(e) {
        O.rejectAllEvent(e)
    }, gr.prototype.sendReceipt = function() {
        var e = g.readCookieParam(C.OPTANON_CONSENT, u.INTERACTION_TYPE);
        hs.createConsentTxn(!1, e, !1, !0, !0)
    }, gr.prototype.setDataSubjectIdV2 = function(e, t, o) {
        void 0 === t && (t = !1), void 0 === o && (o = ""), (e || t) && (e && e.trim() && (e = e.replace(/ /g, ""), g.writeCookieParam(C.OPTANON_CONSENT, u.CONSENT_ID, e, !0)), null != (e = o) && e.trim() && g.writeCookieParam(C.OPTANON_CONSENT, u.IDENTIFIER_TYPE, o.trim()), L.dsParams.isAnonymous = t, L.dsParams.forceUserConsentAttributes = !0, g.writeCookieParam(C.OPTANON_CONSENT, u.IS_ANONYMOUS_CONSENT, t ? "1" : "0"))
    }, gr.prototype.getDataSubjectId = function() {
        return g.readCookieParam(C.OPTANON_CONSENT, u.CONSENT_ID, !0)
    }, gr.prototype.getDSDefaultIdentifier = function() {
        var e;
        return null == (e = I.ConsentIntegration) ? void 0 : e.DefaultIdentifier
    }, gr.prototype.synchroniseCookieWithPayload = function(n) {
        var e = g.readCookieParam(C.OPTANON_CONSENT, "groups"),
            e = P.strToArr(e),
            r = [];
        e.forEach(function(e) {
            var e = e.split(":"),
                t = y.getGroupById(e[0]),
                o = P.findIndex(n, function(e) {
                    return e.Id === t.PurposeId
                }),
                o = n[o];
            o ? o.TransactionType === xe ? (r.push(e[0] + ":1"), t.Parent ? D.toggleSubCategory(null, t.CustomGroupId, !0, t.CustomGroupId) : D.toggleV2Category(null, t, !0, t.CustomGroupId)) : (r.push(e[0] + ":0"), t.Parent ? D.toggleSubCategory(null, t.CustomGroupId, !1, t.CustomGroupId) : D.toggleV2Category(null, t, !1, t.CustomGroupId)) : r.push(e[0] + ":" + e[1])
        }), co.writeGrpParam(C.OPTANON_CONSENT, r)
    }, gr.prototype.getGeolocationData = function() {
        return L.userLocation
    }, gr.prototype.TriggerGoogleAnalyticsEvent = function(e, t, o, n) {
        so.triggerGoogleAnalyticsEvent(e, t, o, n)
    }, gr.prototype.ReconsentGroups = function() {
        var n = !1,
            e = g.readCookieParam(C.OPTANON_CONSENT, "groups"),
            r = P.strToArr(e),
            i = P.strToArr(e.replace(/:0|:1/g, "")),
            s = !1,
            t = g.readCookieParam(C.OPTANON_CONSENT, "hosts"),
            a = P.strToArr(t),
            l = P.strToArr(t.replace(/:0|:1/g, "")),
            c = ["inactive", "inactive landingpage", "do not track"];
        e && (I.Groups.forEach(function(e) {
            U(e.SubGroups, [e]).forEach(function(e) {
                var t = e.CustomGroupId,
                    o = P.indexOf(i, t); - 1 !== o && (e = y.getGrpStatus(e).toLowerCase(), -1 < c.indexOf(e)) && (n = !0, r[o] = t + ("inactive landingpage" === e ? ":1" : ":0"))
            })
        }), n) && co.writeGrpParam(C.OPTANON_CONSENT, r), t && (I.Groups.forEach(function(e) {
            U(e.SubGroups, [e]).forEach(function(n) {
                n.Hosts.forEach(function(e) {
                    var t, o = P.indexOf(l, e.HostId); - 1 !== o && (t = y.getGrpStatus(n).toLowerCase(), -1 < c.indexOf(t)) && (s = !0, a[o] = e.HostId + ("inactive landingpage" === t ? ":1" : ":0"))
                })
            })
        }), s) && co.writeHstParam(C.OPTANON_CONSENT, a)
    }, gr.prototype.SetAlertBoxClosed = function(e) {
        so.setAlertBoxClosed(e)
    }, gr.prototype.GetDomainData = function() {
        return A.pubDomainData
    }, gr.prototype.setGeoLocation = function(e, t) {
        L.userLocation = {
            country: e,
            state: t = void 0 === t ? "" : t,
            stateName: ""
        }
    }, gr.prototype.changeLang = function(t) {
        var o;
        t !== L.lang && (o = m.moduleInitializer, xt.getLangJson(t).then(function(e) {
            e ? (A.init(e), N.fetchAssets(t).then(function() {
                var e = document.getElementById("onetrust-style"),
                    e = (e && (e.textContent = ""), Qt.initialiseCssReferences(), o.IsSuppressPC && !L.isPCVisible || (P.removeChild(T("#onetrust-pc-sdk").el), L.vendorDomInit = !1, L.genVendorDomInit = !1, V.insertPcHtml(), D.initialiseConsentNoticeHandlers(), I.IsIabEnabled && (p.assignIABDataWithGlobalVendorList(L.gvlObj), w.InitializeVendorList()), L.isPCVisible && D.restorePc()), !0);
                P.removeChild(T("#onetrust-banner-sdk").el), p.isAlertBoxClosedAndValid() || o.IsSuppressBanner && (o.IsSuppressBanner, L.skipAddingHTML) || I.NoBanner || !I.ShowAlertNotice || (D.initializeAlartHtmlAndHandler(), e = !1), pr.initCookiePolicyAndSettings(), P.removeChild(T("#ot-sdk-btn-floating").el), ks.insertCSBtn(e), pr.processedHtml = null, pr.updateTCStringOnLangChange(t)
            })) : console.error("Language:" + t + " doesn't exist for the geo rule")
        }))
    }, gr.prototype.updateTCStringOnLangChange = function(e) {
        A.isIab2orv2Template && (L.consentLanguage = e, L.tcModel.consentLanguage = L.consentLanguage, L.tcModel.useNonStandardTexts = I.UseNonStandardStacks, p.isAlertBoxClosedAndValid() || h.updateTCString())
    }, gr.prototype.initCookiePolicyAndSettings = function(e) {
        var t;
        (e = void 0 === e ? !1 : e) && (null != (t = document.querySelector(".ot-sdk-show-settings")) && t.removeEventListener("click", D.cookiesSettingsBoundListener), null != (t = document.querySelector(".optanon-toggle-display"))) && t.removeEventListener("click", D.cookiesSettingsBoundListener), m.fp.CookieV2TrackingTechnologies ? ks.insertTrackingTechnologies() : cr.insertCookiePolicyHtml(), D.insertCookieSettingText(e)
    }, gr.prototype.showVendorsList = function() {
        L.pcLayer !== se.VendorList && (D.showAllVendors(), so.triggerGoogleAnalyticsEvent(Lo, xo))
    }, gr.prototype.getTestLogData = function() {
        var e = I.Groups,
            t = A.pubDomainData,
            o = m.moduleInitializer.Version,
            o = (console.info("%cWelcome to OneTrust Log", "padding: 8px; background-color: #43c233; color: white; font-style: italic; border: 1px solid black; font-size: 1.5em;"), console.info("Script is for: %c" + (t.Domain || I.optanonCookieDomain), "padding: 4px 6px; font-style: italic; border: 2px solid #43c233; font-size: 12px;"), console.info("Script Version Published: " + o), console.info("The consent model is: " + t.ConsentModel.Name), null !== p.alertBoxCloseDate()),
            n = (console.info("Consent has " + (o ? "" : "not ") + "been given " + (o ? "👍" : "🛑")), hn.checkAndWarnGCMConfig(), []),
            r = (e.forEach(function(e) {
                var t = "",
                    t = e.Status && "always active" === e.Status.toLowerCase() ? "Always Active" : f.isGroupActive(e) ? "Active" : "Inactive";
                n.push({
                    CustomGroupId: e.CustomGroupId,
                    GroupName: e.GroupName,
                    Status: t
                })
            }), console.groupCollapsed("Current Category Status"), console.table(n), console.groupEnd(), []),
            o = (t.GeneralVendors.forEach(function(e) {
                r.push({
                    CustomGroupId: e.VendorCustomId,
                    Name: e.Name,
                    Status: pr.isCategoryActive(e.VendorCustomId) ? "active" : "inactive"
                })
            }), console.groupCollapsed("General Vendor Ids"), console.table(r), console.groupEnd(), A.getRegionRule()),
            t = L.userLocation,
            i = m.moduleInitializer.GeoRuleGroupName,
            t = (A.conditionalLogicEnabled ? console.groupCollapsed("Geolocation, Template & Condition") : console.groupCollapsed("Geolocation and Template"), L.userLocation.country && console.info("The Geolocation is " + t.country.toUpperCase()), console.info("The Geolocation rule is " + o.Name), console.info("The GeolocationRuleGroup is " + i), A.canUseConditionalLogic && console.info("The Condition name is " + A.Condition.Name), console.info("The TemplateName is " + A.getTemplateName()), console.groupEnd(), e.filter(function(e) {
                return f.isGroupActive(e) && "COOKIE" === e.Type
            }));
        console.groupCollapsed("The cookies expected to be active if blocking has been implemented are"), t.forEach(function(e) {
            console.groupCollapsed(e.GroupName);
            e = pr.getAllFormatCookiesForAGroup(e);
            console.table(e, ["Name", "Host", "description"]), console.groupEnd()
        }), console.groupEnd()
    }, gr.prototype.isCategoryActive = function(e) {
        return -1 !== window.OptanonActiveGroups.indexOf("," + e + ",")
    }, gr.prototype.getAllFormatCookiesForAGroup = function(e) {
        var t = [];
        return e.FirstPartyCookies.forEach(function(e) {
            return t.push({
                Name: e.Name,
                Host: e.Host,
                Description: e.description
            })
        }), (null == (e = e.Hosts) ? void 0 : e.reduce(function(e, t) {
            return e.concat(JSON.parse(JSON.stringify(t.Cookies)))
        }, [])).forEach(function(e) {
            return t.push({
                Name: e.Name,
                Host: e.Host,
                Description: e.description
            })
        }), t
    }, gr.prototype.updateSingularConsent = function(l, c) {
        return F(this, void 0, void 0, function() {
            var t, o, n, r, i, s, a;
            return M(this, function(e) {
                switch (e.label) {
                    case 0:
                        return [4, D.fetchAndSetupPC()];
                    case 1:
                        for (e.sent(), A.apiSource = oe.UpdateConsent, t = c.split(","), o = [], n = 0, r = t; n < r.length; n++) s = r[n], s = s.split(":"), i = s[0], s = s[1], a = Boolean(Number(s)), l === ct ? "always active" === y.getGrpStatus(y.getGroupById(i)) || (pr.updateConsentArray(L.groupsConsent, i, s), o.push({
                            id: i,
                            isEnabled: a
                        })) : l === dt ? pr.updateConsentArray(L.hostsConsent, i, s) : l === ut ? L.genVendorsConsent[i] = a : l === pt && o.push({
                            id: i,
                            isEnabled: a
                        });
                        return O.handleTogglesOnSingularConsentUpdate(l, o), [2]
                }
            })
        })
    }, gr.prototype.vendorServiceEnabled = function() {
        return L.showVendorService
    }, gr.prototype.updateGCM = function(e) {
        e || console.error("No callback passed to the UpdateGCM"), A.gcmUpdateCallback = e
    }, gr.prototype.updateConsentArray = function(e, t, o) {
        var n = e.findIndex(function(e) {
            return e === t + ":0" || e === t + ":1"
        }); - 1 < n ? e[n] = t + ":" + o : e.push(t + ":" + o)
    };
    var pr, Cr = gr;

    function gr() {
        this.processedHtml = "", this.useGeoLocationService = !0, this.IsAlertBoxClosed = this.IsAlertBoxClosedAndValid, this.InitializeBanner = function() {
            return ks.initBanner()
        }, this.getHTML = function() {
            return document.getElementById("onetrust-banner-sdk") || (V.insertPcHtml(), er.insertAlertHtml()), pr.processedHtml || (pr.processedHtml = document.querySelector("#onetrust-consent-sdk").outerHTML), pr.processedHtml
        }, this.getCSS = function() {
            return Qt.processedCSS
        }, this.setConsentProfile = function(e) {
            var t, o;
            e.customPayload && null != (t = o = e.customPayload) && t.Interaction && g.writeCookieParam(C.OPTANON_CONSENT, u.INTERACTION_COUNT, o.Interaction), pr.setDataSubjectIdV2(e.identifier, e.isAnonymous, e.identifierType), pr.synchroniseCookieWithPayload(e.purposes), O.executeOptanonWrapper()
        }, this.InsertScript = function(e, t, o, n, r, i) {
            var s, a = null != n && void 0 !== n,
                l = a && void 0 !== n.ignoreGroupCheck && !0 === n.ignoreGroupCheck;
            if (f.canInsertForGroup(r, l) && !P.contains(L.srcExecGrps, r)) {
                L.srcExecGrpsTemp.push(r), a && void 0 !== n.deleteSelectorContent && !0 === n.deleteSelectorContent && P.empty(t);
                var c = document.createElement("script");
                switch (null != o && void 0 !== o && (s = !1, c.onload = c.onreadystatechange = function() {
                    s || this.readyState && "loaded" !== this.readyState && "complete" !== this.readyState || (s = !0, o())
                }), c.type = "text/javascript", c.src = e, i && (c.async = i), t) {
                    case "head":
                        document.getElementsByTagName("head")[0].appendChild(c);
                        break;
                    case "body":
                        document.getElementsByTagName("body")[0].appendChild(c);
                        break;
                    default:
                        var d = document.getElementById(t);
                        d && (d.appendChild(c), a) && void 0 !== n.makeSelectorVisible && !0 === n.makeSelectorVisible && P.show(t)
                }
                if (a && void 0 !== n.makeElementsVisible)
                    for (var u = 0, p = n.makeElementsVisible; u < p.length; u++) {
                        var C = p[u];
                        P.show(C)
                    }
                if (a && void 0 !== n.deleteElements)
                    for (var g = 0, h = n.deleteElements; g < h.length; g++) {
                        C = h[g];
                        P.remove(C)
                    }
            }
        }, this.InsertHtml = function(e, t, o, n, r) {
            var i = null != n && void 0 !== n,
                s = i && void 0 !== n.ignoreGroupCheck && !0 === n.ignoreGroupCheck;
            if (f.canInsertForGroup(r, s) && !P.contains(L.htmlExecGrps, r)) {
                if (L.htmlExecGrpsTemp.push(r), i && void 0 !== n.deleteSelectorContent && !0 === n.deleteSelectorContent && P.empty(t), P.appendTo(t, e), i && void 0 !== n.makeSelectorVisible && !0 === n.makeSelectorVisible && P.show(t), i && void 0 !== n.makeElementsVisible)
                    for (var a = 0, l = n.makeElementsVisible; a < l.length; a++) {
                        var c = l[a];
                        P.show(c)
                    }
                if (i && void 0 !== n.deleteElements)
                    for (var d = 0, u = n.deleteElements; d < u.length; d++) {
                        c = u[d];
                        P.remove(c)
                    }
                null != o && void 0 !== o && o()
            }
        }, this.BlockGoogleAnalytics = function(e, t) {
            window["ga-disable-" + e] = !f.canInsertForGroup(t)
        }
    }
    hr.prototype.getFieldsValues = function(e, t, o, n, r) {
        void 0 === r && (r = !1);
        e = this.getSectionFieldsMapping(e), t = this.getSectionFieldsMapping(t, !0), o = this.getDynamicFields(o, n), n = this.getMSPASectionFieldValue(), r = r ? this.getGpcSectionFieldValue() : {};
        return R(R(R(R(R({}, e), t), o), n), r)
    }, hr.prototype.getGpcSectionFieldValue = function() {
        var e = {};
        return e[Ve.GpcSegmentType] = 1, e[Ve.Gpc] = A.gpcEnabled, e
    }, hr.prototype.getMSPASectionFieldValue = function() {
        var e = {};
        return I.IsMSPAEnabled ? (e.MspaCoveredTransaction = 1, I.MSPAOptionMode === Oe.MspaServiceProviderMode ? (e.MspaServiceProviderMode = 1, e.MspaOptOutOptionMode = 2) : I.MSPAOptionMode === Oe.MspaOptOutOptionMode ? (e.MspaServiceProviderMode = 2, e.MspaOptOutOptionMode = 1) : (e.MspaServiceProviderMode = 2, e.MspaOptOutOptionMode = 2)) : (e.MspaCoveredTransaction = 2, e.MspaServiceProviderMode = 0, e.MspaOptOutOptionMode = 0), e
    }, hr.prototype.getDynamicArrayFieldsValue = function(e, t) {
        for (var o = {}, n = [], r = this.getSectionFieldsMapping(t), i = 1; i <= Object.keys(r).length; i++) n.push(r[e + i]);
        return o[e] = n, o
    }, hr.prototype.getDynamicFields = function(e, t) {
        var o, n = {};
        return I.IsGPPKnownChildApplicable && e && (o = this.getDynamicArrayFieldsValue(De.KnownChildSensitiveDataConsents, e), n = R(R({}, n), o)), I.IsGPPDataProcessingApplicable && t && (o = this.getDynamicArrayFieldsValue(De.SensitiveDataProcessing, t), n = R(R({}, n), o)), n
    }, hr.prototype.getSectionFieldsMapping = function(e, o) {
        var n = this,
            r = (void 0 === o && (o = !1), {}),
            t = m.fp,
            e = (Object.entries(e).forEach(function(e) {
                var t = e[0],
                    e = n.evaluateValueOperators(e[1]);
                r[t] = n.calculateFieldValue(e, o)
            }), null == (e = pr.getGeolocationData()) ? void 0 : e.country);
        return t && t.CookieIABGPPV2 && I.IsGPPKnownChildApplicable && "us" === e.toLocaleLowerCase() && r.hasOwnProperty(De.KnownChildSensitiveDataConsents) && (t = A.getRegionRule(), A.getRegionDetailsOnRuleSet(r, null == (t = t) ? void 0 : t.States[e])), r
    }, hr.prototype.evaluateValueOperators = function(e) {
        var t, o, n = "",
            r = [];
        return e && (t = e.split(" && "), o = e.split(" || "), r = (1 < t.length ? (n = "&&", t) : 1 < o.length ? (n = "||", o) : (n = "", [e])).map(function(e) {
            return I.GPPPurposes[e] || ""
        })), {
            values: r,
            operator: n
        }
    }, hr.prototype.calculateFieldValue = function(e, t) {
        var o;
        if (e.values.length) switch (e.operator) {
            case "&&":
                o = this.calculateAndFieldValue(e.values, t);
                break;
            case "||":
                o = this.calculateOrFieldValue(e.values, t);
                break;
            default:
                o = this.calculateSingleFieldValue(e.values[0], t)
        } else o = 0;
        return o
    }, hr.prototype.calculateOrFieldValue = function(e, t) {
        var o = this;
        return this.isNotApplicable(e) ? 0 : (e = e.some(function(e) {
            return o.fieldValueCondition(e, t)
        }), this.calculateFieldValueFromBit(e, t))
    }, hr.prototype.calculateAndFieldValue = function(e, t) {
        var o = this;
        return this.isNotApplicable(e) ? 0 : (e = e.every(function(e) {
            return o.fieldValueCondition(e, t)
        }), this.calculateFieldValueFromBit(e, t))
    }, hr.prototype.calculateSingleFieldValue = function(e, t) {
        return e && this.isValidGroup(e) ? (e = this.fieldValueCondition(e, t), this.calculateFieldValueFromBit(e, t)) : 0
    }, hr.prototype.isValidGroup = function(e) {
        e = e ? y.getGroupById(e) : null;
        return !!e && A.isValidConsentNoticeGroup(e, I.IsIabEnabled)
    }, hr.prototype.calculateFieldValueFromBit = function(e, t) {
        t = t ? e ? 1 : 0 : e ? 2 : 1;
        return t
    }, hr.prototype.isNotApplicable = function(e) {
        var t = this;
        return !e.some(function(e) {
            return Boolean(e) && t.isValidGroup(e)
        })
    }, hr.prototype.fieldValueCondition = function(e, t) {
        return t ? Boolean(e) : pr.isCategoryActive(e)
    };
    var s = hr;

    function hr() {}
    x(Tr, yr = s), Tr.prototype.getSectionFieldsValues = function() {
        return this.getFieldsValues(Kt, zt, Wt, Yt, !0)
    };
    var yr, fr, Sr, mr, vr = Tr;

    function Tr() {
        return null !== yr && yr.apply(this, arguments) || this
    }(G = fr = fr || {}).SaleOptOut = "SaleOptOutCID", G.KnownChildSensitiveDataConsents = "KnownChildSellPICID", G.TargetedAdvertisingOptOut = "TargetedAdvertisingOptOutCID", (G = Sr = Sr || {}).SharingNotice = "SaleOptOutCID || TargetedAdvertisingOptOutCID", G.SaleOptOutNotice = "SaleOptOutCID", G.TargetedAdvertisingOptOutNotice = "TargetedAdvertisingOptOutCID", (G = mr = mr || {}).SensitiveDataProcessing1 = "RaceCID", G.SensitiveDataProcessing2 = "ReligionCID", G.SensitiveDataProcessing3 = "HealthCID", G.SensitiveDataProcessing4 = "SexualOrientationCID", G.SensitiveDataProcessing5 = "ImmigrationCID", G.SensitiveDataProcessing6 = "GeneticCID", G.SensitiveDataProcessing7 = "BiometricCID", G.SensitiveDataProcessing8 = "GeolocationCID", x(Ar, Pr = s), Ar.prototype.getSectionFieldsValues = function() {
        return this.getFieldsValues(fr, Sr, null, mr, !1)
    };
    var Pr, kr, br = Ar;

    function Ar() {
        return null !== Pr && Pr.apply(this, arguments) || this
    }(G = kr = kr || {}).Version = "version", G.CmpId = "cmpId", G.CmpVersion = "cmpVersion", G.ConsentScreen = "consentScreen", G.ConsentLanguage = "consentLanguage", G.VendorListVersion = "vendorListVersion", G.PolicyVersion = "policyVersion", G.IsServiceSpecific = "isServiceSpecific", G.UseNonStandardStacks = "useNonStandardTexts", G.PurposeOneTreatment = "purposeOneTreatment", G.PublisherCountryCode = "publisherCountryCode", G.NumCustomPurposes = "numCustomPurposes", G.VendorsAllowedSegmentType = "VendorsAllowedSegmentType", G.VendorsDisclosedSegmentType = "VendorsDisclosedSegmentType", G.PublisherPurposesSegmentType = "PublisherPurposesSegmentType", Vr.prototype.getSectionFieldsValues = function() {
        for (var e = {}, t = 0, o = Object.keys(kr); t < o.length; t++) {
            var n = o[t],
                r = kr[n];
            L.tcModel && L.tcModel[r] && (e[n] = L.tcModel[r])
        }
        e.ConsentLanguage = null == (i = e.ConsentLanguage) ? void 0 : i.toString().toUpperCase();
        var i = this.setPurposesData();
        return R(R({}, e), i)
    }, Vr.prototype.setPurposesData = function() {
        var e = {},
            t = L.oneTrustIABConsent,
            o = this.getConsentValuesFromPurpose(t.purpose),
            o = (e.PurposeConsents = o, e.PublisherConsents = o, A.legIntSettings.PAllowLI ? this.getConsentValuesFromPurpose(t.legimateInterest) : []);
        return e.PurposeLegitimateInterests = o, e.PublisherLegitimateInterests = o, e.VendorConsents = this.syncVendorConsent(L.tcModel.vendorConsents), A.legIntSettings.PAllowLI && !o.length && (t.legIntVendors = []), e.VendorLegitimateInterests = this.getConsentValuesFromPurpose(P.distinctArray(t.legIntVendors), !0, !0), e.SpecialFeatureOptins = this.getConsentValuesFromPurpose(t.specialFeatures), e
    }, Vr.prototype.syncVendorConsent = function(e) {
        var e = e.clone(),
            o = [];
        return e.forEach(function(e, t) {
            L.vendorsSetting[t] && L.vendorsSetting[t].consent || !e || o.push(t)
        }), e.unset(o), Array.from(e.values())
    }, Vr.prototype.getConsentValuesFromPurpose = function(e, t, o) {
        var n = (t = void 0 === t ? !1 : t) ? 0 : 1;
        return (o = void 0 === o ? !1 : o) && (e = e.filter(function(e) {
            return "true" === e.split(":")[1]
        })), t ? e.map(function(e) {
            return parseInt(e.split(":")[n])
        }) : e.map(function(e) {
            return "true" === e.split(":")[n]
        })
    };
    var Ir, Lr, _r, Er, Or = Vr;

    function Vr() {}(G = Ir = Ir || {}).SaleOptOut = "SaleOptOutCID", G.SharingOptOut = "SharingOptOutCID", G.PersonalDataConsents = "PersonalDataCID", G.TargetedAdvertisingOptOut = "TargetedAdvertisingOptOutCID", (G = Lr = Lr || {}).SharingNotice = "SharingOptOutCID", G.SaleOptOutNotice = "SaleOptOutCID", G.SharingOptOutNotice = "SharingOptOutCID", G.SensitiveDataProcessingOptOutNotice = "RaceCID || ReligionCID || HealthCID || SexualOrientationCID || ImmigrationCID || GeneticCID || BiometricCID || GeolocationCID || SensitivePICID || SensitiveSICID || UnionMembershipCID || CommunicationCID", G.SensitiveDataLimitUseNotice = "RaceCID || ReligionCID || HealthCID || SexualOrientationCID || ImmigrationCID || GeneticCID || BiometricCID || GeolocationCID || SensitivePICID || SensitiveSICID || UnionMembershipCID || CommunicationCID", G.TargetedAdvertisingOptOutNotice = "TargetedAdvertisingOptOutCID", (G = _r = _r || {}).KnownChildSensitiveDataConsents1 = "PDCAboveAgeCID", G.KnownChildSensitiveDataConsents2 = "PDCBelowAgeCID", (G = Er = Er || {}).SensitiveDataProcessing1 = "RaceCID", G.SensitiveDataProcessing2 = "ReligionCID", G.SensitiveDataProcessing3 = "HealthCID", G.SensitiveDataProcessing4 = "SexualOrientationCID", G.SensitiveDataProcessing5 = "ImmigrationCID", G.SensitiveDataProcessing6 = "GeneticCID", G.SensitiveDataProcessing7 = "BiometricCID", G.SensitiveDataProcessing8 = "GeolocationCID", G.SensitiveDataProcessing9 = "SensitivePICID", G.SensitiveDataProcessing10 = "SensitiveSICID", G.SensitiveDataProcessing11 = "UnionMembershipCID", G.SensitiveDataProcessing12 = "CommunicationCID", x(xr, Dr = s), xr.prototype.getSectionFieldsValues = function() {
        return this.getFieldsValues(Ir, Lr, _r, Er, !0)
    };
    var Dr, Nr, wr, Gr, Br = xr;

    function xr() {
        return null !== Dr && Dr.apply(this, arguments) || this
    }(G = Nr = Nr || {}).SaleOptOut = "SaleOptOutCID", G.TargetedAdvertisingOptOut = "TargetedAdvertisingOptOutCID", G.KnownChildSensitiveDataConsents = "KnownChildSellPICID", (G = wr = wr || {}).SharingNotice = "SaleOptOutCID || TargetedAdvertisingOptOutCID", G.SaleOptOutNotice = "SaleOptOutCID", G.TargetedAdvertisingOptOutNotice = "TargetedAdvertisingOptOutCID", (G = Gr = Gr || {}).SensitiveDataProcessing1 = "RaceCID", G.SensitiveDataProcessing2 = "ReligionCID", G.SensitiveDataProcessing3 = "HealthCID", G.SensitiveDataProcessing4 = "SexualOrientationCID", G.SensitiveDataProcessing5 = "ImmigrationCID", G.SensitiveDataProcessing6 = "GeneticCID", G.SensitiveDataProcessing7 = "BiometricCID", x(jr, Hr = s), jr.prototype.getSectionFieldsValues = function() {
        return this.getFieldsValues(Nr, wr, null, Gr, !0)
    };
    var Hr, Rr, Fr, Mr, Ur, qr = jr;

    function jr() {
        return null !== Hr && Hr.apply(this, arguments) || this
    }(G = Rr = Rr || {}).SaleOptOut = "SaleOptOutCID", G.TargetedAdvertisingOptOut = "TargetedAdvertisingOptOutCID", (G = Fr = Fr || {}).SharingNotice = "SaleOptOutCID || TargetedAdvertisingOptOutCID", G.SaleOptOutNotice = "SaleOptOutCID", G.TargetedAdvertisingOptOutNotice = "TargetedAdvertisingOptOutCID", (G = Mr = Mr || {}).KnownChildSensitiveDataConsents1 = "KnownChildProcessCID", G.KnownChildSensitiveDataConsents2 = "KnownChildSellPICID", G.KnownChildSensitiveDataConsents3 = "KnownChildSharePICID", (G = Ur = Ur || {}).SensitiveDataProcessing1 = "RaceCID", G.SensitiveDataProcessing2 = "ReligionCID", G.SensitiveDataProcessing3 = "HealthCID", G.SensitiveDataProcessing4 = "SexualOrientationCID", G.SensitiveDataProcessing5 = "ImmigrationCID", G.SensitiveDataProcessing6 = "GeneticCID", G.SensitiveDataProcessing7 = "BiometricCID", G.SensitiveDataProcessing8 = "GeolocationCID", x(Qr, Kr = s), Qr.prototype.getSectionFieldsValues = function() {
        return this.getFieldsValues(Rr, Fr, Mr, Ur, !0)
    };
    var Kr, zr, Wr, Yr, Jr, Xr = Qr;

    function Qr() {
        return null !== Kr && Kr.apply(this, arguments) || this
    }(G = zr = zr || {}).SaleOptOut = "SaleOptOutCID", G.TargetedAdvertisingOptOut = "TargetedAdvertisingOptOutCID", G.AdditionalDataProcessingConsent = "PersonalDataCID", (G = Wr = Wr || {}).SharingNotice = "SaleOptOutCID || TargetedAdvertisingOptOutCID", G.SaleOptOutNotice = "SaleOptOutCID", G.TargetedAdvertisingOptOutNotice = "TargetedAdvertisingOptOutCID", (G = Yr = Yr || {}).KnownChildSensitiveDataConsents1 = "KnownChildProcessCID", G.KnownChildSensitiveDataConsents2 = "KnownChildSellPICID", G.KnownChildSensitiveDataConsents3 = "KnownChildSharePICID", (G = Jr = Jr || {}).SensitiveDataProcessing1 = "RaceCID", G.SensitiveDataProcessing2 = "ReligionCID", G.SensitiveDataProcessing3 = "HealthCID", G.SensitiveDataProcessing4 = "SexualOrientationCID", G.SensitiveDataProcessing5 = "ImmigrationCID", G.SensitiveDataProcessing6 = "GeneticCID", G.SensitiveDataProcessing7 = "BiometricCID", G.SensitiveDataProcessing8 = "GeolocationCID", x(ni, Zr = s), ni.prototype.getSectionFieldsValues = function() {
        return this.getFieldsValues(zr, Wr, Yr, Jr, !0)
    };
    var Zr, $r, ei, ti, oi = ni;

    function ni() {
        return null !== Zr && Zr.apply(this, arguments) || this
    }(G = $r = $r || {}).SaleOptOut = "SaleOptOutCID", G.TargetedAdvertisingOptOut = "TargetedAdvertisingOptOutCID", G.AdditionalDataProcessingConsent = "PersonalDataCID", G.KnownChildSensitiveDataConsents = "KnownChildSellPICID", (G = ei = ei || {}).ProcessingNotice = "AdditionalDataCID", G.SaleOptOutNotice = "SaleOptOutCID", G.TargetedAdvertisingOptOutNotice = "TargetedAdvertisingOptOutCID", (G = ti = ti || {}).SensitiveDataProcessing1 = "RaceCID", G.SensitiveDataProcessing2 = "ReligionCID", G.SensitiveDataProcessing3 = "HealthCID", G.SensitiveDataProcessing4 = "SexualOrientationCID", G.SensitiveDataProcessing5 = "ImmigrationCID", G.SensitiveDataProcessing6 = "GeneticCID", G.SensitiveDataProcessing7 = "BiometricCID", G.SensitiveDataProcessing8 = "GeolocationCID", x(di, ri = s), di.prototype.getSectionFieldsValues = function() {
        return this.getFieldsValues($r, ei, null, ti, !0)
    };
    var ri, ii, si, ai, li, ci = di;

    function di() {
        return null !== ri && ri.apply(this, arguments) || this
    }(G = ii = ii || {}).SaleOptOut = "SaleOptOutCID", G.TargetedAdvertisingOptOut = "TargetedAdvertisingOptOutCID", G.AdditionalDataProcessingConsent = "PersonalDataCID", (G = si = si || {}).ProcessingNotice = "AdditionalDataCID", G.SaleOptOutNotice = "SaleOptOutCID", G.TargetedAdvertisingOptOutNotice = "TargetedAdvertisingOptOutCID", (G = ai = ai || {}).KnownChildSensitiveDataConsents1 = "KnownChildProcessBelowAge13CID", G.KnownChildSensitiveDataConsents2 = "KnownChildProcessBetweenAge13To16CID", G.KnownChildSensitiveDataConsents3 = "KnownChildProcessBetweenAge16To18CID", (G = li = li || {}).SensitiveDataProcessing1 = "RaceCID", G.SensitiveDataProcessing2 = "ReligionCID", G.SensitiveDataProcessing3 = "HealthCID", G.SensitiveDataProcessing4 = "SexualOrientationCID", G.SensitiveDataProcessing5 = "ImmigrationCID", G.SensitiveDataProcessing6 = "GeneticCID", G.SensitiveDataProcessing7 = "BiometricCID", G.SensitiveDataProcessing8 = "GeolocationCID", x(fi, ui = s), fi.prototype.getSectionFieldsValues = function() {
        return this.getFieldsValues(ii, si, ai, li, !1)
    };
    var ui, pi, Ci, gi, hi, yi = fi;

    function fi() {
        return null !== ui && ui.apply(this, arguments) || this
    }(G = pi = pi || {}).SaleOptOut = "SaleOptOutCID", G.TargetedAdvertisingOptOut = "TargetedAdvertisingOptOutCID", G.AdditionalDataProcessingConsent = "PersonalDataCID", (G = Ci = Ci || {}).ProcessingNotice = "AdditionalDataCID", G.SaleOptOutNotice = "SaleOptOutCID", G.TargetedAdvertisingOptOutNotice = "TargetedAdvertisingOptOutCID", (G = gi = gi || {}).KnownChildSensitiveDataConsents1 = "KnownChildProcessCID", G.KnownChildSensitiveDataConsents2 = "KnownChildSellPICID", G.KnownChildSensitiveDataConsents3 = "KnownChildSharePICID", G.KnownChildSensitiveDataConsents4 = "KnownChildSellAge16To18CID", G.KnownChildSensitiveDataConsents5 = "KnownChildProcessAge16To18CID", (G = hi = hi || {}).SensitiveDataProcessing1 = "RaceCID", G.SensitiveDataProcessing2 = "ReligionCID", G.SensitiveDataProcessing3 = "HealthCID", G.SensitiveDataProcessing4 = "SexualOrientationCID", G.SensitiveDataProcessing5 = "ImmigrationCID", G.SensitiveDataProcessing6 = "GeneticCID", G.SensitiveDataProcessing7 = "BiometricCID", G.SensitiveDataProcessing8 = "GeolocationCID", G.SensitiveDataProcessing9 = "TransgenderCID", x(ki, Si = s), ki.prototype.getSectionFieldsValues = function() {
        return this.getFieldsValues(pi, Ci, gi, hi, !0)
    };
    var Si, mi, vi, Ti, Pi = ki;

    function ki() {
        return null !== Si && Si.apply(this, arguments) || this
    }(G = mi = mi || {}).SaleOptOut = "SaleOptOutCID", G.TargetedAdvertisingOptOut = "TargetedAdvertisingOptOutCID", G.KnownChildSensitiveDataConsents = "KnownChildSellPICID", (G = vi = vi || {}).ProcessingNotice = "AdditionalDataCID", G.SaleOptOutNotice = "SaleOptOutCID", G.TargetedAdvertisingOptOutNotice = "TargetedAdvertisingOptOutCID", G.SensitiveDataOptOutNotice = "SensitiveDataOptOutNotice", (G = Ti = Ti || {}).SensitiveDataProcessing1 = "RaceCID", G.SensitiveDataProcessing2 = "ReligionCID", G.SensitiveDataProcessing3 = "HealthCID", G.SensitiveDataProcessing4 = "SexualOrientationCID", G.SensitiveDataProcessing5 = "ImmigrationCID", G.SensitiveDataProcessing6 = "GeneticCID", G.SensitiveDataProcessing7 = "BiometricCID", G.SensitiveDataProcessing8 = "GeolocationCID", x(Ei, bi = s), Ei.prototype.getSectionFieldsValues = function() {
        return this.getFieldsValues(mi, vi, null, Ti, !0)
    };
    var bi, Ai, Ii, Li, _i = Ei;

    function Ei() {
        return null !== bi && bi.apply(this, arguments) || this
    }(G = Ai = Ai || {}).SaleOptOut = "SaleOptOutCID", G.TargetedAdvertisingOptOut = "TargetedAdvertisingOptOutCID", G.KnownChildSensitiveDataConsents = "KnownChildSellPICID", G.AdditionalDataProcessingConsent = "PersonalDataCID", (G = Ii = Ii || {}).ProcessingNotice = "AdditionalDataCID", G.SaleOptOutNotice = "SaleOptOutCID", G.TargetedAdvertisingOptOutNotice = "TargetedAdvertisingOptOutCID", (G = Li = Li || {}).SensitiveDataProcessing1 = "RaceCID", G.SensitiveDataProcessing2 = "ReligionCID", G.SensitiveDataProcessing3 = "HealthCID", G.SensitiveDataProcessing4 = "SexualOrientationCID", G.SensitiveDataProcessing5 = "ImmigrationCID", G.SensitiveDataProcessing6 = "GeneticCID", G.SensitiveDataProcessing7 = "BiometricCID", G.SensitiveDataProcessing8 = "GeolocationCID", x(Gi, Oi = s), Gi.prototype.getSectionFieldsValues = function() {
        return this.getFieldsValues(Ai, Ii, null, Li, !0)
    };
    var Oi, Vi, Di, Ni, wi = Gi;

    function Gi() {
        return null !== Oi && Oi.apply(this, arguments) || this
    }(G = Vi = Vi || {}).SaleOptOut = "SaleOptOutCID", G.TargetedAdvertisingOptOut = "TargetedAdvertisingOptOutCID", G.KnownChildSensitiveDataConsents = "KnownChildSellPICID", G.AdditionalDataProcessingConsent = "PersonalDataCID", (G = Di = Di || {}).ProcessingNotice = "AdditionalDataCID", G.SaleOptOutNotice = "SaleOptOutCID", G.TargetedAdvertisingOptOutNotice = "TargetedAdvertisingOptOutCID", (G = Ni = Ni || {}).SensitiveDataProcessing1 = "RaceCID", G.SensitiveDataProcessing2 = "ReligionCID", G.SensitiveDataProcessing3 = "HealthCID", G.SensitiveDataProcessing4 = "SexualOrientationCID", G.SensitiveDataProcessing5 = "ImmigrationCID", G.SensitiveDataProcessing6 = "GeneticCID", G.SensitiveDataProcessing7 = "BiometricCID", G.SensitiveDataProcessing8 = "GeolocationCID", x(Ui, Bi = s), Ui.prototype.getSectionFieldsValues = function() {
        return this.getFieldsValues(Vi, Di, null, Ni, !0)
    };
    var Bi, xi, Hi, Ri, Fi, Mi = Ui;

    function Ui() {
        return null !== Bi && Bi.apply(this, arguments) || this
    }(G = xi = xi || {}).SaleOptOut = "SaleOptOutCID", G.TargetedAdvertisingOptOut = "TargetedAdvertisingOptOutCID", G.AdditionalDataProcessingConsent = "PersonalDataCID", (G = Hi = Hi || {}).ProcessingNotice = "AdditionalDataCID", G.SaleOptOutNotice = "SaleOptOutCID", G.TargetedAdvertisingOptOutNotice = "TargetedAdvertisingOptOutCID", (G = Ri = Ri || {}).KnownChildSensitiveDataConsents1 = "KnownChildProcessCID", G.KnownChildSensitiveDataConsents2 = "KnownChildSellPICID", G.KnownChildSensitiveDataConsents3 = "KnownChildSharePICID", G.KnownChildSensitiveDataConsents4 = "KnownChildSellAge16To17CID", G.KnownChildSensitiveDataConsents5 = "KnownChildProcessAge16To17CID", (G = Fi = Fi || {}).SensitiveDataProcessing1 = "RaceCID", G.SensitiveDataProcessing2 = "ReligionCID", G.SensitiveDataProcessing3 = "HealthCID", G.SensitiveDataProcessing4 = "SexualOrientationCID", G.SensitiveDataProcessing5 = "ImmigrationCID", G.SensitiveDataProcessing6 = "GeneticCID", G.SensitiveDataProcessing7 = "BiometricCID", G.SensitiveDataProcessing8 = "GeolocationCID", G.SensitiveDataProcessing9 = "TransgenderCID", G.SensitiveDataProcessing10 = "SensitiveSICID", x(Ji, qi = s), Ji.prototype.getSectionFieldsValues = function() {
        return this.getFieldsValues(xi, Hi, Ri, Fi, !0)
    };
    var qi, ji, Ki, zi, Wi, Yi = Ji;

    function Ji() {
        return null !== qi && qi.apply(this, arguments) || this
    }(G = ji = ji || {}).SaleOptOut = "SaleOptOutCID", G.TargetedAdvertisingOptOut = "TargetedAdvertisingOptOutCID", G.AdditionalDataProcessingConsent = "PersonalDataCID", (G = Ki = Ki || {}).ProcessingNotice = "AdditionalDataCID", G.SaleOptOutNotice = "SaleOptOutCID", G.TargetedAdvertisingOptOutNotice = "TargetedAdvertisingOptOutCID", (G = zi = zi || {}).KnownChildSensitiveDataConsents1 = "KnownChildProcessCID", G.KnownChildSensitiveDataConsents2 = "KnownChildSellPICID", G.KnownChildSensitiveDataConsents3 = "KnownChildSharePICID", (G = Wi = Wi || {}).SensitiveDataProcessing1 = "RaceCID", G.SensitiveDataProcessing2 = "ReligionCID", G.SensitiveDataProcessing3 = "HealthCID", G.SensitiveDataProcessing4 = "SexualOrientationCID", G.SensitiveDataProcessing5 = "ImmigrationCID", G.SensitiveDataProcessing6 = "GeneticCID", G.SensitiveDataProcessing7 = "BiometricCID", G.SensitiveDataProcessing8 = "GeolocationCID", x(ts, Xi = s), ts.prototype.getSectionFieldsValues = function() {
        return this.getFieldsValues(ji, Ki, zi, Wi, !0)
    };
    var Xi, Qi, Zi, $i, es = ts;

    function ts() {
        return null !== Xi && Xi.apply(this, arguments) || this
    }(G = Qi = Qi || {}).SaleOptOut = "SaleOptOutCID", G.TargetedAdvertisingOptOut = "TargetedAdvertisingOptOutCID", G.KnownChildSensitiveDataConsents = "KnownChildSellPICID", (G = Zi = Zi || {}).SharingNotice = "SaleOptOutCID || TargetedAdvertisingOptOutCID", G.SaleOptOutNotice = "SaleOptOutCID", G.TargetedAdvertisingOptOutNotice = "TargetedAdvertisingOptOutCID", G.SensitiveDataProcessingOptOutNotice = "RaceCID || ReligionCID || SexualOrientationCID || ImmigrationCID || HealthCID || GeneticCID || BiometricCID || GeolocationCID", (G = $i = $i || {}).SensitiveDataProcessing1 = "RaceCID", G.SensitiveDataProcessing2 = "ReligionCID", G.SensitiveDataProcessing3 = "SexualOrientationCID", G.SensitiveDataProcessing4 = "ImmigrationCID", G.SensitiveDataProcessing5 = "HealthCID", G.SensitiveDataProcessing6 = "GeneticCID", G.SensitiveDataProcessing7 = "BiometricCID", G.SensitiveDataProcessing8 = "GeolocationCID", x(rs, os = s), rs.prototype.getSectionFieldsValues = function() {
        return this.getFieldsValues(Qi, Zi, null, $i, !1)
    };
    var os, ns = rs;

    function rs() {
        return null !== os && os.apply(this, arguments) || this
    }(G = is = is || {}).SaleOptOut = "SaleOptOutCID", G.TargetedAdvertisingOptOut = "TargetedAdvertisingOptOutCID", G.AdditionalDataProcessingConsent = "PersonalDataCID", (G = ss = ss || {}).ProcessingNotice = "AdditionalDataCID", G.SaleOptOutNotice = "SaleOptOutCID", G.TargetedAdvertisingOptOutNotice = "TargetedAdvertisingOptOutCID", (G = as = as || {}).KnownChildSensitiveDataConsents1 = "KnownChildProcessCID", G.KnownChildSensitiveDataConsents2 = "KnownChildSellPICID", G.KnownChildSensitiveDataConsents3 = "KnownChildSharePICID", (G = ls = ls || {}).SensitiveDataProcessing1 = "RaceCID", G.SensitiveDataProcessing2 = "ReligionCID", G.SensitiveDataProcessing3 = "HealthCID", G.SensitiveDataProcessing4 = "SexualOrientationCID", G.SensitiveDataProcessing5 = "TransgenderCID", G.SensitiveDataProcessing6 = "ImmigrationCID", G.SensitiveDataProcessing7 = "NationalOriginCID", G.SensitiveDataProcessing8 = "CrimeVictimCID", G.SensitiveDataProcessing9 = "GeneticCID", G.SensitiveDataProcessing10 = "BiometricCID", G.SensitiveDataProcessing11 = "GeolocationCID", x(us, cs = s), us.prototype.getSectionFieldsValues = function() {
        return this.getFieldsValues(is, ss, as, ls, !0)
    };
    var is, ss, as, ls, cs, ds = us;

    function us() {
        return null !== cs && cs.apply(this, arguments) || this
    }
    gs.prototype.initGppConsent = function() {
        this.initTemplateAndSectionInstance(), this.cmpApi.setApplicableSections(this.getApplicableSections(this.gppTemplateApplied));
        var o, n, e = this.readGppCookies(),
            t = this.getCurrentSectionName(this.gppTemplateApplied),
            r = !1;
        e && (p.needReconsent() ? this.deleteAllGppCookies() : (this.cmpApi.setGppString(e), r = !0)), this.cmpApi.setSupportedAPIs((o = [], n = {}, Object.keys(we).forEach(function(e) {
            var t = {},
                e = (t[e] = we[e], Object.assign(t, n));
            n = e
        }), Object.keys(Ne).map(function(e) {
            return {
                name: e,
                value: Ne[e]
            }
        }).forEach(function(e) {
            e = n[e.name] + ":" + e.value;
            o.push(e)
        }), o.filter(function(e, t) {
            return o.indexOf(e) === t
        }))), this.cmpApi.setCmpStatus(null == (e = this.gppSDKRef) ? void 0 : e.cmpStatus.LOADED), this.cmpApi.setSignalStatus(null == (e = this.gppSDKRef) ? void 0 : e.signalStatus.READY), (t && !this.cmpApi.hasSection(t) || A.gpcBrowserValueChanged || L.grpsSynced && 0 < L.grpsSynced.length) && this.setOrUpdateGppSectionString(t, r), window.OneTrust.OnConsentChanged(this.updateGppConsentString)
    }, gs.prototype.initTemplateAndSectionInstance = function() {
        var e = m.fp;
        e && e.CookieIABGPPV2 ? this.gppTemplateApplied = this.getTemplateTypeByLocation() : this.gppTemplateApplied = this.getGppTemplateApplied(), this.gppSection = this.getSectionInstance(this.gppTemplateApplied)
    }, gs.prototype.setCmpDisplayStatus = function(e) {
        var t;
        "visible" === e ? this.cmpApi.setCmpDisplayStatus(null == (t = this.gppSDKRef) ? void 0 : t.displayStatus.VISIBLE) : "hidden" === e ? this.cmpApi.setCmpDisplayStatus(null == (t = this.gppSDKRef) ? void 0 : t.displayStatus.HIDDEN) : "disabled" === e && this.cmpApi.setCmpDisplayStatus(null == (t = this.gppSDKRef) ? void 0 : t.displayStatus.DISABLED)
    }, gs.prototype.setGppCookies = function(e, t) {
        t ? this.updateGppCookies(e) : (t = this.getCookiesChunk(e), e = Object.keys(t).length, this.writeGppCookies(e, t))
    }, gs.prototype.readGppCookies = function() {
        var e = Number(g.readCookieParam(C.OPTANON_CONSENT, Ee.ChunkCountParam) || 0);
        if (e <= 1) return 0 === e ? "" : g.getCookie(C.GPP_CONSENT);
        for (var t = "", o = 1; o <= e; o++) var n = g.getCookie("" + Ee.Name + o),
            t = t.concat(n);
        return t
    }, gs.prototype.deleteGppCookies = function(e, t) {
        if (0 < e && (1 === e && (g.setCookie("" + Ee.Name, "", 0, !0), e++), e <= t))
            for (var o = e; o <= t; o++) g.setCookie("" + Ee.Name + o, "", 0, !0)
    }, gs.prototype.getSectionInstance = function(e) {
        var t;
        switch (e) {
            case o.CPRA:
            case o.CCPA:
                t = new vr;
                break;
            case o.CDPA:
                t = new br;
                break;
            case o.USNATIONAL:
                t = new Br;
                break;
            case o.COLORADO:
                t = new qr;
                break;
            case o.OREGON:
                t = new ds;
                break;
            case o.FLORIDA:
                t = new yi;
                break;
            case o.CONNECTICUT:
                t = new Xr
        }
        return t = ["MONTANA", "TEXAS", "DELAWARE", "NEBRASKA", "IOWA", "TENNESSEE", "NEWJERSEY", "NEWHAMPSHIRE", "UCPA", "IAB2V2"].includes(e) ? this.getSectionInstanceByTempType(e) : t
    }, gs.prototype.getSectionInstanceByTempType = function(e) {
        var t;
        switch (e) {
            case o.MONTANA:
                t = new oi;
                break;
            case o.TEXAS:
                t = new ci;
                break;
            case o.DELAWARE:
                t = new Pi;
                break;
            case o.IOWA:
                t = new _i;
                break;
            case o.NEBRASKA:
                t = new wi;
                break;
            case o.TENNESSEE:
                t = new Mi;
                break;
            case o.NEWJERSEY:
                t = new Yi;
                break;
            case o.NEWHAMPSHIRE:
                t = new es;
                break;
            case o.UCPA:
                t = new ns;
                break;
            case o.IAB2V2:
                t = new Or
        }
        return t
    }, gs.prototype.getTemplateTypeByLocation = function() {
        var e;
        return A.getRegionRuleType() === o.IAB2V2 ? o.IAB2V2 : !I.UseGPPUSNational && "us" === (e = pr.getGeolocationData()).country.toLocaleLowerCase() && Be[e.state.toLocaleLowerCase()] || o.USNATIONAL
    }, gs.prototype.hasGPPSection = function() {
        return !!this.gppSection
    }, gs.prototype.getGppTemplateApplied = function() {
        return I.UseGPPUSNational ? o.USNATIONAL : A.getRegionRuleType()
    }, gs.prototype.initGppSDK = function() {
        var e, t = Number.parseInt((null == (t = m.moduleInitializer.GppData) ? void 0 : t.cmpId) || "28");
        return null == (e = this.gppSDKRef) ? void 0 : e.gppCmpApi(t, 1.1)
    }, gs.prototype.setOrUpdateGppSectionString = function(o, e) {
        var n = this,
            t = this.gppSection.getSectionFieldsValues();
        Object.entries(t).forEach(function(e) {
            var t = e[0];
            n.cmpApi.setFieldValue(o, t, e[1])
        }), this.cmpApi.fireSectionChange(o), this.setGppCookies(this.cmpApi.getGppString(), e)
    }, gs.prototype.getCurrentSectionName = function(t) {
        var e, o = "",
            n = Object.entries(Ne).find(function(e) {
                e = e[0];
                return e === t
            });
        return o = null != (e = n) && e.length && 1 < n.length ? n[1] : o
    }, gs.prototype.getCurrentSectionId = function(t) {
        var e, o = 0,
            n = Object.entries(we).find(function(e) {
                e = e[0];
                return e === t
            });
        return o = null != (e = n) && e.length && 1 < n.length ? n[1] : o
    }, gs.prototype.updateGppCookies = function(e) {
        var e = this.getCookiesChunk(e),
            t = Object.keys(e).length,
            o = Number(g.readCookieParam(C.OPTANON_CONSENT, Ee.ChunkCountParam) || 0);
        this.writeGppCookies(t, e), t < o && this.deleteGppCookies(t + 1, o)
    }, gs.prototype.deleteAllGppCookies = function() {
        var e = Number(g.readCookieParam(C.OPTANON_CONSENT, Ee.ChunkCountParam) || 0);
        this.deleteGppCookies(1, e)
    }, gs.prototype.getCookiesChunk = function(e) {
        for (var t = {}, o = !1, n = e, r = 1; n.length;) {
            var i, s = void 0;
            n.length > Ee.ChunkSize ? s = Ee.ChunkSize : (s = n.length, o = 1 === r), o ? (t[Ee.Name] = n, n = "") : (i = n.slice(0, s), n = n.slice(s, n.length), t["" + Ee.Name + r] = i), r++
        }
        return t
    }, gs.prototype.writeGppCookies = function(e, t) {
        g.writeCookieParam(C.OPTANON_CONSENT, Ee.ChunkCountParam, e);
        for (var o = 0, n = Object.entries(t); o < n.length; o++) {
            var r = n[o],
                i = r[0];
            g.setCookie(i, r[1], I.ReconsentFrequencyDays)
        }
    }, gs.prototype.getSupportedAPIs = function() {
        return Object.values(Ne).filter(function(e, t, o) {
            return o.indexOf(e) === t
        })
    }, gs.prototype.getApplicableSections = function(e) {
        return [this.getCurrentSectionId(e)]
    };
    var ps, Cs = gs;

    function gs() {
        var e, t = this;
        this.gppSDKRef = null == (e = window.otIabModule) ? void 0 : e.gppSdkRef, this.cmpApi = this.initGppSDK(), this.updateGppConsentString = function() {
            t.cmpApi.getCmpDisplayStatus() === (null == (e = t.gppSDKRef) ? void 0 : e.displayStatus.VISIBLE) && t.cmpApi.setCmpDisplayStatus(null == (e = t.gppSDKRef) ? void 0 : e.displayStatus.HIDDEN);
            var e = t.getCurrentSectionName(t.gppTemplateApplied);
            t.setOrUpdateGppSectionString(e, !0)
        }
    }
    fs.prototype.isAuthUsr = function(e) {
        var t = g.readCookieParam(C.OPTANON_CONSENT, u.IS_ANONYMOUS_CONSENT);
        L.consentPreferences || "1" !== t ? g.writeCookieParam(C.OPTANON_CONSENT, "iType", "") : g.writeCookieParam(C.OPTANON_CONSENT, "iType", "" + Ce[e])
    }, fs.prototype.isBannerClosedByIconOrLink = function() {
        var e = L.bannerCloseSource;
        return e === ee.BannerCloseButton || e === ee.ContinueWithoutAcceptingButton
    }, fs.prototype.addCrossDeviceAttributes = function(e) {
        L.isV2Stub && (e.syncGroup = L.syncGrpId, I.UseGoogleVendors) && (e.gacString = g.getCookie(C.ADDITIONAL_CONSENT_STRING))
    }, fs.prototype.addAdvAnalyticsAttributes = function(e, t) {
        var o, n = y.getGroupById(I.AdvancedAnalyticsCategory);
        n && this.canSendAdvancedAnalytics(e.purposes, n) && (o = window.navigator.userAgent, e.dsDataElements = {
            InteractionType: t,
            Country: L && L.userLocation && /^[a-zA-Z]{2}$/.test(L.userLocation.country) ? L.userLocation.country.toUpperCase() : "",
            UserAgent: o,
            ConsentModel: I.ConsentModel.Name
        }, e.source = {
            purposeIds: [n.PurposeId],
            content: window.location.href,
            type: "WEB"
        }, this.addGeolocationAttributes(e, n))
    }, fs.prototype.addGeolocationAttributes = function(e, t) {
        var o = L.userLocation;
        o && (e.geolocation = {
            country: o.country.toUpperCase(),
            state: o.state,
            stateName: o.stateName || "",
            purposeIds: t ? [t.PurposeId] : []
        })
    }, fs.prototype.canSendConsentReceipt = function(e, t, o) {
        return e || A.apiSource === oe.UpdateConsent || L.consentInteractionType !== t || o
    }, fs.prototype.addGppStringAttribute = function(e) {
        I.IsGPPEnabled && ps.hasGPPSection() && ps.updateGppConsentString();
        var t = g.getCookie(C.GPP_CONSENT);
        t && (e.gppString = t)
    }, fs.prototype.addConsentStringToPayload = function(e) {
        var t = g.getCookie(C.EU_PUB_CONSENT),
            o = A.getRegionRuleType();
        (A.isIab2orv2Template || "IABC" === o) && t ? e.consentString = {
            type: "IABC" === o ? "tcfcanada" : "IAB2" !== o && "IAB2V2" !== o ? "" : "tcfeu",
            content: t
        } : I.IsGPPEnabled && e.hasOwnProperty("gppString") && e.gppString && (e.consentString = {
            type: "gpp",
            content: e.gppString
        }, delete e.gppString)
    }, fs.prototype.createConsentTxn = function(e, t, o, n, r) {
        void 0 === t && (t = ""), void 0 === o && (o = !1);
        var i = this.ensureConsentId(e, n = void 0 === n ? !0 : n, r = void 0 === r ? !1 : r),
            s = I.ConsentIntegration,
            a = window.navigator.userAgent,
            a = /OneTrust/.test(a);
        s.ConsentApi && s.RequestInformation && i.id && !a && (a = m.moduleInitializer, hs.noOptOutToogle = a.TenantFeatures.CookieV2NoOptOut, hs.isCloseByIconOrLink = this.isBannerClosedByIconOrLink(), i = {
            requestInformation: s.RequestInformation,
            identifier: i.id,
            identifierType: i.identifierType,
            customPayload: {
                Interaction: i.count,
                AddDefaultInteraction: i.addDfltInt
            },
            isAnonymous: i.isAnonymous,
            test: a.ScriptType === Ue.TEST || a.ScriptType === Ue.LOCAL_TEST,
            purposes: this.getConsetPurposes(e),
            dsDataElements: {}
        }, this.handleReceiptsWhenSendReceiptIsEnabled(i, r, t), this.addCrossDeviceAttributes(i), this.addAdvAnalyticsAttributes(i, t), this.addGppStringAttribute(i), this.addConsentStringToPayload(i), !a.MobileSDK && n && i.purposes.length && (a = JSON.stringify(i), n = this.getAuthToken(), this.sendBeaconSupported(e, n) ? (navigator.sendBeacon(s.ConsentApi, a), p.dispatchConsentEvent()) : this.canSendConsentReceipt(o, t, r) && (L.isV2Stub && t && this.isAuthUsr(t), v.ajax({
            url: s.ConsentApi,
            type: "post",
            dataType: "json",
            contentType: "application/json",
            data: JSON.stringify(i),
            sync: e,
            success: function() {
                p.dispatchConsentEvent()
            },
            error: function() {
                p.dispatchConsentEvent()
            },
            token: n
        }))), A.pubDomainData.ConsentIntegrationData = {
            consentApi: s.ConsentApi,
            consentPayload: i
        }), L.consentInteractionType = t, this.storeInteractionType(t)
    }, fs.prototype.ensureConsentId = function(e, t, o) {
        void 0 === o && (o = !1);
        var n, r = !1,
            i = this.getIdenTypeAndIsAnonAttr(),
            s = i.isAnonymous,
            i = i.identifierType,
            e = e || !t || o ? 0 : (r = !0, 1),
            a = g.readCookieParam(C.OPTANON_CONSENT, u.CONSENT_ID, !0);
        return a ? (n = parseInt(g.readCookieParam(C.OPTANON_CONSENT, u.INTERACTION_COUNT), 10), isNaN(n) || (t && !o && ++n, e = n, r = !1)) : (a = P.generateUUID(), g.writeCookieParam(C.OPTANON_CONSENT, u.CONSENT_ID, a)), g.writeCookieParam(C.OPTANON_CONSENT, u.INTERACTION_COUNT, e), g.writeCookieParam(C.OPTANON_CONSENT, u.IS_ANONYMOUS_CONSENT, s ? "1" : "0"), {
            id: a,
            count: e,
            addDfltInt: r,
            identifierType: i,
            isAnonymous: s
        }
    }, fs.prototype.getIdenTypeAndIsAnonAttr = function() {
        var e = !0,
            t = g.readCookieParam(C.OPTANON_CONSENT, u.IDENTIFIER_TYPE, !1),
            o = t,
            n = (!1 !== (null == (n = I.ConsentIntegration) ? void 0 : n.IdentifiedReceiptsAllowed) && L.isV2Stub || (e = !0, o = null == (n = I.ConsentIntegration) ? void 0 : n.DefaultAnonymousIdentifier), (L.isV2Stub || null != (n = I.ConsentIntegration) && n.IdentifiedReceiptsAllowed && !L.isV2Stub) && (e = (n = this.setAnonymityBasedOnKnownUserOrNot(e, o)).isAnonymous, o = n.idTypeUpdated), L.dsParams);
        return n.forceUserConsentAttributes && (n && n.hasOwnProperty("isAnonymous") && (e = n.isAnonymous), t) && (o = t), {
            isAnonymous: e,
            identifierType: o
        }
    }, fs.prototype.setAnonymityBasedOnKnownUserOrNot = function(e, t) {
        var o, n = "",
            n = null != (o = L.dsParams) && o.id ? (e = !1, null != (o = t) && o.trim().length ? t : null == (o = I.ConsentIntegration) ? void 0 : o.DefaultIdentifier) : (e = !0, null == (t = I.ConsentIntegration) ? void 0 : t.DefaultAnonymousIdentifier);
        return {
            isAnonymous: e,
            idTypeUpdated: n
        }
    }, fs.prototype.storeInteractionType = function(e) {
        var t;
        null != (t = e) && t.length && (isNaN(e) && (e = Ce[e]), g.writeCookieParam(C.OPTANON_CONSENT, u.INTERACTION_TYPE, e))
    }, fs.prototype.getAuthToken = function() {
        var e = null;
        return e = I.ConsentIntegration.EnableJWTAuthForKnownUsers && L.dsParams.id && L.dsParams.token ? L.dsParams.token : e
    }, fs.prototype.sendBeaconSupported = function(e, t) {
        return e && navigator.sendBeacon && !t
    }, fs.prototype.handleReceiptsWhenSendReceiptIsEnabled = function(e, t, o) {
        !L.isV2Stub && t && ((t = g.getCookie(C.ALERT_BOX_CLOSED)) && (e.interactionDate = t), o && (e.InteractionType = o), e.enableDataElementDateValidation = !0)
    }, fs.prototype.getGrpDetails = function(e, o) {
        var n = [];
        return e.forEach(function(e) {
            var e = e.split(":"),
                t = e[0],
                e = "true" === e[1] ? "1" : "0",
                t = hs.getOptanonIdForIabGroup(t, o);
            n.push(t + ":" + e)
        }), n
    }, fs.prototype.getOptanonIdForIabGroup = function(e, t) {
        var o;
        return t === ne.Purpose ? o = b.IdPatterns.Pur + e : t === ne.SpecialFeature && (o = b.IdPatterns.Spl_Ft + e), o
    }, fs.prototype.getConsetPurposes = function(o) {
        var n = this,
            r = [],
            e = [],
            t = L.oneTrustIABConsent,
            i = t && t.purpose ? this.getGrpDetails(t.purpose, ne.Purpose) : [],
            s = t && t.specialFeatures ? this.getGrpDetails(t.specialFeatures, ne.SpecialFeature) : [],
            e = U(t.specialPurposes, t.features);
        return U(L.groupsConsent, i, s).forEach(function(e) {
            var e = e.split(":"),
                t = y.getGroupById(e[0]);
            t && t.PurposeId && (e = n.getTransactionType(t, e, o), r.push({
                Id: t.PurposeId,
                TransactionType: e.txnType
            }), n.setVSConsentByGroup(t, e).forEach(function(e) {
                return r.push(e)
            }))
        }), e.forEach(function(e) {
            e.purposeId && r.push({
                Id: e.purposeId,
                TransactionType: Re
            })
        }), L.bannerCloseSource = ee.Unknown, r
    }, fs.prototype.setVSConsentByGroup = function(e, o) {
        var n = [];
        return L.showVendorService && e.VendorServices && e.VendorServices.forEach(function(e) {
            var t;
            t = o.useOwn ? L.vsConsent.get(e.CustomVendorServiceId) ? xe : He : o.txnType, n.push({
                Id: e.PurposeId,
                TransactionType: t
            })
        }), n
    }, fs.prototype.getTransactionType = function(e, t, o) {
        var n = {
            txnType: Re,
            useOwn: !1
        };
        return e.Status === S.ALWAYS_ACTIVE ? n.txnType = Re : e.Status.toLowerCase() === S.ALWAYS_INACTIVE || e.Status === S.INACTIVE && hs.isCloseByIconOrLink || o ? n.txnType = Fe : e.Status === S.ACTIVE && hs.isCloseByIconOrLink ? n.txnType = hs.noOptOutToogle ? Me : xe : (n.useOwn = !0, n.txnType = this.getTxnType(t[1])), n
    }, fs.prototype.getTxnType = function(e) {
        return "0" === e ? He : xe
    }, fs.prototype.isPurposeConsentedTo = function(e, t) {
        var o = [xe, Re];
        return e.some(function(e) {
            return e.Id === t.PurposeId && (-1 !== o.indexOf(e.TransactionType) || y.checkIfGroupHasConsent(t))
        })
    }, fs.prototype.canSendAdvancedAnalytics = function(t, e) {
        var o = this;
        return "BRANCH" === e.Type || e.Type === b.GroupTypes.Stack ? e.SubGroups.length && e.SubGroups.every(function(e) {
            return o.isPurposeConsentedTo(t, e)
        }) : this.isPurposeConsentedTo(t, e)
    };
    var hs, ys = fs;

    function fs() {}
    var N, Ss = function() {
            this.assets = function() {
                return {
                    name: "otCookiePolicy",
                    html: '<div class="ot-sdk-cookie-policy ot-sdk-container">\n    <h3 id="cookie-policy-title">Cookie Tracking Table</h3>\n    <div id="cookie-policy-description"></div>\n    <section>\n        <h4 class="ot-sdk-cookie-policy-group">Strictly Necessary Cookies</h4>\n        <p class="ot-sdk-cookie-policy-group-desc">group description</p>\n        <h5 class="cookies-used-header">Cookies Used</h5>\n        <ul class="cookies-list">\n            <li>Cookie 1</li>\n        </ul>\n        <table>\n            <caption class="ot-scrn-rdr">caption</caption>\n            <thead>\n                <tr>\n                    <th scope="col" class="table-header host">Host</th>\n                    <th scope="col" class="table-header host-description">Host Description</th>\n                    <th scope="col" class="table-header cookies">Cookies</th>\n                    <th scope="col" class="table-header life-span">Life Span</th>\n                </tr>\n            </thead>\n            <tbody>\n                <tr>\n                    <td class="host-td" data-label="Host"><span class="ot-mobile-border"></span><a\n                            href="https://cookiepedia.co.uk/host/.app.onetrust.com?_ga=2.157675898.1572084395.1556120090-1266459230.1555593548&_ga=2.157675898.1572084395.1556120090-1266459230.1555593548">Azure</a>\n                    </td>\n                    <td class="host-description-td" data-label="Host Description"><span\n                            class="ot-mobile-border"></span>These\n                        cookies are used to make sure\n                        visitor page requests are routed to the same server in all browsing sessions.</td>\n                    <td class="cookies-td" data-label="Cookies">\n                        <span class="ot-mobile-border"></span>\n                        <ul>\n                            <li>ARRAffinity</li>\n                        </ul>\n                    </td>\n                    <td class="life-span-td" data-label="Life Span"><span class="ot-mobile-border"></span>\n                        <ul>\n                            <li>100 days</li>\n                        </ul>\n                    </td>\n                </tr>\n            </tbody>\n        </table>\n    </section>\n    <section class="subgroup">\n        <h5 class="ot-sdk-cookie-policy-group">Strictly Necessary Cookies</h5>\n        <p class="ot-sdk-cookie-policy-group-desc">description</p>\n        <h6 class="cookies-used-header">Cookies Used</h6>\n        <ul class="cookies-list">\n            <li>Cookie 1</li>\n        </ul>\n        <table>\n            <caption class="ot-scrn-rdr">caption</caption>\n            <thead>\n                <tr>\n                    <th scope="col" class="table-header host">Host</th>\n                    <th scope="col" class="table-header host-description">Host Description</th>\n                    <th scope="col" class="table-header cookies">Cookies</th>\n                    <th scope="col" class="table-header life-span">Life Span</th>\n                </tr>\n            </thead>\n            <tbody>\n                <tr>\n                    <td class="host-td" data-label="Host"><span class="ot-mobile-border"></span><a\n                            href="https://cookiepedia.co.uk/host/.app.onetrust.com?_ga=2.157675898.1572084395.1556120090-1266459230.1555593548&_ga=2.157675898.1572084395.1556120090-1266459230.1555593548">Azure</a>\n                    </td>\n                    <td class="host-description-td" data-label="Host Description">\n                        <span class="ot-mobile-border"></span>\n                        cookies are used to make sureng sessions.\n                    </td>\n                    <td class="cookies-td" data-label="Cookies">\n                        <span class="ot-mobile-border"></span>\n                        <ul>\n                            <li>ARRAffinity</li>\n                        </ul>\n                    </td>\n                    <td class="life-span-td" data-label="Life Span"><span class="ot-mobile-border"></span>\n                        <ul>\n                            <li>100 days</li>\n                        </ul>\n                    </td>\n                </tr>\n            </tbody>\n        </table>\n    </section>\n</div>\n\x3c!-- New Cookies policy Link--\x3e\n<div id="ot-sdk-cookie-policy-v2" class="ot-sdk-cookie-policy ot-sdk-container">\n    <h3 id="cookie-policy-title" class="ot-sdk-cookie-policy-title">Cookie Tracking Table</h3>\n    <div id="cookie-policy-description"></div>\n    <section>\n        <h4 class="ot-sdk-cookie-policy-group">Strictly Necessary Cookies</h4>\n        <p class="ot-sdk-cookie-policy-group-desc">group description</p>\n        <section class="ot-sdk-subgroup">\n            <ul>\n                <li>\n                    <h5 class="ot-sdk-cookie-policy-group">Strictly Necessary Cookies</h5>\n                    <p class="ot-sdk-cookie-policy-group-desc">description</p>\n                </li>\n            </ul>\n        </section>\n        <table>\n            <caption class="ot-scrn-rdr">caption</caption>\n            <thead>\n                <tr>\n                    <th scope="col" class="ot-table-header ot-host">Host</th>\n                    <th scope="col" class="ot-table-header ot-host-description">Host Description</th>\n                    <th scope="col" class="ot-table-header ot-cookies">Cookies</th>\n                    <th scope="col" class="ot-table-header ot-cookies-type">Type</th>\n                    <th scope="col" class="ot-table-header ot-life-span">Life Span</th>\n                </tr>\n            </thead>\n            <tbody>\n                <tr>\n                    <td class="ot-host-td" data-label="Host"><span class="ot-mobile-border"></span><a\n                            href="https://cookiepedia.co.uk/host/.app.onetrust.com?_ga=2.157675898.1572084395.1556120090-1266459230.1555593548&_ga=2.157675898.1572084395.1556120090-1266459230.1555593548">Azure</a>\n                    </td>\n                    <td class="ot-host-description-td" data-label="Host Description">\n                        <span class="ot-mobile-border"></span>\n                        cookies are used to make sureng sessions.\n                    </td>\n                    <td class="ot-cookies-td" data-label="Cookies">\n                        <span class="ot-mobile-border"></span>\n                        <span class="ot-cookies-td-content">ARRAffinity</span>\n                    </td>\n                    <td class="ot-cookies-type" data-label="Type">\n                        <span class="ot-mobile-border"></span>\n                        <span class="ot-cookies-type-td-content">1st Party</span>\n                    </td>\n                    <td class="ot-life-span-td" data-label="Life Span">\n                        <span class="ot-mobile-border"></span>\n                        <span class="ot-life-span-td-content">100 days</span>\n                    </td>\n                </tr>\n            </tbody>\n        </table>\n    </section>\n</div>',
                    css: ".ot-sdk-cookie-policy{font-family:inherit;font-size:16px}.ot-sdk-cookie-policy.otRelFont{font-size:1rem}.ot-sdk-cookie-policy h3,.ot-sdk-cookie-policy h4,.ot-sdk-cookie-policy h6,.ot-sdk-cookie-policy p,.ot-sdk-cookie-policy li,.ot-sdk-cookie-policy a,.ot-sdk-cookie-policy th,.ot-sdk-cookie-policy #cookie-policy-description,.ot-sdk-cookie-policy .ot-sdk-cookie-policy-group,.ot-sdk-cookie-policy #cookie-policy-title{color:dimgray}.ot-sdk-cookie-policy #cookie-policy-description{margin-bottom:1em}.ot-sdk-cookie-policy h4{font-size:1.2em}.ot-sdk-cookie-policy h6{font-size:1em;margin-top:2em}.ot-sdk-cookie-policy th{min-width:75px}.ot-sdk-cookie-policy a,.ot-sdk-cookie-policy a:hover{background:#fff}.ot-sdk-cookie-policy thead{background-color:#f6f6f4;font-weight:bold}.ot-sdk-cookie-policy .ot-mobile-border{display:none}.ot-sdk-cookie-policy section{margin-bottom:2em}.ot-sdk-cookie-policy table{border-collapse:inherit}#ot-sdk-cookie-policy-v2.ot-sdk-cookie-policy{font-family:inherit;font-size:1rem}#ot-sdk-cookie-policy-v2.ot-sdk-cookie-policy h3,#ot-sdk-cookie-policy-v2.ot-sdk-cookie-policy h4,#ot-sdk-cookie-policy-v2.ot-sdk-cookie-policy h6,#ot-sdk-cookie-policy-v2.ot-sdk-cookie-policy p,#ot-sdk-cookie-policy-v2.ot-sdk-cookie-policy li,#ot-sdk-cookie-policy-v2.ot-sdk-cookie-policy a,#ot-sdk-cookie-policy-v2.ot-sdk-cookie-policy th,#ot-sdk-cookie-policy-v2.ot-sdk-cookie-policy #cookie-policy-description,#ot-sdk-cookie-policy-v2.ot-sdk-cookie-policy .ot-sdk-cookie-policy-group,#ot-sdk-cookie-policy-v2.ot-sdk-cookie-policy #cookie-policy-title{color:dimgray}#ot-sdk-cookie-policy-v2.ot-sdk-cookie-policy #cookie-policy-description{margin-bottom:1em}#ot-sdk-cookie-policy-v2.ot-sdk-cookie-policy .ot-sdk-subgroup{margin-left:1.5em}#ot-sdk-cookie-policy-v2.ot-sdk-cookie-policy #cookie-policy-description,#ot-sdk-cookie-policy-v2.ot-sdk-cookie-policy .ot-sdk-cookie-policy-group-desc,#ot-sdk-cookie-policy-v2.ot-sdk-cookie-policy .ot-table-header,#ot-sdk-cookie-policy-v2.ot-sdk-cookie-policy a,#ot-sdk-cookie-policy-v2.ot-sdk-cookie-policy span,#ot-sdk-cookie-policy-v2.ot-sdk-cookie-policy td{font-size:.9em}#ot-sdk-cookie-policy-v2.ot-sdk-cookie-policy td span,#ot-sdk-cookie-policy-v2.ot-sdk-cookie-policy td a{font-size:inherit}#ot-sdk-cookie-policy-v2.ot-sdk-cookie-policy .ot-sdk-cookie-policy-group{font-size:1em;margin-bottom:.6em}#ot-sdk-cookie-policy-v2.ot-sdk-cookie-policy .ot-sdk-cookie-policy-title{margin-bottom:1.2em}#ot-sdk-cookie-policy-v2.ot-sdk-cookie-policy>section{margin-bottom:1em}#ot-sdk-cookie-policy-v2.ot-sdk-cookie-policy th{min-width:75px}#ot-sdk-cookie-policy-v2.ot-sdk-cookie-policy a,#ot-sdk-cookie-policy-v2.ot-sdk-cookie-policy a:hover{background:#fff}#ot-sdk-cookie-policy-v2.ot-sdk-cookie-policy thead{background-color:#f6f6f4;font-weight:bold}#ot-sdk-cookie-policy-v2.ot-sdk-cookie-policy .ot-mobile-border{display:none}#ot-sdk-cookie-policy-v2.ot-sdk-cookie-policy section{margin-bottom:2em}#ot-sdk-cookie-policy-v2.ot-sdk-cookie-policy .ot-sdk-subgroup ul li{list-style:disc;margin-left:1.5em}#ot-sdk-cookie-policy-v2.ot-sdk-cookie-policy .ot-sdk-subgroup ul li h4{display:inline-block}#ot-sdk-cookie-policy-v2.ot-sdk-cookie-policy table{border-collapse:inherit;margin:auto;border:1px solid #d7d7d7;border-radius:5px;border-spacing:initial;width:100%;overflow:hidden}#ot-sdk-cookie-policy-v2.ot-sdk-cookie-policy table th,#ot-sdk-cookie-policy-v2.ot-sdk-cookie-policy table td{border-bottom:1px solid #d7d7d7;border-right:1px solid #d7d7d7}#ot-sdk-cookie-policy-v2.ot-sdk-cookie-policy table tr:last-child td{border-bottom:0px}#ot-sdk-cookie-policy-v2.ot-sdk-cookie-policy table tr th:last-child,#ot-sdk-cookie-policy-v2.ot-sdk-cookie-policy table tr td:last-child{border-right:0px}#ot-sdk-cookie-policy-v2.ot-sdk-cookie-policy table .ot-host,#ot-sdk-cookie-policy-v2.ot-sdk-cookie-policy table .ot-cookies-type{width:25%}.ot-sdk-cookie-policy[dir=rtl]{text-align:left}#ot-sdk-cookie-policy h3{font-size:1.5em}@media only screen and (max-width: 530px){.ot-sdk-cookie-policy:not(#ot-sdk-cookie-policy-v2) table,.ot-sdk-cookie-policy:not(#ot-sdk-cookie-policy-v2) thead,.ot-sdk-cookie-policy:not(#ot-sdk-cookie-policy-v2) tbody,.ot-sdk-cookie-policy:not(#ot-sdk-cookie-policy-v2) th,.ot-sdk-cookie-policy:not(#ot-sdk-cookie-policy-v2) td,.ot-sdk-cookie-policy:not(#ot-sdk-cookie-policy-v2) tr{display:block}.ot-sdk-cookie-policy:not(#ot-sdk-cookie-policy-v2) thead tr{position:absolute;top:-9999px;left:-9999px}.ot-sdk-cookie-policy:not(#ot-sdk-cookie-policy-v2) tr{margin:0 0 1em 0}.ot-sdk-cookie-policy:not(#ot-sdk-cookie-policy-v2) tr:nth-child(odd),.ot-sdk-cookie-policy:not(#ot-sdk-cookie-policy-v2) tr:nth-child(odd) a{background:#f6f6f4}.ot-sdk-cookie-policy:not(#ot-sdk-cookie-policy-v2) td{border:none;border-bottom:1px solid #eee;position:relative;padding-left:50%}.ot-sdk-cookie-policy:not(#ot-sdk-cookie-policy-v2) td:before{position:absolute;height:100%;left:6px;width:40%;padding-right:10px}.ot-sdk-cookie-policy:not(#ot-sdk-cookie-policy-v2) .ot-mobile-border{display:inline-block;background-color:#e4e4e4;position:absolute;height:100%;top:0;left:45%;width:2px}.ot-sdk-cookie-policy:not(#ot-sdk-cookie-policy-v2) td:before{content:attr(data-label);font-weight:bold}.ot-sdk-cookie-policy:not(#ot-sdk-cookie-policy-v2) li{word-break:break-word;word-wrap:break-word}#ot-sdk-cookie-policy-v2.ot-sdk-cookie-policy table{overflow:hidden}#ot-sdk-cookie-policy-v2.ot-sdk-cookie-policy table td{border:none;border-bottom:1px solid #d7d7d7}#ot-sdk-cookie-policy-v2.ot-sdk-cookie-policy table,#ot-sdk-cookie-policy-v2.ot-sdk-cookie-policy thead,#ot-sdk-cookie-policy-v2.ot-sdk-cookie-policy tbody,#ot-sdk-cookie-policy-v2.ot-sdk-cookie-policy th,#ot-sdk-cookie-policy-v2.ot-sdk-cookie-policy td,#ot-sdk-cookie-policy-v2.ot-sdk-cookie-policy tr{display:block}#ot-sdk-cookie-policy-v2.ot-sdk-cookie-policy table .ot-host,#ot-sdk-cookie-policy-v2.ot-sdk-cookie-policy table .ot-cookies-type{width:auto}#ot-sdk-cookie-policy-v2.ot-sdk-cookie-policy tr{margin:0 0 1em 0}#ot-sdk-cookie-policy-v2.ot-sdk-cookie-policy td:before{height:100%;width:40%;padding-right:10px}#ot-sdk-cookie-policy-v2.ot-sdk-cookie-policy td:before{content:attr(data-label);font-weight:bold}#ot-sdk-cookie-policy-v2.ot-sdk-cookie-policy li{word-break:break-word;word-wrap:break-word}#ot-sdk-cookie-policy-v2.ot-sdk-cookie-policy thead tr{position:absolute;top:-9999px;left:-9999px;z-index:-9999}#ot-sdk-cookie-policy-v2.ot-sdk-cookie-policy table tr:last-child td{border-bottom:1px solid #d7d7d7;border-right:0px}#ot-sdk-cookie-policy-v2.ot-sdk-cookie-policy table tr:last-child td:last-child{border-bottom:0px}}",
                    cssRTL: ".ot-sdk-cookie-policy{font-family:inherit;font-size:16px}.ot-sdk-cookie-policy.otRelFont{font-size:1rem}.ot-sdk-cookie-policy h3,.ot-sdk-cookie-policy h4,.ot-sdk-cookie-policy h6,.ot-sdk-cookie-policy p,.ot-sdk-cookie-policy li,.ot-sdk-cookie-policy a,.ot-sdk-cookie-policy th,.ot-sdk-cookie-policy #cookie-policy-description,.ot-sdk-cookie-policy .ot-sdk-cookie-policy-group,.ot-sdk-cookie-policy #cookie-policy-title{color:dimgray}.ot-sdk-cookie-policy #cookie-policy-description{margin-bottom:1em}.ot-sdk-cookie-policy h4{font-size:1.2em}.ot-sdk-cookie-policy h6{font-size:1em;margin-top:2em}.ot-sdk-cookie-policy th{min-width:75px}.ot-sdk-cookie-policy a,.ot-sdk-cookie-policy a:hover{background:#fff}.ot-sdk-cookie-policy thead{background-color:#f6f6f4;font-weight:bold}.ot-sdk-cookie-policy .ot-mobile-border{display:none}.ot-sdk-cookie-policy section{margin-bottom:2em}.ot-sdk-cookie-policy table{border-collapse:inherit}#ot-sdk-cookie-policy-v2.ot-sdk-cookie-policy{font-family:inherit;font-size:1rem}#ot-sdk-cookie-policy-v2.ot-sdk-cookie-policy h3,#ot-sdk-cookie-policy-v2.ot-sdk-cookie-policy h4,#ot-sdk-cookie-policy-v2.ot-sdk-cookie-policy h6,#ot-sdk-cookie-policy-v2.ot-sdk-cookie-policy p,#ot-sdk-cookie-policy-v2.ot-sdk-cookie-policy li,#ot-sdk-cookie-policy-v2.ot-sdk-cookie-policy a,#ot-sdk-cookie-policy-v2.ot-sdk-cookie-policy th,#ot-sdk-cookie-policy-v2.ot-sdk-cookie-policy #cookie-policy-description,#ot-sdk-cookie-policy-v2.ot-sdk-cookie-policy .ot-sdk-cookie-policy-group,#ot-sdk-cookie-policy-v2.ot-sdk-cookie-policy #cookie-policy-title{color:dimgray}#ot-sdk-cookie-policy-v2.ot-sdk-cookie-policy #cookie-policy-description{margin-bottom:1em}#ot-sdk-cookie-policy-v2.ot-sdk-cookie-policy .ot-sdk-subgroup{margin-right:1.5em}#ot-sdk-cookie-policy-v2.ot-sdk-cookie-policy #cookie-policy-description,#ot-sdk-cookie-policy-v2.ot-sdk-cookie-policy .ot-sdk-cookie-policy-group-desc,#ot-sdk-cookie-policy-v2.ot-sdk-cookie-policy .ot-table-header,#ot-sdk-cookie-policy-v2.ot-sdk-cookie-policy a,#ot-sdk-cookie-policy-v2.ot-sdk-cookie-policy span,#ot-sdk-cookie-policy-v2.ot-sdk-cookie-policy td{font-size:.9em}#ot-sdk-cookie-policy-v2.ot-sdk-cookie-policy td span,#ot-sdk-cookie-policy-v2.ot-sdk-cookie-policy td a{font-size:inherit}#ot-sdk-cookie-policy-v2.ot-sdk-cookie-policy .ot-sdk-cookie-policy-group{font-size:1em;margin-bottom:.6em}#ot-sdk-cookie-policy-v2.ot-sdk-cookie-policy .ot-sdk-cookie-policy-title{margin-bottom:1.2em}#ot-sdk-cookie-policy-v2.ot-sdk-cookie-policy>section{margin-bottom:1em}#ot-sdk-cookie-policy-v2.ot-sdk-cookie-policy th{min-width:75px}#ot-sdk-cookie-policy-v2.ot-sdk-cookie-policy a,#ot-sdk-cookie-policy-v2.ot-sdk-cookie-policy a:hover{background:#fff}#ot-sdk-cookie-policy-v2.ot-sdk-cookie-policy thead{background-color:#f6f6f4;font-weight:bold}#ot-sdk-cookie-policy-v2.ot-sdk-cookie-policy .ot-mobile-border{display:none}#ot-sdk-cookie-policy-v2.ot-sdk-cookie-policy section{margin-bottom:2em}#ot-sdk-cookie-policy-v2.ot-sdk-cookie-policy .ot-sdk-subgroup ul li{list-style:disc;margin-right:1.5em}#ot-sdk-cookie-policy-v2.ot-sdk-cookie-policy .ot-sdk-subgroup ul li h4{display:inline-block}#ot-sdk-cookie-policy-v2.ot-sdk-cookie-policy table{border-collapse:inherit;margin:auto;border:1px solid #d7d7d7;border-radius:5px;border-spacing:initial;width:100%;overflow:hidden}#ot-sdk-cookie-policy-v2.ot-sdk-cookie-policy table th,#ot-sdk-cookie-policy-v2.ot-sdk-cookie-policy table td{border-bottom:1px solid #d7d7d7;border-left:1px solid #d7d7d7}#ot-sdk-cookie-policy-v2.ot-sdk-cookie-policy table tr:last-child td{border-bottom:0px}#ot-sdk-cookie-policy-v2.ot-sdk-cookie-policy table tr th:last-child,#ot-sdk-cookie-policy-v2.ot-sdk-cookie-policy table tr td:last-child{border-left:0px}#ot-sdk-cookie-policy-v2.ot-sdk-cookie-policy table .ot-host,#ot-sdk-cookie-policy-v2.ot-sdk-cookie-policy table .ot-cookies-type{width:25%}.ot-sdk-cookie-policy[dir=rtl]{text-align:right}#ot-sdk-cookie-policy h3{font-size:1.5em}@media only screen and (max-width: 530px){.ot-sdk-cookie-policy:not(#ot-sdk-cookie-policy-v2) table,.ot-sdk-cookie-policy:not(#ot-sdk-cookie-policy-v2) thead,.ot-sdk-cookie-policy:not(#ot-sdk-cookie-policy-v2) tbody,.ot-sdk-cookie-policy:not(#ot-sdk-cookie-policy-v2) th,.ot-sdk-cookie-policy:not(#ot-sdk-cookie-policy-v2) td,.ot-sdk-cookie-policy:not(#ot-sdk-cookie-policy-v2) tr{display:block}.ot-sdk-cookie-policy:not(#ot-sdk-cookie-policy-v2) thead tr{position:absolute;top:-9999px;right:-9999px}.ot-sdk-cookie-policy:not(#ot-sdk-cookie-policy-v2) tr{margin:0 0 1em 0}.ot-sdk-cookie-policy:not(#ot-sdk-cookie-policy-v2) tr:nth-child(odd),.ot-sdk-cookie-policy:not(#ot-sdk-cookie-policy-v2) tr:nth-child(odd) a{background:#f6f6f4}.ot-sdk-cookie-policy:not(#ot-sdk-cookie-policy-v2) td{border:none;border-bottom:1px solid #eee;position:relative;padding-right:50%}.ot-sdk-cookie-policy:not(#ot-sdk-cookie-policy-v2) td:before{position:absolute;height:100%;right:6px;width:40%;padding-left:10px}.ot-sdk-cookie-policy:not(#ot-sdk-cookie-policy-v2) .ot-mobile-border{display:inline-block;background-color:#e4e4e4;position:absolute;height:100%;top:0;right:45%;width:2px}.ot-sdk-cookie-policy:not(#ot-sdk-cookie-policy-v2) td:before{content:attr(data-label);font-weight:bold}.ot-sdk-cookie-policy:not(#ot-sdk-cookie-policy-v2) li{word-break:break-word;word-wrap:break-word}#ot-sdk-cookie-policy-v2.ot-sdk-cookie-policy table{overflow:hidden}#ot-sdk-cookie-policy-v2.ot-sdk-cookie-policy table td{border:none;border-bottom:1px solid #d7d7d7}#ot-sdk-cookie-policy-v2.ot-sdk-cookie-policy table,#ot-sdk-cookie-policy-v2.ot-sdk-cookie-policy thead,#ot-sdk-cookie-policy-v2.ot-sdk-cookie-policy tbody,#ot-sdk-cookie-policy-v2.ot-sdk-cookie-policy th,#ot-sdk-cookie-policy-v2.ot-sdk-cookie-policy td,#ot-sdk-cookie-policy-v2.ot-sdk-cookie-policy tr{display:block}#ot-sdk-cookie-policy-v2.ot-sdk-cookie-policy table .ot-host,#ot-sdk-cookie-policy-v2.ot-sdk-cookie-policy table .ot-cookies-type{width:auto}#ot-sdk-cookie-policy-v2.ot-sdk-cookie-policy tr{margin:0 0 1em 0}#ot-sdk-cookie-policy-v2.ot-sdk-cookie-policy td:before{height:100%;width:40%;padding-left:10px}#ot-sdk-cookie-policy-v2.ot-sdk-cookie-policy td:before{content:attr(data-label);font-weight:bold}#ot-sdk-cookie-policy-v2.ot-sdk-cookie-policy li{word-break:break-word;word-wrap:break-word}#ot-sdk-cookie-policy-v2.ot-sdk-cookie-policy thead tr{position:absolute;top:-9999px;right:-9999px;z-index:-9999}#ot-sdk-cookie-policy-v2.ot-sdk-cookie-policy table tr:last-child td{border-bottom:1px solid #d7d7d7;border-left:0px}#ot-sdk-cookie-policy-v2.ot-sdk-cookie-policy table tr:last-child td:last-child{border-bottom:0px}}"
                }
            }
        },
        ms = "opt-out",
        vs = (Ts.prototype.initializeFeaturesAndSpecialPurposes = function() {
            var t = this;
            L.oneTrustIABConsent.features = [], L.oneTrustIABConsent.specialPurposes = [], I.Groups.forEach(function(e) {
                t.checkAndPopulateFeatAndSplPur(e)
            })
        }, Ts.prototype.checkAndPopulateFeatAndSplPur = function(e) {
            var t, o = this,
                n = b.GroupTypes;
            e.Type !== n.Ft && e.Type !== n.Spl_Pur || ((t = {}).groupId = e.OptanonGroupId, t.purposeId = e.PurposeId, t.value = !0, (e.Type === n.Ft ? L.oneTrustIABConsent.features : L.oneTrustIABConsent.specialPurposes).push(t)), e.SubGroups && e.SubGroups.forEach(function(e) {
                o.checkAndPopulateFeatAndSplPur(e)
            })
        }, Ts.prototype.initGrpsAndHosts = function() {
            this.initializeGroupData(A.consentableGrps), p.isAlertBoxClosedAndValid() || A.initConsentableImpliedConsentGroup(A.consentableGrps), I.showCookieList && h.isOptOutEnabled() ? this.initializeHostData(A.consentableGrps) : (L.hostsConsent = [], co.writeHstParam(C.OPTANON_CONSENT))
        }, Ts.prototype.ensureHtmlGroupDataInitialised = function() {
            var e, t, o, n;
            this.initGrpsAndHosts(), L.showGeneralVendors && (fo.populateGenVendorLists(), fo.initGenVendorConsent()), I.IsIabEnabled && (this.initializeIABData(), this.initializeFeaturesAndSpecialPurposes()), L.vsIsActiveAndOptOut && this.initializeVendorsService(), p.setOrUpdate3rdPartyIABConsentFlag(), p.setGeolocationInCookies(), I.IsConsentLoggingEnabled && (e = window.OneTrust.dataSubjectParams || {}, t = g.readCookieParam(C.OPTANON_CONSENT, "iType"), o = "", n = !1, L.isV2Stub && e.id && e.token && (t || A.forceCreateTrxLocalConsentIsGreater) && (n = !0, o = Ce[t]), hs.createConsentTxn(!1, o, !1, n))
        }, Ts.prototype.initializeVendorsService = function() {
            var o = p.isAlertBoxClosedAndValid(),
                e = g.readCookieParam(C.OPTANON_CONSENT, go),
                n = P.strToMap(e);
            L.getVendorsInDomain().forEach(function(e, t) {
                n.has(t) || (e = !o && y.checkIsActiveByDefault(e.groupRef), n.set(t, e))
            }), L.vsConsent = n
        }, Ts.prototype.initializeGroupData = function(e) {
            var t;
            g.readCookieParam(C.OPTANON_CONSENT, uo) ? (ko.synchroniseCookieGroupData(e), t = g.readCookieParam(C.OPTANON_CONSENT, uo), L.groupsConsent = P.strToArr(t), L.gpcConsentTxn && (I.IsConsentLoggingEnabled && hs.createConsentTxn(!1, "GPC value changed", !1, !0), L.gpcConsentTxn = !1, so.setAlertBoxClosed(!0))) : (L.groupsConsent = [], e.forEach(function(e) {
                var t = y.checkIsActiveByDefault(e) && e.HasConsentOptOut;
                e.Status === S.INACTIVE_LANDING_PAGE && !p.isAlertBoxClosedAndValid() && vo.isLandingPage() && (t = !1), L.groupsConsent.push(e.CustomGroupId + ":" + (t ? "1" : "0"))
            }), I.IsConsentLoggingEnabled && window.addEventListener("beforeunload", this.consentDefaulCall))
        }, Ts.prototype.initializeHostData = function(e) {
            var t, r;
            g.readCookieParam(C.OPTANON_CONSENT, "hosts") ? (ko.synchroniseCookieHostData(), t = g.readCookieParam(C.OPTANON_CONSENT, "hosts"), L.hostsConsent = P.strToArr(t), e.forEach(function(e) {
                y.isAlwaysActiveGroup(e) && e.Hosts.length && e.Hosts.forEach(function(e) {
                    L.oneTrustAlwaysActiveHosts.push(e.HostId)
                })
            })) : (L.hostsConsent = [], r = {}, e.forEach(function(e) {
                var o = y.isAlwaysActiveGroup(e),
                    n = L.syncRequired ? ko.groupHasConsent(e) : y.checkIsActiveByDefault(e);
                e.Hosts.length && e.Hosts.forEach(function(e) {
                    var t;
                    r[e.HostId] ? ko.updateHostStatus(e, n) : (r[e.HostId] = !0, o && L.oneTrustAlwaysActiveHosts.push(e.HostId), t = ko.isHostPartOfAlwaysActiveGroup(e.HostId), L.hostsConsent.push(e.HostId + (t || n ? ":1" : ":0")))
                })
            }))
        }, Ts.prototype.consentDefaulCall = function() {
            var e = parseInt(g.readCookieParam(C.OPTANON_CONSENT, u.INTERACTION_COUNT), 10);
            !isNaN(e) && 0 !== e || (so.triggerGoogleAnalyticsEvent(Lo, "Click", "No interaction"), I.IsConsentLoggingEnabled && hs.createConsentTxn(!0), window.removeEventListener("beforeunload", N.consentDefaulCall))
        }, Ts.prototype.fetchAssets = function(s) {
            return void 0 === s && (s = null), F(this, void 0, void 0, function() {
                var t, o, n, r, i;
                return M(this, function(e) {
                    switch (e.label) {
                        case 0:
                            return t = m.moduleInitializer, i = p.isAlertBoxClosedAndValid(), o = !!s, i = N.isFetchBanner(t.IsSuppressBanner, i), n = N.cookieSettingBtnPresent(), n = A.isIab2orv2Template ? I.PCShowPersistentCookiesHoverButton && (!I.PCenterDynamicRenderingEnable || (I.PCenterDynamicRenderingEnable, !n)) : I.PCShowPersistentCookiesHoverButton, r = "true" === L.urlParams.get(st), L.hideBanner = r, [4, Promise.all([!i || I.NoBanner || r ? Promise.resolve(null) : xt.getBannerContent(o, s), !t.IsSuppressPC || L.isPCVisible ? xt.getPcContent() : Promise.resolve(null), n ? xt.getCSBtnContent() : Promise.resolve(null), xt.getCommonStyles()])];
                        case 1:
                            return i = e.sent(), r = i[0], o = i[1], t = i[2], n = i[3], N.fetchContent(r, o, t, n), N.setCookieListGroupData(), [2]
                    }
                })
            })
        }, Ts.prototype.fetchContent = function(e, t, o, n) {
            var r;
            e && (r = e.html, m.fp.CookieV2SSR || (r = atob(e.html)), this.bannerGroup = {
                name: e.name,
                html: r,
                css: e.css
            }), t && (this.preferenceCenterGroup = {
                name: t.name,
                html: atob(t.html),
                css: t.css
            }, m.isV2Template = I.PCTemplateUpgrade && /otPcPanel|otPcCenter|otPcTab/.test(t.name)), o && (this.csBtnGroup = {
                name: "CookieSettingsButton",
                html: atob(o.html),
                css: o.css
            }), n && (this.commonStyles = n)
        }, Ts.prototype.cookieSettingBtnPresent = function() {
            return T("#ot-sdk-btn").length || T(".ot-sdk-show-settings").length || T(".optanon-show-settings").length
        }, Ts.prototype.isFetchBanner = function(e, t) {
            return !e || I.ShowAlertNotice && !t && e && !T("#onetrust-banner-sdk").length
        }, Ts.prototype.setCookieListGroupData = function() {
            var e;
            m.fp.CookieV2TrackingTechnologies || (e = (new Ss).assets(), N.cookieListGroup = {
                name: e.name,
                html: e.html,
                css: I.useRTL ? e.cssRTL : e.css
            })
        }, Ts.prototype.initializeIabPurposeConsentOnReload = function() {
            var t = this;
            A.consentableIabGrps.forEach(function(e) {
                t.setIABConsent(e, !1), e.IsLegIntToggle = !0, t.setIABConsent(e, !1)
            })
        }, Ts.prototype.initializeIABData = function(o, n, r) {
            var i = this,
                e = (void 0 === o && (o = !1), void 0 === n && (n = !1), void 0 === r && (r = !1), L.oneTrustIABConsent),
                t = (e.purpose = [], e.vendors = [], e.legIntVendors = [], e.specialFeatures = [], e.legimateInterest = [], L.addtlVendors),
                s = I.VendorConsentModel === ms;
            t.vendorConsent = [], !e.IABCookieValue || o || n || p.reconsentRequired() ? (A.consentableIabGrps.forEach(function(e) {
                var t;
                n && !r ? i.setIABConsent(e, y.isAlwaysActiveGroup(e)) : r ? e.HasConsentOptOut && i.setIABConsent(e, !1) : (t = o && e.HasConsentOptOut, i.setIABConsent(e, t), e.Type === b.GroupTypes.Pur && (e.IsLegIntToggle = !0, i.setIABConsent(e, e.HasLegIntOptOut)))
            }), I.IsIabEnabled && r && (L.oneTrustIABConsent.legimateInterest = L.vendors.selectedLegInt.slice()), t = o || !n && s, r && this.iab.saveVendorStatus(r), p.setIABVendor(t, r, n), !p.reconsentRequired() || o || n || p.resetTCModel()) : (this.initializeIabPurposeConsentOnReload(), no.populateGoogleConsent(), no.populateVendorAndPurposeFromCookieData())
        }, Ts.prototype.canSoftOptInInsertForGroup = function(e) {
            var e = y.getGroupById(e);
            if (e) return e = e && !e.Parent ? e : y.getParentGroup(e.Parent), "inactive landingpage" !== y.getGrpStatus(e).toLowerCase() || !vo.isLandingPage()
        }, Ts.prototype.setIABConsent = function(e, t) {
            e.Type === b.GroupTypes.Spl_Ft ? this.setIabSpeciFeatureConsent(e, t) : e.IsLegIntToggle ? (this.setIabLegIntConsent(e, t), e.IsLegIntToggle = !1) : this.setIabPurposeConsent(e, t)
        }, Ts.prototype.setIabPurposeConsent = function(o, n) {
            var r = !1;
            L.oneTrustIABConsent.purpose = L.oneTrustIABConsent.purpose.map(function(e) {
                var t = e.split(":")[0];
                return t === o.IabGrpId && (e = t + ":" + n, r = !0), e
            }), r || L.oneTrustIABConsent.purpose.push(o.IabGrpId + ":" + n)
        }, Ts.prototype.setIabLegIntConsent = function(o, n) {
            var r = !1;
            L.oneTrustIABConsent.legimateInterest = L.oneTrustIABConsent.legimateInterest.map(function(e) {
                var t = e.split(":")[0];
                return t === o.IabGrpId && (e = t + ":" + n, r = !0), e
            }), r || L.oneTrustIABConsent.legimateInterest.push(o.IabGrpId + ":" + n)
        }, Ts.prototype.setIabSpeciFeatureConsent = function(o, n) {
            var r = !1;
            L.oneTrustIABConsent.specialFeatures = L.oneTrustIABConsent.specialFeatures.map(function(e) {
                var t = e.split(":")[0];
                return t === o.IabGrpId && (e = t + ":" + n, r = !0), e
            }), r || L.oneTrustIABConsent.specialFeatures.push(o.IabGrpId + ":" + n)
        }, Ts);

    function Ts() {
        this.iab = w
    }
    l.prototype.getSearchQuery = function(e) {
        var t = this,
            e = e.trim().split(/\s+/g);
        return new RegExp(e.map(function(e) {
            return t.escapeRegExp(e)
        }).join("|") + "(.+)?", "gi")
    }, l.prototype.escapeRegExp = function(e) {
        return e.replace(/[-/\\^$*+?.()|[\]{}]/g, "\\$&")
    }, l.prototype.setGlobalFilteredList = function(e) {
        return L.currentGlobalFilteredList = e
    }, l.prototype.vendorHasPurpose = function(e, t) {
        var o = !1,
            n = parseInt(A.iabGrpIdMap[t]);
        return -1 < t.indexOf(b.IdPatterns.Ft) ? (e.features || []).forEach(function(e) {
            e.featureId === n && (o = !0)
        }) : -1 < t.indexOf(b.IdPatterns.Spl_Ft) ? e.specialFeatures.forEach(function(e) {
            e.featureId === n && (o = !0)
        }) : -1 < t.indexOf(b.IdPatterns.Spl_Pur) ? (e.specialPurposes || []).forEach(function(e) {
            e.purposeId === n && (o = !0)
        }) : (e.purposes.forEach(function(e) {
            e.purposeId === n && (o = !0)
        }), e.legIntPurposes.forEach(function(e) {
            e.purposeId === n && (o = !0)
        })), o
    }, l.prototype.filterList = function(t, e, o) {
        var n, r, i = o && o.length;
        return "" !== t || i ? (i && (i = T("#onetrust-pc-sdk " + k.P_Fltr_Options + " input").el.length, r = !(n = []), i !== o.length ? e.forEach(function(t) {
            r = !0, t.vendorName && o.forEach(function(e) {
                w.vendorHasPurpose(t, e) && n.push(t)
            })
        }) : n = e, r && (n = n.filter(function(e, t, o) {
            return o.indexOf(e) === t
        })), this.setGlobalFilteredList(n)), "" === t ? L.currentGlobalFilteredList : L.currentGlobalFilteredList.filter(function(e) {
            if (e.vendorName) return e.vendorName.toLowerCase().includes(t.toLowerCase())
        })) : this.setGlobalFilteredList(e)
    }, l.prototype.loadVendorList = function(e, t) {
        void 0 === e && (e = "");
        var o = L.vendors,
            o = (L.currentGlobalFilteredList = o.list, e ? (o.searchParam = e, L.filterByIABCategories = [], Sn.updateFilterSelection(!1)) : o.searchParam !== e ? o.searchParam = "" : t = L.filterByIABCategories, this.filterList(o.searchParam, o.list, t));
        T("#onetrust-pc-sdk " + k.P_Vendor_Content).el[0].scrollTop = 0, L.addtlVendorsList && 0 < Object.keys(L.addtlVendorsList).length && (this.hasGoogleVendors = !0), this.initVendorsData(e, o)
    }, l.prototype.searchVendors = function(e, t, o, n) {
        if (n) {
            var r, i, s = this.getSearchQuery(n),
                a = 0;
            for (r in t) r && (i = o === me.GoogleVendor ? r : t[r].VendorCustomId, i = T("" + e.vendorAccBtn + i).el[0].parentElement, s.lastIndex = 0, s.test(t[r][e.name]) ? (d(i, this._displayNull, !0), a++) : d(i, "display: none;", !0));
            0 === a ? (T(e.accId).hide(), o === me.GoogleVendor ? this.hasGoogleVendors = !1 : this.hasGenVendors = !1) : (o === me.GoogleVendor ? this.hasGoogleVendors = !0 : this.hasGenVendors = !0, T(e.accId).show()), this.showEmptyResults(!this.hasGoogleVendors && !this.hasIabVendors && !this.hasGenVendors, n)
        } else
            for (var l = T(" " + e.venListId + ' li[style^="display: none"]').el, c = 0; c < l.length; c++) d(l[c], this._displayNull, !0);
        n = T("#onetrust-pc-sdk " + e.selectAllEvntHndlr).el[0];
        document.querySelector(e.venListId + ' li:not([style^="display: none"]) ' + e.ctgl + " > input[checked]") ? P.setCheckedAttribute("", n, !0) : P.setCheckedAttribute("", n, !1), document.querySelector(e.venListId + ' li:not([style^="display: none"]) ' + e.ctgl + " > input:not([checked])") ? n.parentElement.classList.add(this.LINE_THROUGH_CLASS) : n.parentElement.classList.remove(this.LINE_THROUGH_CLASS)
    }, l.prototype.initGoogleVendors = function() {
        this.populateAddtlVendors(L.addtlVendorsList), this.venAdtlSelAllTglEvent()
    }, l.prototype.initGenVendors = function() {
        this.populateGeneralVendors(), I.GenVenOptOut && I.GeneralVendors && I.GeneralVendors.length && this.genVenSelectAllTglEvent()
    }, l.prototype.resetAddtlVendors = function() {
        w.searchVendors(w.googleSearchSelectors, L.addtlVendorsList, me.GoogleVendor), this.showConsentHeader()
    }, l.prototype.venAdtlSelAllTglEvent = function() {
        w.selectAllEventHandler({
            vendorsList: '#ot-addtl-venlst li:not([style^="display: none"]) .ot-ven-adtlctgl input',
            selAllCntr: "#onetrust-pc-sdk #ot-selall-adtlvencntr",
            selAllChkbox: "#onetrust-pc-sdk #ot-selall-adtlven-handler"
        })
    }, l.prototype.genVenSelectAllTglEvent = function() {
        var e = {
            vendorsList: k.P_Gven_List + ' li:not([style^="display: none"]) .ot-ven-gvctgl input',
            selAllCntr: "#onetrust-pc-sdk #ot-selall-gnvencntr",
            selAllChkbox: "#onetrust-pc-sdk #ot-selall-gnven-handler"
        };
        w.selectAllEventHandler(e)
    }, l.prototype.handleSelectAllChboxSelection = function(e, t, o) {
        for (var n = !0, r = !0, i = 0; i < e.length && (e[i].checked ? r = !1 : n = !1, n || r); i++);
        n || r ? o.classList.remove(this.LINE_THROUGH_CLASS) : (o.classList.add(this.LINE_THROUGH_CLASS), P.setAriaCheckedAttribute("", t, "mixed")), t.checked = !1, n ? (t.checked = !0, P.setAriaCheckedAttribute("", t, t.checked)) : r && P.setAriaCheckedAttribute("", t, t.checked), P.setCheckedAttribute("", t, t.checked)
    }, l.prototype.selectAllEventHandler = function(e) {
        var t = T(e.vendorsList).el,
            o = T(e.selAllCntr).el[0],
            e = T(e.selAllChkbox).el[0];
        w.handleSelectAllChboxSelection(t, e, o)
    }, l.prototype.vendorLegIntToggleEvent = function() {
        var e = T(k.P_Vendor_Container + ' li:not([style^="display: none"]) .' + k.P_Ven_Ltgl + " input").el,
            t = T("#onetrust-pc-sdk #" + k.P_Sel_All_Vendor_Leg_El).el[0],
            o = T("#onetrust-pc-sdk #select-all-vendor-leg-handler").el[0];
        w.handleSelectAllChboxSelection(e, o, t)
    }, l.prototype.vendorsListEvent = function() {
        var e = T(k.P_Vendor_Container + ' li:not([style^="display: none"]) .' + k.P_Ven_Ctgl + " input").el,
            t = T("#onetrust-pc-sdk #" + k.P_Sel_All_Vendor_Consent_El).el[0],
            o = T("#onetrust-pc-sdk #select-all-vendor-groups-handler").el[0];
        w.handleSelectAllChboxSelection(e, o, t)
    }, l.prototype.showEmptyResults = function(e, t, o) {
        void 0 === o && (o = !1);
        var n = T("#onetrust-pc-sdk #no-results");
        e ? this.setNoResultsContent(t, o) : (T("#onetrust-pc-sdk " + k.P_Vendor_Content).removeClass("no-results"), n.length && n.remove())
    }, l.prototype.playSearchStatus = function(e) {
        var t = e ? document.querySelectorAll(k.P_Host_Cntr + " > li") : document.querySelectorAll(k.P_Vendor_Container + ' li:not([style$="none;"]),' + k.P_Gven_List + ' li:not([style$="none;"])'),
            o = t.length,
            n = T('#onetrust-pc-sdk [role="status"]');
        o ? n.text(t.length + " " + (e ? "host" : "vendor") + (1 < o ? "s" : "") + " returned.") : n.el[0].textContent = ""
    }, l.prototype.setNoResultsContent = function(e, t) {
        void 0 === t && (t = !1);
        var o, n, r, i = T("#onetrust-pc-sdk #no-results").el[0];
        if (!i) return t = w.getNoResultsFound(t), o = document.createElement("div"), n = document.createElement("p"), t = document.createTextNode(t), r = document.createElement("span"), o.id = "no-results", r.id = "user-text", r.innerText = e, n.appendChild(r), n.appendChild(t), o.appendChild(n), T("#onetrust-pc-sdk " + k.P_Vendor_Content).addClass("no-results"), T("#vendor-search-handler").el[0].setAttribute("aria-describedby", o.id), T("#onetrust-pc-sdk " + k.P_Vendor_Content).append(o);
        i.querySelector("span").innerText = e
    }, l.prototype.searchHostList = function(e) {
        var t = {},
            o = [];
        L.showTrackingTech ? (t = L.currentTrackingTech, o = (t = e ? w.getFilteredAdditionaTechtData(e, t) : t).Cookies) : (o = L.currentGlobalFilteredList, e && (o = this.searchList(e, o))), this.initHostData({
            searchString: e,
            cookiesList: o,
            addTechData: t
        })
    }, l.prototype.searchList = function(e, t) {
        var o = this.getSearchQuery(e);
        return t.filter(function(e) {
            return o.lastIndex = 0, o.test(e.DisplayName || e.HostName)
        })
    }, l.prototype.setListSearchValues = function(e) {
        var t = I.PCenterVendorSearchAriaLabel,
            o = I.PCenterVendorListSearch,
            n = I.PCenterVendorsListText,
            e = (e === _e.cookies && (t = I.PCenterCookieSearchAriaLabel, o = I.PCenterCookieListSearch, n = I.PCenterCookiesListText), L.cookieListType !== ye.HostAndGenVen && L.cookieListType !== ye.Host || !L.showTrackingTech || (n = I.AdditionalTechnologiesConfig.PCTrackingTechTitle), document.querySelector("#onetrust-pc-sdk " + k.P_Vendor_Title).innerText = n, T("#onetrust-pc-sdk " + k.P_Vendor_Search_Input));
        e.el[0].placeholder = o, e.attr("aria-label", t)
    }, l.prototype.initHostData = function(e) {
        var t = e.searchString,
            o = e.cookiesList,
            e = e.addTechData,
            n = (L.optanonHostList = o, !1),
            r = (this.setBackBtnTxt(), T(k.P_Vendor_List + " #select-all-text-container p").html(I.PCenterAllowAllConsentText), w.getHostParentContainer()),
            i = o && 0 === o.length,
            s = (L.showTrackingTech && (i = 0 === e.LocalStorages.length && 0 === e.SessionStorages.length && (0 === e.Cookies.length || 0 === e.Cookies[0].Cookies.length)), L.cookieListType === ye.Host);
        this.showEmptyResults(i, t, s), this.setHostListSearchValues(), T("#filter-btn-handler").el[0].setAttribute(this.ARIA_LABEL_ATTRIBUTE, I.PCenterCookieListFilterAria);
        T("#filter-btn-handler title").html(I.PCenterCookieListFilterAria), m.isV2Template && T("#ot-sel-blk span:first-child").html(I.PCenterAllowAllConsentText || I.ConsentText);
        for (var a = document.createDocumentFragment(), l = 0; l < o.length; l++) {
            var c = L.hosts.hostTemplate.cloneNode(!0),
                d = o[l].DisplayName || o[l].HostName;
            this.createHostAccordions(d, c, l), n = this.createHostCheckboxes(d, o, l, c, n), this.populateHostDataIntoDOMElements(c, o, d, l, a)
        }
        w.setCookiesInsideHostContainer(r, a, e);
        i = 1 === o.length && o[0].HostName === I.PCFirstPartyCookieListText;
        if (h.isOptOutEnabled() && !i) {
            P.setDisabledAttribute("#onetrust-pc-sdk #select-all-hosts-groups-handler", null, !n);
            for (var u = T("#onetrust-pc-sdk " + k.P_Host_Cntr + " .ot-host-tgl input").el, p = 0; p < u.length; p++) u[p].addEventListener("click", this.hostsListEvent);
            T("#onetrust-pc-sdk " + k.P_Select_Cntr).removeClass("ot-hide"), this.hostsListEvent()
        } else T("#onetrust-pc-sdk " + k.P_Select_Cntr).addClass("ot-hide")
    }, l.prototype.setCookiesInsideHostContainer = function(e, t, o) {
        var n, r;
        L.showTrackingTech && o ? 0 < (o = w.getAdditionalTechnologiesHtml(o)).children.length && ((n = o.querySelector("." + this.TECH_COOKIES_SELECTOR + " " + this.ACC_TXT)) && ((r = e.querySelector("ul" + k.P_Host_Cntr)).appendChild(t), n.appendChild(r)), e.appendChild(o)) : e.appendChild(t)
    }, l.prototype.getHostParentContainer = function() {
        var e = null;
        return L.showTrackingTech ? (e = document.querySelector("#onetrust-pc-sdk " + k.P_Vendor_Content + " .ot-sdk-column"), w.removeTrackingTechAccorions()) : (e = document.querySelector("#onetrust-pc-sdk " + k.P_Vendor_Content + " ul" + k.P_Host_Cntr)).innerHTML = v.getInnerHtmlContent(""), e
    }, l.prototype.removeTrackingTechAccorions = function() {
        var e = document.querySelector("#onetrust-pc-sdk " + k.P_Vendor_Content + " .ot-sdk-column"),
            t = e.querySelector("." + this.TECH_COOKIES_SELECTOR + " ul" + k.P_Host_Cntr);
        if (t ? (t.innerHTML = v.getInnerHtmlContent(""), e.appendChild(t)) : (t = e.querySelector("ul" + k.P_Host_Cntr)).innerHTML = v.getInnerHtmlContent(""), e)
            for (var o = e.querySelectorAll(".ot-add-tech"), n = o.length - 1; 0 <= n; n--) {
                var r = o.item(n);
                e.removeChild(r)
            }
    }, l.prototype.setHostListSearchValues = function() {
        var e = A.pcName;
        I.GeneralVendorsEnabled && (m.isV2Template || e !== it) && this.setListSearchValues(_e.vendors), I.GeneralVendorsEnabled || !m.isV2Template && e === it || this.setListSearchValues(_e.cookies)
    }, l.prototype.createHostAccordions = function(e, t, o) {
        var n = t.querySelector("." + k.P_Host_Bx),
            e = (n && P.setHtmlAttributes(n, {
                id: "host-" + o,
                name: "host-" + o,
                "aria-label": e + " " + I.PCViewCookiesText,
                "aria-controls": "ot-host-acc-txt-" + o
            }), t.querySelector(k.P_Acc_Txt));
        e && P.setHtmlAttributes(e, {
            id: "ot-host-acc-txt-" + o,
            role: "region",
            "aria-labelledby": n.id
        })
    }, l.prototype.createHostCheckboxes = function(e, t, o, n, r) {
        var i = h.isOptOutEnabled(),
            s = m.isV2Template,
            a = A.pcName;
        return !i || t[o].isFirstParty ? (i = n.querySelector(".ot-host-tgl")) && i.parentElement.removeChild(i) : (i = void 0, s ? ((i = _.chkboxEl.cloneNode(!0)).classList.add("ot-host-tgl"), i.querySelector("input").classList.add("host-checkbox-handler"), a === it ? n.querySelector(k.P_Host_Hdr).insertAdjacentElement("beforebegin", i) : n.querySelector(k.P_Tgl_Cntr).insertAdjacentElement("beforeend", i)) : i = n.querySelector(".ot-host-tgl"), P.setHtmlAttributes(i.querySelector("input"), {
            id: "ot-host-chkbox-" + o,
            "aria-label": e,
            hostId: t[o].HostId,
            ckType: t[o].Type
        }), i.querySelector("label").setAttribute("for", "ot-host-chkbox-" + o), (t[o].Type === he.GenVendor ? L.genVendorsConsent[t[o].HostId] : -1 !== L.hostsConsent.indexOf(t[o].HostId + ":1")) ? (P.setCheckedAttribute(null, i.querySelector("input"), !0), t[o].isActive ? P.setDisabledAttribute(null, i.querySelector("input"), !0) : r = r || !0) : (r = !0, P.setCheckedAttribute(null, i.querySelector("input"), !1)), i.querySelector(k.P_Label_Txt).innerText = e), r
    }, l.prototype.populateHostDataIntoDOMElements = function(t, o, e, n, r) {
        var i, s = this,
            a = m.isV2Template,
            l = A.pcName,
            l = (I.PCAccordionStyle === ce.PlusMinus ? t.querySelector(k.P_Acc_Header).insertAdjacentElement("afterbegin", _.plusMinusEl.cloneNode(!0)) : a && (i = _.arrowEl.cloneNode(!0), l === it ? t.querySelector(k.P_Host_View_Cookies).insertAdjacentElement("afterend", i) : t.querySelector(k.P_Tgl_Cntr).insertAdjacentElement("beforeend", i)), I.AddLinksToCookiepedia && !o[n].isFirstParty && (e = '\n                            <a  class="cookie-label"\n                                href="http://cookiepedia.co.uk/host/' + o[n].HostName + '"\n                                rel="noopener"\n                                target="_blank"\n                            >\n                                ' + e + '&nbsp;<span class="ot-scrn-rdr">' + I.NewWinTxt + "</span>\n                            </a>\n                        "), t.querySelector(k.P_Host_Title).innerHTML = v.getInnerHtmlContent(e), t.querySelector(k.P_Host_Desc).innerHTML = v.getInnerHtmlContent(o[n].Description), o[n].PrivacyPolicy && I.pcShowCookieHost && t.querySelector(k.P_Host_Desc).insertAdjacentHTML("afterend", v.getInnerHtmlContent('<a href="' + o[n].PrivacyPolicy + '" rel="noopener" target="_blank">' + (a ? I.PCGVenPolicyTxt : I.PCCookiePolicyText) + '&nbsp;<span class="ot-scrn-rdr">' + I.NewWinTxt + "</span></a>")), t.querySelector(k.P_Host_View_Cookies));
        return !L.showGeneralVendors || o[n].Cookies && o[n].Cookies.length ? I.PCViewCookiesText && (l.innerHTML = v.getInnerHtmlContent(I.PCViewCookiesText)) : (P.removeChild(l), T(t).addClass("ot-hide-acc")), o[n].Description && I.pcShowCookieHost || (i = t.querySelector(k.P_Host_Desc)).parentElement.removeChild(i), T(t.querySelector(k.P_Host_Opt)).html(""), null != (a = o[n].Cookies) && a.forEach(function(e) {
            e = s.getCookieElement(e, o[n]);
            T(t.querySelector(k.P_Host_Opt)).append(e)
        }), r.append(t), e
    }, l.prototype.hostsListEvent = function() {
        var e = T("#onetrust-pc-sdk " + k.P_Host_Cntr + " .ot-host-tgl input").el,
            t = T("#onetrust-pc-sdk #" + k.P_Sel_All_Host_El).el[0],
            o = T("#onetrust-pc-sdk #select-all-hosts-groups-handler").el[0],
            n = T("#onetrust-pc-sdk " + k.P_Cnsnt_Header).el[0];
        w.handleSelectAllChboxSelection(e, o, t), o && n && o.setAttribute(this.ARIA_LABEL_ATTRIBUTE, n.textContent + " " + I.PCenterSelectAllVendorsText)
    }, l.prototype.loadHostList = function(e, t) {
        var o = {},
            n = [],
            n = L.showTrackingTech ? (o = w.getAdditionalTechnologiesDataFromGroup(t), (L.currentTrackingTech = o).Cookies) : w.getCombinedCookieList(t);
        L.currentGlobalFilteredList = n, this.initHostData({
            searchString: e,
            cookiesList: n,
            addTechData: o
        })
    }, l.prototype.getCombinedCookieList = function(e) {
        var t, o = [],
            n = [];
        return L.cookieListType !== ye.GenVen && (n = (t = w.getFirstsAndThirdCookisFromGroups(e)).firstPartyCookiesList, o = t.thirdPartyCookiesList, n.length) && o.unshift({
            HostName: I.PCFirstPartyCookieListText,
            DisplayName: I.PCFirstPartyCookieListText,
            HostId: this.FIRST_PARTY_COOKIES_GROUP_NAME,
            isFirstParty: !0,
            Cookies: n,
            Description: ""
        }), L.showGeneralVendors ? (t = this.getFilteredGenVendorsList(e), U(o, this.mapGenVendorListToHostFormat(t))) : o
    }, l.prototype.mapGenVendorListToHostFormat = function(e) {
        return e.map(function(e) {
            return {
                Cookies: e.Cookies,
                DisplayName: e.Name,
                HostName: e.Name,
                HostId: e.VendorCustomId,
                Description: e.Description,
                Type: he.GenVendor,
                PrivacyPolicy: e.PrivacyPolicyUrl,
                isActive: -1 < L.alwaysActiveGenVendors.indexOf(e.VendorCustomId)
            }
        })
    }, l.prototype.mapGenVendorToHostFormat = function(e) {
        return {
            Cookies: e.Cookies,
            DisplayName: e.Name,
            HostName: e.Name,
            HostId: e.VendorCustomId,
            Description: e.Description,
            Type: he.GenVendor
        }
    }, l.prototype.getFilteredGenVendorsList = function(t) {
        var e, o = [],
            n = [];
        return t.length ? (I.Groups.forEach(function(e) {
            U(e.SubGroups, [e]).forEach(function(e) {
                -1 !== t.indexOf(e.CustomGroupId) && e.GeneralVendorsIds && e.GeneralVendorsIds.forEach(function(e) {
                    o.push(e)
                })
            })
        }), e = I.GeneralVendors, o.length ? e.filter(function(e) {
            if (-1 < o.indexOf(e.VendorCustomId)) return e
        }) : n) : I.GeneralVendors
    }, l.prototype.initVendorsData = function(e, t) {
        var o = this,
            n = t,
            t = L.vendors.list;
        if (this.setBackBtnTxt(), T(k.P_Vendor_List + " #select-all-text-container p").html(I.PCenterAllowAllConsentText), w.setConsentLegIntAndHeaderText(), T("#onetrust-pc-sdk #filter-btn-handler").el[0].setAttribute(this.ARIA_LABEL_ATTRIBUTE, I.PCenterVendorListFilterAria), T("#onetrust-pc-sdk #filter-btn-handler title").html(I.PCenterVendorListFilterAria), this.hasIabVendors = 0 < n.length, this.showEmptyResults(!this.hasGoogleVendors && !this.hasIabVendors && !this.hasGenVendors, e, !1), w.hideOrShowVendorList(n), T("#onetrust-pc-sdk " + k.P_Vendor_Container + " ." + k.P_Ven_Bx).length !== t.length && this.attachVendorsToDOM(), n.length !== t.length) t.forEach(function(e) {
            var t = T(k.P_Vendor_Container + " #IAB" + e.vendorId).el[0].parentElement; - 1 === n.indexOf(e) ? d(t, "display: none;", !0) : d(t, o._displayNull, !0)
        });
        else
            for (var r = T(k.P_Vendor_Container + ' li[style^="display: none"]').el, i = 0; i < r.length; i++) d(r[i], this._displayNull, !0);
        !m.isV2Template && A.pcName === it || this.setListSearchValues(_e.vendors);
        e = document.querySelector("#vdr-lst-dsc");
        !e && I.PCenterVendorListDescText && ((e = document.createElement("p")).id = "vdr-lst-dsc", T(e).html(I.PCenterVendorListDescText), A.pcName !== it && A.pcName !== ot ? (t = document.querySelector("#onetrust-pc-sdk " + k.P_Vendor_Title_Elm)) && t.insertAdjacentElement("afterend", e) : (t = document.querySelector(k.P_Vendor_Content + " .ot-sdk-row")) && t.insertAdjacentElement("beforebegin", e)), T("#onetrust-pc-sdk " + k.P_Select_Cntr).removeClass("ot-hide"), this.vendorsListEvent(), A.legIntSettings.PAllowLI && this.vendorLegIntToggleEvent()
    }, l.prototype.setConsentLegIntAndHeaderText = function() {
        m.isV2Template && (T("#ot-sel-blk span:first-child").html(I.PCenterAllowAllConsentText || I.ConsentText), T("#ot-sel-blk span:last-child").html(I.LegitInterestText), T("#onetrust-pc-sdk " + k.P_Cnsnt_Header).html(I.PCenterAllowAllConsentText), A.legIntSettings.PAllowLI && !A.legIntSettings.PShowLegIntBtn && T("#onetrust-pc-sdk .ot-sel-all-hdr .ot-li-hdr").html(I.PCenterLegitInterestText), A.legIntSettings.PAllowLI && !A.legIntSettings.PShowLegIntBtn || d(T("#ot-sel-blk span:first-child").el[0], "max-width: 100%;", !0))
    }, l.prototype.hideOrShowVendorList = function(e) {
        0 === e.length ? T("#ot-lst-cnt .ot-acc-cntr").hide() : T("#ot-lst-cnt .ot-acc-cntr").show(), L.showTrackingTech && w.removeTrackingTechAccorions()
    }, l.prototype.updateVendorsDOMToggleStatus = function(e, t) {
        void 0 === t && (t = !1);
        for (var o = T(k.P_Vendor_Container + " " + k.P_Tgl_Cntr).el, n = 0; n < o.length; n++) {
            var r = o[n].querySelector("." + k.P_Ven_Ctgl + " input"),
                i = o[n].querySelector("." + k.P_Ven_Ltgl + " input");
            t ? r && P.setCheckedAttribute("", r, !1) : (r && P.setCheckedAttribute("", r, e), i && P.setCheckedAttribute("", i, e))
        }
        var s = T("#onetrust-pc-sdk #select-all-vendor-leg-handler").el[0],
            s = (s && (s.parentElement.classList.remove(this.LINE_THROUGH_CLASS), P.setCheckedAttribute("", s, !!t || e)), T("#onetrust-pc-sdk #select-all-vendor-groups-handler").el[0]);
        s && (s.parentElement.classList.remove(this.LINE_THROUGH_CLASS), P.setCheckedAttribute("", s, !t && e)), I.UseGoogleVendors && (t ? this.updateGoogleCheckbox(!1) : this.updateGoogleCheckbox(e)), L.showGeneralVendors && I.GenVenOptOut && this.updateGenVenCheckbox(e)
    }, l.prototype.updateGenVenCheckbox = function(e) {
        for (var t = T(k.P_Gven_List + " .ot-ven-gvctgl input").el, o = 0; o < t.length; o++) P.setCheckedAttribute("", t[o], e);
        var n = T("#onetrust-pc-sdk #ot-selall-gnven-handler").el[0];
        n && (n.parentElement.classList.remove(this.LINE_THROUGH_CLASS), P.setCheckedAttribute("", n, e))
    }, l.prototype.updateGoogleCheckbox = function(e) {
        for (var t = T("#ot-addtl-venlst .ot-tgl-cntr input").el, o = 0; o < t.length; o++) P.setCheckedAttribute("", t[o], e);
        var n = T("#onetrust-pc-sdk #ot-selall-adtlven-handler").el[0];
        n && (n.parentElement.classList.remove(this.LINE_THROUGH_CLASS), P.setCheckedAttribute("", n, e))
    }, l.prototype.updateVendorDisclosure = function(e, t) {
        var r, i, e = T(k.P_Vendor_Container + " #IAB" + e).el[0].parentElement;
        t && t.disclosures && (r = e.querySelector(k.P_Ven_Dets), (e = (i = e.querySelector(k.P_Ven_Disc).cloneNode(!0)).cloneNode(!0)).innerHTML = v.getInnerHtmlContent("<p><b>" + I.PCenterVendorListDisclosure + ": </b></p>"), r.insertAdjacentElement("beforeend", e), t.disclosures.forEach(function(e) {
            var t, o = i.cloneNode(!0),
                n = "<p>" + I.PCenterVendorListStorageIdentifier + " </p> <p>" + (e.name || e.identifier) + " </p>";
            e.type && (n += "<p>" + I.PCenterVendorListStorageType + " </p> <p>" + e.type + " </p>"), e.maxAgeSeconds && (t = P.calculateCookieLifespan(e.maxAgeSeconds), n += "<p>" + I.PCenterVendorListLifespan + " </p> <p>" + t + " </p>"), e.domain && (n += "<p>" + I.PCenterVendorListStorageDomain + " </p> <p>" + e.domain + " </p>"), e.purposes && (n += "<p>" + I.PCenterVendorListStoragePurposes + ' </p><div class="disc-pur-cont">', e.purposes.forEach(function(e) {
                e = null == (e = A.iabGroups.purposes[e]) ? void 0 : e.name;
                e && (n += ' <p class="disc-pur">' + e + " </p>")
            }), n += "</div>"), o.innerHTML = v.getInnerHtmlContent(n), r.insertAdjacentElement("beforeend", o)
        }), this.updateDomainsUsageInDisclosures(t, i, r))
    }, l.prototype.updateDomainsUsageInDisclosures = function(e, n, r) {
        var t;
        e.domains && e.domains.length && ((t = n.cloneNode(!0)).innerHTML = v.getInnerHtmlContent("<p><b>" + I.PCVLSDomainsUsed + ": </b></p>"), r.insertAdjacentElement("beforeend", t), e.domains.forEach(function(e) {
            var t, o = n.cloneNode(!0);
            e.domain && (t = "<p>" + I.PCenterVendorListStorageDomain + " </p> <p>" + e.domain + " </p>"), e.use && (t += "<p>" + I.PCVLSUse + " </p> <p>" + e.use + " </p>"), o.innerHTML = v.getInnerHtmlContent(t), r.insertAdjacentElement("beforeend", o)
        }))
    }, l.prototype.addDescriptionElement = function(e, t) {
        var o = document.createElement("p");
        o.innerHTML = v.getInnerHtmlContent(t || ""), e.parentNode.insertBefore(o, e)
    }, l.prototype.setVdrConsentTglOrChbox = function(e, t, o, n, r, i) {
        var s, a, l = L.vendorsSetting[e],
            t = t.cloneNode(!0);
        l.consent && (t.classList.add(k.P_Ven_Ctgl), l = -1 !== v.inArray(e + ":true", L.vendors.selectedVendors), s = t.querySelector("input"), m.isV2Template && (s.classList.add("vendor-checkbox-handler"), a = t.querySelector(this.LABEL_STATUS), I.PCShowConsentLabels ? a.innerHTML = v.getInnerHtmlContent(l ? I.PCActiveText : I.PCInactiveText) : P.removeChild(a)), P.setCheckedAttribute("", s, l), P.setHtmlAttributes(s, {
            id: k.P_Vendor_CheckBx + "-" + i,
            vendorid: e,
            "aria-label": o
        }), t.querySelector("label").setAttribute("for", k.P_Vendor_CheckBx + "-" + i), t.querySelector(k.P_Label_Txt).textContent = o, A.pcName === it ? I.PCTemplateUpgrade ? n.insertAdjacentElement("beforeend", t) : T(n).append(t) : n.insertBefore(t, r))
    }, l.prototype.setVndrLegIntTglTxt = function(e, t) {
        e = e.querySelector(this.LABEL_STATUS);
        I.PCShowConsentLabels ? e.innerHTML = v.getInnerHtmlContent(t ? I.PCActiveText : I.PCInactiveText) : P.removeChild(e)
    }, l.prototype.setVdrLegIntTglOrChbx = function(t, e, o, n, r, i, s) {
        var a, l = L.vendorsSetting[t],
            o = o.cloneNode(!0),
            c = null == (c = L.vendors.list.find(function(e) {
                return e.vendorId === t
            }).legIntPurposes) ? void 0 : c.length;
        l.legInt && !l.specialPurposesOnly && c && (c = -1 !== v.inArray(t + ":true", L.vendors.selectedLegIntVendors), A.legIntSettings.PShowLegIntBtn ? (a = p.generateLegIntButtonElements(c, t, !0), e.querySelector(k.P_Acc_Txt).insertAdjacentHTML("beforeend", a), (a = e.querySelector(".ot-remove-objection-handler")) && d(a, a.getAttribute("data-style"))) : (a = o.querySelector("input"), m.isV2Template && (a.classList.add("vendor-checkbox-handler"), this.setVndrLegIntTglTxt(o, c)), o.classList.add(k.P_Ven_Ltgl), a.classList.remove("vendor-checkbox-handler"), a.classList.add("vendor-leg-checkbox-handler"), P.setCheckedAttribute("", a, c), P.setHtmlAttributes(a, {
            id: k.P_Vendor_LegCheckBx + "-" + r,
            "leg-vendorid": t,
            "aria-label": n
        }), o.querySelector("label").setAttribute("for", k.P_Vendor_LegCheckBx + "-" + r), o.querySelector(k.P_Label_Txt).textContent = n, e.querySelector("." + k.P_Ven_Ctgl) && (i = e.querySelector("." + k.P_Ven_Ctgl)), A.pcName !== it || s.children.length ? s.insertBefore(o, i) : T(s).append(o), l.consent || A.pcName !== it || o.classList.add(k.P_Ven_Ltgl_Only)))
    }, l.prototype.setVndrSplPurSection = function(e, t) {
        var o = this,
            n = e.querySelector(".spl-purpose"),
            e = e.querySelector(".spl-purpose-grp"),
            r = e.cloneNode(!0);
        e.parentElement.removeChild(e), A.isIab2orv2Template && t.specialPurposes.forEach(function(e) {
            T(r.querySelector(o.CONSENT_CATEGORY)).text(e.purposeName), n.insertAdjacentHTML("afterend", v.getInnerHtmlContent(r.outerHTML))
        }), 0 === t.specialPurposes.length ? n.parentElement.removeChild(n) : T(n.querySelector("p")).text(I.SpecialPurposesText)
    }, l.prototype.setVndrFtSection = function(e, t) {
        var o = this,
            n = e.querySelector(".vendor-feature"),
            e = e.querySelector(".vendor-feature-group"),
            r = e.cloneNode(!0);
        e.parentElement.removeChild(e), T(n.querySelector("p")).text(I.FeaturesText), t.features.forEach(function(e) {
            T(r.querySelector(o.CONSENT_CATEGORY)).text(e.featureName), n.insertAdjacentHTML("afterend", v.getInnerHtmlContent(r.outerHTML))
        }), 0 === t.features.length && n.parentElement.removeChild(n)
    }, l.prototype.setVndrSplFtSection = function(e, t) {
        var o = this,
            n = e.querySelector(".vendor-spl-feature"),
            e = e.querySelector(".vendor-spl-feature-grp"),
            r = e.cloneNode(!0);
        n.parentElement.removeChild(e), A.isIab2orv2Template && t.specialFeatures.forEach(function(e) {
            T(r.querySelector(o.CONSENT_CATEGORY)).text(e.featureName), n.insertAdjacentHTML("afterend", v.getInnerHtmlContent(r.outerHTML))
        }), 0 === t.specialFeatures.length ? n.parentElement.removeChild(n) : T(n.querySelector("p")).text(I.SpecialFeaturesText)
    }, l.prototype.setVndrAccTxt = function(e, t) {
        t = t.querySelector(k.P_Acc_Txt);
        t && P.setHtmlAttributes(t, {
            id: "IAB-ACC-TXT" + e,
            "aria-labelledby": "IAB-ACC-TXT" + e,
            role: "region"
        })
    }, l.prototype.setVndrDisclosure = function(e, t, o) {
        t.deviceStorageDisclosureUrl && (P.setHtmlAttributes(o, {
            "disc-vid": e
        }), L.discVendors[e] = {
            isFetched: !1,
            disclosureUrl: t.deviceStorageDisclosureUrl
        })
    }, l.prototype.setVndrListSelectAllChkBoxs = function() {
        var e = T("#onetrust-pc-sdk " + k.P_Sel_All_Vendor_Consent_Handler).el[0],
            e = (e && e.setAttribute(this.ARIA_LABEL_ATTRIBUTE, I.PCenterSelectAllVendorsText + " " + I.LegitInterestText), T("#onetrust-pc-sdk " + k.P_Sel_All_Vendor_Leg_Handler).el[0]);
        e && e.setAttribute(this.ARIA_LABEL_ATTRIBUTE, I.PCenterSelectAllVendorsText + " " + I.ConsentText)
    }, l.prototype.setVndrConsentPurposes = function(e, t, o) {
        var n = this,
            r = e.querySelector(".vendor-consent-group"),
            i = e.querySelector(".vendor-option-purpose"),
            s = r.cloneNode(!0),
            a = e.querySelector(".legitimate-interest"),
            l = !1;
        return r.parentElement.removeChild(r), t.consent && (T(i.querySelector("p")).text(I.ConsentPurposesText), o.purposes.forEach(function(e) {
            T(s.querySelector(n.CONSENT_CATEGORY)).text(e.purposeName);
            e = s.querySelector(".consent-status");
            e && s.removeChild(e), a.insertAdjacentHTML("beforebegin", v.getInnerHtmlContent(s.outerHTML)), l = !0
        })), t.consent || i.parentElement.removeChild(i), l
    }, l.prototype.getVndrTglCntr = function(e) {
        return m.isV2Template ? _.chkboxEl.cloneNode(!0) : e.querySelector(".ot-checkbox")
    }, l.prototype.attachVendorsToDOM = function() {
        for (var u, p, C = this, g = L.vendors.list, h = L.vendors.vendorTemplate.cloneNode(!0), y = (L.discVendors = {}, m.isV2Template && (u = h.querySelector(".ot-ven-pur").cloneNode(!0), p = h.querySelector(k.P_Ven_Disc).cloneNode(!0), T(h.querySelector(".ot-ven-dets")).html("")), document.createDocumentFragment()), f = this, e = 0; e < g.length; e++)(e => {
            var t, o, n = h.cloneNode(!0),
                r = g[e].vendorId,
                i = g[e].vendorName,
                s = n.querySelector("." + k.P_Ven_Bx),
                a = L.vendorsSetting[r],
                l = (P.setHtmlAttributes(s, {
                    id: "IAB" + r,
                    name: "IAB" + r,
                    "aria-controls": "IAB-ACC-TXT" + r,
                    "aria-label": i
                }), s.nextElementSibling.setAttribute("for", "IAB" + r), n.querySelector(k.P_Ven_Name).innerText = i, f.updateIABLinksDOM(g[e], n), f.getVndrTglCntr(n)),
                c = n.querySelector(k.P_Tgl_Cntr),
                d = (m.isV2Template || l.parentElement.removeChild(l), n.querySelector(k.P_Arrw_Cntr));
            f.setVdrConsentTglOrChbox(r, l, i, c, d, e), f.setVdrLegIntTglOrChbx(r, n, l, i, e, d, c), m.isV2Template && (c.insertAdjacentElement("beforeend", _.arrowEl.cloneNode(!0)), I.PCAccordionStyle !== ce.Caret) && n.querySelector(".ot-ven-hdr").insertAdjacentElement("beforebegin", _.plusMinusEl.cloneNode(!0)), f.setVndrAccTxt(r, n), f.setVndrDisclosure(r, g[e], s), m.isV2Template ? f.populateVendorDetailsHtml(n, u, g[e], p) : (t = n.querySelector(".legitimate-interest"), l = n.querySelector(".legitimate-interest-group"), o = l.cloneNode(!0), p = n.querySelector(k.P_Ven_Disc), i = n.querySelector(k.P_Ven_Dets), d = p.cloneNode(!0), p.parentElement.removeChild(p), f.attachVendorDisclosure(d, g[e]), i.insertAdjacentElement("afterbegin", d), f.setVndrConsentPurposes(n, a, g[e]), c = o.querySelector(".vendor-opt-out-handler"), A.isIab2orv2Template && c.parentElement.removeChild(c), l.parentElement.removeChild(l), a.legInt && (T(t.querySelector("p")).text(I.LegitimateInterestPurposesText), A.legIntSettings.PAllowLI) && A.isIab2orv2Template && g[e].legIntPurposes.forEach(function(e) {
                T(o.querySelector(C.CONSENT_CATEGORY)).text(e.purposeName), t.insertAdjacentHTML("afterend", v.getInnerHtmlContent(o.outerHTML))
            }), a.legInt || t.parentElement.removeChild(t), f.setVndrSplPurSection(n, g[e]), f.setVndrFtSection(n, g[e]), f.setVndrSplFtSection(n, g[e]), (r = s.parentElement.querySelector(".vendor-purposes p")).parentElement.removeChild(r)), y.appendChild(n), f.setVndrListSelectAllChkBoxs()
        })(e);
        document.querySelector("#onetrust-pc-sdk " + k.P_Vendor_Container).append(y)
    }, l.prototype.updateIABLinksDOM = function(e, t) {
        var o = e.vendorName,
            n = t.querySelector(k.P_Ven_Link),
            t = t.querySelector(k.P_Ven_Leg_Claim),
            r = A.isTcfV2Template ? e.vendorPrivacyUrl : e.policyUrl;
        P.setHtmlAttributes(n, {
            href: r,
            rel: "noopener",
            target: "_blank"
        }), n.innerHTML = v.getInnerHtmlContent(I.PCenterViewPrivacyPolicyText + "&nbsp;<span class='ot-scrn-rdr'>" + o + " " + I.NewWinTxt + "</span>"), n.insertAdjacentHTML("afterend", v.getInnerHtmlContent("<span class='ot-ext-lnk'></span>")), A.isTcfV2Template && e.legIntClaim && 0 < I.PCIABVendorLegIntClaimText.trim().length ? (P.setHtmlAttributes(t, {
            href: e.legIntClaim,
            rel: "noopener",
            target: "_blank"
        }), t.innerHTML = v.getInnerHtmlContent(I.PCIABVendorLegIntClaimText + "&nbsp;<span class='ot-scrn-rdr'>" + o + " " + I.NewWinTxt + "</span>"), t.insertAdjacentHTML("afterend", v.getInnerHtmlContent("<span class='ot-ext-lnk'></span>"))) : t.remove()
    }, l.prototype.populateVendorDetailsHtml = function(e, t, o, n) {
        var r, i, s, a, l, c, d, u, e = e.querySelector(".ot-ven-dets"),
            p = L.vendorsSetting[o.vendorId],
            n = n.cloneNode(!0);
        this.attachVendorDisclosure(n, o), e.insertAdjacentElement("beforeEnd", n), A.isTcfV2Template && null != (n = o.dataDeclaration) && n.length && (n = t.cloneNode(!0), r = "<h5>" + I.PCVListDataDeclarationText + "</h5>", r += "<ul>", o.dataDeclaration.forEach(function(e) {
            r += "<li><p>" + e.Name + "</p></li>"
        }), r += "</ul>", n.innerHTML = v.getInnerHtmlContent(r), e.insertAdjacentElement("beforeEnd", n)), A.isTcfV2Template && null !== (null == (n = o.dataRetention) ? void 0 : n.stdRetention) && void 0 !== (null == (n = o.dataRetention) ? void 0 : n.stdRetention) && (n = t.cloneNode(!0), c = 1 === o.dataRetention.stdRetention ? I.PCenterVendorListLifespanDay : I.PCenterVendorListLifespanDays, s = "<h5>" + I.PCVListDataRetentionText + "</h5>", s += "<li><p>" + I.PCVListStdRetentionText + " (" + o.dataRetention.stdRetention + " " + c + ")</p></li>", n.innerHTML = v.getInnerHtmlContent(s), e.insertAdjacentElement("beforeEnd", n)), p.consent && (c = t.cloneNode(!0), i = "<h5>" + I.ConsentPurposesText + "</h5>", i += "<ul>", o.purposes.forEach(function(e) {
            var t;
            i += "<li><p>" + e.purposeName, A.isTcfV2Template && null != (t = o.dataRetention) && t.purposes && o.dataRetention.purposes[e.purposeId] && (e = 1 === (t = o.dataRetention.purposes[e.purposeId].retention) ? I.PCenterVendorListLifespanDay : I.PCenterVendorListLifespanDays, i += " (" + t + " " + e + ")"), i += "</p></li>"
        }), i += "</ul>", c.innerHTML = v.getInnerHtmlContent(i), e.insertAdjacentElement("beforeEnd", c)), p.legInt && o.legIntPurposes.length && (s = t.cloneNode(!0), a = "<h5>" + I.LegitimateInterestPurposesText + "</h5>", a += "<ul>", o.legIntPurposes.forEach(function(e) {
            a += "<li><p>" + e.purposeName + "</p></li>"
        }), a += "</ul>", s.innerHTML = v.getInnerHtmlContent(a), e.insertAdjacentElement("beforeEnd", s)), A.isIab2orv2Template && o.specialPurposes.length && (n = t.cloneNode(!0), l = "<h5>" + I.SpecialPurposesText + "</h5>", l += "<ul>", o.specialPurposes.forEach(function(e) {
            var t;
            l += "<li><p>" + e.purposeName, A.isTcfV2Template && null != (t = o.dataRetention) && t.specialPurposes && o.dataRetention.specialPurposes[e.purposeId] && (e = 1 === (t = o.dataRetention.specialPurposes[e.purposeId].retention) ? I.PCenterVendorListLifespanDay : I.PCenterVendorListLifespanDays, l += " (" + t + " " + e + ")"), l += "</p></li>"
        }), l += "</ul>", n.innerHTML = v.getInnerHtmlContent(l), e.insertAdjacentElement("beforeEnd", n)), o.features.length && (c = t.cloneNode(!0), d = "<h5>" + I.FeaturesText + "</h5>", d += "<ul>", o.features.forEach(function(e) {
            d += "<li><p>" + e.featureName + "</p></li>"
        }), d += "</ul>", c.innerHTML = v.getInnerHtmlContent(d), e.insertAdjacentElement("beforeEnd", c)), A.isIab2orv2Template && o.specialFeatures.length && (p = t.cloneNode(!0), u = "<h5>" + I.SpecialFeaturesText + "</h5>", u += "<ul>", o.specialFeatures.forEach(function(e) {
            u += "<li><p>" + e.featureName + "</p></li>"
        }), u += "</ul>", p.innerHTML = v.getInnerHtmlContent(u), e.insertAdjacentElement("beforeEnd", p))
    }, l.prototype.InitializeVendorList = function() {
        var e;
        L.vendors.list = L.iabData ? L.iabData.vendors : null, L.vendors.vendorTemplate = T(k.P_Vendor_Container + " li").el[0].cloneNode(!0), T("#onetrust-pc-sdk " + k.P_Vendor_Container).html(""), m.isV2Template || A.pcName !== it || (e = L.vendors.vendorTemplate.querySelectorAll(k.P_Acc_Header), (e = A.legIntSettings.PAllowLI && A.isIab2orv2Template ? e[0] : e[1]).parentElement.removeChild(e))
    }, l.prototype.cancelVendorFilter = function() {
        for (var e = T("#onetrust-pc-sdk .category-filter-handler").el, t = 0; t < e.length; t++) {
            var o = e[t].getAttribute("data-purposeid"),
                o = 0 <= L.filterByIABCategories.indexOf(o);
            P.setCheckedAttribute(null, e[t], o)
        }
    }, l.prototype.attachVendorDisclosure = function(e, t) {
        var o = "";
        t.cookieMaxAge && (o += "<h5>" + I.PCenterVendorListLifespan + " :</h5><span> " + t.cookieMaxAge + "</span>"), t.usesNonCookieAccess && (o += "<p>" + I.PCenterVendorListNonCookieUsage + "</p>"), e.innerHTML = v.getInnerHtmlContent(o)
    }, l.prototype.updateVendorFilterList = function() {
        for (var e = T("#onetrust-pc-sdk .category-filter-handler").el, t = 0; t < e.length; t++) {
            var o, n = e[t].getAttribute("data-purposeid");
            e[t].checked && L.filterByIABCategories.indexOf(n) < 0 ? L.filterByIABCategories.push(n) : !e[t].checked && -1 < L.filterByIABCategories.indexOf(n) && (o = L.filterByIABCategories, L.filterByIABCategories.splice(o.indexOf(n), 1))
        }
        return L.filterByIABCategories
    }, l.prototype.saveVendorStatus = function(e) {
        var t = L.vendors,
            o = L.oneTrustIABConsent,
            e = ((e = void 0 === e ? !1 : e) || (o.purpose = t.selectedPurpose.slice(), o.specialFeatures = t.selectedSpecialFeatures.slice()), o.legimateInterest = t.selectedLegInt.slice(), o.vendors = t.selectedVendors.slice(), o.legIntVendors = t.selectedLegIntVendors.slice(), L.addtlVendors);
        e.vendorConsent = Object.keys(e.vendorSelected)
    }, l.prototype.updateIabVariableReference = function() {
        var e = L.oneTrustIABConsent,
            t = L.vendors,
            o = (t.selectedPurpose = e.purpose.slice(), t.selectedLegInt = e.legimateInterest.slice(), t.selectedVendors = e.vendors.slice(), t.selectedLegIntVendors = e.legIntVendors.slice(), t.selectedSpecialFeatures = e.specialFeatures.slice(), L.addtlVendors);
        o.vendorSelected = {}, o.vendorConsent.forEach(function(e) {
            o.vendorSelected[e] = !0
        })
    }, l.prototype.allowAllhandler = function() {
        N.initializeIABData(!0, !1)
    }, l.prototype.rejectAllHandler = function(e) {
        N.initializeIABData(!1, !0, e = void 0 === e ? !1 : e)
    }, l.prototype.populateAddtlVendors = function(e) {
        var t, o, n, r, i, s, a, l = (I.PCAccordionStyle === ce.Caret ? _.arrowEl : _.plusMinusEl).cloneNode(!0),
            c = document.querySelector("#onetrust-pc-sdk .ot-sel-all-chkbox"),
            d = c.cloneNode(!0),
            c = (P.removeChild(d.querySelector("#ot-selall-hostcntr")), P.removeChild(c.querySelector("#ot-selall-vencntr")), P.removeChild(c.querySelector("#ot-selall-licntr")), _.accordionEl.cloneNode(!0)),
            c = (c.classList.add("ot-iab-acc"), c.querySelector(".ot-acc-hdr").insertAdjacentElement("beforeEnd", l.cloneNode(!0)), c.querySelector(".ot-acc-hdr").insertAdjacentHTML("beforeEnd", v.getInnerHtmlContent("<div class='ot-vensec-title'>" + I.PCIABVendorsText + "</div>")), c.querySelector(".ot-acc-hdr").insertAdjacentElement("beforeEnd", d), c.querySelector(this.ACC_TXT).insertAdjacentElement("beforeEnd", T("#ot-ven-lst").el[0]), T("#ot-lst-cnt .ot-sdk-column").append(c), c.querySelector("button").setAttribute(this.ARIA_LABEL_ATTRIBUTE, I.PCIABVendorsText), this.iabAccInit = !0, d.cloneNode(!0)),
            u = (P.removeChild(c.querySelector("#ot-selall-licntr")), c.querySelector(".ot-chkbox").id = "ot-selall-adtlvencntr", c.querySelector("input").id = "ot-selall-adtlven-handler", c.querySelector("label").setAttribute("for", "ot-selall-adtlven-handler"), _.accordionEl.cloneNode(!0)),
            p = (u.querySelector(".ot-acc-hdr").insertAdjacentElement("beforeEnd", l.cloneNode(!0)), u.querySelector(".ot-acc-hdr").insertAdjacentHTML("beforeEnd", "<div class='ot-vensec-title'>" + I.PCGoogleVendorsText + "</div>"), u.querySelector(".ot-acc-hdr").insertAdjacentElement("beforeEnd", c), u.querySelector(this.ACC_TXT).insertAdjacentHTML("beforeEnd", v.getInnerHtmlContent("<ul id='ot-addtl-venlst'></ul>")), u.classList.add("ot-adtlv-acc"), u.querySelector("button").setAttribute(this.ARIA_LABEL_ATTRIBUTE, I.PCGoogleVendorsText), L.vendors.vendorTemplate.cloneNode(!0));
        for (t in p.querySelector("button").classList.remove("ot-ven-box"), p.querySelector("button").classList.add("ot-addtl-venbox"), P.removeChild(p.querySelector(this.ACC_TXT)), e) e[t] && (o = p.cloneNode(!0), n = e[t].name, o.querySelector(k.P_Ven_Name).innerText = n, r = o.querySelector("button"), P.setHtmlAttributes(r, {
            id: "Adtl-IAB" + t
        }), P.setHtmlAttributes(o.querySelector(k.P_Ven_Link), {
            href: e[t].policyUrl,
            rel: "noopener",
            target: "_blank"
        }), o.querySelector(k.P_Ven_Link).innerHTML = v.getInnerHtmlContent(I.PCenterViewPrivacyPolicyText + "&nbsp;<span class='ot-scrn-rdr'>" + n + " " + I.NewWinTxt + "</span>"), (r = _.chkboxEl.cloneNode(!0)).classList.remove("ot-ven-ctgl"), r.classList.add("ot-ven-adtlctgl"), i = Boolean(L.addtlVendors.vendorSelected[t]), (s = r.querySelector("input")).classList.add("ot-addtlven-chkbox-handler"), a = r.querySelector(this.LABEL_STATUS), I.PCShowConsentLabels ? a.innerHTML = v.getInnerHtmlContent(i ? I.PCActiveText : I.PCInactiveText) : P.removeChild(a), P.setCheckedAttribute("", s, i), P.setHtmlAttributes(s, {
            id: "ot-addtlven-chkbox-" + t,
            "addtl-vid": t,
            "aria-label": n
        }), r.querySelector("label").setAttribute("for", "ot-addtlven-chkbox-" + t), r.querySelector(k.P_Label_Txt).textContent = n, a = o.querySelector(k.P_Tgl_Cntr), T(a).append(r), a.insertAdjacentElement("beforeend", _.arrowEl.cloneNode(!0)), I.PCAccordionStyle !== ce.Caret && o.querySelector(".ot-ven-hdr").insertAdjacentElement("beforebegin", _.plusMinusEl.cloneNode(!0)), this.checkIfLegLinkRemove(o), T(u.querySelector("#ot-addtl-venlst")).append(o));
        T("#ot-lst-cnt .ot-sdk-column").append(u), T("#onetrust-pc-sdk").on("click", "#ot-pc-lst .ot-acc-cntr > input", function(e) {
            P.setCheckedAttribute(null, e.target, e.target.checked)
        }), this.showConsentHeader()
    }, l.prototype.populateGeneralVendors = function() {
        var e, t, o, c, d, u, p = this,
            n = I.GeneralVendors,
            r = document.querySelector(".ot-gv-acc"),
            C = !!r;
        n.length ? (this.hasGenVendors = !0, r && T(r).show(), e = (I.PCAccordionStyle === ce.Caret ? _.arrowEl : _.plusMinusEl).cloneNode(!0), this.iabAccInit || this.addIabAccordion(), (t = document.createElement("div")).setAttribute("class", "ot-sel-all-chkbox"), o = _.chkboxEl.cloneNode(!0), o.id = "ot-selall-gnvencntr", o.querySelector("input").id = "ot-selall-gnven-handler", o.querySelector("label").setAttribute("for", "ot-selall-gnven-handler"), T(t).append(o), c = _.accordionEl.cloneNode(!0), c.querySelector(".ot-acc-hdr").insertAdjacentElement("beforeEnd", e.cloneNode(!0)), c.querySelector(".ot-acc-hdr").insertAdjacentHTML("beforeEnd", "<div class='ot-vensec-title'>" + I.PCenterGeneralVendorsText + "</div>"), I.GenVenOptOut && c.querySelector(".ot-acc-hdr").insertAdjacentElement("beforeEnd", t), c.querySelector(this.ACC_TXT).insertAdjacentHTML("beforeEnd", v.getInnerHtmlContent("<ul id='ot-gn-venlst'></ul>")), c.classList.add("ot-gv-acc"), c.querySelector("button").setAttribute(this.ARIA_LABEL_ATTRIBUTE, I.PCenterGeneralVendorsText), d = L.vendors.vendorTemplate.cloneNode(!0), d.querySelector("button").classList.remove("ot-ven-box"), d.querySelector("button").classList.add("ot-gv-venbox"), T(d.querySelector(this.ACC_TXT)).html('<ul class="ot-host-opt"></ul>'), C && T("" + k.P_Gven_List).html(""), u = !0, n.forEach(function(e) {
            var t, o, n = p.mapGenVendorToHostFormat(e),
                r = d.cloneNode(!0),
                i = e.VendorCustomId,
                s = e.Name,
                a = r.querySelector(k.P_Ven_Link),
                l = (r.querySelector(k.P_Ven_Name).innerText = s, r.querySelector("button"));
            P.setHtmlAttributes(l, {
                id: "Gn-" + i
            }), e.PrivacyPolicyUrl ? (P.setHtmlAttributes(a, {
                href: e.PrivacyPolicyUrl,
                rel: "noopener",
                target: "_blank"
            }), a.innerHTML = v.getInnerHtmlContent(I.PCGVenPolicyTxt + "&nbsp;<span class='ot-scrn-rdr'>" + s + " " + I.NewWinTxt + "</span>")) : a.classList.add("ot-hide"), p.addDescriptionElement(a, e.Description), I.GenVenOptOut && ((l = _.chkboxEl.cloneNode(!0)).classList.remove("ot-ven-ctgl"), l.classList.add("ot-ven-gvctgl"), a = Boolean(L.genVendorsConsent[i]), (t = l.querySelector("input")).classList.add("ot-gnven-chkbox-handler"), o = l.querySelector(p.LABEL_STATUS), I.PCShowConsentLabels ? o.innerHTML = v.getInnerHtmlContent(a ? I.PCActiveText : I.PCInactiveText) : P.removeChild(o), P.setCheckedAttribute("", t, a), P.setHtmlAttributes(t, {
                id: "ot-gnven-chkbox-" + i,
                "gn-vid": i,
                "aria-label": s
            }), fo.isGenVenPartOfAlwaysActiveGroup(i) ? P.setDisabledAttribute(null, t, !0) : u = !1, l.querySelector("label").setAttribute("for", "ot-gnven-chkbox-" + i), l.querySelector(k.P_Label_Txt).textContent = s, o = r.querySelector(k.P_Tgl_Cntr), T(o).append(l), o.insertAdjacentElement("beforeend", _.arrowEl.cloneNode(!0))), I.PCAccordionStyle !== ce.Caret && r.querySelector(".ot-ven-hdr").insertAdjacentElement("beforebegin", _.plusMinusEl.cloneNode(!0)), e.Cookies.length || T(r).addClass("ot-hide-acc"), e.Cookies.forEach(function(e) {
                e = p.getCookieElement(e, n);
                T(r.querySelector(".ot-host-opt")).append(e)
            }), p.checkIfLegLinkRemove(r), T(C ? "" + k.P_Gven_List : c.querySelector("" + k.P_Gven_List)).append(r)
        }), C || T("#ot-lst-cnt .ot-sdk-column").append(c), T("#onetrust-pc-sdk").on("click", "#ot-pc-lst .ot-acc-cntr > input", function(e) {
            P.setCheckedAttribute(null, e.target, e.target.checked)
        }), this.showConsentHeader(), u && P.setDisabledAttribute("#ot-selall-gnven-handler", null, !0)) : (this.hasGenVendors = !1, r && T(r).hide())
    }, l.prototype.addIabAccordion = function() {
        var e = (I.PCAccordionStyle === ce.Caret ? _.arrowEl : _.plusMinusEl).cloneNode(!0),
            t = document.querySelector("#onetrust-pc-sdk .ot-sel-all-chkbox"),
            o = t.cloneNode(!0),
            t = (P.removeChild(o.querySelector("#ot-selall-hostcntr")), P.removeChild(t.querySelector("#ot-selall-vencntr")), P.removeChild(t.querySelector("#ot-selall-licntr")), _.accordionEl.cloneNode(!0));
        t.classList.add("ot-iab-acc"), t.querySelector(".ot-acc-hdr").insertAdjacentElement("beforeEnd", e.cloneNode(!0)), t.querySelector(".ot-acc-hdr").insertAdjacentHTML("beforeEnd", v.getInnerHtmlContent("<div class='ot-vensec-title'>" + I.PCIABVendorsText + "</div>")), t.querySelector(".ot-acc-hdr").insertAdjacentElement("beforeEnd", o), t.querySelector(this.ACC_TXT).insertAdjacentElement("beforeEnd", T("#ot-ven-lst").el[0]), T("#ot-lst-cnt .ot-sdk-column").append(t), t.querySelector("button").setAttribute(this.ARIA_LABEL_ATTRIBUTE, I.PCIABVendorsText), this.iabAccInit = !0
    }, l.prototype.showConsentHeader = function() {
        var e = A.legIntSettings;
        T("#onetrust-pc-sdk .ot-sel-all-hdr").show(), e.PAllowLI && !e.PShowLegIntBtn || T("#onetrust-pc-sdk .ot-li-hdr").hide()
    }, l.prototype.setBackBtnTxt = function() {
        (m.isV2Template ? (T(k.P_Vendor_List + " .back-btn-handler").attr(this.ARIA_LABEL_ATTRIBUTE, I.PCenterBackText), T(k.P_Vendor_List + " .back-btn-handler title")) : T(k.P_Vendor_List + " .back-btn-handler .pc-back-button-text")).html(I.PCenterBackText)
    }, l.prototype.getCookieElement = function(e, t) {
        var o = L.hosts.hostCookieTemplate.cloneNode(!0),
            n = o.querySelector("div").cloneNode(!0),
            r = (n.classList.remove("cookie-name-container"), T(o).html(""), e.Name),
            i = (I.AddLinksToCookiepedia && t.isFirstParty && (r = h.getCookieLabel(e, I.AddLinksToCookiepedia)), n.cloneNode(!0));
        return i.classList.add(k.P_c_Name), i.querySelector(this.NTH_CHILD_ONE_SELECTOR).innerHTML = v.getInnerHtmlContent(I.pcCListName), i.querySelector(this.NTH_CHILD_TWO_SELECTOR).innerHTML = v.getInnerHtmlContent(r), T(o).append(i), I.pcShowCookieHost && ((r = n.cloneNode(!0)).classList.add(k.P_c_Host), r.querySelector(this.NTH_CHILD_ONE_SELECTOR).innerHTML = v.getInnerHtmlContent(I.pcCListHost), r.querySelector(this.NTH_CHILD_TWO_SELECTOR).innerHTML = v.getInnerHtmlContent(e.Host), T(o).append(r)), I.pcShowCookieDuration && ((i = n.cloneNode(!0)).classList.add(k.P_c_Duration), i.querySelector(this.NTH_CHILD_ONE_SELECTOR).innerHTML = v.getInnerHtmlContent(I.pcCListDuration), i.querySelector(this.NTH_CHILD_TWO_SELECTOR).innerHTML = v.getInnerHtmlContent(e.IsSession ? I.LifespanTypeText : h.getDuration(e)), T(o).append(i)), I.pcShowCookieType && (r = t.Type === he.GenVendor ? !e.isThirdParty : t.isFirstParty, (i = n.cloneNode(!0)).classList.add(k.P_c_Type), i.querySelector(this.NTH_CHILD_ONE_SELECTOR).innerHTML = v.getInnerHtmlContent(I.pcCListType), i.querySelector(this.NTH_CHILD_TWO_SELECTOR).innerHTML = v.getInnerHtmlContent(r ? I.firstPartyTxt : I.thirdPartyTxt), T(o).append(i)), I.pcShowCookieCategory && (r = void 0, r = t.Type === he.GenVendor ? e.category : (t.isFirstParty ? e : t).groupName) && ((i = n.cloneNode(!0)).classList.add(k.P_c_Category), i.querySelector(this.NTH_CHILD_ONE_SELECTOR).innerHTML = v.getInnerHtmlContent(I.pcCListCategory), i.querySelector(this.NTH_CHILD_TWO_SELECTOR).innerHTML = v.getInnerHtmlContent(r), T(o).append(i)), I.pcShowCookieDescription && e.description && ((t = n.cloneNode(!0)).classList.add(k.P_c_Desc), t.querySelector(this.NTH_CHILD_ONE_SELECTOR).innerHTML = v.getInnerHtmlContent(I.pcCListDescription), t.querySelector(this.NTH_CHILD_TWO_SELECTOR).innerHTML = v.getInnerHtmlContent(e.description), T(o).append(t)), o
    }, l.prototype.getNoResultsFound = function(e) {
        e = L.showTrackingTech ? I.PCTechNotFound : e ? I.PCHostNotFound : I.PCVendorNotFound;
        return " " + e + "."
    }, l.prototype.getAdditionalTechnologiesHtml = function(e) {
        var t = document.createDocumentFragment(),
            o = I.AdditionalTechnologiesConfig,
            n = 0 < e.Cookies.length;
        return (n = n && e.Cookies[0].HostId === this.FIRST_PARTY_COOKIES_GROUP_NAME ? 0 < e.Cookies[0].Cookies.length : n) && ((n = w.getMainAccordionContainer(o.PCCookiesLabel, o.PCCookiesLabel, !1)).classList.add(this.TECH_COOKIES_SELECTOR), t.appendChild(n)), 0 < e.LocalStorages.length && ((n = w.getMainAccordionContainer(o.PCLocalStorageLabel, o.PCLocalStorageLabel)).classList.add("tech-local"), w.setSessionLocalStorageTemplate(n, e.LocalStorages, I.AdditionalTechnologiesConfig.PCLocalStorageDurationText), t.appendChild(n)), 0 < e.SessionStorages.length && ((n = w.getMainAccordionContainer(o.PCSessionStorageLabel, o.PCSessionStorageDurationText)).classList.add("tech-session"), w.setSessionLocalStorageTemplate(n, e.SessionStorages, I.AdditionalTechnologiesConfig.PCSessionStorageDurationText), t.appendChild(n)), t
    }, l.prototype.getMainAccordionContainer = function(e, t, o) {
        void 0 === o && (o = !0);
        var n = w.getAccordionStyleElement(),
            r = _.accordionEl.cloneNode(!0);
        return r.classList.add("ot-add-tech"), r.querySelector(".ot-acc-hdr").insertAdjacentElement("beforeEnd", n), r.querySelector(".ot-acc-hdr").insertAdjacentHTML("beforeEnd", "<div class='ot-vensec-title'>" + e + "</div>"), r.querySelector("button").setAttribute(this.ARIA_LABEL_ATTRIBUTE, t), o && r.querySelector(this.ACC_TXT).insertAdjacentHTML("beforeend", v.getInnerHtmlContent('<ul id="ot-host-lst" style="display: block;"></ul>')), r.cloneNode(!0)
    }, l.prototype.setSessionLocalStorageTemplate = function(e, t, o) {
        var n = L.hosts.hostTemplate.cloneNode(!0),
            r = (P.removeChild(n.querySelector(".ot-a scc-txt")), e.querySelector(this.ACC_TXT + " " + k.P_Host_Cntr));
        r.removeAttribute("style"), r.classList.add("ot-host-opt");
        for (var i = 0, s = t; i < s.length; i++) {
            var a = s[i],
                a = w.getSessionLocalStorageElement(a, o);
            r.append(a)
        }
    }, l.prototype.getSessionLocalStorageElement = function(e, t) {
        var o = L.hosts.hostCookieTemplate.cloneNode(!0),
            n = o.querySelector("div").cloneNode(!0),
            r = (T(o).html(""), w.createKeyValueDivEle(n, k.P_c_Name, I.pcCListName, e.Name)),
            r = (T(o).append(r), w.createKeyValueDivEle(n, k.P_c_Host, I.pcCListHost, e.Host)),
            r = (T(o).append(r), w.createKeyValueDivEle(n, k.P_c_Duration, I.pcCListDuration, t)),
            t = (T(o).append(r), w.createKeyValueDivEle(n, k.P_c_Desc, I.pcCListDescription, e.description));
        return T(o).append(t), o
    }, l.prototype.createKeyValueDivEle = function(e, t, o, n) {
        e = e.cloneNode(!0);
        return e.classList.add(t), e.querySelector(this.NTH_CHILD_ONE_SELECTOR).innerHTML = v.getInnerHtmlContent(o), e.querySelector(this.NTH_CHILD_TWO_SELECTOR).innerHTML = v.getInnerHtmlContent(n), e
    }, l.prototype.getAdditionalTechnologiesDataFromGroup = function(e) {
        for (var t, o = [], n = {
                SessionStorages: [],
                LocalStorages: [],
                Cookies: []
            }, r = 0, i = w.getGroupsFromFilter(e); r < i.length; r++) {
            var s = i[r],
                a = Sn.getCookiesForGroup(s),
                o = U(o, null != (t = a.firstPartyCookiesList) ? t : []);
            n.Cookies = U(n.Cookies, a.thirdPartyCookiesList), n.LocalStorages = U(n.LocalStorages, null != (a = null == (t = s.TrackingTech) ? void 0 : t.LocalStorages) ? a : []), n.SessionStorages = U(n.SessionStorages, null != (a = null == (t = s.TrackingTech) ? void 0 : t.SessionStorages) ? a : [])
        }
        return o.length && n.Cookies.unshift({
            HostName: I.PCFirstPartyCookieListText,
            DisplayName: I.PCFirstPartyCookieListText,
            HostId: this.FIRST_PARTY_COOKIES_GROUP_NAME,
            isFirstParty: !0,
            Cookies: o,
            Description: ""
        }), n
    }, l.prototype.getFirstsAndThirdCookisFromGroups = function(e) {
        var t = [],
            o = [];
        return w.getGroupsFromFilter(e).forEach(function(e) {
            e = Sn.getCookiesForGroup(e);
            t = U(t, e.firstPartyCookiesList), o = U(o, e.thirdPartyCookiesList)
        }), {
            firstPartyCookiesList: t,
            thirdPartyCookiesList: o
        }
    }, l.prototype.getGroupsFromFilter = function(t) {
        var o = [];
        return I.Groups.forEach(function(e) {
            U(e.SubGroups, [e]).forEach(function(e) {
                (!t || !t.length || -1 !== t.indexOf(e.CustomGroupId)) && o.push(e)
            })
        }), o
    }, l.prototype.getAccordionStyleElement = function() {
        return (I.PCAccordionStyle === ce.Caret ? _.arrowEl : _.plusMinusEl).cloneNode(!0)
    }, l.prototype.getFilteredAdditionaTechtData = function(e, t) {
        var o, n = {
                SessionStorages: [],
                LocalStorages: [],
                Cookies: []
            },
            r = this.getSearchQuery(e),
            e = JSON.parse(JSON.stringify(t));
        return e.Cookies[0].HostId === this.FIRST_PARTY_COOKIES_GROUP_NAME && ((o = e.Cookies.shift()).Cookies = null == (t = o.Cookies) ? void 0 : t.filter(function(e) {
            return r.lastIndex = 0, r.test(e.Name || e.Host)
        })), n.Cookies = null == (t = e.Cookies) ? void 0 : t.filter(function(e) {
            return r.lastIndex = 0, r.test(e.DisplayName || e.HostName)
        }), o && 0 < o.Cookies.length && n.Cookies.unshift(o), n.LocalStorages = null == (t = e.LocalStorages) ? void 0 : t.filter(function(e) {
            return r.lastIndex = 0, r.test(e.Name || e.Host)
        }), n.SessionStorages = null == (o = e.SessionStorages) ? void 0 : o.filter(function(e) {
            return r.lastIndex = 0, r.test(e.Name || e.Host)
        }), n
    }, l.prototype.checkIfLegLinkRemove = function(e) {
        A.isTcfV2Template && e.querySelector(k.P_Ven_Leg_Claim).remove()
    };
    var w, Ps = l;

    function l() {
        this.hasIabVendors = !1, this.hasGoogleVendors = !1, this.hasGenVendors = !1, this.iabAccInit = !1, this._displayNull = "display: '';", this.ARIA_LABEL_ATTRIBUTE = "aria-label", this.TECH_COOKIES_SELECTOR = "tech-cookies", this.FIRST_PARTY_COOKIES_GROUP_NAME = "first-party-cookies-group", this.LABEL_STATUS = ".ot-label-status", this.CONSENT_CATEGORY = ".consent-category", this.ACC_TXT = ".ot-acc-txt", this.NTH_CHILD_ONE_SELECTOR = "div:nth-child(1)", this.NTH_CHILD_TWO_SELECTOR = "div:nth-child(2)", this.LINE_THROUGH_CLASS = "line-through", this.googleSearchSelectors = {
            vendorAccBtn: "#ot-addtl-venlst #Adtl-IAB",
            name: "name",
            accId: ".ot-adtlv-acc",
            selectAllEvntHndlr: "#ot-selall-adtlven-handler",
            venListId: "#ot-addtl-venlst",
            ctgl: ".ot-ven-adtlctgl"
        }, this.genVendorSearchSelectors = {
            vendorAccBtn: "#ot-gn-venlst #Gn-",
            name: "Name",
            accId: ".ot-gv-acc",
            selectAllEvntHndlr: "#ot-selall-gnven-handler",
            venListId: "#ot-gn-venlst",
            ctgl: ".ot-ven-gvctgl"
        }
    }
    As.prototype.initBanner = function() {
        this.canImpliedConsentLandingPage(), m.moduleInitializer.CookieSPAEnabled ? T(window).on("otloadbanner", this.windowLoadBanner.bind(this)) : T(window).one("otloadbanner", this.windowLoadBanner.bind(this))
    }, As.prototype.insertCSBtnHtmlAndCss = function(e) {
        var t = document.getElementById("onetrust-style"),
            t = (t.innerHTML = v.getInnerHtmlContent(t.innerHTML + N.csBtnGroup.css), document.createElement("div")),
            t = (T(t).html(N.csBtnGroup.html), t.querySelector("#ot-sdk-btn-floating"));
        e && t && T(t).removeClass("ot-hide"), T("#onetrust-consent-sdk").append(t), I.cookiePersistentLogo && (I.cookiePersistentLogo.includes("ot_guard_logo.svg") ? this.applyPersistentSvgOnDOM() : T(".ot-floating-button__front, .ot-floating-button__back").addClass("custom-persistent-icon"))
    }, As.prototype.applyPersistentSvgOnDOM = function() {
        return F(this, void 0, void 0, function() {
            var t;
            return M(this, function(e) {
                switch (e.label) {
                    case 0:
                        return [4, xt.getPersistentCookieSvg()];
                    case 1:
                        return t = e.sent(), T(this.FLOATING_COOKIE_FRONT_BTN).html(t), D.otGuardLogoResolve(!0), [2]
                }
            })
        })
    }, As.prototype.canImpliedConsentLandingPage = function() {
        this.isImpliedConsent() && !vo.isLandingPage() && "true" === g.readCookieParam(C.OPTANON_CONSENT, u.AWAITING_RE_CONSENT) && this.checkForRefreshCloseImplied()
    }, As.prototype.isImpliedConsent = function() {
        return I.ConsentModel && "implied consent" === I.ConsentModel.Name.toLowerCase() || 0 < A.consentableImpliedConsentGroup.length
    }, As.prototype.checkForRefreshCloseImplied = function() {
        O.bannerCloseButtonHandler(!0)
    }, As.prototype.hideCustomHtml = function() {
        var e = document.getElementById("onetrust-banner-sdk");
        e && d(e, "display: none;")
    }, As.prototype.shouldShowBanner = function(e) {
        return I.ShowAlertNotice && !e && !I.NoBanner && !L.hideBanner
    }, As.prototype.shouldShowPc = function(e) {
        return I.ShowAlertNotice && !e && I.NoBanner
    }, As.prototype.windowLoadBanner = function() {
        return F(this, void 0, void 0, function() {
            var t, o, n, r, i;
            return M(this, function(e) {
                switch (e.label) {
                    case 0:
                        return (this.core.substitutePlainTextScriptTags(), t = m.moduleInitializer, T("#onetrust-consent-sdk").length ? o = document.getElementById("onetrust-consent-sdk") : (o = document.createElement("div"), T(o).attr("id", "onetrust-consent-sdk"), T(o).attr("data-nosnippet", "true"), T(document.body).append(o)), T(".onetrust-pc-dark-filter").length || (n = document.createElement("div"), T(n).attr("class", "onetrust-pc-dark-filter"), T(n).attr("class", "ot-hide"), T(n).attr("class", "ot-fade-in"), o.firstChild ? o.insertBefore(n, o.firstChild) : T(o).append(n)), I.IsIabEnabled && this.iab.updateIabVariableReference(), n = p.isAlertBoxClosedAndValid(), r = this.shouldShowBanner(n), i = this.shouldShowPc(n), L.ntfyRequired ? (this.hideCustomHtml(), Tn.init(), Tn.changeState()) : (r ? D.initializeAlartHtmlAndHandler() : (I.IsGPPEnabled && ps.setCmpDisplayStatus("disabled"), this.hideCustomHtml()), D.addEventListnerForVendorsList()), t.IsSuppressPC || (V.insertPcHtml(), D.initialiseConsentNoticeHandlers(), I.IsIabEnabled && this.iab.InitializeVendorList()), this.prepopulateCookieOrVendorPageTitle(), this.initializeHbbTvScript(), this.insertCSBtn(!r), i) ? [4, D.toggleInfoDisplay()] : [3, 2];
                    case 1:
                        e.sent(), e.label = 2;
                    case 2:
                        return D.insertCookieSettingText(), this.initializeFloatingButtonOnBannerLoad(i), ks.insertTrackigTechOrCookiePolicy(), O.executeOptanonWrapper(), this.initializeCookieParamsOnBannerLoad(r), [2]
                }
            })
        })
    }, As.prototype.prepopulateCookieOrVendorPageTitle = function() {
        m.isV2Template && (I.GeneralVendorsEnabled ? this.iab.setListSearchValues(_e.vendors) : this.iab.setListSearchValues(_e.cookies))
    }, As.prototype.initializeFloatingButtonOnBannerLoad = function(e) {
        var t = T(this.FLOATING_COOKIE_BTN),
            o = T(this.FLOATING_COOKIE_FRONT_BTN),
            n = T(this.FLOATING_COOKIE_BACK_BTN);
        t.length && (t.attr("data-title", I.CookieSettingButtonText), o.el[0].setAttribute(Ct, I.CookieSettingButtonText), n.el[0].setAttribute(Ct, I.AriaClosePreferences), e ? (o.el[0].setAttribute(gt, !0), o.el[0].style.display = "none") : (n.el[0].setAttribute(gt, !0), n.el[0].style.display = "none"))
    }, As.prototype.initializeCookieParamsOnBannerLoad = function(e) {
        g.readCookieParam(C.OPTANON_CONSENT, uo) || co.writeGrpParam(C.OPTANON_CONSENT), g.readCookieParam(C.OPTANON_CONSENT, po) || co.writeHstParam(C.OPTANON_CONSENT), L.showGeneralVendors && !g.readCookieParam(C.OPTANON_CONSENT, Co) && co.writeGenVenCookieParam(C.OPTANON_CONSENT), L.vsIsActiveAndOptOut && !g.readCookieParam(C.OPTANON_CONSENT, go) && co.writeVSConsentCookieParam(C.OPTANON_CONSENT), e && Io.setBannerFocus()
    }, As.prototype.initializeHbbTvScript = function() {
        var e;
        m.moduleInitializer.RemoteActionsEnabled && ((e = document.getElementById("hbbtv")) && e.remove(), (e = document.createElement("script")).id = "hbbtv", e.src = L.storageBaseURL + "/scripttemplates/" + m.moduleInitializer.Version + "/hbbtv.js", e.type = "text/javascript", T(document.body).append(e))
    }, As.prototype.insertCSBtn = function(e) {
        N.csBtnGroup && (this.insertCSBtnHtmlAndCss(e), D.initFlgtCkStgBtnEventHandlers())
    }, As.prototype.insertTrackingTechnologies = function() {
        var e;
        T("#ot-sdk-cookie-policy, #optanon-cookie-policy").length && (window.OnetrustCookiePolicy && window.OnetrustCookiePolicy.InsertCookiePolicyHtml ? window.OnetrustCookiePolicy.InsertCookiePolicyHtml(h, I, T) : ((e = document.createElement("script")).id = "cookie-policy-script", e.onload = function() {
            return window.OnetrustCookiePolicy.InsertCookiePolicyHtml(h, I, T)
        }, e.type = "text/javascript", e.src = L.storageBaseURL + "/scripttemplates/" + m.moduleInitializer.Version + "/trackingTechnologies.js", document.head.appendChild(e)))
    }, As.prototype.insertTrackigTechOrCookiePolicy = function() {
        m.fp.CookieV2TrackingTechnologies ? ks.insertTrackingTechnologies() : cr.insertCookiePolicyHtml()
    };
    var ks, bs = As;

    function As() {
        this.iab = w, this.core = Sn, this.FLOATING_COOKIE_BTN = "#ot-sdk-btn-floating", this.FLOATING_COOKIE_FRONT_BTN = "#ot-sdk-btn-floating .ot-floating-button__front .ot-floating-button__open", this.FLOATING_COOKIE_BACK_BTN = "#ot-sdk-btn-floating .ot-floating-button__back .ot-floating-button__close"
    }
    x(Es, Is = Cr), Es.prototype.Close = function(e) {
        O.closeBanner(!1), window.location.href = "http://otsdk//consentChanged"
    }, Es.prototype.RejectAll = function(e) {
        O.rejectAllEvent(), window.location.href = "http://otsdk//consentChanged"
    }, Es.prototype.AllowAll = function(e) {
        O.AllowAllV2(e), window.location.href = "http://otsdk//consentChanged"
    }, Es.prototype.ToggleInfoDisplay = function() {
        D.toggleInfoDisplay()
    };
    var Is, Ls, _s = Es;

    function Es() {
        var e = null !== Is && Is.apply(this, arguments) || this;
        return e.mobileOnlineURL = A.mobileOnlineURL, e
    }
    Ds.prototype.syncConsentProfile = function(t, e, o) {
        void 0 === o && (o = !1), t ? L.dsParams.id = t.trim() : t = L.dsParams.id, o && (L.dsParams.isAnonymous = o), e = e || L.dsParams.token, t && e && xt.getConsentProfile(t, e).then(function(e) {
            return Os.consentProfileCallback(e, t)
        })
    }, Ds.prototype.checkCarryOverAnonConsentForIAB = function() {
        var e, t, o, n, r, i;
        return null != (r = A.consentableIabGrps) && r.length && A.checkLocalConsentForIabPurposes ? (r = !1, t = (e = L.consentPreferences) && 0 < e.preferences.length, A.carryOverAnonymousConsent ? (o = (n = this.checkLatestConsentDate(A.serverLatestDateForCookies)).consentedDate, n = n.isLocalConsentLatest) : (n = !1, i = this.getLastesConsentDateFromIabConsent(), A.serverLatestDateForCookies > (o = i) && (o = A.serverLatestDateForCookies)), this.checkIfServerConsent(t, n) && (g.writeCookieParam(C.OPTANON_CONSENT, u.PREV_USER_CONSENT, ""), r = !0, i = e.syncGroups[L.syncGrpId]) && (i.tcStringV2 && (L.isIabSynced = !0, L.syncRequired = !0, g.setCookie(C.EU_PUB_CONSENT, i.tcStringV2, I.ReconsentFrequencyDays, !1, new Date(o))), i.gacString) && (L.isGacSynced = !0, L.syncRequired = !0, g.setCookie(C.ADDITIONAL_CONSENT_STRING, i.gacString, I.ReconsentFrequencyDays, !1, new Date(o))), this.forceConsentReceipt(t, n), {
            iabSyncRequired: r,
            latestConsentDate: o
        }) : {
            iabSyncRequired: !1,
            latestConsentDate: new Date(0)
        }
    }, Ds.prototype.syncPreferences = function(e, t) {
        void 0 === t && (t = !1);
        var o = g.getCookie(C.ALERT_BOX_CLOSED),
            n = o,
            r = !1,
            i = !0,
            s = !1,
            a = !1,
            l = P.strToArr(g.readCookieParam(C.OPTANON_CONSENT, "groups"));
        if (e && e.preferences.length) {
            this.checkIfConsentIsGiven(e);
            for (var c = void 0, d = 0, u = e.preferences; d < u.length; d++) {
                var p = u[d],
                    p = this.syncGroupWithPreferences(p, l, n, s, t),
                    r = r || p.syncRequired,
                    s = s || p.syncOnlyDate,
                    a = a || p.isLocalConsentLatest;
                (!c || new Date(p.latestConsentDate) > new Date(c)) && (c = p.latestConsentDate)
            }
            o = c
        } else i = !1;
        return this.forceConsentReceipt(i, a), {
            alertBoxCookieVal: o,
            groupsConsent: l,
            profileFound: i,
            syncRequired: r,
            syncOnlyDate: s = s && !r
        }
    }, Ds.prototype.checkIfConsentIsGiven = function(e) {
        for (var t = 0, o = e.preferences; t < o.length; t++) {
            var n = o[t],
                r = A.domainGrps[n.id];
            r && this.isCookieGroup(r) && (A.consentGiven = A.consentGiven || n.status !== H[H.NO_CONSENT] && n.status !== H[H.ALWAYS_ACTIVE])
        }
    }, Ds.prototype.syncGroupWithPreferences = function(e, t, o, n, r) {
        var i, s = !1,
            a = e.status === H[H.NO_CONSENT],
            l = A.domainGrps[e.id],
            c = !1;
        if (l && this.isCookieGroup(l)) {
            i = o, -1 < L.grpsSynced.indexOf(l) && (L.syncedValidGrp = !0);
            var d = A.carryOverAnonymousConsent,
                o = new Date(e.lastInteractionDate) > new Date(o),
                s = !o;
            if (!d && A.consentGiven || d && o)
                if (a) {
                    if (t.length) {
                        for (var u = -1, p = 0; p < t.length; p++)
                            if (t[p].split(":")[0] === l) {
                                u = p;
                                break
                            } - 1 < u && (t.splice(u, 1), L.grpsSynced.push(l))
                    }
                } else {
                    d = this.getConsentValue(e.status);
                    n = !0, i = e.lastInteractionDate, c = this.updateCookieCatConsent(r, l, d, t)
                }
        }
        return {
            syncRequired: c,
            syncOnlyDate: n,
            latestConsentDate: i,
            isLocalConsentLatest: s
        }
    }, Ds.prototype.updateCookieCatConsent = function(e, t, o, n) {
        var r = !1;
        if (!e) {
            for (var i = t + ":" + o, s = -1, a = 0; a < n.length; a++) {
                var l = n[a].split(":");
                if (l[0] === t) {
                    l[1] !== o && (n[a] = i, r = !0), s = a;
                    break
                }
            } - 1 === s && (n.push(i), r = !0)
        }
        return r
    }, Ds.prototype.getConsentValue = function(e) {
        var t = null;
        switch (e) {
            case H[H.ACTIVE]:
            case H[H.ALWAYS_ACTIVE]:
                t = ge.Active;
                break;
            case H[H.EXPIRED]:
            case H[H.OPT_OUT]:
            case H[H.PENDING]:
            case H[H.WITHDRAWN]:
                t = ge.InActive
        }
        return t
    }, Ds.prototype.isCookieGroup = function(e) {
        return !/IABV2|ISPV2|IFEV2|ISFV2|IAB2V2|IFE2V2|ISP2V2|ISF2V2/.test(e)
    }, Ds.prototype.hideBannerAndPc = function() {
        var e = h.isBannerVisible();
        e && h.hideBanner(), (e || L.isPCVisible) && (sn.removeAddedOTCssStyles(), pn.hideConsentNoticeV2())
    }, Ds.prototype.setOptanonConsentCookie = function(e, t) {
        var o;
        e.syncRequired && (g.writeCookieParam(C.OPTANON_CONSENT, "groups", e.groupsConsent.toString()), o = g.getCookie(C.OPTANON_CONSENT), g.setCookie(C.OPTANON_CONSENT, o, t, !1, new Date(e.alertBoxCookieVal)), g.writeCookieParam(C.OPTANON_CONSENT, u.PREV_USER_CONSENT, ""), g.writeCookieParam(C.OPTANON_CONSENT, u.IS_ANONYMOUS_CONSENT, "0"))
    }, Ds.prototype.setIabCookie = function(e, t, o, n) {
        var e = this.checkLatestConsentDate(new Date(e)),
            r = e.isLocalConsentLatest,
            e = e.consentedDate,
            n = n.syncGroups && n.syncGroups[L.syncGrpId],
            i = (null == (i = n) ? void 0 : i.tcStringV2) || (null == (i = n) ? void 0 : i.gacString);
        this.checkIfServerConsent(!!i, r) ? (t.syncRequired = !0, t.profileFound = !0, t.alertBoxCookieVal = e.toISOString(), n.tcStringV2 && g.setCookie(C.EU_PUB_CONSENT, n.tcStringV2, o, !1, new Date(e)), n.gacString && g.setCookie(C.ADDITIONAL_CONSENT_STRING, n.gacString, o, !1, new Date(e))) : i || (t.profileFound = !1), this.forceConsentReceipt(t.profileFound, r)
    }, Ds.prototype.setAddtlVendorsCookie = function(e, t) {
        I.UseGoogleVendors && !g.getCookie(C.ADDITIONAL_CONSENT_STRING) && g.setCookie(C.ADDITIONAL_CONSENT_STRING, L.addtlConsentVersion, t, !1, new Date(e.alertBoxCookieVal))
    }, Ds.prototype.updateGrpsDom = function(s) {
        for (var e = 0, t = f.getAllGroupElements(); e < t.length; e++)(e => {
            var t, o = e.getAttribute("data-optanongroupid"),
                n = y.getGroupById(o),
                r = !0,
                i = P.findIndex(L.groupsConsent, function(e) {
                    return e.split(":")[0] === o
                });
            (-1 < i && L.groupsConsent[i].split(":")[1] === ge.InActive || I.IsIabEnabled && s && "COOKIE" !== n.Type && -1 < (t = s.preferences.findIndex(function(e) {
                return e.id === n.PurposeId.toLowerCase()
            })) && -1 === ["ACTIVE", "ALWAYS_ACTIVE"].findIndex(function(e) {
                return e === s.preferences[t].status
            })) && (r = !1), f.toggleGrpElements(e, n, r), f.toogleSubGroupElement(e, r, !1, !0), f.toogleSubGroupElement(e, r, !0, !0)
        })(t[e])
    }, Ds.prototype.updateVendorsDom = function() {
        I.IsIabEnabled && (w.updateIabVariableReference(), Nn.toggleVendorConsent(), A.legIntSettings.PAllowLI) && (A.legIntSettings.PShowLegIntBtn ? Nn.updateVendorLegBtns() : Nn.toggleVendorLi())
    }, Ds.prototype.consentProfileCallback = function(r, i) {
        return F(this, void 0, void 0, function() {
            var t, o, n;
            return M(this, function(e) {
                switch (e.label) {
                    case 0:
                        return this.checkIfKnownUsersAreLogged(r, i) ? [2] : (t = this.syncPreferences(r), L.consentPreferences = r, o = I.ReconsentFrequencyDays, n = p.isIABCrossConsentEnabled(), this.setOptanonConsentCookie(t, o), I.IsIabEnabled && !n && this.setIabCookie(t.alertBoxCookieVal, t, o, r), t.syncOnlyDate && (p.syncAlertBoxCookie(t.alertBoxCookieVal), p.syncCookieExpiry()), pr.setDataSubjectIdV2(i), t.syncRequired && t.profileFound ? (g.writeCookieParam(C.OPTANON_CONSENT, u.PREV_USER_CONSENT, ""), g.writeCookieParam(C.OPTANON_CONSENT, u.IS_ANONYMOUS_CONSENT, "0"), L.syncRequired = t.syncRequired, p.syncAlertBoxCookie(t.alertBoxCookieVal), this.setAddtlVendorsCookie(t, o), this.hideBannerAndPc(), O.closeOptanonAlertBox(), N.initGrpsAndHosts(), !n && I.NtfyConfig.ShowNtfy && p.isAlertBoxClosedAndValid() ? [4, Tn.getContent()] : [3, 2]) : [3, 3]);
                    case 1:
                        e.sent(), Tn.init(), Tn.changeState(), e.label = 2;
                    case 2:
                        return I.IsIabEnabled && (p.setIABCookieData(), N.initializeIabPurposeConsentOnReload(), no.populateVendorAndPurposeFromCookieData()), this.updateGrpsDom(r), this.updateVendorsDom(), vo.setLandingPathParam(u.NOT_LANDING_PAGE), Sn.substitutePlainTextScriptTags(), hn.updateGtmMacros(!0), O.executeOptanonWrapper(), [3, 4];
                    case 3:
                        t.profileFound && !A.forceCreateTrxLocalConsentIsGreater || !t.alertBoxCookieVal || this.createTrans(A.forceCreateTrxLocalConsentIsGreater), e.label = 4;
                    case 4:
                        return [2]
                }
            })
        })
    }, Ds.prototype.checkIfKnownUsersAreLogged = function(e, t) {
        var o = g.readCookieParam(C.OPTANON_CONSENT, u.CONSENT_ID),
            n = g.readCookieParam(C.OPTANON_CONSENT, u.PREV_USER_CONSENT),
            e = 0 < (null == (e = e.preferences) ? void 0 : e.length);
        return o !== t && !n && (g.removeAllCookies(), !e) && (D.initializeAlartHtmlAndHandler(), pr.setDataSubjectIdV2(t), !0)
    }, Ds.prototype.createTrans = function(e) {
        var t = g.readCookieParam(C.OPTANON_CONSENT, "iType");
        hs.createConsentTxn(!1, Ce[t], !1, !0, e)
    }, Ds.prototype.checkLatestConsentDate = function(e) {
        var t = g.getCookie(C.ALERT_BOX_CLOSED),
            t = t ? new Date(t) : new Date(0),
            o = this.getLastesConsentDateFromIabConsent();
        return t < o ? {
            isLocalConsentLatest: !1,
            consentedDate: o < e ? e : o
        } : t < e ? {
            isLocalConsentLatest: !1,
            consentedDate: e
        } : {
            isLocalConsentLatest: !0,
            consentedDate: t
        }
    }, Ds.prototype.getLastesConsentDateFromIabConsent = function() {
        var e = L.consentPreferences;
        if (!e) return new Date(0);
        for (var t = A.consentableIabGrps.reduce(function(e, t) {
                return e[t.PurposeId] = t, e
            }, {}), o = null, n = 0, r = e.preferences; n < r.length; n++) {
            var i = r[n];
            t[i.id.toUpperCase()] && (i = new Date(i.lastInteractionDate), !o || o < i) && (o = i)
        }
        return o
    }, Ds.prototype.checkIfServerConsent = function(e, t) {
        var o = A.carryOverAnonymousConsent;
        return !!(!o && e || o && e && !t)
    }, Ds.prototype.forceConsentReceipt = function(e, t) {
        var o = A.carryOverAnonymousConsent,
            n = g.readCookieParam(C.OPTANON_CONSENT, u.PREV_USER_CONSENT);
        A.forceCreateTrxLocalConsentIsGreater = A.forceCreateTrxLocalConsentIsGreater || !(!n || "" === n || "0" === n) && (!e || o && t)
    };
    var Os, Vs = Ds;

    function Ds() {}
    Gs.prototype.removeCookies = function() {
        g.removePreview(), g.removeOptanon(), g.removeAlertBox(), g.removeIab2(), g.removeAddtlStr(), g.removeVariant(), L.isPreview && Ns.setPreviewCookie(), L.urlParams.get("otreset") && L.urlParams.set("otreset", "false");
        var e = window.location.pathname + "?" + L.urlParams.toString() + window.location.hash;
        Ns.replaceHistory(e)
    }, Gs.prototype.setPreviewCookie = function() {
        var e = new Date,
            t = (e.setTime(e.getTime() + 864e5), L.geoFromUrl ? "&geo=" + L.geoFromUrl : ""),
            e = "expiry=" + e.toISOString() + t;
        g.setCookie(C.OT_PREVIEW, e, 1, !1)
    }, Gs.prototype.bindStopPreviewEvent = function() {
        (window.attachEvent || window.addEventListener)("message", function(e) {
            return Ns.onMessage(e)
        })
    }, Gs.prototype.replaceHistory = function(e) {
        history.pushState({}, "", e), location.reload()
    }, Gs.prototype.onMessage = function(e) {
        "string" == typeof e.data && e.data === Ns.CLEAR_COOKIES && (Ns.removeCookies(), e.source) && e.source.postMessage && e.source.postMessage(Ns.CLEARED_COOKIES, e.origin)
    };
    var Ns, ws, G = Gs;

    function Gs() {
        this.CLEAR_COOKIES = "CLEAR_OT_COOKIES", this.CLEARED_COOKIES = "CLEARED_OT_COOKIES"
    }
    Ge.initPolyfill(), g = new Et, h = new Ft, A = new Ut, Gt = new e, Ns = new G, (s = window.otStubData) && (m.moduleInitializer = s.domainData, m.fp = m.moduleInitializer.TenantFeatures, L.isAMP = s.isAmp, L.dataDomainId = s.domainId, L.isPreview = s.isPreview, L.urlParams = s.urlParams, L.isV2Stub = s.isV2Stub || !1, A.gtmUpdatedinStub = s.gtmUpdated, s.isReset ? Ns.removeCookies() : s.isPreview && Ns.setPreviewCookie(), s.isV2Stub && (A.landingPath = s.landingPathValue), A.setBannerScriptElement(s.stubElement), A.setRegionRule(s.regionRule), m.fp.CookieV2TargetedTemplates && (A.conditionalLogicEnabled = !(null == (ws = A.getRegionRule().Conditions) || !ws.length), A.conditionalLogicEnabled) && ((() => {
            for (var e = A.getRegionRule(), t = 0; t < e.Conditions.length; t++) try {
                if ((e => {
                        if (e) return e = window.atob(e), Function('"use strict"; return ' + e)()
                    })(e.Conditions[t].Expression)) return A.Condition = e.Conditions[t]
            } catch (e) {
                console.warn(e);
                continue
            }
            A.allConditionsFailed = !0
        })(), A.canUseConditionalLogic = !A.allConditionsFailed), L.userLocation = s.userLocation, L.crossOrigin = s.crossOrigin, A.bannerDataParentURL = s.bannerBaseDataURL, A.mobileOnlineURL = U(A.mobileOnlineURL, s.mobileOnlineURL), ws = A.getRegionRule(), A.multiVariantTestingEnabled = m.moduleInitializer.MultiVariantTestingEnabled && 0 < ws.Variants.length && h.isDateCurrent(ws.TestEndTime), A.otDataLayer = s.otDataLayer, L.grpsSynced = s.grpsSynced || [], L.isIabSynced = s.isIabSynced, L.isGacSynced = s.isGacSynced, L.syncRequired = s.isIabSynced || s.isGacSynced || s.grpsSynced && 0 < s.grpsSynced.length, L.consentPreferences = s.preferences, L.syncGrpId = s.syncGrpId, L.consentApi = s.consentApi, L.tenantId = s.tenantId, L.geoFromUrl = s.geoFromUrl, L.nonce = s.nonce, L.setAttributePolyfillIsActive = s.setAttributePolyfillIsActive, L.storageBaseURL = s.storageBaseURL, L.identifierType = s.identifierType, A.previewMode = s.previewMode, A.prevUserWasAnon = s.prevUserWasAnon, A.userHasProfile = s.userHasProfile, A.consentGiven = s.consentGiven, A.serverLatestDateForCookies = s.serverLatestDateForCookies, A.carryOverAnonymousConsent = s.domainData.AuthenticatedConsent, A.checkLocalConsentForIabPurposes = s.checkLocalConsentForIabPurposes, A.forceCreateTrxLocalConsentIsGreater = s.forceCreateTrxLocalConsentIsGreater, A.stubUrl = s.stubUrl, Gt.populateLangSwitcherPlhdr(), window.otStubData = {
            userLocation: L.userLocation
        }, window.OneTrustStub = null),
        function() {
            F(this, void 0, void 0, function() {
                var i, s, a, l;
                return M(this, function(e) {
                    switch (e.label) {
                        case 0:
                            return (y = new Jt, f = new on, eo = new to, w = new Ps, Sn = new mn, O = new Un, D = new ir, V = new $n, er = new tr, ks = new bs, m.fp.CookieV2TrackingTechnologies || (cr = new dr), Qt = new Zt, fo = new So, N = new vs, hn = new yn, sr = new ar, so = new ao, _ = new jt, Os = new Vs, Nn = new wn, xt = new Ht, Io = new en, pn = new Cn, E = new xn, Wn = new Yn, Xn = new Qn, c = new nr, m.moduleInitializer.MobileSDK ? Ls = new _s : pr = new Cr, no = new ro, n = g.getCookie(C.ALERT_BOX_CLOSED), r = g.getCookie(C.OPTANON_CONSENT), n && !r && g.removeAlertBox(), A.setGCMcallback(), l = A.getRegionRule(), l = (A.canUseConditionalLogic ? A.Condition : l).UseGoogleVendors, A.isIab2orv2Template = "IAB2" === A.getRegionRuleType() || "IAB2V2" === A.getRegionRuleType(), A.isTcfV2Template = "IAB2V2" === A.getRegionRuleType(), A.isIab2orv2Template) ? [4, Promise.all([xt.getLangJson(), xt.fetchGvlObj(), l ? xt.fetchGoogleVendors() : Promise.resolve(null), xt.loadCMP()])] : [3, 2];
                        case 1:
                            return l = e.sent(), i = l[0], s = l[1], a = l[2], L.gvlObj = s, L.addtlVendorsList = a ? a.vendors : null, [3, 4];
                        case 2:
                            return [4, xt.getLangJson()];
                        case 3:
                            i = e.sent(), e.label = 4;
                        case 4:
                            return i.DomainData.IsGPPEnabled ? [4, xt.loadGPP()] : [3, 6];
                        case 5:
                            e.sent(), ps = new Cs, e.label = 6;
                        case 6:
                            var t, o;
                            return function(c) {
                                var d;
                                F(this, void 0, void 0, function() {
                                    var l;
                                    return M(this, function(e) {
                                        switch (e.label) {
                                            case 0:
                                                window.OneTrust = window.Optanon = Object.assign({}, window.OneTrust, (e => {
                                                    var t, o = m.moduleInitializer.MobileSDK,
                                                        n = {
                                                            AllowAll: (t = o ? Ls : pr).AllowAll,
                                                            BlockGoogleAnalytics: t.BlockGoogleAnalytics,
                                                            Close: t.Close,
                                                            getCSS: t.getCSS,
                                                            GetDomainData: t.GetDomainData,
                                                            getGeolocationData: t.getGeolocationData,
                                                            getHTML: t.getHTML,
                                                            Init: t.Init,
                                                            InitializeBanner: t.InitializeBanner,
                                                            initializeCookiePolicyHtml: t.initCookiePolicyAndSettings,
                                                            InsertHtml: t.InsertHtml,
                                                            InsertScript: t.InsertScript,
                                                            IsAlertBoxClosed: t.IsAlertBoxClosed,
                                                            IsAlertBoxClosedAndValid: t.IsAlertBoxClosedAndValid,
                                                            LoadBanner: t.LoadBanner,
                                                            OnConsentChanged: so.OnConsentChanged,
                                                            ReconsentGroups: t.ReconsentGroups,
                                                            RejectAll: t.RejectAll,
                                                            SetAlertBoxClosed: t.SetAlertBoxClosed,
                                                            setGeoLocation: t.setGeoLocation,
                                                            ToggleInfoDisplay: t.ToggleInfoDisplay,
                                                            TriggerGoogleAnalyticsEvent: t.TriggerGoogleAnalyticsEvent,
                                                            useGeoLocationService: t.useGeoLocationService,
                                                            FetchAndDownloadPC: t.FetchAndDownloadPC,
                                                            changeLanguage: t.changeLang,
                                                            testLog: t.getTestLogData,
                                                            UpdateConsent: t.updateSingularConsent,
                                                            IsVendorServiceEnabled: t.vendorServiceEnabled,
                                                            UpdateGCM: t.updateGCM
                                                        };
                                                    return e.IsConsentLoggingEnabled && (n.getDataSubjectId = t.getDataSubjectId, n.setConsentProfile = t.setConsentProfile, n.setDataSubjectId = t.setDataSubjectIdV2, n.getDSDefaultIdentifier = t.getDSDefaultIdentifier, L.isV2Stub ? n.syncConsentProfile = Os.syncConsentProfile : n.SendReceipt = t.sendReceipt), o && (n.mobileOnlineURL = t.mobileOnlineURL, n.otCookieData = L.otCookieData), e.IsIabEnabled && (n.updateConsentFromCookies = so.updateConsentFromCookie, n.getPingRequest = no.getPingRequestForTcf, n.getVendorConsentsRequestV2 = no.getVendorConsentsRequestV2, n.showVendorsList = t.showVendorsList), n
                                                })(c.DomainData)), p.initializeBannerVariables(c), co = new ho, ko = new bo, hs = new ys, sn = new dn, vo = new To, jn = new Kn, Tn = new Vn;
                                                var t, o, n, r = window.OTExternalConsent,
                                                    i = (r && r.consentedDate && (r.groups || r.tcString || r.addtlString) && (console.info("Consent is being passed to SDK through OTExternalConsent and is accepted.", r), t = [], (a = r.groups.split(",")).forEach(function(e) {
                                                        e = e.split(":");
                                                        t.push({
                                                            lastInteractionDate: r.consentedDate,
                                                            status: "1" === e[1] ? H[H.ACTIVE] : H[H.OPT_OUT],
                                                            id: e[0]
                                                        }), L.grpsSynced.push(e[0])
                                                    }), L.consentPreferences = {
                                                        preferences: t,
                                                        syncGroups: null
                                                    }, L.syncRequired = !0, co.updateGroupsInCookie(C.OPTANON_CONSENT, a), g.setCookie(C.ALERT_BOX_CLOSED, r.consentedDate, 365), r.tcString && (L.isIabSynced = !0, g.setCookie(C.EU_PUB_CONSENT, r.tcString, 365)), r.addtlString) && (L.isGacSynced = !0, g.setCookie(C.ADDITIONAL_CONSENT_STRING, "" + r.addtlString, 365)), L.isPreview && (p.syncOtPreviewCookie(), Ns.bindStopPreviewEvent()), L.isV2Stub && (a = Os.syncPreferences(L.consentPreferences, !0), i = Os.checkCarryOverAnonConsentForIAB(), s = i.iabSyncRequired, i = i.latestConsentDate, s && (a.alertBoxCookieVal = i.toISOString()), a.syncRequired = a.syncRequired || s, L.syncRequired || a.syncRequired) && p.syncAlertBoxCookie(a.alertBoxCookieVal), p.syncCookieExpiry(), c),
                                                    s = window.OneTrust.dataSubjectParams || {},
                                                    s = ((L.dsParams = s).id && (o = s.identifierType || (null == (o = i.CommonData.ConsentIntegration) ? void 0 : o.DefaultIdentifier), pr.setDataSubjectIdV2(s.id, s.isAnonymous, o)), null == (o = s.identifierType) ? void 0 : o.trim());
                                                return L.isV2Stub && (o = void 0, n = null == (n = L.identifierType) ? void 0 : n.trim(), o = n || s || (null == (n = i.CommonData.ConsentIntegration) ? void 0 : n.DefaultIdentifier), g.writeCookieParam(C.OPTANON_CONSENT, u.IDENTIFIER_TYPE, o)), A.multiVariantTestingEnabled && A.selectedVariant && g.setCookie(C.SELECTED_VARIANT, A.selectedVariant.Id, I.ReconsentFrequencyDays), L.isV2Stub && null != (d = A.landingPath) && d.length && I.NextPageCloseBanner && g.writeCookieParam(C.OPTANON_CONSENT, "landingPath", A.landingPath), [4, no.initializeIABModule()];
                                            case 1:
                                                return e.sent(), window.OneTrust.Init(!0), c.DomainData.IsGPPEnabled && ps.initGppConsent(), [4, N.fetchAssets()];
                                            case 2:
                                                return (e.sent(), ks.initBanner(), so.assetResolve(!0), Qt.initialiseCssReferences(), l = p.isIABCrossConsentEnabled(), (L.syncedValidGrp || L.isIabSynced || L.isGacSynced) && !l && I.NtfyConfig.ShowNtfy && p.isAlertBoxClosedAndValid()) ? (L.ntfyRequired = !0, [4, Tn.getContent()]) : [3, 4];
                                            case 3:
                                                e.sent(), e.label = 4;
                                            case 4:
                                                return l || window.OneTrust.LoadBanner(), [2]
                                        }
                                        var a, s, i
                                    })
                                })
                            }(i), m.moduleInitializer.WebFormIntegrationEnabled && m.moduleInitializer.WebFormSrcUrl && (n = window.otStubData, r = document.createElement("script"), t = m.moduleInitializer.WebFormSrcUrl, r.type = "text/javascript", r.src = t, o = m.moduleInitializer.TenantGuid, m.moduleInitializer.ScriptType === Ue.TEST && (o += "-test"), r.setAttribute("dataId", o), r.setAttribute("worker", m.moduleInitializer.WebFormWorkerUrl), n.charset && r.setAttribute("charset", n.charset), n.crossOrigin && r.setAttribute("crossorigin", n.crossOrigin), document.querySelector('script[src="' + t + '"]') || document.getElementsByTagName("head")[0].appendChild(r)), [2]
                    }
                    var n, r
                })
            })
        }()
})();