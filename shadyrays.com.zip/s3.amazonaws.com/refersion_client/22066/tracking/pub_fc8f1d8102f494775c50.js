// Last edit: Mon, 08 Feb 21 19:04:22 -0500
_rfsn_tracker.load_settings({
    version: 2.0,
    base_url: '/',
    xdomains: [],
    verbose: false,
    is_loaded: true
})