function trackRules(e) {
    let t, i, n, o, a;
    for (let r = 0; r < e.length && (i = e[r].raw_condition, t = getAttributeFor(i), n = i.p, o = i.v[0].value, a = _px.evaluate(t, n, o), 0 != a); r++);
    return a
}

function verifyStore() {
    return fetch(atob(_px.verificationUrl), {
        method: "POST",
        headers: {
            "Content-Type": "application/json"
        },
        body: JSON.stringify({
            store_id: _px.storeId
        })
    }), !0
}

function getAttributeFor(e) {
    switch (e.a[0].name) {
        case "time_spent":
            return (Date.now() - localStorage._pxSessionStart) / 6e4;
        case "number_of_pages":
            return _px.getPageVisited().length;
        case "page_visited":
            return window.location.href
    }
}

function getImg(e, t) {
    let i = document.createElement("img"),
        n = {
            cid: "c013",
            evid: "4d746137-8d1d-465b-981b-f81f6382dec0",
            r: Date.now(),
            dmn: window.location.hostname,
            pn: window.location.pathname,
            qs: window.location.search,
            suu: 1,
            v1: t,
            v2: e
        };
    return i.width = "1", i.height = "1", i.border = "0", i.src = `https://aa.trkn.us/1/e/c.gif?${Object.keys(n).map((e=>`${e}=${n[e]}`)).join("&")}`, i.id = "_pxPixel4", i
}
window._px = window._px || [], _px.ipRetargetingTriggers = [{
    ruleset_id: "6qcq2e",
    rules: [{
        id: "1739556160",
        raw_condition: {
            a: {
                0: {
                    name: "number_of_pages"
                }
            },
            p: "gt",
            v: {
                0: {
                    value: "0"
                }
            }
        }
    }]
}], _px.storeId = "6cgTz", _px.verified = !0, _px.verificationUrl = "aHR0cHM6Ly9hcHAucG9zdHBpbG90LmNvbS9pcF9yZXRhcmdldGluZ192ZXJpZmljYXRpb24=", _px.cleanup = function() {
    if (localStorage.removeItem("_pxSessionStart"), localStorage.removeItem("_pxTimeBeforeUnload"), void 0 !== localStorage._pxPageVisited) {
        let e = JSON.parse(localStorage._pxPageVisited);
        delete e[_px.storeId], localStorage._pxPageVisited = JSON.stringify(e)
    }
}, _px.setStorePixelSent = function(e) {
    const t = localStorage._pxPixelSent;
    if (void 0 === t) {
        const t = {
            [_px.storeId]: {
                [e]: {
                    pixelSent: !0,
                    sentAt: Date.now()
                }
            }
        };
        localStorage._pxPixelSent = JSON.stringify(t)
    } else {
        let i = JSON.parse(t);
        void 0 === i[_px.storeId] ? i[_px.storeId] = {
            [e]: {
                pixelSent: !0,
                sentAt: Date.now()
            }
        } : i[_px.storeId][e] = {
            pixelSent: !0,
            sentAt: Date.now()
        }, localStorage._pxPixelSent = JSON.stringify(i)
    }
}, _px.hasStorePixelSet = function(e) {
    const t = localStorage._pxPixelSent;
    if (void 0 === t) return !1;
    let i = JSON.parse(t);
    const n = i[_px.storeId];
    if (void 0 === n || void 0 === n[e]) return !1;
    return !((Date.now() - n[e].sentAt) / 1e3 / 86400 > 30) || (delete i[_px.storeId][e], localStorage._pxPixelSent = JSON.stringify(i), !1)
}, _px.setPageVisited = function() {
    const e = localStorage._pxPageVisited,
        t = document.location.pathname;
    if (void 0 === e) {
        const e = {
            [_px.storeId]: [t]
        };
        localStorage._pxPageVisited = JSON.stringify(e)
    } else {
        let i = JSON.parse(e);
        void 0 === i[_px.storeId] ? i[_px.storeId] = [t] : -1 === i[_px.storeId].indexOf(t) && i[_px.storeId].push(t), localStorage._pxPageVisited = JSON.stringify(i)
    }
}, _px.getPageVisited = function() {
    const e = localStorage._pxPageVisited;
    if (void 0 === e) return [];
    const t = JSON.parse(e);
    return void 0 === t[_px.storeId] ? [] : t[_px.storeId]
}, _px.track = function() {
    let e;
    for (let t = 0; t < _px.ipRetargetingTriggers.length; t++) {
        const i = _px.ipRetargetingTriggers[t];
        e = trackRules(i.rules), e && (_px.hasStorePixelSet(i.ruleset_id) || _px.insertPixel(_px.storeId, i.ruleset_id))
    }
    return !!e || new Promise((function() {
        return setTimeout(_px.track, 6e4)
    }))
}, window.addEventListener("unload", (function() {
    localStorage._pxTimeBeforeUnload = Date.now()
})), _px.evaluate = function(e, t, i) {
    switch (t) {
        case "gt":
            return e > i;
        case "lt":
            return e < i;
        case "eq":
            return e === i;
        case "not_eq":
            return e !== i;
        case "cont":
            return e.match(i);
        case "not_cont":
            return !e.match(i);
        case "start":
            return e.startsWith(i);
        case "end":
            return e.endsWith(i)
    }
}, _px.insertPixel = function(e, t) {
    const i = getImg(e, t);
    return document.body.appendChild(i), _px.setStorePixelSent(t), console.log(`::# Ruleset ${t} matched.`), !0
}, _px.isUsaBased = function() {
    const e = Intl.DateTimeFormat().resolvedOptions().timeZone;
    return ["America/New_York", "America/Detroit", "America/Kentucky/Louisville", "America/Kentucky/Monticello", "America/Indiana/Indianapolis", "America/Indiana/Vincennes", "America/Indiana/Winamac", "America/Indiana/Marengo", "America/Indiana/Petersburg", "America/Indiana/Vevay", "America/Chicago", "America/Indiana/Tell_City", "America/Indiana/Knox", "America/Menominee", "America/North_Dakota/Center", "America/North_Dakota/New_Salem", "America/North_Dakota/Beulah", "America/Denver", "America/Boise", "America/Phoenix", "America/Los_Angeles", "America/Anchorage", "America/Juneau", "America/Sitka", "America/Metlakatla", "America/Yakutat", "America/Nome", "America/Adak", "Pacific/Honolulu"].includes(e)
}, _px.init = function() {
    if (console.log(`::# Loading ${window._px.storeId}.`), !window._px.isUsaBased()) return !1;
    if (0 == window._px.verified) return verifyStore(), !0;
    if (null != localStorage._pxTimeBeforeUnload) {
        (Date.now() - localStorage._pxTimeBeforeUnload) / 1e3 <= 10 ? localStorage.removeItem("_pxTimeBeforeUnload") : window._px.cleanup()
    }
    void 0 === localStorage._pxSessionStart && (localStorage._pxSessionStart = Date.now()), window._px.setPageVisited(), window._px.track(), console.log(`::# Loaded ruleset ${window._px.ipRetargetingTriggers.map((e=>e.ruleset_id))}.`)
}, "loading" === document.readyState ? (console.log("::# Adding event listener"), document.addEventListener("DOMContentLoaded", _px.init)) : (console.log("::# Running immediately"), _px.init());